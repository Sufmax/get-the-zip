import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { useEffect, useMemo, useRef } from "react";
import type { Group, InstancedMesh, PerspectiveCamera } from "three";
import { Color, Object3D } from "three";
import { audio } from "../game/audio";
import { createRace, makeResults, snapshotHud, stepRace } from "../game/physics";
import { buildTrack } from "../game/tracks";
import type { HudSnapshot, InputState, RaceResults, Settings } from "../game/types";
import { LowPolyCar } from "./LowPolyCar";
import { TrackWorld } from "./TrackWorld";

type Props = {
  carId: string;
  trackId: string;
  settings: Settings;
  paused: boolean;
  onHud: (h: HudSnapshot) => void;
  onFinish: (r: RaceResults) => void;
  inputRef: React.MutableRefObject<InputState>;
};

function CameraRig({
  getPlayer,
}: {
  getPlayer: () => { x: number; z: number; heading: number; speed: number; maxSpeed: number; boosting: boolean; shake: number };
}) {
  const { camera } = useThree();
  const look = useRef({ x: 0, y: 1, z: 0 });
  const boot = useRef(false);
  useFrame((_, dt) => {
    const p = getPlayer();
    const cam = camera as PerspectiveCamera;
    if (!boot.current) {
      boot.current = true;
      const dist = 8.2;
      cam.position.set(p.x - Math.sin(p.heading) * dist, 3.1, p.z - Math.cos(p.heading) * dist);
      look.current = { x: p.x + Math.sin(p.heading) * 10, y: 0.8, z: p.z + Math.cos(p.heading) * 10 };
      cam.lookAt(look.current.x, look.current.y, look.current.z);
    }
    const speedT = Math.min(1, Math.abs(p.speed) / Math.max(1, p.maxSpeed));
    const dist = 7.4 + speedT * 4.8 + (p.boosting ? 1.2 : 0);
    const height = 2.55 + speedT * 1.05;
    const lagH = p.heading;
    const tx = p.x - Math.sin(lagH) * dist;
    const tz = p.z - Math.cos(lagH) * dist;
    const ty = height + (p.shake ? (Math.random() - 0.5) * p.shake * 0.6 : 0);
    cam.position.x += (tx - cam.position.x) * Math.min(1, dt * 7.5);
    cam.position.y += (ty - cam.position.y) * Math.min(1, dt * 6);
    cam.position.z += (tz - cam.position.z) * Math.min(1, dt * 7.5);
    look.current.x += (p.x + Math.sin(p.heading) * (10 + speedT * 8) - look.current.x) * Math.min(1, dt * 8);
    look.current.y += (0.7 + speedT * 0.4 - look.current.y) * Math.min(1, dt * 5);
    look.current.z += (p.z + Math.cos(p.heading) * (10 + speedT * 8) - look.current.z) * Math.min(1, dt * 8);
    cam.lookAt(look.current.x, look.current.y, look.current.z);
    const fov = 64 + speedT * 20 + (p.boosting ? 7 : 0);
    cam.fov += (fov - cam.fov) * Math.min(1, dt * 4);
    cam.updateProjectionMatrix();
  });
  return null;
}

function LiveCar({
  index,
  getCar,
}: {
  index: number;
  getCar: (i: number) => {
    x: number;
    z: number;
    heading: number;
    def: import("../game/types").CarDef;
    wheelRot: number;
    steerVis: number;
    boosting: boolean;
    slip: number;
  };
}) {
  const ref = useRef<Group>(null);
  const c0 = getCar(index);
  useFrame(() => {
    const c = getCar(index);
    if (!ref.current) return;
    ref.current.position.set(c.x, 0, c.z);
    ref.current.rotation.y = c.heading;
  });
  return (
    <group ref={ref} position={[c0.x, 0, c0.z]} rotation={[0, c0.heading, 0]}>
      <LowPolyCar
        def={c0.def}
        live={() => {
          const c = getCar(index);
          return { wheelRot: c.wheelRot, steer: c.steerVis, boosting: c.boosting, slip: c.slip };
        }}
      />
    </group>
  );
}

function SpeedStreaks({ getIntensity }: { getIntensity: () => number }) {
  const mesh = useRef<InstancedMesh>(null);
  const data = useMemo(
    () =>
      Array.from({ length: 48 }, () => ({
        x: (Math.random() - 0.5) * 16,
        y: 0.3 + Math.random() * 5,
        z: -2 - Math.random() * 22,
        s: 0.6 + Math.random() * 1.8,
        v: 28 + Math.random() * 50,
      })),
    [],
  );
  const dummy = useMemo(() => new Object3D(), []);
  useFrame((state, dt) => {
    if (!mesh.current) return;
    const k = getIntensity();
    mesh.current.visible = k > 0.18;
    if (k <= 0.18) return;
    const cam = state.camera;
    for (let i = 0; i < data.length; i++) {
      const d = data[i];
      d.z += d.v * dt * (0.6 + k * 1.6);
      if (d.z > 4) {
        d.z = -8 - Math.random() * 20;
        d.x = (Math.random() - 0.5) * 16;
        d.y = 0.2 + Math.random() * 5;
      }
      dummy.position.copy(cam.position);
      dummy.quaternion.copy(cam.quaternion);
      dummy.translateX(d.x);
      dummy.translateY(d.y);
      dummy.translateZ(d.z);
      dummy.scale.set(0.03, 0.03, d.s * (0.8 + k * 2.2));
      dummy.updateMatrix();
      mesh.current.setMatrixAt(i, dummy.matrix);
    }
    mesh.current.instanceMatrix.needsUpdate = true;
  });
  return (
    <instancedMesh ref={mesh} args={[undefined, undefined, data.length]}>
      <boxGeometry args={[1, 1, 1]} />
      <meshBasicMaterial color="#ffffff" transparent opacity={0.35} />
    </instancedMesh>
  );
}

function Smoke({ getCars }: { getCars: () => { x: number; z: number; heading: number; slip: number; speed: number }[] }) {
  const mesh = useRef<InstancedMesh>(null);
  const parts = useRef(
    Array.from({ length: 80 }, () => ({ x: 0, y: 0, z: 0, life: 0, vx: 0, vz: 0, s: 0.4 })),
  );
  const dummy = useMemo(() => new Object3D(), []);
  const spawn = useRef(0);
  useFrame((_, dt) => {
    if (!mesh.current) return;
    spawn.current += dt;
    const cars = getCars();
    if (spawn.current > 0.04) {
      spawn.current = 0;
      for (const c of cars) {
        if (Math.abs(c.slip) < 0.22 || c.speed < 12) continue;
        const slot = parts.current.find((p) => p.life <= 0);
        if (!slot) continue;
        const back = -1.4;
        slot.x = c.x - Math.sin(c.heading) * back + (Math.random() - 0.5) * 1.2;
        slot.z = c.z - Math.cos(c.heading) * back + (Math.random() - 0.5) * 1.2;
        slot.y = 0.25;
        slot.life = 0.45 + Math.random() * 0.3;
        slot.vx = (Math.random() - 0.5) * 1.5;
        slot.vz = (Math.random() - 0.5) * 1.5;
        slot.s = 0.35;
      }
    }
    for (let i = 0; i < parts.current.length; i++) {
      const p = parts.current[i];
      if (p.life > 0) {
        p.life -= dt;
        p.x += p.vx * dt;
        p.z += p.vz * dt;
        p.y += dt * 0.6;
        p.s += dt * 1.2;
        dummy.position.set(p.x, p.y, p.z);
        dummy.scale.setScalar(p.s);
      } else {
        dummy.position.set(0, -10, 0);
        dummy.scale.setScalar(0.01);
      }
      dummy.updateMatrix();
      mesh.current.setMatrixAt(i, dummy.matrix);
    }
    mesh.current.instanceMatrix.needsUpdate = true;
  });
  return (
    <instancedMesh ref={mesh} args={[undefined, undefined, 80]}>
      <sphereGeometry args={[0.5, 5, 4]} />
      <meshBasicMaterial color="#d8d8d8" transparent opacity={0.28} />
    </instancedMesh>
  );
}

function Loop({
  carId,
  trackId,
  settings,
  paused,
  onHud,
  onFinish,
  inputRef,
}: Props) {
  const track = useMemo(() => buildTrack(trackId), [trackId]);
  const game = useRef(createRace(track, carId));
  const hudAcc = useRef(0);
  const lastBeep = useRef(4);
  const finishedOnce = useRef(false);
  const lastCrash = useRef(0);

  useEffect(() => {
    game.current = createRace(track, carId);
    finishedOnce.current = false;
    lastBeep.current = 4;
  }, [track, carId]);

  useFrame((state, delta) => {
    if (paused) return;
    const dt = Math.min(delta, 0.05);
    const g = game.current;
    const prevPhase = g.phase;
    stepRace(g, inputRef.current, track, dt, settings.autoAccel);

    if (g.phase === "countdown") {
      const n = Math.ceil(g.countdown);
      if (n !== lastBeep.current && n <= 3) {
        lastBeep.current = n;
        audio.countdown(n);
        if (settings.vibration) navigator.vibrate?.(n <= 0 ? 40 : 20);
      }
    }
    if (prevPhase === "countdown" && g.phase === "racing") {
      audio.countdown(0);
      if (settings.vibration) navigator.vibrate?.(50);
    }

    const p = g.cars[g.playerIndex];
    if (p.shake > 0.45 && state.clock.elapsedTime - lastCrash.current > 0.35) {
      lastCrash.current = state.clock.elapsedTime;
      audio.crash();
      if (settings.vibration) navigator.vibrate?.(30);
    }

    const speedT = Math.min(1, Math.abs(p.speed) / p.def.maxSpeed);
    audio.engineAt(speedT, p.boosting, g.phase !== "countdown");

    hudAcc.current += dt;
    if (hudAcc.current > 0.08) {
      hudAcc.current = 0;
      onHud(snapshotHud(g, track));
    }

    if (g.phase === "finished" && !finishedOnce.current) {
      finishedOnce.current = true;
      audio.finish();
      onFinish(makeResults(g));
    }
  });

  const getPlayer = () => {
    const p = game.current.cars[game.current.playerIndex];
    return {
      x: p.x,
      z: p.z,
      heading: p.heading,
      speed: p.speed,
      maxSpeed: p.def.maxSpeed,
      boosting: p.boosting,
      shake: p.shake,
    };
  };

  return (
    <>
      <color attach="background" args={[track.fog]} />
      <fog attach="fog" args={[new Color(track.fog), 80, track.theme === "forest" ? 220 : 420]} />
      <hemisphereLight args={[track.skyTop, track.ground, track.ambient]} />
      <directionalLight
        position={[40, 70, 20]}
        intensity={track.sun}
        color={track.sunColor}
        castShadow={false}
      />
      {track.theme === "city" && (
        <>
          <pointLight position={[0, 12, 0]} intensity={0.6} color="#ff4ad8" distance={80} />
          <ambientLight intensity={0.18} />
        </>
      )}
      <TrackWorld track={track} quality={settings.quality} />
      {game.current.cars.map((c, i) => (
        <LiveCar key={c.id} index={i} getCar={(idx) => game.current.cars[idx]} />
      ))}
      <CameraRig getPlayer={getPlayer} />
      <SpeedStreaks
        getIntensity={() => {
          const p = game.current.cars[game.current.playerIndex];
          const t = Math.min(1, Math.abs(p.speed) / p.def.maxSpeed);
          return p.boosting ? Math.max(t, 0.7) : t;
        }}
      />
      <Smoke getCars={() => game.current.cars} />
    </>
  );
}

export function RaceScene(props: Props) {
  const dpr: [number, number] = props.settings.quality === "high" ? [1, 1.5] : [1, 1];
  return (
    <Canvas
      dpr={dpr}
      gl={{ antialias: false, powerPreference: "high-performance", alpha: false }}
      camera={{ fov: 68, near: 0.15, far: 900, position: [0, 6, 12] }}
      style={{ width: "100%", height: "100%", display: "block", touchAction: "none" }}
      onCreated={({ gl }) => {
        gl.setClearColor("#7ec8f0");
      }}
      onPointerDown={(e) => e.stopPropagation()}
    >
      <Loop {...props} />
    </Canvas>
  );
}
