import React, { useEffect } from 'react';
import confetti from 'canvas-confetti';
import { Trophy, Zap, RotateCcw, Home, Wrench, Award } from 'lucide-react';
import { audio } from '../services/audio';
import { triggerHaptic } from '../services/storage';

interface RaceResultData {
  position: number;
  totalTime: number;
  bestLap: number;
  driftScore: number;
  distance: number;
  cashEarned: number;
  nearMisses: number;
  isNewRecord?: boolean;
}

interface EndRaceModalProps {
  result: RaceResultData;
  isEndless: boolean;
  onRestart: () => void;
  onGoGarage: () => void;
  onGoHome: () => void;
}

export const EndRaceModal: React.FC<EndRaceModalProps> = ({
  result,
  isEndless,
  onRestart,
  onGoGarage,
  onGoHome,
}) => {
  useEffect(() => {
    if (result.position <= 3 || (isEndless && result.distance > 2000)) {
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#06b6d4', '#facc15', '#f43f5e', '#3b82f6'],
        });
      } catch {
        // Ignore confetti error
      }
    }
  }, [result.position, isEndless, result.distance]);

  const formatTime = (seconds: number) => {
    if (!seconds || seconds <= 0) return '00:00.00';
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    const ms = Math.floor((seconds % 1) * 100);
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}.${ms.toString().padStart(2, '0')}`;
  };

  const getPositionTitle = (pos: number) => {
    if (isEndless) return 'COURSE TERMINÉE';
    switch (pos) {
      case 1:
        return 'VICTOIRE ÉCLATANTE !';
      case 2:
        return '2ÈME PLACE - PODIUM !';
      case 3:
        return '3ÈME PLACE - PODIUM !';
      default:
        return `${pos}ÈME PLACE`;
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-4">
      <div className="w-full max-w-lg bg-slate-900 border border-white/20 rounded-3xl p-6 shadow-2xl flex flex-col items-center text-center animate-in fade-in zoom-in-95 duration-200">
        {/* Trophy / Medal Icon */}
        <div
          className={`w-20 h-20 rounded-3xl flex items-center justify-center mb-3 shadow-xl ${
            result.position === 1
              ? 'bg-amber-400 text-slate-950 shadow-amber-400/40 animate-bounce'
              : result.position === 2
              ? 'bg-slate-300 text-slate-950 shadow-slate-300/30'
              : result.position === 3
              ? 'bg-amber-700 text-white shadow-amber-800/30'
              : 'bg-slate-800 text-slate-400 border border-white/10'
          }`}
        >
          {result.position === 1 ? (
            <Trophy className="w-10 h-10 fill-current" />
          ) : (
            <Award className="w-10 h-10 fill-current" />
          )}
        </div>

        <span className="text-xs font-black uppercase tracking-widest text-cyan-400">
          RÉSULTATS DE LA COURSE
        </span>
        <h2 className="text-2xl md:text-3xl font-black italic uppercase tracking-tight text-white mb-4">
          {getPositionTitle(result.position)}
        </h2>

        {/* Stats Grid */}
        <div className="w-full grid grid-cols-2 gap-2.5 mb-5 text-left">
          {!isEndless ? (
            <>
              <div className="p-3 rounded-2xl bg-slate-950/80 border border-white/10">
                <span className="text-[10px] font-black uppercase text-slate-400 block">TEMPS TOTAL</span>
                <span className="text-base font-mono font-bold text-white">
                  {formatTime(result.totalTime)}
                </span>
              </div>
              <div className="p-3 rounded-2xl bg-slate-950/80 border border-white/10">
                <span className="text-[10px] font-black uppercase text-slate-400 block">MEILLEUR TOUR</span>
                <span className="text-base font-mono font-bold text-amber-400">
                  {formatTime(result.bestLap)}
                </span>
              </div>
            </>
          ) : (
            <>
              <div className="p-3 rounded-2xl bg-slate-950/80 border border-white/10">
                <span className="text-[10px] font-black uppercase text-slate-400 block">DISTANCE PARCOURUE</span>
                <span className="text-base font-mono font-bold text-cyan-400">
                  {result.distance.toLocaleString()} m
                </span>
              </div>
              <div className="p-3 rounded-2xl bg-slate-950/80 border border-white/10">
                <span className="text-[10px] font-black uppercase text-slate-400 block">FRÔLEMENTS</span>
                <span className="text-base font-mono font-bold text-amber-400">
                  {result.nearMisses}
                </span>
              </div>
            </>
          )}

          <div className="p-3 rounded-2xl bg-slate-950/80 border border-white/10">
            <span className="text-[10px] font-black uppercase text-slate-400 block">SCORE DE DRIFT</span>
            <span className="text-base font-mono font-bold text-rose-400">
              {result.driftScore.toLocaleString()} pts
            </span>
          </div>

          <div className="p-3 rounded-2xl bg-gradient-to-r from-amber-500/20 to-yellow-500/10 border border-amber-400/40">
            <span className="text-[10px] font-black uppercase text-amber-300 block">CRÉDITS GAGNÉS</span>
            <span className="text-base font-mono font-black text-amber-300 flex items-center gap-1">
              <Zap className="w-4 h-4 fill-amber-300" />
              +{result.cashEarned.toLocaleString()} ⚡
            </span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="w-full flex flex-col gap-2.5">
          <button
            onClick={() => {
              audio.playClick();
              triggerHaptic(30);
              onRestart();
            }}
            className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-cyan-500 to-sky-400 hover:from-cyan-400 hover:to-sky-300 text-slate-950 font-black text-sm uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-cyan-500/30 active:scale-95 transition-all"
          >
            <RotateCcw className="w-4 h-4" /> REJOUER
          </button>

          <div className="flex gap-2.5 w-full">
            <button
              onClick={() => {
                audio.playClick();
                triggerHaptic(20);
                onGoGarage();
              }}
              className="flex-1 py-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-white font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 border border-white/10 active:scale-95 transition-all"
            >
              <Wrench className="w-4 h-4 text-cyan-400" /> GARAGE
            </button>

            <button
              onClick={() => {
                audio.playClick();
                triggerHaptic(20);
                onGoHome();
              }}
              className="flex-1 py-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-white font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 border border-white/10 active:scale-95 transition-all"
            >
              <Home className="w-4 h-4 text-slate-300" /> MENU
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
