import * as THREE from 'three';

interface Particle {
  pos: THREE.Vector3;
  vel: THREE.Vector3;
  life: number;
  maxLife: number;
  scale: number;
  color: THREE.Color;
}

export class ParticleSystem {
  public group: THREE.Group;

  // Speed lines (radial motion streaks)
  private speedLinesMesh: THREE.LineSegments;
  private speedLinePositions: Float32Array;
  private numSpeedLines = 140;

  // Tire smoke
  private smokeParticles: Particle[] = [];
  private maxSmoke = 160;
  private smokeInstancedMesh: THREE.InstancedMesh;
  private smokeDummy = new THREE.Object3D();

  // Sparks
  private sparkParticles: Particle[] = [];
  private maxSparks = 80;
  private sparkPointsMesh: THREE.Points;
  private sparkPositions: Float32Array;
  private sparkColors: Float32Array;

  // Nitro Flames
  private nitroFlameMeshes: THREE.Mesh[] = [];

  constructor() {
    this.group = new THREE.Group();

    // 1. Build Speed Lines (LineSegments relative to camera)
    const lineGeo = new THREE.BufferGeometry();
    this.speedLinePositions = new Float32Array(this.numSpeedLines * 6); // 2 vertices per line (x,y,z * 2)

    for (let i = 0; i < this.numSpeedLines; i++) {
      const idx = i * 6;
      const angle = Math.random() * Math.PI * 2;
      const radius = 3 + Math.random() * 8;
      const z = -4 - Math.random() * 25;
      const len = 4 + Math.random() * 8;

      const x = Math.cos(angle) * radius;
      const y = Math.sin(angle) * (radius * 0.6);

      this.speedLinePositions[idx] = x;
      this.speedLinePositions[idx + 1] = y;
      this.speedLinePositions[idx + 2] = z;

      this.speedLinePositions[idx + 3] = x;
      this.speedLinePositions[idx + 4] = y;
      this.speedLinePositions[idx + 5] = z - len;
    }

    lineGeo.setAttribute('position', new THREE.BufferAttribute(this.speedLinePositions, 3));
    const speedLineMat = new THREE.LineBasicMaterial({
      color: 0x93c5fd,
      transparent: true,
      opacity: 0,
      blending: THREE.AdditiveBlending,
    });
    this.speedLinesMesh = new THREE.LineSegments(lineGeo, speedLineMat);
    this.speedLinesMesh.frustumCulled = false;
    this.group.add(this.speedLinesMesh);

    // 2. Build Smoke InstancedMesh (Low poly icosahedrons)
    const smokeGeo = new THREE.IcosahedronGeometry(0.35, 0);
    const smokeMat = new THREE.MeshStandardMaterial({
      color: 0xe2e8f0,
      transparent: true,
      opacity: 0.6,
      roughness: 0.9,
      flatShading: true,
    });
    this.smokeInstancedMesh = new THREE.InstancedMesh(smokeGeo, smokeMat, this.maxSmoke);
    this.smokeInstancedMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.smokeInstancedMesh.frustumCulled = false;
    // Hide all initially
    for (let i = 0; i < this.maxSmoke; i++) {
      this.smokeDummy.position.set(0, -999, 0);
      this.smokeDummy.scale.set(0.001, 0.001, 0.001);
      this.smokeDummy.updateMatrix();
      this.smokeInstancedMesh.setMatrixAt(i, this.smokeDummy.matrix);
    }
    this.smokeInstancedMesh.instanceMatrix.needsUpdate = true;
    this.group.add(this.smokeInstancedMesh);

    // 3. Build Sparks
    const sparkGeo = new THREE.BufferGeometry();
    this.sparkPositions = new Float32Array(this.maxSparks * 3);
    this.sparkColors = new Float32Array(this.maxSparks * 3);
    sparkGeo.setAttribute('position', new THREE.BufferAttribute(this.sparkPositions, 3));
    sparkGeo.setAttribute('color', new THREE.BufferAttribute(this.sparkColors, 3));
    const sparkMat = new THREE.PointsMaterial({
      size: 0.35,
      vertexColors: true,
      transparent: true,
      opacity: 0.9,
      blending: THREE.AdditiveBlending,
    });
    this.sparkPointsMesh = new THREE.Points(sparkGeo, sparkMat);
    this.sparkPointsMesh.frustumCulled = false;
    this.group.add(this.sparkPointsMesh);

    // 4. Nitro Flames (Cones attached to exhausts)
    const flameGeo = new THREE.ConeGeometry(0.18, 1.2, 6);
    flameGeo.rotateX(Math.PI / 2);
    const flameMat = new THREE.MeshBasicMaterial({
      color: 0x38bdf8,
      transparent: true,
      opacity: 0,
      blending: THREE.AdditiveBlending,
    });
    for (let i = 0; i < 4; i++) {
      const fMesh = new THREE.Mesh(flameGeo, flameMat.clone());
      fMesh.visible = false;
      this.nitroFlameMeshes.push(fMesh);
      this.group.add(fMesh);
    }
  }

  public emitSmoke(pos: THREE.Vector3, lateralVel: THREE.Vector3) {
    if (this.smokeParticles.length >= this.maxSmoke) {
      this.smokeParticles.shift();
    }
    this.smokeParticles.push({
      pos: pos.clone().add(new THREE.Vector3((Math.random() - 0.5) * 0.2, 0.1, (Math.random() - 0.5) * 0.2)),
      vel: new THREE.Vector3(
        lateralVel.x * 0.3 + (Math.random() - 0.5) * 0.5,
        0.5 + Math.random() * 0.8,
        lateralVel.z * 0.3 + (Math.random() - 0.5) * 0.5
      ),
      life: 0,
      maxLife: 0.6 + Math.random() * 0.4,
      scale: 0.4 + Math.random() * 0.4,
      color: new THREE.Color(0xd4d4d8),
    });
  }

  public emitSparks(pos: THREE.Vector3, normal: THREE.Vector3, count = 8) {
    for (let i = 0; i < count; i++) {
      if (this.sparkParticles.length >= this.maxSparks) {
        this.sparkParticles.shift();
      }
      this.sparkParticles.push({
        pos: pos.clone(),
        vel: new THREE.Vector3(
          normal.x * 3 + (Math.random() - 0.5) * 6,
          2 + Math.random() * 5,
          normal.z * 3 + (Math.random() - 0.5) * 6
        ),
        life: 0,
        maxLife: 0.25 + Math.random() * 0.25,
        scale: 1,
        color: new THREE.Color(Math.random() > 0.3 ? 0xfbbf24 : 0xef4444),
      });
    }
  }

  public updateNitroFlames(exhaustWorldPositions: THREE.Vector3[], carForward: THREE.Vector3, active: boolean, colorHex = 0x38bdf8) {
    for (let i = 0; i < this.nitroFlameMeshes.length; i++) {
      const mesh = this.nitroFlameMeshes[i];
      if (i < exhaustWorldPositions.length && active) {
        mesh.visible = true;
        const pos = exhaustWorldPositions[i];
        mesh.position.copy(pos);
        // Point backward from car forward
        mesh.lookAt(pos.clone().sub(carForward));
        // Pulsate flame size
        const flicker = 0.8 + Math.random() * 0.5;
        mesh.scale.set(flicker, flicker, flicker * (1.2 + Math.random() * 0.6));
        const mat = mesh.material as THREE.MeshBasicMaterial;
        mat.color.setHex(colorHex);
        mat.opacity = 0.85;
      } else {
        mesh.visible = false;
      }
    }
  }

  public updateSpeedLines(camera: THREE.Camera, speedRatio: number, isNitro: boolean) {
    // Attach lines right in front of camera
    this.speedLinesMesh.position.copy(camera.position);
    this.speedLinesMesh.quaternion.copy(camera.quaternion);

    const mat = this.speedLinesMesh.material as THREE.LineBasicMaterial;
    if (speedRatio < 0.65 && !isNitro) {
      mat.opacity = 0;
      return;
    }

    // Dynamic speed lines opacity and elongation
    const targetOpacity = isNitro ? 0.9 : (speedRatio - 0.65) / 0.35 * 0.65;
    mat.opacity += (targetOpacity - mat.opacity) * 0.15;
    mat.color.setHex(isNitro ? 0x67e8f9 : 0xffffff);

    // Animate lines rushing forward
    const speed = (speedRatio * 40 + (isNitro ? 30 : 0)) * 0.016;
    for (let i = 0; i < this.numSpeedLines; i++) {
      const idx = i * 6;
      this.speedLinePositions[idx + 2] += speed;
      this.speedLinePositions[idx + 5] += speed;

      // Wrap around
      if (this.speedLinePositions[idx + 2] > 2) {
        const z = -25 - Math.random() * 15;
        const len = 5 + Math.random() * 10;
        this.speedLinePositions[idx + 2] = z;
        this.speedLinePositions[idx + 5] = z - len;
      }
    }
    this.speedLinesMesh.geometry.attributes.position.needsUpdate = true;
  }

  public update(dt: number) {
    // 1. Update Smoke
    for (let i = this.smokeParticles.length - 1; i >= 0; i--) {
      const p = this.smokeParticles[i];
      p.life += dt;
      if (p.life >= p.maxLife) {
        this.smokeParticles.splice(i, 1);
        continue;
      }
      p.pos.addScaledVector(p.vel, dt);
      p.vel.y += dt * 0.5; // rise up
    }

    for (let i = 0; i < this.maxSmoke; i++) {
      if (i < this.smokeParticles.length) {
        const p = this.smokeParticles[i];
        const progress = p.life / p.maxLife;
        const scale = p.scale * (1 + progress * 2.2);
        this.smokeDummy.position.copy(p.pos);
        this.smokeDummy.scale.set(scale, scale, scale);
        this.smokeDummy.rotation.set(progress * 2, progress * 1.5, 0);
        this.smokeDummy.updateMatrix();
        this.smokeInstancedMesh.setMatrixAt(i, this.smokeDummy.matrix);
      } else {
        this.smokeDummy.position.set(0, -999, 0);
        this.smokeDummy.scale.set(0.001, 0.001, 0.001);
        this.smokeDummy.updateMatrix();
        this.smokeInstancedMesh.setMatrixAt(i, this.smokeDummy.matrix);
      }
    }
    this.smokeInstancedMesh.instanceMatrix.needsUpdate = true;

    // 2. Update Sparks
    for (let i = this.sparkParticles.length - 1; i >= 0; i--) {
      const p = this.sparkParticles[i];
      p.life += dt;
      if (p.life >= p.maxLife) {
        this.sparkParticles.splice(i, 1);
        continue;
      }
      p.pos.addScaledVector(p.vel, dt);
      p.vel.y -= 9.8 * dt; // gravity
    }

    for (let i = 0; i < this.maxSparks; i++) {
      const idx = i * 3;
      if (i < this.sparkParticles.length) {
        const p = this.sparkParticles[i];
        this.sparkPositions[idx] = p.pos.x;
        this.sparkPositions[idx + 1] = p.pos.y;
        this.sparkPositions[idx + 2] = p.pos.z;

        this.sparkColors[idx] = p.color.r;
        this.sparkColors[idx + 1] = p.color.g;
        this.sparkColors[idx + 2] = p.color.b;
      } else {
        this.sparkPositions[idx + 1] = -999;
      }
    }
    this.sparkPointsMesh.geometry.attributes.position.needsUpdate = true;
    this.sparkPointsMesh.geometry.attributes.color.needsUpdate = true;
  }
}
