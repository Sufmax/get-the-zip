import * as THREE from 'three';
import { CarDefinition, PlayerCarCustomization } from '../types/game';

export interface Car3DObject {
  root: THREE.Group;
  bodyGroup: THREE.Group;
  bodyMesh: THREE.Mesh;
  bodyMaterial: THREE.MeshStandardMaterial;
  frontWheels: THREE.Group[];
  rearWheels: THREE.Group[];
  exhaustPoints: THREE.Vector3[]; // local positions of exhaust tips
  headlights: THREE.Mesh[];
  taillights: THREE.Mesh[];
  brakeLightMaterial: THREE.MeshBasicMaterial;
  underglowMesh?: THREE.Mesh;
  steerAngle: number;
  wheelSpin: number;
}

export function buildLowPolyCar(
  carDef: CarDefinition,
  customization?: PlayerCarCustomization
): Car3DObject {
  const root = new THREE.Group();
  root.castShadow = true;
  root.receiveShadow = true;

  const bodyColor = customization?.color || carDef.baseColor;
  const underglowColor = customization?.underglowColor;

  // Shared stylized materials
  const bodyMaterial = new THREE.MeshStandardMaterial({
    color: new THREE.Color(bodyColor),
    roughness: 0.25,
    metalness: 0.65,
    flatShading: true,
  });

  const blackTrimMaterial = new THREE.MeshStandardMaterial({
    color: 0x111827,
    roughness: 0.6,
    metalness: 0.2,
    flatShading: true,
  });

  const glassMaterial = new THREE.MeshStandardMaterial({
    color: 0x1e293b,
    roughness: 0.1,
    metalness: 0.9,
    transparent: true,
    opacity: 0.75,
    flatShading: true,
  });

  const chromeMaterial = new THREE.MeshStandardMaterial({
    color: 0xe2e8f0,
    roughness: 0.1,
    metalness: 0.95,
    flatShading: true,
  });

  const headlightMaterial = new THREE.MeshBasicMaterial({
    color: 0xffffff,
  });

  const taillightMaterial = new THREE.MeshBasicMaterial({
    color: 0xef4444,
  });

  const brakeLightMaterial = new THREE.MeshBasicMaterial({
    color: 0x991b1b,
  });

  const neonAccentMaterial = new THREE.MeshBasicMaterial({
    color: carDef.category === 'electric' ? 0x00f2fe : 0xff007f,
  });

  const tireMaterial = new THREE.MeshStandardMaterial({
    color: 0x18181b,
    roughness: 0.85,
    metalness: 0.1,
    flatShading: true,
  });

  const rimMaterial = new THREE.MeshStandardMaterial({
    color: 0xd4d4d8,
    roughness: 0.3,
    metalness: 0.85,
    flatShading: true,
  });

  const caliperMaterial = new THREE.MeshBasicMaterial({
    color: 0xe11d48,
  });

  const frontWheels: THREE.Group[] = [];
  const rearWheels: THREE.Group[] = [];
  const exhaustPoints: THREE.Vector3[] = [];
  const headlights: THREE.Mesh[] = [];
  const taillights: THREE.Mesh[] = [];

  // Wheel factory
  const isOffroad = carDef.category === 'offroad';
  const isFormula = carDef.category === 'formula';
  const wheelRadius = isOffroad ? 0.52 : isFormula ? 0.38 : 0.35;
  const wheelWidth = isOffroad ? 0.32 : isFormula ? 0.34 : 0.26;

  function createWheel(_isFront: boolean): THREE.Group {
    const wheelGroup = new THREE.Group();

    // Tire mesh
    const tireGeo = new THREE.CylinderGeometry(wheelRadius, wheelRadius, wheelWidth, 14);
    tireGeo.rotateZ(Math.PI / 2);
    const tireMesh = new THREE.Mesh(tireGeo, tireMaterial);
    tireMesh.castShadow = true;
    wheelGroup.add(tireMesh);

    // Rim mesh (5-spoke low-poly star or disc)
    const rimGeo = new THREE.CylinderGeometry(wheelRadius * 0.65, wheelRadius * 0.65, wheelWidth + 0.02, 10);
    rimGeo.rotateZ(Math.PI / 2);
    const rimMesh = new THREE.Mesh(rimGeo, rimMaterial);
    wheelGroup.add(rimMesh);

    // Spokes
    for (let i = 0; i < 5; i++) {
      const angle = (i * Math.PI * 2) / 5;
      const spokeGeo = new THREE.BoxGeometry(0.04, wheelRadius * 0.6, 0.04);
      const spoke = new THREE.Mesh(spokeGeo, rimMaterial);
      spoke.rotation.x = angle;
      wheelGroup.add(spoke);
    }

    // Brake disc & caliper
    const discGeo = new THREE.CylinderGeometry(wheelRadius * 0.48, wheelRadius * 0.48, 0.03, 12);
    discGeo.rotateZ(Math.PI / 2);
    const disc = new THREE.Mesh(discGeo, chromeMaterial);
    wheelGroup.add(disc);

    const caliperGeo = new THREE.BoxGeometry(0.06, 0.12, 0.07);
    const caliper = new THREE.Mesh(caliperGeo, caliperMaterial);
    caliper.position.set(0, wheelRadius * 0.28, 0);
    wheelGroup.add(caliper);

    return wheelGroup;
  }

  // Build specialized body based on car archetype
  let carLength = 4.2;
  let carWidth = 1.9;
  let wheelBase = 2.5;
  let trackWidth = 1.65;
  let groundClearance = 0.36;

  if (isOffroad) {
    carLength = 4.4;
    carWidth = 2.1;
    groundClearance = 0.58;
    trackWidth = 1.85;
  } else if (isFormula) {
    carLength = 4.8;
    carWidth = 1.95;
    groundClearance = 0.25;
    trackWidth = 1.8;
  } else if (carDef.category === 'hypercar' || carDef.category === 'prototype') {
    carLength = 4.5;
    carWidth = 2.05;
    groundClearance = 0.3;
    trackWidth = 1.75;
  }

  const bodyGroup = new THREE.Group();
  bodyGroup.position.y = groundClearance;
  root.add(bodyGroup);

  // Chassis bottom
  const chassisGeo = new THREE.BoxGeometry(carWidth * 0.9, 0.15, carLength * 0.95);
  const chassisMesh = new THREE.Mesh(chassisGeo, blackTrimMaterial);
  chassisMesh.position.y = 0.08;
  bodyGroup.add(chassisMesh);

  // Construct category-specific bodywork
  let mainBodyMesh: THREE.Mesh;

  switch (carDef.category) {
    case 'formula': {
      // Formula 1 open wheel aerodynamic body
      const noseGeo = new THREE.ConeGeometry(0.4, 2.4, 6);
      noseGeo.rotateX(Math.PI / 2);
      mainBodyMesh = new THREE.Mesh(noseGeo, bodyMaterial);
      mainBodyMesh.position.set(0, 0.25, 0.9);
      mainBodyMesh.scale.set(1.4, 0.8, 1);
      bodyGroup.add(mainBodyMesh);

      // Main tub & engine cover
      const tubGeo = new THREE.BoxGeometry(0.85, 0.45, 1.8);
      const tubMesh = new THREE.Mesh(tubGeo, bodyMaterial);
      tubMesh.position.set(0, 0.28, -0.6);
      bodyGroup.add(tubMesh);

      // Sidepods
      const sidepodGeo = new THREE.BoxGeometry(0.38, 0.35, 1.4);
      const leftPod = new THREE.Mesh(sidepodGeo, bodyMaterial);
      leftPod.position.set(-0.62, 0.25, -0.5);
      const rightPod = leftPod.clone();
      rightPod.position.x = 0.62;
      bodyGroup.add(leftPod, rightPod);

      // Cockpit cutout & low-poly helmet
      const helmetGeo = new THREE.SphereGeometry(0.16, 8, 8);
      const helmet = new THREE.Mesh(helmetGeo, headlightMaterial);
      helmet.position.set(0, 0.48, -0.2);
      bodyGroup.add(helmet);

      // Front wing
      const frontWingGeo = new THREE.BoxGeometry(1.85, 0.05, 0.45);
      const frontWing = new THREE.Mesh(frontWingGeo, blackTrimMaterial);
      frontWing.position.set(0, 0.1, 1.95);
      bodyGroup.add(frontWing);

      // Rear wing with endplates
      const rearWingGeo = new THREE.BoxGeometry(1.5, 0.06, 0.4);
      const rearWing = new THREE.Mesh(rearWingGeo, bodyMaterial);
      rearWing.position.set(0, 0.85, -1.9);
      const endplateGeo = new THREE.BoxGeometry(0.04, 0.4, 0.5);
      const endplateL = new THREE.Mesh(endplateGeo, blackTrimMaterial);
      endplateL.position.set(-0.75, 0.8, -1.9);
      const endplateR = endplateL.clone();
      endplateR.position.x = 0.75;
      const wingPillarGeo = new THREE.BoxGeometry(0.06, 0.6, 0.1);
      const wingPillar = new THREE.Mesh(wingPillarGeo, blackTrimMaterial);
      wingPillar.position.set(0, 0.5, -1.8);
      bodyGroup.add(rearWing, endplateL, endplateR, wingPillar);

      // Single large central exhaust
      exhaustPoints.push(new THREE.Vector3(0, groundClearance + 0.35, -2.1));
      break;
    }

    case 'muscle': {
      // Wide muscular body with dual hood scoops
      const mainGeo = new THREE.BoxGeometry(carWidth, 0.5, carLength);
      mainBodyMesh = new THREE.Mesh(mainGeo, bodyMaterial);
      mainBodyMesh.position.set(0, 0.35, 0);
      bodyGroup.add(mainBodyMesh);

      // Cabin / Roof
      const cabinGeo = new THREE.BoxGeometry(carWidth * 0.82, 0.45, carLength * 0.48);
      const cabin = new THREE.Mesh(cabinGeo, glassMaterial);
      cabin.position.set(0, 0.78, -0.25);
      bodyGroup.add(cabin);

      // Hood scoop / Blower supercharger
      const scoopGeo = new THREE.BoxGeometry(0.45, 0.16, 0.6);
      const scoop = new THREE.Mesh(scoopGeo, blackTrimMaterial);
      scoop.position.set(0, 0.65, 0.8);
      bodyGroup.add(scoop);

      // Front wide grille
      const grilleGeo = new THREE.BoxGeometry(carWidth * 0.85, 0.22, 0.08);
      const grille = new THREE.Mesh(grilleGeo, blackTrimMaterial);
      grille.position.set(0, 0.32, carLength * 0.5 + 0.01);
      bodyGroup.add(grille);

      // Dual side/rear exhausts
      exhaustPoints.push(
        new THREE.Vector3(-0.6, groundClearance + 0.25, -carLength * 0.5 - 0.05),
        new THREE.Vector3(0.6, groundClearance + 0.25, -carLength * 0.5 - 0.05)
      );
      break;
    }

    case 'hypercar': {
      // Low-slung sharp wedge
      const mainGeo = new THREE.BoxGeometry(carWidth, 0.42, carLength);
      mainBodyMesh = new THREE.Mesh(mainGeo, bodyMaterial);
      mainBodyMesh.position.set(0, 0.3, 0);
      bodyGroup.add(mainBodyMesh);

      // Canopy teardrop cockpit
      const canopyGeo = new THREE.ConeGeometry(0.8, carLength * 0.6, 7);
      canopyGeo.rotateX(Math.PI / 2);
      const canopy = new THREE.Mesh(canopyGeo, glassMaterial);
      canopy.position.set(0, 0.58, -0.1);
      canopy.scale.set(1.1, 0.5, 0.9);
      bodyGroup.add(canopy);

      // Aerodynamic roof fin
      const finGeo = new THREE.BoxGeometry(0.04, 0.28, 1.2);
      const fin = new THREE.Mesh(finGeo, blackTrimMaterial);
      fin.position.set(0, 0.68, -0.8);
      bodyGroup.add(fin);

      // Integrated rear spoiler wing
      const wingGeo = new THREE.BoxGeometry(carWidth * 0.95, 0.06, 0.35);
      const wing = new THREE.Mesh(wingGeo, bodyMaterial);
      wing.position.set(0, 0.68, -carLength * 0.48);
      bodyGroup.add(wing);

      // Twin centered high-mount exhausts
      exhaustPoints.push(
        new THREE.Vector3(-0.2, groundClearance + 0.4, -carLength * 0.5 - 0.05),
        new THREE.Vector3(0.2, groundClearance + 0.4, -carLength * 0.5 - 0.05)
      );
      break;
    }

    case 'prototype': {
      // Jet fighter inspired supercar with giant central turbine
      const jetBodyGeo = new THREE.CylinderGeometry(0.55, 0.75, carLength, 10);
      jetBodyGeo.rotateX(Math.PI / 2);
      mainBodyMesh = new THREE.Mesh(jetBodyGeo, bodyMaterial);
      mainBodyMesh.position.set(0, 0.4, 0);
      mainBodyMesh.scale.set(1.4, 0.6, 1);
      bodyGroup.add(mainBodyMesh);

      // Twin side pontoons
      const pontoonGeo = new THREE.BoxGeometry(0.35, 0.32, carLength * 0.85);
      const pontoonL = new THREE.Mesh(pontoonGeo, bodyMaterial);
      pontoonL.position.set(-0.85, 0.3, 0);
      const pontoonR = pontoonL.clone();
      pontoonR.position.x = 0.85;
      bodyGroup.add(pontoonL, pontoonR);

      // Cockpit bubble
      const bubbleGeo = new THREE.SphereGeometry(0.5, 10, 8);
      const bubble = new THREE.Mesh(bubbleGeo, glassMaterial);
      bubble.position.set(0, 0.55, 0.2);
      bubble.scale.set(0.9, 0.6, 1.8);
      bodyGroup.add(bubble);

      // Giant rear jet engine nozzle
      const nozzleGeo = new THREE.CylinderGeometry(0.38, 0.46, 0.4, 12);
      nozzleGeo.rotateX(Math.PI / 2);
      const nozzle = new THREE.Mesh(nozzleGeo, blackTrimMaterial);
      nozzle.position.set(0, 0.42, -carLength * 0.5);
      bodyGroup.add(nozzle);

      // Glowing nozzle interior
      const jetGlowGeo = new THREE.CircleGeometry(0.3, 10);
      jetGlowGeo.rotateY(Math.PI);
      const jetGlow = new THREE.Mesh(jetGlowGeo, new THREE.MeshBasicMaterial({ color: 0x9333ea }));
      jetGlow.position.set(0, 0.42, -carLength * 0.5 - 0.05);
      bodyGroup.add(jetGlow);

      exhaustPoints.push(new THREE.Vector3(0, groundClearance + 0.42, -carLength * 0.5 - 0.2));
      break;
    }

    case 'electric': {
      // Ultra-sleek minimalist cyber car
      const cyberGeo = new THREE.BoxGeometry(carWidth, 0.42, carLength);
      mainBodyMesh = new THREE.Mesh(cyberGeo, bodyMaterial);
      mainBodyMesh.position.set(0, 0.32, 0);
      bodyGroup.add(mainBodyMesh);

      // Aerodynamic glass dome
      const domeGeo = new THREE.BoxGeometry(carWidth * 0.8, 0.42, carLength * 0.55);
      const dome = new THREE.Mesh(domeGeo, glassMaterial);
      dome.position.set(0, 0.68, -0.1);
      bodyGroup.add(dome);

      // Front glowing cyber line (headlight strip)
      const stripGeo = new THREE.BoxGeometry(carWidth * 0.9, 0.05, 0.05);
      const stripFront = new THREE.Mesh(stripGeo, neonAccentMaterial);
      stripFront.position.set(0, 0.36, carLength * 0.5 + 0.01);
      bodyGroup.add(stripFront);

      // Rear glowing cyber line
      const stripRear = new THREE.Mesh(stripGeo, taillightMaterial);
      stripRear.position.set(0, 0.38, -carLength * 0.5 - 0.01);
      bodyGroup.add(stripRear);

      exhaustPoints.push(
        new THREE.Vector3(-0.4, groundClearance + 0.2, -carLength * 0.5),
        new THREE.Vector3(0.4, groundClearance + 0.2, -carLength * 0.5)
      );
      break;
    }

    case 'offroad': {
      // Rugged boxy offroad SUV
      const offGeo = new THREE.BoxGeometry(carWidth, 0.7, carLength * 0.95);
      mainBodyMesh = new THREE.Mesh(offGeo, bodyMaterial);
      mainBodyMesh.position.set(0, 0.5, 0);
      bodyGroup.add(mainBodyMesh);

      // Tall cab
      const cabGeo = new THREE.BoxGeometry(carWidth * 0.85, 0.55, carLength * 0.55);
      const cab = new THREE.Mesh(cabGeo, glassMaterial);
      cab.position.set(0, 1.05, -0.3);
      bodyGroup.add(cab);

      // Roof rack with 4 light pods
      const rackGeo = new THREE.BoxGeometry(carWidth * 0.78, 0.06, carLength * 0.45);
      const rack = new THREE.Mesh(rackGeo, blackTrimMaterial);
      rack.position.set(0, 1.35, -0.3);
      bodyGroup.add(rack);

      for (let i = -1.5; i <= 1.5; i += 1) {
        const podGeo = new THREE.CylinderGeometry(0.1, 0.1, 0.12, 8);
        podGeo.rotateX(Math.PI / 2);
        const pod = new THREE.Mesh(podGeo, headlightMaterial);
        pod.position.set(i * 0.25, 1.42, 0.0);
        bodyGroup.add(pod);
      }

      // Front heavy bull-bar
      const bullBarGeo = new THREE.BoxGeometry(carWidth * 0.8, 0.3, 0.15);
      const bullBar = new THREE.Mesh(bullBarGeo, blackTrimMaterial);
      bullBar.position.set(0, 0.45, carLength * 0.5 + 0.05);
      bodyGroup.add(bullBar);

      // Twin chunky exhausts
      exhaustPoints.push(
        new THREE.Vector3(-0.55, groundClearance + 0.3, -carLength * 0.5),
        new THREE.Vector3(0.55, groundClearance + 0.3, -carLength * 0.5)
      );
      break;
    }

    case 'tuner': {
      // JDM Drift Legend with aggressive tuner kit
      const tunerGeo = new THREE.BoxGeometry(carWidth, 0.44, carLength);
      mainBodyMesh = new THREE.Mesh(tunerGeo, bodyMaterial);
      mainBodyMesh.position.set(0, 0.3, 0);
      bodyGroup.add(tunerGeo ? mainBodyMesh : new THREE.Mesh());

      // Sport cabin
      const cabinGeo = new THREE.BoxGeometry(carWidth * 0.8, 0.42, carLength * 0.5);
      const cabin = new THREE.Mesh(cabinGeo, glassMaterial);
      cabin.position.set(0, 0.68, -0.2);
      bodyGroup.add(cabin);

      // Front splitter & intercooler
      const splitterGeo = new THREE.BoxGeometry(carWidth * 0.95, 0.05, 0.3);
      const splitter = new THREE.Mesh(splitterGeo, blackTrimMaterial);
      splitter.position.set(0, 0.08, carLength * 0.5);
      bodyGroup.add(splitter);

      // Big angled drift rear wing
      const wingGeo = new THREE.BoxGeometry(carWidth * 0.95, 0.05, 0.35);
      const wing = new THREE.Mesh(wingGeo, blackTrimMaterial);
      wing.position.set(0, 0.88, -carLength * 0.46);
      const standL = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.4, 0.08), blackTrimMaterial);
      standL.position.set(-0.5, 0.68, -carLength * 0.46);
      const standR = standL.clone();
      standR.position.x = 0.5;
      bodyGroup.add(wing, standL, standR);

      // Angled large titanium exhaust tip
      exhaustPoints.push(new THREE.Vector3(0.65, groundClearance + 0.22, -carLength * 0.5 - 0.08));
      break;
    }

    default: {
      // 'sport' - Classic balanced sports coupe
      const sportGeo = new THREE.BoxGeometry(carWidth, 0.45, carLength);
      mainBodyMesh = new THREE.Mesh(sportGeo, bodyMaterial);
      mainBodyMesh.position.set(0, 0.32, 0);
      bodyGroup.add(mainBodyMesh);

      // Coupe aerodynamic roof
      const roofGeo = new THREE.BoxGeometry(carWidth * 0.78, 0.42, carLength * 0.52);
      const roof = new THREE.Mesh(roofGeo, glassMaterial);
      roof.position.set(0, 0.7, -0.2);
      bodyGroup.add(roof);

      // Rear lip spoiler
      const lipGeo = new THREE.BoxGeometry(carWidth * 0.75, 0.08, 0.15);
      const lip = new THREE.Mesh(lipGeo, blackTrimMaterial);
      lip.position.set(0, 0.58, -carLength * 0.48);
      bodyGroup.add(lip);

      // Twin sporty exhausts
      exhaustPoints.push(
        new THREE.Vector3(-0.45, groundClearance + 0.22, -carLength * 0.5 - 0.04),
        new THREE.Vector3(0.45, groundClearance + 0.22, -carLength * 0.5 - 0.04)
      );
      break;
    }
  }

  // Front Headlights
  if (carDef.category !== 'formula') {
    const headGeo = new THREE.BoxGeometry(0.3, 0.12, 0.05);
    const headL = new THREE.Mesh(headGeo, headlightMaterial);
    headL.position.set(-carWidth * 0.38, 0.38, carLength * 0.5 + 0.01);
    const headR = headL.clone();
    headR.position.x = carWidth * 0.38;
    bodyGroup.add(headL, headR);
    headlights.push(headL, headR);

    // Rear Taillights
    const tailGeo = new THREE.BoxGeometry(0.32, 0.12, 0.05);
    const tailL = new THREE.Mesh(tailGeo, taillightMaterial);
    tailL.position.set(-carWidth * 0.38, 0.38, -carLength * 0.5 - 0.01);
    const tailR = tailL.clone();
    tailR.position.x = carWidth * 0.38;
    bodyGroup.add(tailL, tailR);
    taillights.push(tailL, tailR);
  }

  // Underglow neon mesh (ground reflection plane)
  let underglowMesh: THREE.Mesh | undefined;
  if (underglowColor) {
    const underGeo = new THREE.PlaneGeometry(carWidth * 1.3, carLength * 1.1);
    underGeo.rotateX(-Math.PI / 2);
    const underMat = new THREE.MeshBasicMaterial({
      color: new THREE.Color(underglowColor),
      transparent: true,
      opacity: 0.55,
      side: THREE.DoubleSide,
    });
    underglowMesh = new THREE.Mesh(underGeo, underMat);
    underglowMesh.position.y = 0.05;
    root.add(underglowMesh);
  }

  // Build 4 wheels
  const halfTrack = trackWidth * 0.5;
  const halfWheelBase = wheelBase * 0.5;

  // Front Left
  const flPivot = new THREE.Group();
  flPivot.position.set(-halfTrack, wheelRadius, halfWheelBase);
  const flWheel = createWheel(true);
  flPivot.add(flWheel);
  root.add(flPivot);
  frontWheels.push(flPivot);

  // Front Right
  const frPivot = new THREE.Group();
  frPivot.position.set(halfTrack, wheelRadius, halfWheelBase);
  const frWheel = createWheel(true);
  frWheel.rotation.y = Math.PI;
  frPivot.add(frWheel);
  root.add(frPivot);
  frontWheels.push(frPivot);

  // Rear Left
  const rlGroup = new THREE.Group();
  rlGroup.position.set(-halfTrack, wheelRadius, -halfWheelBase);
  const rlWheel = createWheel(false);
  rlGroup.add(rlWheel);
  root.add(rlGroup);
  rearWheels.push(rlGroup);

  // Rear Right
  const rrGroup = new THREE.Group();
  rrGroup.position.set(halfTrack, wheelRadius, -halfWheelBase);
  const rrWheel = createWheel(false);
  rrWheel.rotation.y = Math.PI;
  rrGroup.add(rrWheel);
  root.add(rrGroup);
  rearWheels.push(rrGroup);

  return {
    root,
    bodyGroup,
    bodyMesh: mainBodyMesh,
    bodyMaterial,
    frontWheels,
    rearWheels,
    exhaustPoints,
    headlights,
    taillights,
    brakeLightMaterial,
    underglowMesh,
    steerAngle: 0,
    wheelSpin: 0,
  };
}
