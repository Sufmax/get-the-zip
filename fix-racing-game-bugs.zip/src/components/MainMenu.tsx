import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { PlayerProgress, CarDefinition } from '../types/game';
import { CARS_CATALOG } from '../game/carsData';
import { buildLowPolyCar, Car3DObject } from '../game/proceduralCar';
import { audio } from '../services/audio';
import { triggerHaptic } from '../services/storage';
import { Play, Wrench, Trophy, Settings, Zap, Volume2, VolumeX } from 'lucide-react';

interface MainMenuProps {
  progress: PlayerProgress;
  onOpenTrackSelect: () => void;
  onOpenGarage: () => void;
  onOpenAchievements: () => void;
  onOpenSettings: () => void;
}

export const MainMenu: React.FC<MainMenuProps> = ({
  progress,
  onOpenTrackSelect,
  onOpenGarage,
  onOpenAchievements,
  onOpenSettings,
}) => {
  const canvasContainerRef = useRef<HTMLDivElement>(null);
  const [isMuted, setIsMuted] = React.useState(false);

  const selectedCar: CarDefinition =
    CARS_CATALOG.find((c) => c.id === progress.selectedCarId) || CARS_CATALOG[0];
  const custom = progress.carCustomizations[selectedCar.id];

  // Background 3D Low-Poly Turntable Car
  useEffect(() => {
    const container = canvasContainerRef.current;
    if (!container) return;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x070b16);

    const camera = new THREE.PerspectiveCamera(50, container.clientWidth / container.clientHeight, 0.1, 100);
    camera.position.set(4.2, 1.8, 5.0);
    camera.lookAt(0, 0.35, 0);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.25;
    container.appendChild(renderer.domElement);

    // Dynamic studio lights
    const ambient = new THREE.AmbientLight(0xffffff, 0.9);
    scene.add(ambient);

    const keyLight = new THREE.DirectionalLight(0x38bdf8, 2.5);
    keyLight.position.set(5, 7, 5);
    scene.add(keyLight);

    const pinkBack = new THREE.DirectionalLight(0xf43f5e, 1.8);
    pinkBack.position.set(-6, 3, -4);
    scene.add(pinkBack);

    // Glowing ground grid plane
    const gridHelper = new THREE.GridHelper(30, 30, 0x06b6d4, 0x1e293b);
    gridHelper.position.y = -0.01;
    scene.add(gridHelper);

    // Build the player's 3D tuned car
    const carObj: Car3DObject = buildLowPolyCar(selectedCar, custom);
    scene.add(carObj.root);

    let animationId: number;
    const animate = () => {
      animationId = requestAnimationFrame(animate);
      carObj.root.rotation.y += 0.007;
      renderer.render(scene, camera);
    };
    animate();

    const onResize = () => {
      if (!container) return;
      camera.aspect = container.clientWidth / container.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(container.clientWidth, container.clientHeight);
    };
    window.addEventListener('resize', onResize);

    return () => {
      cancelAnimationFrame(animationId);
      window.removeEventListener('resize', onResize);
      if (renderer.domElement.parentNode) {
        renderer.domElement.parentNode.removeChild(renderer.domElement);
      }
      renderer.dispose();
    };
  }, [selectedCar, custom]);

  const handleToggleSound = () => {
    const muted = audio.toggleMute();
    setIsMuted(muted);
  };

  return (
    <div className="relative w-full h-full min-h-screen bg-slate-950 text-white flex flex-col justify-between p-4 md:p-8 select-none overflow-hidden">
      {/* 3D Background Canvas */}
      <div ref={canvasContainerRef} className="absolute inset-0 pointer-events-none z-0" />

      {/* Top Navbar */}
      <div className="relative z-10 flex justify-between items-center w-full">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-cyan-500 to-sky-400 flex items-center justify-center shadow-lg shadow-cyan-500/30">
            <span className="text-xl font-black italic text-slate-950">A</span>
          </div>
          <div>
            <h1 className="text-xl md:text-2xl font-black italic uppercase tracking-tight text-white drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)]">
              APEX RACER
            </h1>
            <span className="text-[9px] font-black uppercase tracking-widest text-cyan-400 block -mt-1">
              LOW-POLY MOBILE EDITION
            </span>
          </div>
        </div>

        {/* Wallet & Audio Toggle */}
        <div className="flex items-center gap-2.5">
          <div className="flex items-center gap-1.5 px-4 py-2 rounded-2xl bg-slate-900/80 backdrop-blur-md border border-amber-400/40 text-amber-300 font-mono font-black text-sm shadow-xl shadow-black/40">
            <Zap className="w-4 h-4 fill-amber-300" />
            <span>{progress.money.toLocaleString()} ⚡</span>
          </div>

          <button
            onClick={handleToggleSound}
            aria-label="Toggle mute"
            className="w-10 h-10 rounded-2xl bg-slate-900/80 backdrop-blur-md border border-white/20 flex items-center justify-center text-slate-300 active:scale-95 transition-transform"
          >
            {isMuted ? <VolumeX className="w-5 h-5 text-rose-400" /> : <Volume2 className="w-5 h-5 text-cyan-400" />}
          </button>
        </div>
      </div>

      {/* Center Left: Selected Car Badge */}
      <div className="relative z-10 my-auto pointer-events-none">
        <div className="bg-slate-900/70 backdrop-blur-md p-4 rounded-3xl border border-white/10 w-fit max-w-xs shadow-2xl">
          <span className="text-[10px] font-black uppercase tracking-widest text-cyan-400 block mb-0.5">
            VÉHICULE ACTIF
          </span>
          <h2 className="text-xl font-black uppercase italic text-white tracking-tight">
            {selectedCar.name}
          </h2>
          <span className="text-xs text-slate-400 block mb-2">{selectedCar.subtitle}</span>

          <div className="flex items-center gap-2 text-xs font-mono font-bold text-slate-300">
            <span className="text-cyan-400">⚡ {selectedCar.specs.topSpeed} km/h</span>
            <span>•</span>
            <span className="text-emerald-400">ACC {selectedCar.specs.acceleration}/10</span>
          </div>
        </div>
      </div>

      {/* Bottom Menu Buttons */}
      <div className="relative z-10 flex flex-col gap-3 max-w-md w-full mx-auto pb-2">
        {/* Play / Race Launch Button */}
        <button
          onClick={() => {
            audio.playClick();
            triggerHaptic(30);
            onOpenTrackSelect();
          }}
          className="w-full py-4 rounded-2xl bg-gradient-to-r from-cyan-500 via-sky-400 to-cyan-400 hover:from-cyan-400 hover:to-sky-300 text-slate-950 font-black text-lg uppercase tracking-widest flex items-center justify-center gap-3 shadow-2xl shadow-cyan-500/40 active:scale-95 transition-all"
        >
          <Play className="w-6 h-6 fill-slate-950" />
          COMMENCER LA COURSE
        </button>

        {/* Secondary Row (Garage, Trophées, Paramètres) */}
        <div className="grid grid-cols-3 gap-2.5">
          <button
            onClick={() => {
              audio.playClick();
              triggerHaptic(20);
              onOpenGarage();
            }}
            className="py-3 rounded-2xl bg-slate-900/80 hover:bg-slate-800 backdrop-blur-md border border-white/15 text-white font-black text-xs uppercase tracking-wider flex flex-col items-center justify-center gap-1 active:scale-95 transition-all shadow-xl shadow-black/40"
          >
            <Wrench className="w-5 h-5 text-cyan-400" />
            GARAGE
          </button>

          <button
            onClick={() => {
              audio.playClick();
              triggerHaptic(20);
              onOpenAchievements();
            }}
            className="py-3 rounded-2xl bg-slate-900/80 hover:bg-slate-800 backdrop-blur-md border border-white/15 text-white font-black text-xs uppercase tracking-wider flex flex-col items-center justify-center gap-1 active:scale-95 transition-all shadow-xl shadow-black/40"
          >
            <Trophy className="w-5 h-5 text-amber-400" />
            TROPHÉES
          </button>

          <button
            onClick={() => {
              audio.playClick();
              triggerHaptic(20);
              onOpenSettings();
            }}
            className="py-3 rounded-2xl bg-slate-900/80 hover:bg-slate-800 backdrop-blur-md border border-white/15 text-white font-black text-xs uppercase tracking-wider flex flex-col items-center justify-center gap-1 active:scale-95 transition-all shadow-xl shadow-black/40"
          >
            <Settings className="w-5 h-5 text-slate-300" />
            OPTIONS
          </button>
        </div>
      </div>
    </div>
  );
};
