import { IconAlert, IconCheck, IconInfo } from '../components/icons';
import { Button, ScreenHeader } from '../components/ui/primitives';
import { useApp } from '../context/AppContext';
import { DEMO_CONDITIONS } from '../data/mockData';

export function ConditionsScreen() {
  const { back, navigate } = useApp();
  const confirm = DEMO_CONDITIONS.filter((c) => c.kind === 'confirm');
  const risk = DEMO_CONDITIONS.filter((c) => c.kind === 'risk');
  const inv = DEMO_CONDITIONS.filter((c) => c.kind === 'invalidate');

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <ScreenHeader title="Conditions et alertes" onBack={back} />

      <div className="min-h-0 flex-1 overflow-y-auto px-4 pb-3">
        <section className="mb-4 rounded-2xl border border-white/5 bg-[#101c31] p-4">
          <h3 className="mb-3 text-[14px] font-semibold text-white">Confirmation haussière</h3>
          <ul className="space-y-2.5">
            {confirm.map((c) => (
              <li key={c.id} className="flex items-start gap-2 text-[13px] text-slate-200">
                <span className="mt-0.5 flex h-5 w-5 items-center justify-center rounded-full bg-emerald-500/20 text-emerald-400">
                  <IconCheck size={12} />
                </span>
                <span>
                  {c.label}
                  {c.detail ? <span className="text-slate-400"> {c.detail}</span> : null}
                </span>
              </li>
            ))}
          </ul>
        </section>

        <section className="mb-4 rounded-2xl border border-white/5 bg-[#101c31] p-4">
          <h3 className="mb-3 text-[14px] font-semibold text-rose-400">Risque de baisse</h3>
          <ul className="space-y-2.5">
            {risk.map((c) => (
              <li key={c.id} className="flex items-start gap-2 text-[13px] text-slate-200">
                <span className="mt-0.5 text-rose-400">
                  <IconAlert size={16} />
                </span>
                <span>
                  {c.label}
                  {c.detail ? <span className="text-slate-400"> {c.detail}</span> : null}
                </span>
              </li>
            ))}
          </ul>
        </section>

        <section className="mb-4 rounded-2xl border border-white/5 bg-[#101c31] p-4">
          <h3 className="mb-3 text-[14px] font-semibold text-white">Invalide l’analyse</h3>
          <ul className="space-y-2.5">
            {inv.map((c) => (
              <li key={c.id} className="flex items-start gap-2 text-[13px] text-slate-200">
                <span className="mt-0.5 text-slate-400">
                  <IconInfo size={16} />
                </span>
                {c.label}
              </li>
            ))}
          </ul>
        </section>
      </div>

      <div className="px-5 pb-3">
        <Button variant="outline" onClick={() => navigate('backtest')}>
          <span className="mr-2 opacity-70">⌗</span> Détails techniques
        </Button>
      </div>
    </div>
  );
}
