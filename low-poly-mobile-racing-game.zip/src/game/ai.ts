import { clamp, wrapAngle } from "./math";
import type { BuiltTrack, CarState, InputState } from "./types";

export function aiInput(car: CarState, track: BuiltTrack, time: number): InputState {
  const ai = car.ai;
  if (!ai) return { steer: 0, throttle: 0, brake: 0, nitro: false };

  const n = track.points.length;
  const look = Math.floor(ai.look + car.speed * 0.32);
  const idx = (car.trackIndex + look) % n;
  const tgt = track.points[idx];
  const nor = track.normals[idx];
  const sway = Math.sin(time * (0.7 + ai.skill) + ai.offset) * 1.2;
  const tx = tgt.x + nor.x * (ai.offset + sway);
  const tz = tgt.z + nor.z * (ai.offset + sway);

  const desired = Math.atan2(tx - car.x, tz - car.z);
  const diff = wrapAngle(desired - car.heading);
  let steer = clamp(diff * 1.55, -1, 1);

  const p = track.points[car.trackIndex];
  const cn = track.normals[car.trackIndex];
  const offset = (car.x - p.x) * cn.x + (car.z - p.z) * cn.z;
  if (Math.abs(offset) > track.width * 0.22) {
    steer += -Math.sign(offset) * 0.7;
    steer = clamp(steer, -1, 1);
  }

  let turn = 0;
  for (let k = 6; k <= 22; k += 4) {
    const i0 = (car.trackIndex + k) % n;
    const i1 = (car.trackIndex + k + 4) % n;
    const a = Math.atan2(track.tangents[i0].x, track.tangents[i0].z);
    const b = Math.atan2(track.tangents[i1].x, track.tangents[i1].z);
    turn += Math.abs(wrapAngle(a - b));
  }

  let throttle = 1;
  let brake = 0;
  const corner = turn * (0.7 + (1 - ai.skill) * 0.5);
  if (corner > 0.55 && car.speed > 22 + ai.skill * 10) {
    throttle = 0.25;
    brake = clamp((corner - 0.45) * 0.8, 0, 0.75);
  } else if (corner > 0.32 && car.speed > 34) {
    throttle = 0.55;
  }

  const nitro = corner < 0.18 && car.speed > 18 && car.nitro > 35 && ai.aggression > 0.45 && Math.sin(time * 3 + ai.offset) > 0.15;

  return { steer, throttle, brake, nitro };
}
