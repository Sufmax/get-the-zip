import { useEffect, useState } from 'react';
import { AssetGlyph } from '../components/icons';
import { ScreenHeader } from '../components/ui/primitives';
import { useApp } from '../context/AppContext';
import { marketApi } from '../services/api';
import type { Asset } from '../types';
import { formatPct, formatPrice } from '../utils/format';
import { cn } from '../utils/cn';

export function FavoritesScreen() {
  const { favorites, selectAsset, navigate, back } = useApp();
  const [assets, setAssets] = useState<Asset[]>([]);

  useEffect(() => {
    marketApi.listAssets().then((list) => setAssets(list.filter((a) => favorites.includes(a.id))));
  }, [favorites]);

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <ScreenHeader title="Favoris" onBack={back} />
      <div className="min-h-0 flex-1 overflow-y-auto px-3">
        {!assets.length && <p className="p-6 text-center text-sm text-slate-500">Aucun favori pour le moment.</p>}
        {assets.map((a) => (
          <button
            key={a.id}
            onClick={() => {
              selectAsset(a);
              navigate('chart');
            }}
            className="flex w-full items-center gap-3 rounded-2xl px-2 py-2.5"
          >
            <AssetGlyph symbol={a.symbol} />
            <div className="flex-1 text-left">
              <div className="text-[15px] font-semibold text-white">{a.symbol}</div>
              <div className="text-[12px] text-slate-500">{a.name}</div>
            </div>
            <div className="text-right">
              <div className="text-[14px] text-white">{formatPrice(a.price, a.decimals, a.quoteCurrency)}</div>
              <div className={cn('text-[12px]', a.change24h >= 0 ? 'text-emerald-400' : 'text-rose-400')}>
                {formatPct(a.change24h)}
              </div>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}

export function HistoryScreen() {
  const { matches, selectMatch, navigate, back } = useApp();
  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <ScreenHeader title="Historique" onBack={back} />
      <div className="min-h-0 flex-1 overflow-y-auto px-4">
        {!matches.length && (
          <p className="p-6 text-center text-sm text-slate-500">
            Aucune analyse récente. Lancez une recherche depuis un graphique.
          </p>
        )}
        {matches.map((m) => (
          <button
            key={m.id}
            onClick={() => {
              selectMatch(m);
              navigate('matchDetail');
            }}
            className="mb-2 flex w-full items-center justify-between rounded-2xl border border-white/5 bg-[#101c31] px-4 py-3"
          >
            <span className="text-[14px] text-white">
              #{m.rank} · {m.dateShort}
            </span>
            <span className="text-[14px] font-semibold text-emerald-400">{m.score.toFixed(1).replace('.', ',')}/10</span>
          </button>
        ))}
      </div>
    </div>
  );
}
