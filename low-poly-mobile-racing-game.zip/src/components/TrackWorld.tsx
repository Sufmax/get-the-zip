import { useLayoutEffect, useMemo, useRef } from "react";
import {
  CanvasTexture,
  Color,
  DoubleSide,
  InstancedMesh,
  Object3D,
  RepeatWrapping,
  SRGBColorSpace,
  type Group,
} from "three";
import type { BuiltTrack, Decoration } from "../game/types";

function makeRoadTexture() {
  const c = document.createElement("canvas");
  c.width = 128;
  c.height = 256;
  const ctx = c.getContext("2d")!;
  ctx.fillStyle = "#2c2d33";
  ctx.fillRect(0, 0, 128, 256);
  for (let i = 0; i < 1800; i++) {
    ctx.fillStyle = `rgba(255,255,255,${Math.random() * 0.055})`;
    ctx.fillRect(Math.random() * 128, Math.random() * 256, 2, 2);
  }
  ctx.fillStyle = "#ececec";
  ctx.fillRect(0, 0, 7, 256);
  ctx.fillRect(121, 0, 7, 256);
  ctx.fillStyle = "#efd247";
  for (let y = 0; y < 256; y += 32) ctx.fillRect(61, y, 6, 18);
  const tex = new CanvasTexture(c);
  tex.wrapS = RepeatWrapping;
  tex.wrapT = RepeatWrapping;
  tex.anisotropy = 8;
  tex.colorSpace = SRGBColorSpace;
  tex.needsUpdate = true;
  return tex;
}

function Road({ track }: { track: BuiltTrack }) {
  const geo = useMemo(() => {
    const pts = track.points;
    const n = pts.length;
    const hw = track.width / 2;
    const positions: number[] = [];
    const uvs: number[] = [];
    const normals: number[] = [];
    for (let i = 0; i < n; i++) {
      const i2 = (i + 1) % n;
      const p1 = pts[i];
      const p2 = pts[i2];
      const n1 = track.normals[i];
      const n2 = track.normals[i2];
      const l1x = p1.x + n1.x * hw;
      const l1z = p1.z + n1.z * hw;
      const r1x = p1.x - n1.x * hw;
      const r1z = p1.z - n1.z * hw;
      const l2x = p2.x + n2.x * hw;
      const l2z = p2.z + n2.z * hw;
      const r2x = p2.x - n2.x * hw;
      const r2z = p2.z - n2.z * hw;
      const v1 = track.cumlen[i] / 14;
      const v2 = (i2 === 0 ? track.length : track.cumlen[i2]) / 14;
      const tri = [
        [l1x, 0.04, l1z, 0, v1],
        [r1x, 0.04, r1z, 1, v1],
        [r2x, 0.04, r2z, 1, v2],
        [l1x, 0.04, l1z, 0, v1],
        [r2x, 0.04, r2z, 1, v2],
        [l2x, 0.04, l2z, 0, v2],
      ];
      for (const t of tri) {
        positions.push(t[0], t[1], t[2]);
        uvs.push(t[3], t[4]);
        normals.push(0, 1, 0);
      }
    }
    return { positions: new Float32Array(positions), uvs: new Float32Array(uvs), normals: new Float32Array(normals) };
  }, [track]);

  const tex = useMemo(() => makeRoadTexture(), []);

  const curb = useMemo(() => {
    const pts = track.points;
    const n = pts.length;
    const inner = track.width / 2;
    const outer = inner + 0.85;
    const positions: number[] = [];
    const colors: number[] = [];
    const red = new Color("#e23b3b");
    const white = new Color("#f4f4f4");
    for (const side of [1, -1]) {
      for (let i = 0; i < n; i++) {
        const i2 = (i + 1) % n;
        const p1 = pts[i];
        const p2 = pts[i2];
        const n1 = track.normals[i];
        const n2 = track.normals[i2];
        const a1x = p1.x + n1.x * inner * side;
        const a1z = p1.z + n1.z * inner * side;
        const b1x = p1.x + n1.x * outer * side;
        const b1z = p1.z + n1.z * outer * side;
        const a2x = p2.x + n2.x * inner * side;
        const a2z = p2.z + n2.z * inner * side;
        const b2x = p2.x + n2.x * outer * side;
        const b2z = p2.z + n2.z * outer * side;
        const stripe = Math.floor(track.cumlen[i] / 2.2) % 2 === 0;
        const col = stripe ? red : white;
        const h = 0.12;
        const verts = [
          [a1x, h, a1z],
          [b1x, h, b1z],
          [b2x, h, b2z],
          [a1x, h, a1z],
          [b2x, h, b2z],
          [a2x, h, a2z],
        ];
        for (const v of verts) {
          positions.push(v[0], v[1], v[2]);
          colors.push(col.r, col.g, col.b);
        }
      }
    }
    return { positions: new Float32Array(positions), colors: new Float32Array(colors) };
  }, [track]);

  const wall = useMemo(() => {
    const pts = track.points;
    const n = pts.length;
    const inner = track.width / 2 + 1.15;
    const positions: number[] = [];
    const colors: number[] = [];
    const col = new Color(track.theme === "city" ? "#3a2a66" : track.theme === "desert" ? "#c9a06a" : "#dfe6ee");
    const col2 = col.clone().multiplyScalar(0.72);
    for (const side of [1, -1]) {
      for (let i = 0; i < n; i++) {
        const i2 = (i + 1) % n;
        const p1 = pts[i];
        const p2 = pts[i2];
        const n1 = track.normals[i];
        const n2 = track.normals[i2];
        const a1x = p1.x + n1.x * inner * side;
        const a1z = p1.z + n1.z * inner * side;
        const a2x = p2.x + n2.x * inner * side;
        const a2z = p2.z + n2.z * inner * side;
        const h = track.theme === "city" ? 1.35 : 0.55;
        const verts = [
          [a1x, 0, a1z],
          [a1x, h, a1z],
          [a2x, h, a2z],
          [a1x, 0, a1z],
          [a2x, h, a2z],
          [a2x, 0, a2z],
        ];
        const c = i % 2 === 0 ? col : col2;
        for (const v of verts) {
          positions.push(v[0], v[1], v[2]);
          colors.push(c.r, c.g, c.b);
        }
      }
    }
    return { positions: new Float32Array(positions), colors: new Float32Array(colors) };
  }, [track]);

  return (
    <group>
      <mesh>
        <bufferGeometry>
          <bufferAttribute attach="attributes-position" args={[geo.positions, 3]} />
          <bufferAttribute attach="attributes-uv" args={[geo.uvs, 2]} />
          <bufferAttribute attach="attributes-normal" args={[geo.normals, 3]} />
        </bufferGeometry>
        <meshLambertMaterial map={tex} />
      </mesh>
      <mesh>
        <bufferGeometry onUpdate={(g) => g.computeVertexNormals()}>
          <bufferAttribute attach="attributes-position" args={[curb.positions, 3]} />
          <bufferAttribute attach="attributes-color" args={[curb.colors, 3]} />
        </bufferGeometry>
        <meshLambertMaterial vertexColors />
      </mesh>
      <mesh>
        <bufferGeometry onUpdate={(g) => g.computeVertexNormals()}>
          <bufferAttribute attach="attributes-position" args={[wall.positions, 3]} />
          <bufferAttribute attach="attributes-color" args={[wall.colors, 3]} />
        </bufferGeometry>
        <meshLambertMaterial vertexColors side={DoubleSide} />
      </mesh>
    </group>
  );
}

function Finish({ track }: { track: BuiltTrack }) {
  const p = track.points[0];
  const t = track.tangents[0];
  const n = track.normals[0];
  const rot = Math.atan2(t.x, t.z);
  return (
    <group position={[p.x, 0, p.z]} rotation={[0, rot, 0]}>
      <mesh position={[track.width / 2 + 0.6, 2.4, 0]}>
        <boxGeometry args={[0.18, 4.8, 0.18]} />
        <meshLambertMaterial color="#f2f2f2" flatShading />
      </mesh>
      <mesh position={[-track.width / 2 - 0.6, 2.4, 0]}>
        <boxGeometry args={[0.18, 4.8, 0.18]} />
        <meshLambertMaterial color="#f2f2f2" flatShading />
      </mesh>
      <mesh position={[0, 4.7, 0]}>
        <boxGeometry args={[track.width + 1.6, 0.7, 0.18]} />
        <meshLambertMaterial color="#111" flatShading />
      </mesh>
      <mesh position={[0, 0.05, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <planeGeometry args={[track.width, 3.2]} />
        <meshBasicMaterial color="#222" transparent opacity={0.35} />
      </mesh>
      {Array.from({ length: 8 }).map((_, i) => (
        <mesh key={i} position={[-track.width / 2 + 1.2 + i * ((track.width - 0.4) / 8), 4.7, 0.12]}>
          <boxGeometry args={[track.width / 10, 0.5, 0.06]} />
          <meshBasicMaterial color={i % 2 === 0 ? "#fff" : "#111"} />
        </mesh>
      ))}
      <mesh position={[n.x * 0, 0, 0]} visible={false}>
        <boxGeometry args={[0.01, 0.01, 0.01]} />
        <meshBasicMaterial />
      </mesh>
    </group>
  );
}

function InstancedKind({
  items,
  geometry,
  color,
  yLift = 0,
  emissive,
}: {
  items: Decoration[];
  geometry: "cone" | "box" | "cyl" | "sphere";
  color: string;
  yLift?: number;
  emissive?: string;
}) {
  const ref = useRef<InstancedMesh>(null);
  useLayoutEffect(() => {
    if (!ref.current) return;
    const dummy = new Object3D();
    items.forEach((it, i) => {
      dummy.position.set(it.x, yLift * it.scale, it.z);
      dummy.rotation.set(0, it.rot, 0);
      dummy.scale.setScalar(it.scale);
      dummy.updateMatrix();
      ref.current!.setMatrixAt(i, dummy.matrix);
    });
    ref.current.instanceMatrix.needsUpdate = true;
  }, [items, yLift]);
  if (items.length === 0) return null;
  return (
    <instancedMesh ref={ref} args={[undefined, undefined, items.length]}>
      {geometry === "cone" && <coneGeometry args={[1, 2.4, 6]} />}
      {geometry === "box" && <boxGeometry args={[1, 1, 1]} />}
      {geometry === "cyl" && <cylinderGeometry args={[0.18, 0.22, 1.6, 6]} />}
      {geometry === "sphere" && <sphereGeometry args={[0.7, 6, 5]} />}
      <meshLambertMaterial color={color} emissive={emissive ?? "#000"} emissiveIntensity={emissive ? 0.6 : 0} flatShading />
    </instancedMesh>
  );
}

function Palms({ items }: { items: Decoration[] }) {
  const trunk = useRef<InstancedMesh>(null);
  const leaf = useRef<InstancedMesh>(null);
  useLayoutEffect(() => {
    if (!trunk.current || !leaf.current) return;
    const dummy = new Object3D();
    items.forEach((it, i) => {
      dummy.position.set(it.x, 1.5 * it.scale, it.z);
      dummy.rotation.set(0, it.rot, 0);
      dummy.scale.set(it.scale, it.scale * 1.4, it.scale);
      dummy.updateMatrix();
      trunk.current!.setMatrixAt(i, dummy.matrix);
      dummy.position.set(it.x, 3.1 * it.scale, it.z);
      dummy.scale.set(it.scale * 1.6, it.scale * 1.1, it.scale * 1.6);
      dummy.updateMatrix();
      leaf.current!.setMatrixAt(i, dummy.matrix);
    });
    trunk.current.instanceMatrix.needsUpdate = true;
    leaf.current.instanceMatrix.needsUpdate = true;
  }, [items]);
  if (!items.length) return null;
  return (
    <group>
      <instancedMesh ref={trunk} args={[undefined, undefined, items.length]}>
        <cylinderGeometry args={[0.12, 0.22, 3, 5]} />
        <meshLambertMaterial color="#8a5a32" flatShading />
      </instancedMesh>
      <instancedMesh ref={leaf} args={[undefined, undefined, items.length]}>
        <coneGeometry args={[1.1, 1.6, 5]} />
        <meshLambertMaterial color="#2f9e4a" flatShading />
      </instancedMesh>
    </group>
  );
}

function Pines({ items }: { items: Decoration[] }) {
  const trunk = useRef<InstancedMesh>(null);
  const leaf = useRef<InstancedMesh>(null);
  const leaf2 = useRef<InstancedMesh>(null);
  useLayoutEffect(() => {
    if (!trunk.current || !leaf.current || !leaf2.current) return;
    const dummy = new Object3D();
    items.forEach((it, i) => {
      dummy.position.set(it.x, 0.7 * it.scale, it.z);
      dummy.rotation.set(0, it.rot, 0);
      dummy.scale.set(it.scale, it.scale, it.scale);
      dummy.updateMatrix();
      trunk.current!.setMatrixAt(i, dummy.matrix);
      dummy.position.set(it.x, 2.4 * it.scale, it.z);
      dummy.scale.set(it.scale * 1.3, it.scale * 1.6, it.scale * 1.3);
      dummy.updateMatrix();
      leaf.current!.setMatrixAt(i, dummy.matrix);
      dummy.position.set(it.x, 3.5 * it.scale, it.z);
      dummy.scale.set(it.scale * 0.95, it.scale * 1.3, it.scale * 0.95);
      dummy.updateMatrix();
      leaf2.current!.setMatrixAt(i, dummy.matrix);
    });
    trunk.current.instanceMatrix.needsUpdate = true;
    leaf.current.instanceMatrix.needsUpdate = true;
    leaf2.current.instanceMatrix.needsUpdate = true;
  }, [items]);
  if (!items.length) return null;
  return (
    <group>
      <instancedMesh ref={trunk} args={[undefined, undefined, items.length]}>
        <cylinderGeometry args={[0.16, 0.24, 1.6, 5]} />
        <meshLambertMaterial color="#5a3a22" flatShading />
      </instancedMesh>
      <instancedMesh ref={leaf} args={[undefined, undefined, items.length]}>
        <coneGeometry args={[1.1, 2.4, 6]} />
        <meshLambertMaterial color="#1f7a38" flatShading />
      </instancedMesh>
      <instancedMesh ref={leaf2} args={[undefined, undefined, items.length]}>
        <coneGeometry args={[0.85, 2, 6]} />
        <meshLambertMaterial color="#259445" flatShading />
      </instancedMesh>
    </group>
  );
}

function Buildings({ items }: { items: Decoration[] }) {
  const ref = useRef<InstancedMesh>(null);
  const neon = useRef<InstancedMesh>(null);
  useLayoutEffect(() => {
    if (!ref.current || !neon.current) return;
    const dummy = new Object3D();
    items.forEach((it, i) => {
      dummy.position.set(it.x, it.h * 0.5 * it.scale * 0.35, it.z);
      dummy.rotation.set(0, it.rot, 0);
      dummy.scale.set(4 * it.scale, it.h * it.scale * 0.35, 4 * it.scale);
      dummy.updateMatrix();
      ref.current!.setMatrixAt(i, dummy.matrix);
      dummy.position.set(it.x, it.h * it.scale * 0.35 + 0.2, it.z);
      dummy.scale.set(4.05 * it.scale, 0.12, 4.05 * it.scale);
      dummy.updateMatrix();
      neon.current!.setMatrixAt(i, dummy.matrix);
    });
    ref.current.instanceMatrix.needsUpdate = true;
    neon.current.instanceMatrix.needsUpdate = true;
  }, [items]);
  if (!items.length) return null;
  return (
    <group>
      <instancedMesh ref={ref} args={[undefined, undefined, items.length]}>
        <boxGeometry args={[1, 1, 1]} />
        <meshLambertMaterial color="#1a1430" flatShading />
      </instancedMesh>
      <instancedMesh ref={neon} args={[undefined, undefined, items.length]}>
        <boxGeometry args={[1, 1, 1]} />
        <meshBasicMaterial color="#ff4ad8" />
      </instancedMesh>
    </group>
  );
}

function Lamps({ items }: { items: Decoration[] }) {
  const pole = useRef<InstancedMesh>(null);
  const bulb = useRef<InstancedMesh>(null);
  useLayoutEffect(() => {
    if (!pole.current || !bulb.current) return;
    const dummy = new Object3D();
    items.forEach((it, i) => {
      dummy.position.set(it.x, 2.1, it.z);
      dummy.rotation.set(0, it.rot, 0);
      dummy.scale.set(1, 1, 1);
      dummy.updateMatrix();
      pole.current!.setMatrixAt(i, dummy.matrix);
      dummy.position.set(it.x, 4.15, it.z);
      dummy.scale.setScalar(1);
      dummy.updateMatrix();
      bulb.current!.setMatrixAt(i, dummy.matrix);
    });
    pole.current.instanceMatrix.needsUpdate = true;
    bulb.current.instanceMatrix.needsUpdate = true;
  }, [items]);
  if (!items.length) return null;
  return (
    <group>
      <instancedMesh ref={pole} args={[undefined, undefined, items.length]}>
        <cylinderGeometry args={[0.07, 0.1, 4.2, 5]} />
        <meshLambertMaterial color="#2a2a33" flatShading />
      </instancedMesh>
      <instancedMesh ref={bulb} args={[undefined, undefined, items.length]}>
        <sphereGeometry args={[0.22, 6, 4]} />
        <meshBasicMaterial color="#ffe18a" />
      </instancedMesh>
    </group>
  );
}

function Sky({ top, bot }: { top: string; bot: string }) {
  const mat = useMemo(() => {
    const t = new Color(top);
    const b = new Color(bot);
    return { t, b };
  }, [top, bot]);
  return (
    <mesh scale={[-1, 1, 1]}>
      <sphereGeometry args={[780, 16, 12]} />
      <shaderMaterial
        side={DoubleSide}
        uniforms={{ top: { value: mat.t }, bot: { value: mat.b } }}
        vertexShader={`varying vec3 vP; void main(){ vP = position; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }`}
        fragmentShader={`uniform vec3 top; uniform vec3 bot; varying vec3 vP; void main(){ float h = normalize(vP).y; vec3 c = mix(bot, top, smoothstep(-0.15, 0.72, h)); gl_FragColor = vec4(c, 1.0); }`}
      />
    </mesh>
  );
}

export function TrackWorld({ track, quality }: { track: BuiltTrack; quality: "high" | "low" }) {
  const group = useRef<Group>(null);
  const decos = quality === "low" ? track.decorations.filter((_, i) => i % 2 === 0) : track.decorations;
  const palms = decos.filter((d) => d.kind === "palm");
  const pines = decos.filter((d) => d.kind === "pine");
  const rocks = decos.filter((d) => d.kind === "rock");
  const cactus = decos.filter((d) => d.kind === "cactus");
  const buildings = decos.filter((d) => d.kind === "building");
  const lamps = decos.filter((d) => d.kind === "lamp");
  const signs = decos.filter((d) => d.kind === "sign");

  return (
    <group ref={group}>
      <Sky top={track.skyTop} bot={track.skyBot} />
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.02, 0]} receiveShadow>
        <planeGeometry args={[1800, 1800]} />
        <meshLambertMaterial color={track.ground} />
      </mesh>
      {track.theme === "coast" && (
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.4, 0]}>
          <planeGeometry args={[2200, 2200]} />
          <meshLambertMaterial color="#1e8ad8" />
        </mesh>
      )}
      <Road track={track} />
      <Finish track={track} />
      <Palms items={palms} />
      <Pines items={pines} />
      <InstancedKind items={rocks} geometry="sphere" color="#b88448" yLift={0.6} />
      <InstancedKind items={cactus} geometry="cyl" color="#2f8a3a" yLift={0.8} />
      <Buildings items={buildings} />
      <Lamps items={lamps} />
      <InstancedKind items={signs} geometry="box" color="#ff3d6e" yLift={1.2} emissive="#ff3d6e" />
      {track.mountains.map((m, i) => (
        <mesh key={i} position={[m.x, m.h * 0.35, m.z]}>
          <coneGeometry args={[m.s, m.h, 5]} />
          <meshLambertMaterial color={m.color} flatShading />
        </mesh>
      ))}
    </group>
  );
}
