import React, { useState } from 'react';
import { GameMode, TrackId, PlayerProgress } from '../types/game';
import { TRACKS_CATALOG } from '../game/tracksData';
import { audio } from '../services/audio';
import { triggerHaptic } from '../services/storage';
import { ArrowLeft, Flag, Trophy, Timer, Disc, Flame, Play, Mountain, Sun, Snowflake, Building2 } from 'lucide-react';

interface TrackSelectModalProps {
  progress: PlayerProgress;
  onStartRace: (mode: GameMode, trackId: TrackId) => void;
  onClose: () => void;
}

export const TrackSelectModal: React.FC<TrackSelectModalProps> = ({
  progress,
  onStartRace,
  onClose,
}) => {
  const [selectedMode, setSelectedMode] = useState<GameMode>('quick_race');
  const [selectedTrackId, setSelectedTrackId] = useState<TrackId>('cyber_highway');

  const modes: { id: GameMode; title: string; desc: string; icon: any }[] = [
    {
      id: 'quick_race',
      title: 'Course Rapide',
      desc: 'Affrontez 5 pilotes IA sur le circuit de votre choix.',
      icon: Flag,
    },
    {
      id: 'career',
      title: 'Championnat',
      desc: 'Remportez la coupe et gagnez de gros prix en crédits.',
      icon: Trophy,
    },
    {
      id: 'time_trial',
      title: 'Contre-la-montre',
      desc: 'Battez le record au tour sans adversaires sur la piste.',
      icon: Timer,
    },
    {
      id: 'drift_mode',
      title: 'Défi Drift',
      desc: 'Enchaînez les glissades et scorez un maximum de points.',
      icon: Disc,
    },
    {
      id: 'endless_traffic',
      title: 'Trafic Infini',
      desc: 'Autoroute sans fin à haute vitesse. Évitez le trafic !',
      icon: Flame,
    },
  ];

  const getThemeIcon = (theme: string) => {
    switch (theme) {
      case 'cyber':
        return <Building2 className="w-5 h-5 text-cyan-400" />;
      case 'desert':
        return <Sun className="w-5 h-5 text-amber-400" />;
      case 'snow':
        return <Snowflake className="w-5 h-5 text-sky-300" />;
      case 'sunset':
        return <Mountain className="w-5 h-5 text-rose-400" />;
      default:
        return <Flag className="w-5 h-5 text-white" />;
    }
  };

  const handleLaunch = () => {
    audio.playClick();
    triggerHaptic(40);
    onStartRace(selectedMode, selectedTrackId);
  };

  return (
    <div className="fixed inset-0 z-40 bg-slate-950 text-white flex flex-col overflow-hidden">
      {/* Top Header */}
      <div className="flex justify-between items-center px-4 py-3 bg-slate-900/90 border-b border-white/10 z-10">
        <button
          onClick={() => {
            audio.playClick();
            onClose();
          }}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 border border-white/10 text-slate-300 active:scale-95 transition-transform"
        >
          <ArrowLeft className="w-4 h-4" />
          <span className="text-xs font-black uppercase tracking-wider">RETOUR</span>
        </button>

        <div className="text-center">
          <span className="text-[10px] font-black uppercase tracking-widest text-cyan-400 block -mb-0.5">
            SÉLECTION DE COURSE
          </span>
          <h1 className="text-base md:text-lg font-black uppercase italic tracking-tight text-white">
            MODES & CIRCUITS
          </h1>
        </div>

        <div className="w-16"></div>
      </div>

      <div className="flex-1 flex flex-col md:flex-row overflow-y-auto p-4 gap-6 max-w-6xl mx-auto w-full">
        {/* Left: Game Mode Selector */}
        <div className="w-full md:w-1/2 flex flex-col gap-3">
          <h2 className="text-xs font-black uppercase tracking-wider text-cyan-400 flex items-center gap-2">
            <Flag className="w-4 h-4" /> 1. CHOISIR LE MODE DE JEU
          </h2>

          <div className="flex flex-col gap-2.5">
            {modes.map((m) => {
              const Icon = m.icon;
              const isSel = selectedMode === m.id;
              return (
                <button
                  key={m.id}
                  onClick={() => {
                    audio.playClick();
                    triggerHaptic(20);
                    setSelectedMode(m.id);
                  }}
                  className={`flex items-start gap-3.5 p-3.5 rounded-2xl border text-left transition-all ${
                    isSel
                      ? 'bg-gradient-to-r from-cyan-900/60 to-slate-900/90 border-cyan-400 shadow-xl shadow-cyan-950/50 scale-[1.01]'
                      : 'bg-slate-900/70 border-white/10 hover:border-white/20'
                  }`}
                >
                  <div
                    className={`w-11 h-11 rounded-xl flex items-center justify-center shrink-0 ${
                      isSel ? 'bg-cyan-500 text-slate-950' : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    <Icon className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-sm font-black uppercase tracking-tight text-white">
                      {m.title}
                    </h3>
                    <p className="text-xs text-slate-400 leading-relaxed mt-0.5">
                      {m.desc}
                    </p>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right: Track Selector (or Traffic preview if endless) */}
        <div className="w-full md:w-1/2 flex flex-col gap-3">
          <h2 className="text-xs font-black uppercase tracking-wider text-cyan-400 flex items-center gap-2">
            <Mountain className="w-4 h-4" /> 2. CHOISIR LE CIRCUIT
          </h2>

          {selectedMode === 'endless_traffic' ? (
            <div className="p-6 rounded-2xl bg-slate-900 border border-cyan-500/40 flex flex-col items-center justify-center text-center gap-3">
              <div className="w-16 h-16 rounded-2xl bg-cyan-500/20 border border-cyan-400/40 flex items-center justify-center text-cyan-400">
                <Flame className="w-8 h-8 animate-bounce" />
              </div>
              <h3 className="text-lg font-black uppercase tracking-tight text-white">
                Autoroute Apex Express
              </h3>
              <p className="text-xs text-slate-300 max-w-sm">
                4 voies rectilignes infinies. Slalomez entre les camions et berlines à plus de 250 km/h. Chaque frôlement vous octroie un boost et un multiplicateur de score !
              </p>
              {progress.endlessHighScore > 0 && (
                <div className="px-4 py-2 rounded-xl bg-slate-950 border border-amber-400/40 text-amber-300 text-xs font-black">
                  MEILLEURE DISTANCE : {progress.endlessHighScore.toLocaleString()} m
                </div>
              )}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {TRACKS_CATALOG.map((track) => {
                const isSel = selectedTrackId === track.id;
                const bestLap = progress.bestLaps[track.id];

                return (
                  <button
                    key={track.id}
                    onClick={() => {
                      audio.playClick();
                      triggerHaptic(20);
                      setSelectedTrackId(track.id);
                    }}
                    className={`flex flex-col p-3.5 rounded-2xl border text-left transition-all ${
                      isSel
                        ? 'bg-gradient-to-b from-cyan-950/70 to-slate-900 border-cyan-400 shadow-xl shadow-cyan-950/40 scale-[1.02]'
                        : 'bg-slate-900/70 border-white/10 hover:border-white/20'
                    }`}
                  >
                    <div className="flex justify-between items-start mb-2">
                      <div className="flex items-center gap-2">
                        {getThemeIcon(track.theme)}
                        <span className="text-xs font-black uppercase text-white">
                          {track.nameFr}
                        </span>
                      </div>
                      <span
                        className={`text-[9px] font-black uppercase px-2 py-0.5 rounded ${
                          track.difficulty === 'Facile'
                            ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                            : track.difficulty === 'Moyen'
                            ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/30'
                            : track.difficulty === 'Difficile'
                            ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                            : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                        }`}
                      >
                        {track.difficulty}
                      </span>
                    </div>

                    <p className="text-[11px] text-slate-400 mb-2">
                      {track.subtitleFr}
                    </p>

                    <div className="mt-auto flex justify-between items-center text-[10px] font-mono text-slate-400 pt-2 border-t border-white/10">
                      <span>{track.lengthMeters} m</span>
                      {bestLap ? (
                        <span className="text-amber-400 font-bold">
                          PB: {bestLap.toFixed(2)}s
                        </span>
                      ) : (
                        <span>3 Tours</span>
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* Bottom Launch Button */}
      <div className="p-4 bg-slate-900/90 border-t border-white/10 flex justify-center">
        <button
          onClick={handleLaunch}
          className="w-full max-w-md py-4 rounded-2xl bg-gradient-to-r from-cyan-500 to-sky-400 hover:from-cyan-400 hover:to-sky-300 text-slate-950 font-black text-base uppercase tracking-widest flex items-center justify-center gap-3 shadow-xl shadow-cyan-500/30 active:scale-95 transition-all"
        >
          <Play className="w-5 h-5 fill-slate-950" />
          LANCER LA COURSE
        </button>
      </div>
    </div>
  );
};
