import { IconBook, IconBars, IconChart, IconChat, IconChevronRight, IconInfo, IconLayers, IconPhone, IconRefresh, LogoMark } from '../components/icons';
import { ScreenHeader } from '../components/ui/primitives';
import { useApp } from '../context/AppContext';
import { DEMO_HELP } from '../data/mockData';
import { marketApi } from '../services/api';
import type { HelpArticle } from '../types';

const ICONS: Record<HelpArticle['icon'], typeof IconBook> = {
  book: IconBook,
  layers: IconLayers,
  grid: IconBars,
  star: IconInfo,
  chart: IconChart,
  chat: IconChat,
  phone: IconPhone,
};

export function HelpScreen() {
  const { back, navigate, setHelpArticleId, helpArticleId } = useApp();
  const article = DEMO_HELP.find((h) => h.id === helpArticleId);
  const ver = marketApi.version();

  if (article) {
    const Icon = ICONS[article.icon];
    return (
      <div className="flex min-h-0 flex-1 flex-col">
        <ScreenHeader
          title={article.title}
          onBack={() => setHelpArticleId(null)}
        />
        <div className="min-h-0 flex-1 overflow-y-auto px-5 pb-6">
          <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-[#15263d] text-cyan-300">
            <Icon size={22} />
          </div>
          {article.body.map((p) => (
            <p key={p} className="mb-3 text-[14px] leading-relaxed text-slate-300">
              {p}
            </p>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <ScreenHeader title="Aide (Détails)" onBack={back} />

      <div className="min-h-0 flex-1 overflow-y-auto px-4 pb-4">
        <div className="overflow-hidden rounded-2xl border border-white/5 bg-[#101c31]">
          {DEMO_HELP.map((h, i) => {
            const Icon = ICONS[h.icon];
            return (
              <button
                key={h.id}
                onClick={() => setHelpArticleId(h.id)}
                className={`flex w-full items-center gap-3 px-4 py-3.5 text-left ${
                  i < DEMO_HELP.length - 1 ? 'border-b border-white/5' : ''
                }`}
              >
                <span className="text-slate-400">
                  <Icon size={18} />
                </span>
                <span className="flex-1 text-[14px] text-white">{h.title}</span>
                <IconChevronRight className="text-slate-600" />
              </button>
            );
          })}
        </div>

        <button
          onClick={() => navigate('welcome')}
          className="mt-4 flex w-full items-center gap-3 rounded-2xl border border-white/5 bg-[#101c31] px-4 py-3.5"
        >
          <LogoMark size={36} />
          <div className="flex-1 text-left">
            <div className="text-[14px] font-medium text-white">Version de l’application</div>
            <div className="text-[12px] text-slate-400">Version {ver.version}</div>
            <div className="text-[11px] text-slate-500">Dernière mise à jour : {ver.updatedAt}</div>
          </div>
          <IconRefresh className="text-slate-500" size={16} />
          <IconChevronRight className="text-slate-600" />
        </button>
      </div>
    </div>
  );
}
