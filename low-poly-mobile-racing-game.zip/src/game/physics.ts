import { AI_NAMES, CARS, getCar } from "./cars";
import { clamp } from "./math";
import { pointAt } from "./tracks";
import type { BuiltTrack, CarDef, CarState, HudSnapshot, InputState, RaceResults, RaceState } from "./types";
import { aiInput } from "./ai";

const SECTORS = 10;

export function createRace(track: BuiltTrack, playerCarId: string): RaceState {
  const playerDef = getCar(playerCarId);
  const pool = CARS.filter((c) => c.id !== playerDef.id);
  for (let i = pool.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    const tmp = pool[i];
    pool[i] = pool[j];
    pool[j] = tmp;
  }

  const entries: { def: CarDef; isPlayer: boolean; skill: number; name: string }[] = [];
  const aiCount = 7;
  for (let i = 0; i < aiCount; i++) {
    entries.push({
      def: pool[i % pool.length],
      isPlayer: false,
      skill: 0.74 + Math.random() * 0.3,
      name: AI_NAMES[i % AI_NAMES.length],
    });
  }
  const playerSlot = 4;
  entries.splice(playerSlot, 0, { def: playerDef, isPlayer: true, skill: 1, name: "TOI" });

  const cars: CarState[] = entries.map((e, i) => {
    const row = Math.floor(i / 2);
    const col = i % 2 === 0 ? -3.4 : 3.4;
    const back = 8 + row * 6.8;
    const p = pointAt(track, track.length - back);
    const heading = Math.atan2(p.tx, p.tz);
    return {
      id: e.isPlayer ? "player" : `ai-${i}`,
      name: e.isPlayer ? "TOI" : e.name,
      isPlayer: e.isPlayer,
      def: e.def,
      x: p.x + p.nx * col,
      z: p.z + p.nz * col,
      heading,
      speed: 0,
      slip: 0,
      steerVis: 0,
      nitro: 70,
      boosting: false,
      trackIndex: p.i,
      sector: 0,
      lapsCompleted: 0,
      lapStart: 0,
      lapTimes: [],
      finished: false,
      finishTime: 0,
      wheelRot: 0,
      shake: 0,
      topSpeed: 0,
      ai: e.isPlayer
        ? null
        : {
            skill: e.skill,
            offset: (Math.random() - 0.5) * 5,
            aggression: 0.35 + Math.random() * 0.65,
            look: 10 + Math.random() * 10,
          },
    };
  });

  return {
    cars,
    time: 0,
    phase: "countdown",
    countdown: 3.4,
    totalLaps: track.laps,
    finishTimer: 0,
    ranks: cars.map((_, i) => i + 1),
    playerIndex: cars.findIndex((c) => c.isPlayer),
  };
}

function updateTrackIndex(car: CarState, track: BuiltTrack) {
  const n = track.points.length;
  let best = car.trackIndex;
  let bestD = 1e12;
  for (let k = -4; k <= 14; k++) {
    const i = (car.trackIndex + k + n * 4) % n;
    const dx = car.x - track.points[i].x;
    const dz = car.z - track.points[i].z;
    const d = dx * dx + dz * dz;
    if (d < bestD) {
      bestD = d;
      best = i;
    }
  }
  car.trackIndex = best;
}

function project(car: CarState, track: BuiltTrack) {
  const p = track.points[car.trackIndex];
  const n = track.normals[car.trackIndex];
  const dx = car.x - p.x;
  const dz = car.z - p.z;
  return { offset: dx * n.x + dz * n.z, nx: n.x, nz: n.z, px: p.x, pz: p.z };
}

function stepCar(car: CarState, input: InputState, track: BuiltTrack, dt: number, rubber: number) {
  const stats = car.def;
  if (car.finished) {
    car.speed = Math.max(0, car.speed - 18 * dt);
    car.x += Math.sin(car.heading) * car.speed * dt;
    car.z += Math.cos(car.heading) * car.speed * dt;
    car.boosting = false;
    return;
  }

  if (input.nitro && car.nitro > 0.5 && input.throttle > 0.2) {
    car.boosting = true;
    car.nitro = Math.max(0, car.nitro - 34 * dt);
  } else {
    car.boosting = false;
    car.nitro = Math.min(100, car.nitro + 9 * dt);
  }

  const boostMul = car.boosting ? stats.nitroPower : 1;
  const maxSpeed = stats.maxSpeed * boostMul * rubber;
  const grip = stats.grip * track.grip;

  if (input.brake > 0.1) {
    car.speed -= stats.brake * input.brake * dt;
  } else {
    const want = input.throttle * maxSpeed;
    if (car.speed < want) {
      car.speed += stats.accel * (0.35 + input.throttle) * boostMul * dt;
    } else {
      car.speed -= (6 + car.speed * 0.12) * dt;
    }
  }

  updateTrackIndex(car, track);
  const proj = project(car, track);
  const half = track.width / 2 - 1.05;
  const offAmt = Math.abs(proj.offset) - track.width / 2 + 1.6;
  if (offAmt > 0) {
    car.speed -= (12 + offAmt * 10) * dt;
    car.shake = Math.max(car.shake, 0.15);
  }

  if (Math.abs(proj.offset) > half) {
    const push = proj.offset - Math.sign(proj.offset) * half;
    car.x -= proj.nx * push;
    car.z -= proj.nz * push;
    car.speed *= 0.78;
    car.slip *= 0.4;
    car.shake = 0.55;
  }

  car.speed = clamp(car.speed, -maxSpeed * 0.25, maxSpeed);
  if (Math.abs(car.speed) < 0.15 && input.throttle < 0.05) car.speed = 0;

  const speedT = clamp(Math.abs(car.speed) / Math.max(1, stats.maxSpeed), 0, 1);
  const steerRate = stats.handling * lerp(1.85, 0.62, speedT) * (0.75 + grip * 0.28);
  const steerTarget = input.steer;
  car.steerVis = dampAngle(car.steerVis, steerTarget, 14, dt);

  const turn = car.steerVis * steerRate * (car.speed / 28) * dt * 2.35;
  car.heading += turn;

  const wantSlip =
    Math.abs(input.steer) > 0.62 && Math.abs(car.speed) > 20 && input.brake < 0.55
      ? input.steer * stats.drift * 0.85 * speedT
      : 0;
  car.slip += (wantSlip - car.slip) * Math.min(1, dt * (wantSlip ? 3.2 : 4 + grip * 5));

  const moveH = car.heading + car.slip * 0.42;
  car.x += Math.sin(moveH) * car.speed * dt;
  car.z += Math.cos(moveH) * car.speed * dt;
  car.wheelRot += car.speed * dt * 2.4;
  car.shake = Math.max(0, car.shake - dt * 1.8);
  if (car.speed > car.topSpeed) car.topSpeed = car.speed;

  const n = track.points.length;
  const sectorSize = n / SECTORS;
  const sector = Math.floor(car.trackIndex / sectorSize) % SECTORS;
  if (sector === (car.sector + 1) % SECTORS) {
    const wrapped = sector === 0 && car.sector === SECTORS - 1;
    car.sector = sector;
    if (wrapped) {
      const lt = Math.max(0, 0); // filled by caller time
      car.lapsCompleted += 1;
      car.lapTimes.push(lt);
      if (car.lapsCompleted >= track.laps) {
        car.finished = true;
        car.finishTime = 0;
      }
    }
  }

}

function dampAngle(a: number, b: number, lambda: number, dt: number) {
  return a + (b - a) * (1 - Math.exp(-lambda * dt));
}

function lerp(a: number, b: number, t: number) {
  return a + (b - a) * t;
}

function collideCars(cars: CarState[]) {
  const minDist = 2.35;
  for (let i = 0; i < cars.length; i++) {
    for (let j = i + 1; j < cars.length; j++) {
      const a = cars[i];
      const b = cars[j];
      const dx = b.x - a.x;
      const dz = b.z - a.z;
      const d2 = dx * dx + dz * dz;
      if (d2 > minDist * minDist || d2 < 1e-4) continue;
      const d = Math.sqrt(d2);
      const nx = dx / d;
      const nz = dz / d;
      const overlap = (minDist - d) * 0.5;
      a.x -= nx * overlap;
      a.z -= nz * overlap;
      b.x += nx * overlap;
      b.z += nz * overlap;
      const rel = (b.speed - a.speed) * 0.25;
      a.speed += rel;
      b.speed -= rel;
      a.speed *= 0.96;
      b.speed *= 0.96;
      a.shake = Math.max(a.shake, 0.25);
      b.shake = Math.max(b.shake, 0.25);
    }
  }
}

function computeRanks(cars: CarState[]) {
  const order = cars.map((_, i) => i);
  order.sort((ia, ib) => {
    const a = cars[ia];
    const b = cars[ib];
    if (a.finished && b.finished) return a.finishTime - b.finishTime;
    if (a.finished) return -1;
    if (b.finished) return 1;
    const pa = a.lapsCompleted * 100000 + a.trackIndex;
    const pb = b.lapsCompleted * 100000 + b.trackIndex;
    return pb - pa;
  });
  const ranks = new Array<number>(cars.length);
  order.forEach((ci, p) => {
    ranks[ci] = p + 1;
  });
  return ranks;
}

export function stepRace(
  game: RaceState,
  playerInput: InputState,
  track: BuiltTrack,
  dt: number,
  autoAccel: boolean,
) {
  dt = Math.min(dt, 0.04);
  if (game.phase === "countdown") {
    game.countdown -= dt;
    for (const car of game.cars) {
      car.steerVis += (0 - car.steerVis) * 6 * dt;
      if (car.isPlayer && playerInput.throttle > 0.5) {
        car.shake = 0.08;
      }
    }
    if (game.countdown <= 0) {
      game.phase = "racing";
      game.countdown = 0;
      game.time = 0;
      for (const car of game.cars) car.lapStart = 0;
    }
    game.ranks = computeRanks(game.cars);
    return;
  }

  if (game.phase === "racing") {
    game.time += dt;
  }

  const player = game.cars[game.playerIndex];
  const n = track.points.length;
  const playerProgress = player.lapsCompleted * n + player.trackIndex;

  for (const car of game.cars) {
    let input: InputState;
    if (car.isPlayer) {
      input = {
        steer: playerInput.steer,
        throttle: autoAccel && playerInput.brake < 0.2 ? 1 : playerInput.throttle,
        brake: playerInput.brake,
        nitro: playerInput.nitro,
      };
    } else {
      input = aiInput(car, track, game.time);
    }

    let rubber = 1;
    if (!car.isPlayer && car.ai) {
      const prog = car.lapsCompleted * n + car.trackIndex;
      const delta = playerProgress - prog;
      if (delta > 90) rubber = 1.16;
      else if (delta > 40) rubber = 1.07;
      else if (delta < -140) rubber = 0.9;
      else if (delta < -80) rubber = 0.95;
      rubber *= 0.9 + car.ai.skill * 0.14;
    }

    const prevLaps = car.lapsCompleted;
    const wasFinished = car.finished;
    stepCar(car, input, track, dt, rubber);

    if (car.lapsCompleted > prevLaps) {
      const lt = game.time - car.lapStart;
      car.lapTimes[car.lapTimes.length - 1] = lt;
      car.lapStart = game.time;
    }
    if (car.finished && !wasFinished) {
      car.finishTime = game.time;
    }
  }

  collideCars(game.cars);
  game.ranks = computeRanks(game.cars);

  if (player.finished && game.phase === "racing") {
    game.finishTimer += dt;
    const allDone = game.cars.every((c) => c.finished);
    if (allDone || game.finishTimer > 7) {
      game.phase = "finished";
    }
  }
}

export function snapshotHud(game: RaceState, track: BuiltTrack): HudSnapshot {
  const p = game.cars[game.playerIndex];
  const speedKmh = Math.abs(p.speed) * 4.6;
  const maxKmh = p.def.maxSpeed * 4.6 * p.def.nitroPower;
  const gear = Math.min(6, 1 + Math.floor(Math.abs(p.speed) / (p.def.maxSpeed / 5.2)));
  const inGear = (Math.abs(p.speed) % (p.def.maxSpeed / 5.2)) / (p.def.maxSpeed / 5.2);
  const rpm = p.boosting ? 0.85 + inGear * 0.15 : 0.15 + inGear * 0.8;
  const best = p.lapTimes.length ? Math.min(...p.lapTimes) : 0;
  return {
    speed: speedKmh,
    maxSpeed: maxKmh,
    nitro: p.nitro,
    boosting: p.boosting,
    rpm,
    gear,
    position: game.ranks[game.playerIndex],
    totalCars: game.cars.length,
    lap: Math.min(track.laps, p.lapsCompleted + 1),
    totalLaps: track.laps,
    lapTime: game.phase === "countdown" ? 0 : game.time - p.lapStart,
    bestLap: best,
    raceTime: game.time,
    drift: Math.abs(p.slip),
    phase: game.phase,
    countdown: game.countdown,
    finished: p.finished,
    minimap: game.cars.map((c) => ({
      x: c.x,
      z: c.z,
      heading: c.heading,
      color: c.def.color,
      player: c.isPlayer,
    })),
  };
}

export function makeResults(game: RaceState): RaceResults {
  const p = game.cars[game.playerIndex];
  const board = game.cars
    .map((c, i) => ({
      name: c.name,
      color: c.def.color,
      player: c.isPlayer,
      time: c.finished ? c.finishTime : game.time,
      finished: c.finished,
      pos: game.ranks[i],
    }))
    .sort((a, b) => a.pos - b.pos);
  return {
    position: game.ranks[game.playerIndex],
    total: game.cars.length,
    time: p.finished ? p.finishTime : game.time,
    bestLap: p.lapTimes.length ? Math.min(...p.lapTimes) : 0,
    topSpeed: p.topSpeed * 4.6,
    board,
  };
}


