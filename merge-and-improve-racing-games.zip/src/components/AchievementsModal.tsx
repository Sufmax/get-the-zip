import React from 'react';
import { PlayerProgress, Achievement } from '../types/game';
import { X, Trophy, Check, Lock, Sparkles } from 'lucide-react';
import { triggerHaptic } from '../services/storage';

interface AchievementsModalProps {
  progress: PlayerProgress;
  onUpdateProgress: (newProgress: PlayerProgress) => void;
  onClose: () => void;
}

const ACHIEVEMENTS_LIST: Achievement[] = [
  {
    id: 'first_race',
    titleFr: 'Premier Départ',
    titleEn: 'First Start',
    descFr: 'Terminer votre toute première course sur circuit.',
    descEn: 'Complete your very first circuit race.',
    icon: '🏁',
    rewardCash: 1500,
    progressMax: 1,
  },
  {
    id: 'drift_initiation',
    titleFr: 'Glissade Initiatique',
    titleEn: 'First Drift',
    descFr: 'Effectuer un drift propre et cumuler 2 000 points.',
    descEn: 'Perform a clean drift and score 2,000 points.',
    icon: '💨',
    rewardCash: 2000,
    progressMax: 2000,
  },
  {
    id: 'drift_master',
    titleFr: 'Roi du Crabe',
    titleEn: 'Drift King',
    descFr: 'Atteindre un score de 20 000 points de drift en une seule session.',
    descEn: 'Reach 20,000 drift points in a single session.',
    icon: '👑',
    rewardCash: 6000,
    progressMax: 20000,
  },
  {
    id: 'speed_demon',
    titleFr: 'Mur du Son Low-Poly',
    titleEn: 'Speed Demon',
    descFr: 'Dépasser les 270 km/h en pointe avec nitro.',
    descEn: 'Exceed 270 km/h top speed using nitro boost.',
    icon: '⚡',
    rewardCash: 3500,
    progressMax: 270,
  },
  {
    id: 'highway_survivor',
    titleFr: 'Pilote de l’Infini',
    titleEn: 'Highway Survivor',
    descFr: 'Parcourir plus de 3 000 mètres sur l’Autoroute Infinie.',
    descEn: 'Travel over 3,000 meters in Endless Highway traffic.',
    icon: '🛣️',
    rewardCash: 4500,
    progressMax: 3000,
  },
  {
    id: 'collector_3',
    titleFr: 'Collectionneur Averti',
    titleEn: 'Collector',
    descFr: 'Posséder au moins 3 véhicules distincts dans le garage.',
    descEn: 'Own at least 3 distinct vehicles in your garage.',
    icon: '🏎️',
    rewardCash: 5000,
    progressMax: 3,
  },
  {
    id: 'full_tune',
    titleFr: 'Préparateur Compétition',
    titleEn: 'Master Tuner',
    descFr: 'Installer le Moteur & Turbo Niveau 3 MAX sur un véhicule.',
    descEn: 'Install Stage 3 MAX Engine & Turbo on any vehicle.',
    icon: '🔧',
    rewardCash: 7500,
    progressMax: 1,
  },
  {
    id: 'podium_master',
    titleFr: 'Numéro Un Incontesté',
    titleEn: 'Undisputed #1',
    descFr: 'Remporter une course circuit en 1ère position.',
    descEn: 'Win a circuit race in 1st place.',
    icon: '🥇',
    rewardCash: 4000,
    progressMax: 1,
  },
];

export const AchievementsModal: React.FC<AchievementsModalProps> = ({
  progress,
  onUpdateProgress,
  onClose,
}) => {
  const handleClaimReward = (ach: Achievement) => {
    if (!progress.achievementsUnlocked.includes(ach.id)) {
      const newProgress: PlayerProgress = {
        ...progress,
        cash: progress.cash + ach.rewardCash,
        achievementsUnlocked: [...progress.achievementsUnlocked, ach.id],
      };
      onUpdateProgress(newProgress);
      triggerHaptic(50);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-xl flex flex-col p-4 md:p-8 overflow-y-auto select-none">
      {/* Header */}
      <div className="flex justify-between items-center w-full max-w-4xl mx-auto pb-4 border-b border-white/10">
        <div>
          <h2 className="text-xl md:text-3xl font-black italic tracking-tight text-white uppercase flex items-center gap-2">
            <span>TROPHÉES</span>
            <span className="text-cyan-400">&amp; DÉFIS</span>
          </h2>
          <p className="text-xs text-slate-400">Accomplissez des exploits pour débloquer des primes cash</p>
        </div>

        <button
          onClick={onClose}
          className="w-10 h-10 rounded-2xl bg-slate-800 hover:bg-slate-700 text-white flex items-center justify-center border border-white/10 active:scale-95 transition-all"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* List */}
      <div className="w-full max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-3.5 py-6">
        {ACHIEVEMENTS_LIST.map((ach) => {
          const isUnlocked = progress.achievementsUnlocked.includes(ach.id);

          return (
            <div
              key={ach.id}
              className={`p-4 rounded-3xl border flex items-center justify-between transition-all ${
                isUnlocked
                  ? 'bg-slate-900/80 border-cyan-500/30'
                  : 'bg-slate-950/60 border-white/5 opacity-75'
              }`}
            >
              <div className="flex items-center gap-3">
                <div className="text-3xl">{ach.icon}</div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-sm font-black italic text-white">{ach.titleFr}</span>
                    {isUnlocked && <Check className="w-3.5 h-3.5 text-cyan-400" />}
                  </div>
                  <p className="text-[11px] text-slate-400 leading-snug">{ach.descFr}</p>
                  <div className="flex items-center gap-1 text-[10px] font-bold text-amber-300 mt-1">
                    <Sparkles className="w-3 h-3 text-amber-400" />
                    <span>+{ach.rewardCash.toLocaleString()} Cr</span>
                  </div>
                </div>
              </div>

              <div>
                {isUnlocked ? (
                  <span className="text-[10px] font-black uppercase text-cyan-300 bg-cyan-950/60 px-3 py-1.5 rounded-xl border border-cyan-500/30">
                    OBTENU
                  </span>
                ) : (
                  <button
                    onClick={() => handleClaimReward(ach)}
                    className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-[10px] font-black uppercase text-slate-300 flex items-center gap-1 border border-white/10 active:scale-95 transition-all"
                  >
                    <Lock className="w-3 h-3" />
                    <span>DÉBLOQUER</span>
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
