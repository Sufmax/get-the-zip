import { useEffect, useState } from 'react';
import { CandlestickChart } from '../components/chart/CandlestickChart';
import { Button, ScreenHeader, Segmented } from '../components/ui/primitives';
import { useApp } from '../context/AppContext';
import { marketApi } from '../services/api';
import type { Candle } from '../types';

export function PatternSelectScreen() {
  const { selectedAsset, timeframe, selectionMode, setSelectionMode, zone, setZone, navigate, back } =
    useApp();
  const [candles, setCandles] = useState<Candle[]>([]);

  useEffect(() => {
    marketApi.getCandles(selectedAsset?.id ?? 'btc-usdt', timeframe).then(setCandles);
  }, [selectedAsset, timeframe]);

  const reset = () => {
    if (!candles.length) return;
    setZone({ startIndex: Math.max(0, candles.length - 26), endIndex: candles.length - 1 });
  };

  const continueAnalysis = () => navigate('sync');

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <ScreenHeader title="Sélection du pattern" onBack={back} />

      <div className="px-5">
        <Segmented
          value={selectionMode}
          onChange={(id) => setSelectionMode(id as 'auto' | 'manual')}
          options={[
            { id: 'auto', label: 'Auto' },
            { id: 'manual', label: 'Manuel' },
          ]}
        />
      </div>

      <div className="mt-4 px-2">
        <CandlestickChart
          candles={candles.slice(-40)}
          height={210}
          showVolume={false}
          showAxis={false}
          zone={{
            startIndex: Math.max(0, 40 - (zone.endIndex - zone.startIndex + 1) - 4),
            endIndex: 35,
          }}
        />
      </div>

      <p className="mx-8 mt-4 text-center text-[13px] leading-relaxed text-slate-400">
        {selectionMode === 'auto' ? (
          <>
            Le pattern a été automatiquement détecté
            <br />
            sur les 25 dernières bougies.
            <br />
            Vous pouvez ajuster la zone ci-dessus
            <br />
            ou passer en mode manuel.
          </>
        ) : (
          <>
            Mode manuel : faites glisser les poignées
            <br />
            pour délimiter le motif à rechercher
            <br />
            dans l’historique.
          </>
        )}
      </p>

      <div className="mt-auto flex gap-3 px-5 pb-3 pt-4">
        <Button variant="outline" className="flex-1" onClick={reset}>
          Réinitialiser
        </Button>
        <Button className="flex-1" onClick={continueAnalysis}>
          Continuer
        </Button>
      </div>
    </div>
  );
}
