import React from 'react';
import { RaceState } from '../types/game';
import { MiniMap } from './MiniMap';
import { TrackData } from '../game/proceduralTrack';
import { Trophy, Zap, Wind } from 'lucide-react';

interface HUDProps {
  raceState: RaceState;
  trackData: TrackData | null;
}

export const HUD: React.FC<HUDProps> = ({
  raceState,
  trackData,
}) => {
  const isEndless = raceState.mode === 'endless_traffic';

  // Format time mm:ss.ms
  const formatTime = (seconds: number) => {
    if (!seconds || seconds <= 0) return '00:00.00';
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    const ms = Math.floor((seconds % 1) * 100);
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}.${ms.toString().padStart(2, '0')}`;
  };

  // Speed ratio for gauge
  const maxDialKmh = 360;
  const speedNormalized = Math.min(1, raceState.speedKmh / maxDialKmh);
  const gaugeAngle = -120 + speedNormalized * 240; // -120 deg to +120 deg

  return (
    <div className="absolute inset-0 pointer-events-none select-none z-10 p-3 md:p-6 flex flex-col justify-between">
      {/* Top Header: Standings, Timers, and MiniMap */}
      <div className="flex justify-between items-start w-full">
        {/* Left: Position & Laps */}
        <div className="flex flex-col gap-2">
          {!isEndless ? (
            <div className="flex items-center gap-3">
              {/* Position badge */}
              <div className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-2xl bg-slate-900/80 backdrop-blur-md border border-white/20 shadow-lg shadow-black/40">
                <Trophy className={`w-5 h-5 ${raceState.position === 1 ? 'text-amber-400 fill-amber-400' : 'text-slate-400'}`} />
                <span className="text-xl md:text-2xl font-black italic tracking-tight text-white">
                  {raceState.position}
                </span>
                <span className="text-xs text-slate-400 font-bold uppercase">
                  /{raceState.totalRacers}
                </span>
              </div>

              {/* Lap badge */}
              <div className="px-3.5 py-1.5 rounded-2xl bg-slate-900/80 backdrop-blur-md border border-white/20 shadow-lg shadow-black/40">
                <span className="text-[10px] uppercase font-black tracking-wider text-slate-400 block -mb-1">TOUR</span>
                <span className="text-lg md:text-xl font-black text-cyan-400 italic">
                  {raceState.lap}
                  <span className="text-xs text-slate-400 font-bold">/{raceState.totalLaps}</span>
                </span>
              </div>
            </div>
          ) : (
            <div className="flex items-center gap-3">
              <div className="px-4 py-2 rounded-2xl bg-slate-900/80 backdrop-blur-md border border-cyan-500/30 shadow-lg shadow-cyan-900/30">
                <span className="text-[10px] uppercase font-black tracking-wider text-cyan-400 block -mb-0.5">DISTANCE</span>
                <span className="text-xl md:text-2xl font-black text-white italic tracking-tight">
                  {raceState.distanceTraveled.toLocaleString()} <span className="text-xs text-cyan-400 font-bold">m</span>
                </span>
              </div>
            </div>
          )}

          {/* Timers */}
          {!isEndless && (
            <div className="flex flex-col gap-0.5 text-xs font-mono font-bold bg-slate-900/60 backdrop-blur-sm px-3 py-1.5 rounded-xl border border-white/10 w-fit">
              <div className="text-slate-300 flex justify-between gap-3">
                <span className="text-[10px] text-slate-400 font-sans uppercase">TEMPS</span>
                <span>{formatTime(raceState.currentLapTime)}</span>
              </div>
              {raceState.bestLapTime > 0 && (
                <div className="text-amber-400 flex justify-between gap-3 text-[11px]">
                  <span className="text-[10px] text-amber-500/80 font-sans uppercase">MEILLEUR</span>
                  <span>{formatTime(raceState.bestLapTime)}</span>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Right: Mini-Map */}
        <div className="flex flex-col items-end gap-2">
          <MiniMap
            trackData={trackData}
            playerPos={raceState.playerCoord || null}
            playerHeading={raceState.playerHeading || 0}
            aiPositions={raceState.aiCoords || []}
            isEndless={isEndless}
          />

          {/* Near-Miss Counter for Endless */}
          {isEndless && raceState.nearMissCount > 0 && (
            <div className="flex items-center gap-1.5 px-3 py-1 rounded-xl bg-amber-500/20 backdrop-blur-md border border-amber-400/40 text-amber-300 text-xs font-black">
              <Zap className="w-3.5 h-3.5 fill-amber-300" />
              <span>{raceState.nearMissCount} FRÔLEMENTS</span>
            </div>
          )}
        </div>
      </div>

      {/* Center Alerts: Slipstream, Drift Score, Countdown */}
      <div className="flex flex-col items-center justify-center my-auto pointer-events-none">
        {/* Giant Countdown Overlay */}
        {raceState.countdown > 0 && (
          <div className="text-center animate-bounce">
            <span
              className={`text-7xl md:text-9xl font-black italic tracking-tighter drop-shadow-[0_10px_20px_rgba(0,0,0,0.8)] ${
                Math.ceil(raceState.countdown) === 1
                  ? 'text-emerald-400'
                  : Math.ceil(raceState.countdown) === 2
                  ? 'text-amber-400'
                  : 'text-rose-500'
              }`}
            >
              {Math.ceil(raceState.countdown) === 1 ? '1' : Math.ceil(raceState.countdown) === 2 ? '2' : '3'}
            </span>
            <div className="text-xl md:text-2xl font-black uppercase tracking-widest text-white -mt-2">
              PRÉPAREZ-VOUS !
            </div>
          </div>
        )}

        {/* Slipstream Boost Notification */}
        {raceState.slipstreamActive && (
          <div className="flex items-center gap-2 px-5 py-2 rounded-2xl bg-cyan-500/30 backdrop-blur-md border border-cyan-400 shadow-xl shadow-cyan-500/40 text-cyan-200 animate-pulse mb-3">
            <Wind className="w-5 h-5 text-cyan-300 animate-spin" />
            <span className="text-sm md:text-base font-black uppercase tracking-wider">
              ASPIRATION ACTIVE ⚡ SURGE
            </span>
          </div>
        )}

        {/* Drift Combo Banner */}
        {raceState.isDrifting && (
          <div className="flex flex-col items-center animate-pulse">
            <div className="flex items-center gap-2 px-6 py-2.5 rounded-2xl bg-gradient-to-r from-amber-600/90 to-rose-600/90 backdrop-blur-md border border-amber-300 shadow-2xl shadow-orange-500/50">
              <span className="text-sm font-black uppercase tracking-wider text-amber-200">DRIFT</span>
              <span className="text-2xl md:text-3xl font-black italic tracking-tight text-white">
                +{raceState.driftScore.toLocaleString()}
              </span>
              <span className="px-2 py-0.5 rounded-lg bg-black/40 text-yellow-300 text-xs font-black">
                x{raceState.driftMultiplier.toFixed(1)}
              </span>
            </div>
          </div>
        )}
      </div>

      {/* Bottom Center: Speedometer Gauge, Gear, RPM, Nitro */}
      <div className="flex flex-col items-center justify-end pointer-events-none mb-1 md:mb-2">
        <div className="relative flex flex-col items-center">
          {/* Circular Speedometer Arc Graphic */}
          <div className="relative w-36 h-24 md:w-44 md:h-28 overflow-hidden flex items-end justify-center">
            {/* Background Arc */}
            <div className="absolute top-2 w-32 h-32 md:w-40 md:h-40 rounded-full border-8 border-slate-800/80"></div>

            {/* Glowing Colored Speed Ring */}
            <div
              className={`absolute top-2 w-32 h-32 md:w-40 md:h-40 rounded-full border-8 border-cyan-400 transition-transform duration-75 ${
                raceState.isNitroActive ? 'border-amber-400 shadow-lg shadow-amber-500/50' : ''
              }`}
              style={{
                clipPath: 'polygon(0 0, 100% 0, 100% 60%, 0 60%)',
                transform: `rotate(${gaugeAngle}deg)`,
              }}
            ></div>

            {/* Digital Speed Display */}
            <div className="flex flex-col items-center z-10 mb-1">
              <span className="text-4xl md:text-5xl font-black italic tracking-tighter text-white drop-shadow-[0_4px_8px_rgba(0,0,0,0.8)]">
                {raceState.speedKmh}
              </span>
              <span className="text-[10px] font-black uppercase tracking-widest text-cyan-400 -mt-1">
                KM / H
              </span>
            </div>
          </div>

          {/* RPM Bar & Gear */}
          <div className="flex items-center gap-3 bg-slate-900/85 backdrop-blur-md px-4 py-1.5 rounded-2xl border border-white/20 shadow-xl shadow-black/50 -mt-2">
            {/* Gear */}
            <div className="flex items-center gap-1 pr-2 border-r border-white/20">
              <span className="text-[9px] font-black uppercase text-slate-400">VIT</span>
              <span className="text-lg md:text-xl font-black italic text-cyan-300">
                {raceState.gear}
              </span>
            </div>

            {/* RPM Segments Bar */}
            <div className="flex items-center gap-0.5">
              {[...Array(12)].map((_, idx) => {
                const filled = raceState.rpm * 12 > idx;
                const isRedline = idx >= 9;
                return (
                  <div
                    key={idx}
                    className={`w-1.5 md:w-2 h-4 rounded-sm transition-all duration-75 ${
                      filled
                        ? isRedline
                          ? 'bg-rose-500 shadow-sm shadow-rose-500'
                          : 'bg-cyan-400 shadow-sm shadow-cyan-400'
                        : 'bg-slate-700/60'
                    }`}
                  />
                );
              })}
            </div>
          </div>

          {/* Nitro Tank Gauge */}
          <div className="w-48 md:w-56 mt-2 flex flex-col gap-0.5">
            <div className="flex justify-between items-center text-[9px] font-black uppercase tracking-wider px-1">
              <span className="text-cyan-400 flex items-center gap-1">
                <Zap className="w-3 h-3 fill-cyan-400" /> NITRO
              </span>
              <span className={`${raceState.nitroPercent > 30 ? 'text-cyan-300' : 'text-rose-400'}`}>
                {Math.round(raceState.nitroPercent)}%
              </span>
            </div>
            <div className="w-full h-2 rounded-full bg-slate-900/80 border border-white/20 overflow-hidden p-0.5">
              <div
                className={`h-full rounded-full transition-all duration-100 ${
                  raceState.isNitroActive
                    ? 'bg-gradient-to-r from-amber-400 to-rose-500 shadow-lg shadow-orange-500 animate-pulse'
                    : 'bg-gradient-to-r from-cyan-500 to-sky-400'
                }`}
                style={{ width: `${raceState.nitroPercent}%` }}
              ></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
