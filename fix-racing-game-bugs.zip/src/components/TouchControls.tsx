import React, { useEffect, useState, useRef } from 'react';
import { VehicleInputs } from '../game/physics';
import { ControlSettings } from '../types/game';
import { triggerHaptic } from '../services/storage';
import { Flame, Disc, ArrowLeft, ArrowRight, Camera, RotateCcw, Pause } from 'lucide-react';

interface TouchControlsProps {
  settings: ControlSettings;
  onInputChange: (inputs: Partial<VehicleInputs>) => void;
  onCameraSwitch: () => void;
  onResetCar: () => void;
  onPause: () => void;
  isNitroActive: boolean;
  nitroPercent: number;
}

export const TouchControls: React.FC<TouchControlsProps> = ({
  settings,
  onInputChange,
  onCameraSwitch,
  onResetCar,
  onPause,
  isNitroActive,
  nitroPercent,
}) => {
  const [leftPressed, setLeftPressed] = useState(false);
  const [rightPressed, setRightPressed] = useState(false);
  const [throttlePressed, setThrottlePressed] = useState(false);
  const [brakePressed, setBrakePressed] = useState(false);
  const [handbrakePressed, setHandbrakePressed] = useState(false);
  const [nitroPressed, setNitroPressed] = useState(false);

  // Wheel drag state
  const wheelRef = useRef<HTMLDivElement>(null);
  const [wheelAngle, setWheelAngle] = useState(0);
  const isDraggingWheel = useRef(false);

  // Keyboard controls handler
  useEffect(() => {
    const activeKeys: Record<string, boolean> = {};

    const updateFromKeys = () => {
      let steer = 0;
      if (activeKeys['ArrowLeft'] || activeKeys['KeyA'] || activeKeys['a'] || activeKeys['q']) steer -= 1;
      if (activeKeys['ArrowRight'] || activeKeys['KeyD'] || activeKeys['d']) steer += 1;

      let throttle = 0;
      if (activeKeys['ArrowUp'] || activeKeys['KeyW'] || activeKeys['w'] || activeKeys['z']) throttle = 1;

      let brake = 0;
      if (activeKeys['ArrowDown'] || activeKeys['KeyS'] || activeKeys['s']) brake = 1;

      const handbrake = !!activeKeys['Space'];
      const nitro = !!activeKeys['ShiftLeft'] || !!activeKeys['ShiftRight'];

      onInputChange({
        steer,
        throttle,
        brake,
        handbrake,
        nitro,
      });
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Space'].includes(e.code)) {
        e.preventDefault();
      }
      activeKeys[e.code] = true;
      activeKeys[e.key] = true;

      if (e.code === 'KeyC') onCameraSwitch();
      if (e.code === 'KeyR') onResetCar();
      if (e.code === 'Escape') onPause();

      updateFromKeys();
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      activeKeys[e.code] = false;
      activeKeys[e.key] = false;
      updateFromKeys();
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [onInputChange, onCameraSwitch, onResetCar, onPause]);

  // Update touch steer
  useEffect(() => {
    if (settings.scheme === 'wheel') return;
    let steer = 0;
    if (leftPressed && !rightPressed) steer = -1 * settings.steeringSensitivity;
    if (rightPressed && !leftPressed) steer = 1 * settings.steeringSensitivity;
    onInputChange({ steer });
  }, [leftPressed, rightPressed, settings.steeringSensitivity, settings.scheme, onInputChange]);

  // Update touch pedals
  useEffect(() => {
    onInputChange({
      throttle: throttlePressed ? 1 : 0,
      brake: brakePressed ? 1 : 0,
      handbrake: handbrakePressed,
      nitro: nitroPressed,
    });
  }, [throttlePressed, brakePressed, handbrakePressed, nitroPressed, onInputChange]);

  // Touch handlers for Virtual Steering Wheel
  const handleWheelTouchMove = (e: React.TouchEvent | React.MouseEvent) => {
    if (!isDraggingWheel.current || !wheelRef.current) return;
    const rect = wheelRef.current.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;

    const clientX = 'touches' in e ? e.touches[0].clientX : (e as React.MouseEvent).clientX;
    const clientY = 'touches' in e ? e.touches[0].clientY : (e as React.MouseEvent).clientY;

    const dx = clientX - centerX;
    const dy = clientY - centerY;
    const rad = Math.atan2(dy, dx);
    let deg = (rad * 180) / Math.PI + 90;
    if (deg > 180) deg -= 360;

    const clampedDeg = Math.max(-85, Math.min(85, deg));
    setWheelAngle(clampedDeg);
    onInputChange({ steer: (clampedDeg / 85) * settings.steeringSensitivity });
  };

  const handleWheelTouchEnd = () => {
    isDraggingWheel.current = false;
    setWheelAngle(0);
    onInputChange({ steer: 0 });
  };

  return (
    <div className="absolute inset-0 pointer-events-none select-none flex flex-col justify-between p-3 md:p-6 z-20 overflow-hidden">
      {/* Top Bar Floating Quick Actions */}
      <div className="flex justify-between items-start pointer-events-auto">
        <div className="flex gap-2">
          <button
            onClick={() => {
              triggerHaptic(25);
              onPause();
            }}
            aria-label="Pause"
            className="w-11 h-11 rounded-2xl bg-slate-900/80 backdrop-blur-md border border-white/20 text-white flex items-center justify-center active:scale-95 transition-transform shadow-lg shadow-black/50"
          >
            <Pause className="w-5 h-5 fill-white" />
          </button>

          <button
            onClick={() => {
              triggerHaptic(25);
              onCameraSwitch();
            }}
            aria-label="Camera"
            className="w-11 h-11 rounded-2xl bg-slate-900/80 backdrop-blur-md border border-white/20 text-cyan-400 flex items-center justify-center active:scale-95 transition-transform shadow-lg shadow-black/50"
          >
            <Camera className="w-5 h-5" />
          </button>

          <button
            onClick={() => {
              triggerHaptic(35);
              onResetCar();
            }}
            aria-label="Remettre sur la piste"
            className="w-11 h-11 rounded-2xl bg-slate-900/80 backdrop-blur-md border border-white/20 text-amber-400 flex items-center justify-center active:scale-95 transition-transform shadow-lg shadow-black/50"
          >
            <RotateCcw className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Bottom Area: Steering on Left & Pedals/Nitro on Right */}
      <div className="flex justify-between items-end w-full pb-2 md:pb-4 pointer-events-auto">
        {/* Left Thumb: Steering */}
        {settings.scheme === 'wheel' ? (
          <div
            ref={wheelRef}
            onTouchStart={() => (isDraggingWheel.current = true)}
            onTouchMove={handleWheelTouchMove}
            onTouchEnd={handleWheelTouchEnd}
            onMouseDown={() => (isDraggingWheel.current = true)}
            onMouseMove={handleWheelTouchMove}
            onMouseUp={handleWheelTouchEnd}
            className="w-32 h-32 md:w-40 md:h-40 rounded-full border-4 border-cyan-400/80 bg-slate-900/80 backdrop-blur-md flex items-center justify-center shadow-2xl shadow-cyan-500/20 active:border-cyan-300 transition-colors"
            style={{ transform: `rotate(${wheelAngle}deg)` }}
          >
            <div className="w-12 h-12 rounded-full border-2 border-white/40 bg-slate-800 flex items-center justify-center">
              <div className="w-3 h-3 rounded-full bg-cyan-400"></div>
            </div>
            <div className="absolute top-2 w-2 h-4 bg-red-500 rounded-full"></div>
          </div>
        ) : (
          <div className="flex gap-2.5">
            <button
              onTouchStart={(e) => {
                e.preventDefault();
                setLeftPressed(true);
                triggerHaptic(20);
              }}
              onTouchEnd={(e) => {
                e.preventDefault();
                setLeftPressed(false);
              }}
              onMouseDown={() => setLeftPressed(true)}
              onMouseUp={() => setLeftPressed(false)}
              className={`w-20 h-20 md:w-24 md:h-24 rounded-3xl backdrop-blur-md border flex items-center justify-center transition-all ${
                leftPressed
                  ? 'bg-cyan-500/40 border-cyan-300 scale-95 shadow-lg shadow-cyan-500/40'
                  : 'bg-slate-900/70 border-white/20 text-white shadow-xl shadow-black/40'
              }`}
            >
              <ArrowLeft className="w-9 h-9 text-cyan-300" />
            </button>

            <button
              onTouchStart={(e) => {
                e.preventDefault();
                setRightPressed(true);
                triggerHaptic(20);
              }}
              onTouchEnd={(e) => {
                e.preventDefault();
                setRightPressed(false);
              }}
              onMouseDown={() => setRightPressed(true)}
              onMouseUp={() => setRightPressed(false)}
              className={`w-20 h-20 md:w-24 md:h-24 rounded-3xl backdrop-blur-md border flex items-center justify-center transition-all ${
                rightPressed
                  ? 'bg-cyan-500/40 border-cyan-300 scale-95 shadow-lg shadow-cyan-500/40'
                  : 'bg-slate-900/70 border-white/20 text-white shadow-xl shadow-black/40'
              }`}
            >
              <ArrowRight className="w-9 h-9 text-cyan-300" />
            </button>
          </div>
        )}

        {/* Right Thumb: Nitro, Handbrake, Brake, Gas */}
        <div className="flex items-end gap-2.5">
          {/* Handbrake & Nitro column */}
          <div className="flex flex-col gap-2.5">
            {/* Nitro Boost Button */}
            <button
              onTouchStart={(e) => {
                e.preventDefault();
                setNitroPressed(true);
                triggerHaptic(40);
              }}
              onTouchEnd={(e) => {
                e.preventDefault();
                setNitroPressed(false);
              }}
              onMouseDown={() => setNitroPressed(true)}
              onMouseUp={() => setNitroPressed(false)}
              disabled={nitroPercent <= 5}
              className={`w-16 h-16 md:w-20 md:h-20 rounded-2xl backdrop-blur-md border flex flex-col items-center justify-center transition-all ${
                isNitroActive || nitroPressed
                  ? 'bg-gradient-to-tr from-cyan-600 to-sky-400 border-cyan-200 scale-95 shadow-xl shadow-cyan-400/60 text-white'
                  : nitroPercent > 20
                  ? 'bg-slate-900/80 border-cyan-500/40 text-cyan-400 shadow-lg shadow-cyan-900/30'
                  : 'bg-slate-900/40 border-slate-700/50 text-slate-500'
              }`}
            >
              <Flame className={`w-7 h-7 ${isNitroActive ? 'animate-bounce text-yellow-200' : ''}`} />
              <span className="text-[10px] font-black uppercase tracking-tighter">NITRO</span>
            </button>

            {/* Handbrake Drift Button */}
            <button
              onTouchStart={(e) => {
                e.preventDefault();
                setHandbrakePressed(true);
                triggerHaptic(25);
              }}
              onTouchEnd={(e) => {
                e.preventDefault();
                setHandbrakePressed(false);
              }}
              onMouseDown={() => setHandbrakePressed(true)}
              onMouseUp={() => setHandbrakePressed(false)}
              className={`w-16 h-16 md:w-20 md:h-20 rounded-2xl backdrop-blur-md border flex flex-col items-center justify-center transition-all ${
                handbrakePressed
                  ? 'bg-fuchsia-600/50 border-fuchsia-300 scale-95 shadow-lg shadow-fuchsia-500/40 text-white'
                  : 'bg-slate-900/80 border-fuchsia-500/30 text-fuchsia-400 shadow-xl shadow-black/40'
              }`}
            >
              <Disc className="w-6 h-6 animate-spin" />
              <span className="text-[9px] font-black uppercase tracking-tighter">DRIFT</span>
            </button>
          </div>

          {/* Brake Pedal */}
          <button
            onTouchStart={(e) => {
              e.preventDefault();
              setBrakePressed(true);
              triggerHaptic(20);
            }}
            onTouchEnd={(e) => {
              e.preventDefault();
              setBrakePressed(false);
            }}
            onMouseDown={() => setBrakePressed(true)}
            onMouseUp={() => setBrakePressed(false)}
            className={`w-16 h-28 md:w-20 md:h-32 rounded-3xl backdrop-blur-md border flex flex-col items-center justify-end pb-3 transition-all ${
              brakePressed
                ? 'bg-rose-600/50 border-rose-300 scale-95 shadow-lg shadow-rose-500/40 text-white'
                : 'bg-slate-900/70 border-white/20 text-rose-400 shadow-xl shadow-black/40'
            }`}
          >
            <div className="w-8 h-2 bg-rose-500/60 rounded mb-2"></div>
            <span className="text-[11px] font-black uppercase tracking-wider">FREIN</span>
          </button>

          {/* Gas / Throttle Pedal */}
          <button
            onTouchStart={(e) => {
              e.preventDefault();
              setThrottlePressed(true);
              triggerHaptic(20);
            }}
            onTouchEnd={(e) => {
              e.preventDefault();
              setThrottlePressed(false);
            }}
            onMouseDown={() => setThrottlePressed(true)}
            onMouseUp={() => setThrottlePressed(false)}
            className={`w-18 h-36 md:w-24 md:h-40 rounded-3xl backdrop-blur-md border flex flex-col items-center justify-end pb-4 transition-all ${
              throttlePressed
                ? 'bg-emerald-500/40 border-emerald-300 scale-95 shadow-lg shadow-emerald-500/40 text-white'
                : 'bg-slate-900/80 border-emerald-500/30 text-emerald-400 shadow-xl shadow-black/40'
            }`}
          >
            <div className="w-10 h-2 bg-emerald-400/80 rounded mb-3"></div>
            <span className="text-xs font-black uppercase tracking-widest text-emerald-300">GAZ</span>
          </button>
        </div>
      </div>
    </div>
  );
};
