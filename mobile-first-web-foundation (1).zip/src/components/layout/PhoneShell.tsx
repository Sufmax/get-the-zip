import type { ReactNode } from 'react';
import { HomeIndicator, StatusBar } from '../ui/primitives';

export function PhoneShell({ children }: { children: ReactNode }) {
  return (
    <div className="ms-root flex min-h-dvh items-center justify-center bg-[#070d16] p-0 sm:p-6">
      <div className="pointer-events-none absolute inset-0 hidden overflow-hidden sm:block">
        <div className="absolute -left-20 top-10 h-72 w-72 rounded-full bg-cyan-500/8 blur-3xl" />
        <div className="absolute -right-10 bottom-10 h-80 w-80 rounded-full bg-blue-600/10 blur-3xl" />
      </div>
      <div className="relative flex h-dvh w-full max-w-[430px] flex-col overflow-hidden bg-[#07111f] sm:h-[844px] sm:max-h-[90vh] sm:rounded-[42px] sm:border sm:border-white/10 sm:shadow-[0_40px_80px_rgba(0,0,0,0.55)]">
        <div className="pointer-events-none absolute inset-0 hidden sm:block rounded-[42px] ring-1 ring-inset ring-white/10" />
        <StatusBar />
        <div className="relative flex min-h-0 flex-1 flex-col overflow-hidden">{children}</div>
        <HomeIndicator />
      </div>
    </div>
  );
}
