import React from 'react';
import { Play, RotateCcw, Home, Settings } from 'lucide-react';

interface PauseModalProps {
  onResume: () => void;
  onRestart: () => void;
  onOpenSettings: () => void;
  onQuit: () => void;
}

export const PauseModal: React.FC<PauseModalProps> = ({
  onResume,
  onRestart,
  onOpenSettings,
  onQuit,
}) => {
  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 select-none">
      <div className="w-full max-w-sm p-6 rounded-3xl bg-slate-900 border border-white/20 shadow-2xl flex flex-col items-center text-center">
        <h2 className="text-3xl font-black italic tracking-tight text-white mb-6 uppercase">
          COURSE EN <span className="text-cyan-400">PAUSE</span>
        </h2>

        <div className="flex flex-col gap-3 w-full">
          <button
            onClick={onResume}
            className="w-full py-3.5 rounded-2xl bg-cyan-500 hover:bg-cyan-400 text-white font-black italic text-base tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-cyan-500/30 active:scale-95 transition-all"
          >
            <Play className="w-5 h-5 fill-white" />
            <span>REPRENDRE LA COURSE</span>
          </button>

          <button
            onClick={onRestart}
            className="w-full py-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-sm tracking-wide flex items-center justify-center gap-2 border border-white/10 active:scale-95 transition-all"
          >
            <RotateCcw className="w-4 h-4 text-amber-400" />
            <span>RECOMMENCER</span>
          </button>

          <button
            onClick={onOpenSettings}
            className="w-full py-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-sm tracking-wide flex items-center justify-center gap-2 border border-white/10 active:scale-95 transition-all"
          >
            <Settings className="w-4 h-4 text-cyan-400" />
            <span>PARAMÈTRES</span>
          </button>

          <button
            onClick={onQuit}
            className="w-full py-3 rounded-2xl bg-rose-950/40 hover:bg-rose-900/40 text-rose-300 font-bold text-sm tracking-wide flex items-center justify-center gap-2 border border-rose-500/30 active:scale-95 transition-all mt-2"
          >
            <Home className="w-4 h-4 text-rose-400" />
            <span>QUITTER AU MENU</span>
          </button>
        </div>
      </div>
    </div>
  );
};
