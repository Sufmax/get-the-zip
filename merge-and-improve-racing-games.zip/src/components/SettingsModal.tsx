import React from 'react';
import { ControlSettings, ControlScheme } from '../types/game';
import { X, Volume2, VolumeX, Music, Sliders, Eye, Zap, Sparkles } from 'lucide-react';
import { audio } from '../services/audio';

interface SettingsModalProps {
  settings: ControlSettings;
  onUpdateSettings: (newSettings: ControlSettings) => void;
  onClose: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  settings,
  onUpdateSettings,
  onClose,
}) => {
  const handleSchemeChange = (scheme: ControlScheme) => {
    onUpdateSettings({ ...settings, scheme });
  };

  const handleSensitivityChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    onUpdateSettings({ ...settings, steeringSensitivity: val });
  };

  const handleCameraChange = (cameraView: 'chase' | 'action' | 'hood' | 'topdown') => {
    onUpdateSettings({ ...settings, cameraView });
  };

  const handleToggleSound = () => {
    const next = !settings.soundEnabled;
    audio.setMuted(!next);
    onUpdateSettings({ ...settings, soundEnabled: next });
  };

  const handleToggleMusic = () => {
    const next = !settings.musicEnabled;
    if (next) audio.startMusic();
    else audio.stopMusic();
    onUpdateSettings({ ...settings, musicEnabled: next });
  };

  const handleQualityChange = (quality: 'low' | 'medium' | 'high') => {
    onUpdateSettings({ ...settings, quality });
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-xl flex flex-col p-4 md:p-8 overflow-y-auto select-none">
      {/* Header */}
      <div className="flex justify-between items-center w-full max-w-2xl mx-auto pb-4 border-b border-white/10">
        <div>
          <h2 className="text-xl md:text-3xl font-black italic tracking-tight text-white uppercase flex items-center gap-2">
            <span>PARAMÈTRES</span>
            <span className="text-cyan-400">&amp; CONTRÔLES</span>
          </h2>
          <p className="text-xs text-slate-400">Ajustez la sensibilité, le type de commande et le rendu graphique</p>
        </div>

        <button
          onClick={onClose}
          className="w-10 h-10 rounded-2xl bg-slate-800 hover:bg-slate-700 text-white flex items-center justify-center border border-white/10 active:scale-95 transition-all"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Settings Form */}
      <div className="w-full max-w-2xl mx-auto flex flex-col gap-5 py-6">
        {/* Control Scheme */}
        <div className="p-4 rounded-3xl bg-slate-900/80 border border-white/10">
          <label className="text-xs font-black uppercase tracking-wider text-slate-300 block mb-2.5">
            Type de Direction Tactile
          </label>
          <div className="grid grid-cols-3 gap-2">
            <button
              onClick={() => handleSchemeChange('joystick')}
              className={`py-3 px-2 rounded-2xl text-xs font-black italic uppercase border transition-all ${
                settings.scheme === 'joystick'
                  ? 'bg-cyan-500 border-cyan-400 text-white shadow-lg shadow-cyan-500/30'
                  : 'bg-slate-950/60 border-white/10 text-slate-400 hover:text-white'
              }`}
            >
              Joystick Progressif
            </button>
            <button
              onClick={() => handleSchemeChange('buttons')}
              className={`py-3 px-2 rounded-2xl text-xs font-black italic uppercase border transition-all ${
                settings.scheme === 'buttons'
                  ? 'bg-cyan-500 border-cyan-400 text-white shadow-lg shadow-cyan-500/30'
                  : 'bg-slate-950/60 border-white/10 text-slate-400 hover:text-white'
              }`}
            >
              Boutons Fléchés
            </button>
            <button
              onClick={() => handleSchemeChange('wheel')}
              className={`py-3 px-2 rounded-2xl text-xs font-black italic uppercase border transition-all ${
                settings.scheme === 'wheel'
                  ? 'bg-cyan-500 border-cyan-400 text-white shadow-lg shadow-cyan-500/30'
                  : 'bg-slate-950/60 border-white/10 text-slate-400 hover:text-white'
              }`}
            >
              Volant Virtuel
            </button>
          </div>
          <p className="text-[11px] text-slate-400 mt-2">
            * Le joystick utilise désormais une courbe non-linéaire douce pour éliminer l'effet "tout ou rien".
          </p>
        </div>

        {/* Steering Sensitivity Slider */}
        <div className="p-4 rounded-3xl bg-slate-900/80 border border-white/10">
          <div className="flex justify-between items-center mb-2">
            <label className="text-xs font-black uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
              <Sliders className="w-4 h-4 text-cyan-400" />
              <span>Sensibilité de Direction</span>
            </label>
            <span className="text-xs font-mono font-bold text-cyan-400">
              {Math.round(settings.steeringSensitivity * 100)}%
            </span>
          </div>

          <input
            type="range"
            min="0.4"
            max="1.8"
            step="0.05"
            value={settings.steeringSensitivity}
            onChange={handleSensitivityChange}
            className="w-full accent-cyan-400 h-2 bg-slate-950 rounded-lg cursor-pointer"
          />
          <div className="flex justify-between text-[10px] text-slate-500 mt-1">
            <span>Doux (0.4x)</span>
            <span>Standard (1.0x)</span>
            <span>Ultra Vif (1.8x)</span>
          </div>
        </div>

        {/* Camera Views Default */}
        <div className="p-4 rounded-3xl bg-slate-900/80 border border-white/10">
          <label className="text-xs font-black uppercase tracking-wider text-slate-300 flex items-center gap-1.5 mb-2.5">
            <Eye className="w-4 h-4 text-cyan-400" />
            <span>Vue Caméra par Défaut</span>
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {(['chase', 'action', 'hood', 'topdown'] as const).map((view) => (
              <button
                key={view}
                onClick={() => handleCameraChange(view)}
                className={`py-2.5 px-2 rounded-2xl text-xs font-bold border transition-all ${
                  settings.cameraView === view
                    ? 'bg-slate-800 border-cyan-400 text-cyan-300 shadow-md shadow-cyan-500/20'
                    : 'bg-slate-950/60 border-white/10 text-slate-400 hover:text-white'
                }`}
              >
                {view === 'chase' ? 'Poursuite' : view === 'action' ? 'Action Basse' : view === 'hood' ? 'Capot' : 'Vue du Ciel'}
              </button>
            ))}
          </div>
        </div>

        {/* Toggles: Auto Accelerate, Dynamic FOV, Audio */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {/* Auto Accelerate */}
          <div className="p-4 rounded-3xl bg-slate-900/80 border border-white/10 flex items-center justify-between">
            <div>
              <span className="text-xs font-bold text-white block">Accélération Automatique</span>
              <span className="text-[10px] text-slate-400">Gaz enfoncé en continu</span>
            </div>
            <button
              onClick={() => onUpdateSettings({ ...settings, autoAccelerate: !settings.autoAccelerate })}
              className={`w-12 h-6 rounded-full transition-colors relative p-0.5 ${
                settings.autoAccelerate ? 'bg-cyan-500' : 'bg-slate-800'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white transition-transform ${
                  settings.autoAccelerate ? 'translate-x-6' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* Dynamic FOV Boost */}
          <div className="p-4 rounded-3xl bg-slate-900/80 border border-white/10 flex items-center justify-between">
            <div>
              <span className="text-xs font-bold text-white block">Effet de Vitesse FOV</span>
              <span className="text-[10px] text-slate-400">Élargissement visuel à grande vitesse</span>
            </div>
            <button
              onClick={() => onUpdateSettings({ ...settings, cameraFovBoost: !settings.cameraFovBoost })}
              className={`w-12 h-6 rounded-full transition-colors relative p-0.5 ${
                settings.cameraFovBoost ? 'bg-cyan-500' : 'bg-slate-800'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white transition-transform ${
                  settings.cameraFovBoost ? 'translate-x-6' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* Sound FX */}
          <div className="p-4 rounded-3xl bg-slate-900/80 border border-white/10 flex items-center justify-between">
            <div className="flex items-center gap-2">
              {settings.soundEnabled ? <Volume2 className="w-4 h-4 text-cyan-400" /> : <VolumeX className="w-4 h-4 text-slate-500" />}
              <div>
                <span className="text-xs font-bold text-white block">Bruitages & Moteur</span>
                <span className="text-[10px] text-slate-400">Synthèse WebAudio en temps réel</span>
              </div>
            </div>
            <button
              onClick={handleToggleSound}
              className={`w-12 h-6 rounded-full transition-colors relative p-0.5 ${
                settings.soundEnabled ? 'bg-cyan-500' : 'bg-slate-800'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white transition-transform ${
                  settings.soundEnabled ? 'translate-x-6' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* Music */}
          <div className="p-4 rounded-3xl bg-slate-900/80 border border-white/10 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Music className={`w-4 h-4 ${settings.musicEnabled ? 'text-fuchsia-400' : 'text-slate-500'}`} />
              <div>
                <span className="text-xs font-bold text-white block">Musique Synthwave</span>
                <span className="text-[10px] text-slate-400">Basse rétro arcade en fond</span>
              </div>
            </div>
            <button
              onClick={handleToggleMusic}
              className={`w-12 h-6 rounded-full transition-colors relative p-0.5 ${
                settings.musicEnabled ? 'bg-fuchsia-500' : 'bg-slate-800'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white transition-transform ${
                  settings.musicEnabled ? 'translate-x-6' : 'translate-x-0'
                }`}
              />
            </button>
          </div>
        </div>

        {/* Graphics Quality */}
        <div className="p-4 rounded-3xl bg-slate-900/80 border border-white/10">
          <label className="text-xs font-black uppercase tracking-wider text-slate-300 block mb-2.5">
            Qualité Graphique 3D
          </label>
          <div className="grid grid-cols-3 gap-2">
            {(['low', 'medium', 'high'] as const).map((q) => (
              <button
                key={q}
                onClick={() => handleQualityChange(q)}
                className={`py-2.5 rounded-2xl text-xs font-bold uppercase border transition-all ${
                  settings.quality === q
                    ? 'bg-slate-800 border-cyan-400 text-cyan-300 shadow-md shadow-cyan-500/20'
                    : 'bg-slate-950/60 border-white/10 text-slate-400 hover:text-white'
                }`}
              >
                {q === 'low' ? 'Basse' : q === 'medium' ? 'Moyenne' : 'Haute (Ombres)'}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
