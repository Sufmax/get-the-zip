import { useState } from 'react';
import { Button, Check, Radio, ScreenHeader } from '../components/ui/primitives';
import { useApp } from '../context/AppContext';
import { marketApi } from '../services/api';
import type { ExportConfig } from '../types';

const FORMATS: { id: ExportConfig['format']; title: string; subtitle: string }[] = [
  { id: 'pdf', title: 'PDF', subtitle: 'rapport complet' },
  { id: 'csv', title: 'CSV', subtitle: 'données brutes' },
  { id: 'json', title: 'JSON', subtitle: 'données complètes' },
  { id: 'image', title: 'Image', subtitle: 'graphique' },
];

export function ExportScreen() {
  const { exportConfig, setExportConfig, back, matches, selectedAsset, settings } = useApp();
  const [done, setDone] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const patch = (p: Partial<ExportConfig>) => setExportConfig({ ...exportConfig, ...p });

  const run = async () => {
    setBusy(true);
    const res = await marketApi.exportResults(exportConfig, {
      // Payload de présentation — à remplacer par le rapport backend
      demo: true,
      asset: selectedAsset,
      matches,
      settings,
      generatedAt: new Date().toISOString(),
    });
    setBusy(false);
    setDone(res.filename);
  };

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <ScreenHeader title="Exporter les résultats" onBack={back} />

      <div className="min-h-0 flex-1 overflow-y-auto px-4">
        <div className="space-y-1 rounded-2xl border border-white/5 bg-[#101c31] p-2">
          {FORMATS.map((f) => (
            <button
              key={f.id}
              onClick={() => patch({ format: f.id })}
              className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left"
            >
              <Radio checked={exportConfig.format === f.id} />
              <span className="text-[14px] text-white">
                {f.title} <span className="text-slate-500">({f.subtitle})</span>
              </span>
            </button>
          ))}
        </div>

        <h3 className="mb-2 mt-5 text-[13px] font-semibold text-white">Inclure</h3>
        <div className="space-y-1 rounded-2xl border border-white/5 bg-[#101c31] p-2">
          <Inc label="Graphiques" checked={exportConfig.includeCharts} onChange={(v) => patch({ includeCharts: v })} />
          <Inc
            label="Correspondances"
            checked={exportConfig.includeMatches}
            onChange={(v) => patch({ includeMatches: v })}
          />
          <Inc
            label="Scénarios"
            checked={exportConfig.includeScenarios}
            onChange={(v) => patch({ includeScenarios: v })}
          />
          <Inc
            label="Paramètres"
            checked={exportConfig.includeSettings}
            onChange={(v) => patch({ includeSettings: v })}
          />
        </div>
        {done && <p className="mt-4 text-center text-[12px] text-emerald-400">Fichier généré : {done}</p>}
      </div>

      <div className="px-5 pb-3">
        <Button onClick={run} disabled={busy}>
          {busy ? 'Export…' : 'Exporter'}
        </Button>
      </div>
    </div>
  );
}

function Inc({ label, checked, onChange }: { label: string; checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <button onClick={() => onChange(!checked)} className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5">
      <Check checked={checked} />
      <span className="text-[14px] text-white">{label}</span>
    </button>
  );
}
