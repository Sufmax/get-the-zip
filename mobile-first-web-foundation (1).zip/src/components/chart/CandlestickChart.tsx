import { useMemo } from 'react';
import type { Candle, PatternZone } from '../../types';
import { formatDateTick, formatNumber } from '../../utils/format';
import { cn } from '../../utils/cn';

interface Props {
  candles: Candle[];
  height?: number;
  showVolume?: boolean;
  showAxis?: boolean;
  zone?: PatternZone | null;
  interactiveZone?: boolean;
  onZoneChange?: (z: PatternZone) => void;
  variant?: 'full' | 'mini' | 'compare';
  compareCandles?: Candle[];
  className?: string;
  padTop?: number;
}

export function CandlestickChart({
  candles,
  height = 240,
  showVolume = true,
  showAxis = true,
  zone,
  variant = 'full',
  compareCandles,
  className,
}: Props) {
  const layout = useMemo(() => {
    if (!candles.length) return null;
    const volH = showVolume && variant === 'full' ? height * 0.22 : 0;
    const padL = showAxis ? 8 : 2;
    const padR = showAxis ? 46 : 4;
    const padT = variant === 'mini' ? 4 : 12;
    const padB = showAxis ? 22 : 4;
    const plotH = height - volH - padT - padB;
    const plotW = 100; // percent via viewBox later
    const highs = candles.map((c) => c.high);
    const lows = candles.map((c) => c.low);
    let min = Math.min(...lows);
    let max = Math.max(...highs);
    if (compareCandles?.length) {
      const scale = (src: Candle[]) => {
        const sMin = Math.min(...src.map((c) => c.low));
        const sMax = Math.max(...src.map((c) => c.high));
        return src.map((c) => ({
          ...c,
          open: min + ((c.open - sMin) / (sMax - sMin || 1)) * (max - min),
          close: min + ((c.close - sMin) / (sMax - sMin || 1)) * (max - min),
          high: min + ((c.high - sMin) / (sMax - sMin || 1)) * (max - min),
          low: min + ((c.low - sMin) / (sMax - sMin || 1)) * (max - min),
        }));
      };
      void scale;
    }
    const span = max - min || 1;
    min -= span * 0.06;
    max += span * 0.08;
    const range = max - min;
    const maxVol = Math.max(...candles.map((c) => c.volume), 1);
    return { volH, padL, padR, padT, padB, plotH, plotW, min, max, range, maxVol, height };
  }, [candles, compareCandles, height, showAxis, showVolume, variant]);

  if (!layout || !candles.length) {
    return <div className={cn('flex items-center justify-center text-slate-500', className)} style={{ height }} />;
  }

  const w = 360;
  const h = height;
  const { padL, padR, padT, padB, plotH, min, range, maxVol, volH } = layout;
  const innerW = w - padL - padR;
  const slot = innerW / candles.length;
  const bodyW = Math.max(1.4, slot * 0.62);

  const yFor = (price: number) => padT + ((layout.max - price) / range) * plotH;
  const ticks = 4;
  const yTicks = Array.from({ length: ticks }, (_, i) => {
    const p = layout.max - (range * i) / (ticks - 1);
    return { p, y: yFor(p) };
  });

  const xTicks: { x: number; label: string }[] = [];
  if (showAxis && candles.length > 1) {
    const count = 4;
    for (let i = 0; i < count; i++) {
      const idx = Math.round((i / (count - 1)) * (candles.length - 1));
      xTicks.push({
        x: padL + idx * slot + slot / 2,
        label: formatDateTick(candles[idx].timestamp),
      });
    }
  }

  const zoneX = zone
    ? {
        x: padL + zone.startIndex * slot,
        width: Math.max(slot, (zone.endIndex - zone.startIndex + 1) * slot),
      }
    : null;

  return (
    <svg
      viewBox={`0 0 ${w} ${h}`}
      className={cn('h-full w-full', className)}
      preserveAspectRatio="none"
      role="img"
      aria-label="Graphique en chandeliers (données de présentation)"
    >
      {showAxis &&
        yTicks.map((t, i) => (
          <g key={i}>
            <line
              x1={padL}
              x2={w - padR}
              y1={t.y}
              y2={t.y}
              stroke="#1e3352"
              strokeWidth="0.6"
              strokeDasharray="3 4"
            />
            <text x={w - 4} y={t.y + 3} textAnchor="end" fill="#6d84a3" fontSize="8" fontFamily="system-ui">
              {formatNumber(t.p, t.p > 1000 ? 0 : 2)}
            </text>
          </g>
        ))}

      {zoneX && variant !== 'mini' && (
        <g>
          <rect
            x={zoneX.x}
            y={padT + 4}
            width={zoneX.width}
            height={plotH - 10}
            fill="rgba(45, 212, 191, 0.12)"
            stroke="#2dd4bf"
            strokeWidth="1.4"
            rx="3"
          />
          {variant === 'full' &&
            [
              [zoneX.x, padT + 4],
              [zoneX.x + zoneX.width, padT + 4],
              [zoneX.x, padT + plotH - 6],
              [zoneX.x + zoneX.width, padT + plotH - 6],
            ].map(([hx, hy], i) => (
              <rect key={i} x={hx - 3.5} y={hy - 3.5} width="7" height="7" rx="1" fill="#e2e8f0" />
            ))}
        </g>
      )}

      {candles.map((c, i) => {
        const x = padL + i * slot + slot / 2;
        const bull = c.close >= c.open;
        const color = bull ? '#22c55e' : '#ef4444';
        const yHigh = yFor(c.high);
        const yLow = yFor(c.low);
        const yO = yFor(c.open);
        const yC = yFor(c.close);
        const top = Math.min(yO, yC);
        const bh = Math.max(1.2, Math.abs(yC - yO));
        const volY = h - padB - volH;
        const vh = showVolume ? (c.volume / maxVol) * (volH - 4) : 0;
        return (
          <g key={c.timestamp}>
            <line x1={x} x2={x} y1={yHigh} y2={yLow} stroke={color} strokeWidth="1.1" />
            <rect x={x - bodyW / 2} y={top} width={bodyW} height={bh} fill={color} rx="0.4" />
            {showVolume && variant === 'full' && (
              <rect
                x={x - bodyW / 2}
                y={volY + (volH - 4) - vh}
                width={bodyW}
                height={vh}
                fill={color}
                opacity="0.55"
              />
            )}
          </g>
        );
      })}

      {compareCandles &&
        compareCandles.slice(0, candles.length).map((c, i) => {
          const x = padL + i * slot + slot / 2;
          const srcMin = Math.min(...compareCandles.map((k) => k.low));
          const srcMax = Math.max(...compareCandles.map((k) => k.high));
          const norm = (v: number) => min + ((v - srcMin) / (srcMax - srcMin || 1)) * range;
          const y = yFor(norm(c.close));
          if (i === 0) return null;
          const prev = compareCandles[i - 1];
          const y0 = yFor(norm(prev.close));
          const x0 = padL + (i - 1) * slot + slot / 2;
          return <line key={`cmp-${i}`} x1={x0} y1={y0} x2={x} y2={y} stroke="#38bdf8" strokeWidth="1.4" opacity="0.85" />;
        })}

      {showAxis &&
        xTicks.map((t, i) => (
          <text key={i} x={t.x} y={h - 6} textAnchor="middle" fill="#6d84a3" fontSize="8" fontFamily="system-ui">
            {t.label}
          </text>
        ))}
    </svg>
  );
}

export function MiniSpark({ candles, className }: { candles: Candle[]; className?: string }) {
  return (
    <div className={cn('h-11 w-[72px]', className)}>
      <CandlestickChart candles={candles.slice(-16)} height={44} showVolume={false} showAxis={false} variant="mini" />
    </div>
  );
}

export function EquityCurve({ points }: { points: { x: number; y: number }[] }) {
  if (!points.length) return null;
  const w = 360;
  const h = 110;
  const minY = Math.min(...points.map((p) => p.y), 0);
  const maxY = Math.max(...points.map((p) => p.y), 1);
  const range = maxY - minY || 1;
  const xFor = (x: number) => 28 + (x / 160) * (w - 40);
  const yFor = (y: number) => 10 + ((maxY - y) / range) * (h - 28);
  const d = points.map((p, i) => `${i === 0 ? 'M' : 'L'}${xFor(p.x)},${yFor(p.y)}`).join(' ');
  const zeroY = yFor(0);
  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="h-28 w-full">
      <line x1="28" x2={w - 8} y1={zeroY} y2={zeroY} stroke="#1e3352" strokeDasharray="3 3" />
      <text x="4" y="14" fill="#6d84a3" fontSize="8">
        +20%
      </text>
      <text x="4" y={h - 10} fill="#6d84a3" fontSize="8">
        -12%
      </text>
      {points.map((p, i) => {
        if (i === 0) return null;
        const prev = points[i - 1];
        const up = p.y >= prev.y;
        return (
          <line
            key={i}
            x1={xFor(prev.x)}
            y1={yFor(prev.y)}
            x2={xFor(p.x)}
            y2={yFor(p.y)}
            stroke={up ? '#22c55e' : '#ef4444'}
            strokeWidth="1.6"
          />
        );
      })}
      <path d={d} fill="none" />
    </svg>
  );
}
