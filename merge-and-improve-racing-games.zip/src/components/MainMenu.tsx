import React from 'react';
import { GameMode, PlayerProgress } from '../types/game';
import { CARS_CATALOG } from '../game/carsData';
import { Play, Flame, Wrench, Trophy, Settings as SettingsIcon, Flag, Infinity as InfinityIcon, Compass, Sparkles } from 'lucide-react';

interface MainMenuProps {
  progress: PlayerProgress;
  onStartRace: (mode: GameMode, trackId?: string) => void;
  onOpenGarage: () => void;
  onOpenTrackSelect: () => void;
  onOpenAchievements: () => void;
  onOpenLeaderboard: () => void;
  onOpenSettings: () => void;
}

export const MainMenu: React.FC<MainMenuProps> = ({
  progress,
  onStartRace,
  onOpenGarage,
  onOpenTrackSelect,
  onOpenAchievements,
  onOpenLeaderboard,
  onOpenSettings,
}) => {
  const currentCar = CARS_CATALOG.find((c) => c.id === progress.selectedCarId) || CARS_CATALOG[0];

  return (
    <div className="relative w-full h-full min-h-screen bg-slate-950 text-white flex flex-col justify-between p-4 md:p-8 overflow-y-auto select-none">
      {/* Background radial gradient */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_top,_var(--tw-gradient-stops))] from-cyan-950/40 via-slate-950 to-black pointer-events-none" />

      {/* Top Header Bar */}
      <div className="relative z-10 flex justify-between items-center w-full max-w-6xl mx-auto">
        {/* Brand */}
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-cyan-500 to-sky-400 flex items-center justify-center shadow-lg shadow-cyan-500/30">
            <Flame className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-xl md:text-2xl font-black italic tracking-tighter uppercase bg-gradient-to-r from-white via-cyan-200 to-sky-400 bg-clip-text text-transparent">
              POLYRACE <span className="text-cyan-400">DRIFT</span>
            </h1>
            <p className="text-[10px] uppercase font-bold tracking-widest text-slate-400 -mt-1">
              Arcade Low-Poly Horizon
            </p>
          </div>
        </div>

        {/* Player Cash & Quick Buttons */}
        <div className="flex items-center gap-2.5">
          {/* Wallet */}
          <div className="flex items-center gap-2 px-3.5 py-1.5 md:px-4 md:py-2 rounded-2xl bg-slate-900/90 backdrop-blur-md border border-amber-400/30 shadow-lg shadow-black/40">
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span className="text-sm md:text-base font-black italic text-amber-300">
              {progress.cash.toLocaleString()} <span className="text-xs text-amber-400 font-sans font-bold">Cr</span>
            </span>
          </div>

          {/* Settings icon */}
          <button
            onClick={onOpenSettings}
            className="w-10 h-10 md:w-11 md:h-11 rounded-2xl bg-slate-900/80 backdrop-blur-md border border-white/20 text-white flex items-center justify-center shadow-lg active:scale-95 hover:border-cyan-400 transition-all"
            title="Paramètres"
          >
            <SettingsIcon className="w-5 h-5 text-slate-300 hover:text-cyan-300" />
          </button>
        </div>
      </div>

      {/* Center Hero & Current Car Card */}
      <div className="relative z-10 flex flex-col items-center justify-center my-6 md:my-10 max-w-4xl mx-auto text-center">
        {/* Active Car Preview Card */}
        <div className="w-full max-w-md p-5 rounded-3xl bg-slate-900/80 backdrop-blur-md border border-white/15 shadow-2xl shadow-black/60 flex flex-col items-center mb-6">
          <div className="text-[10px] uppercase font-black tracking-widest text-cyan-400 mb-1">
            VÉHICULE SÉLECTIONNÉ
          </div>
          <h2 className="text-2xl md:text-3xl font-black italic tracking-tight text-white">
            {currentCar.name}
          </h2>
          <p className="text-xs text-slate-400 font-semibold mb-4">
            {currentCar.subtitle} • Catégorie {currentCar.category.toUpperCase()}
          </p>

          {/* Quick Specs Badges */}
          <div className="grid grid-cols-3 gap-2 w-full text-center">
            <div className="bg-slate-950/60 p-2 rounded-xl border border-white/5">
              <span className="text-[9px] uppercase font-black text-slate-400 block">V-MAX</span>
              <span className="text-sm font-black text-white italic">{currentCar.specs.topSpeed} km/h</span>
            </div>
            <div className="bg-slate-950/60 p-2 rounded-xl border border-white/5">
              <span className="text-[9px] uppercase font-black text-slate-400 block">ACCEL</span>
              <span className="text-sm font-black text-cyan-400 italic">{currentCar.specs.acceleration}/10</span>
            </div>
            <div className="bg-slate-950/60 p-2 rounded-xl border border-white/5">
              <span className="text-[9px] uppercase font-black text-slate-400 block">DRIFT</span>
              <span className="text-sm font-black text-fuchsia-400 italic">{currentCar.specs.driftEase}/10</span>
            </div>
          </div>

          <button
            onClick={onOpenGarage}
            className="mt-4 w-full py-2.5 rounded-2xl bg-slate-800 hover:bg-slate-700/90 border border-white/20 text-xs font-black uppercase tracking-wider text-slate-200 flex items-center justify-center gap-2 active:scale-95 transition-all"
          >
            <Wrench className="w-4 h-4 text-cyan-400" />
            <span>Personnaliser & Améliorer (Garage)</span>
          </button>
        </div>

        {/* Big Quick Race CTA */}
        <button
          onClick={() => onStartRace('circuit', 'azure')}
          className="group relative px-10 py-5 rounded-3xl bg-gradient-to-r from-cyan-500 via-sky-500 to-blue-600 border border-cyan-300 shadow-2xl shadow-cyan-500/40 text-white font-black italic text-xl md:text-2xl tracking-tight flex items-center gap-3 active:scale-95 hover:brightness-110 transition-all cursor-pointer"
        >
          <Play className="w-7 h-7 fill-white group-hover:scale-110 transition-transform" />
          <span>COURSE RAPIDE</span>
        </button>
      </div>

      {/* Bottom Mode & Hub Cards Grid */}
      <div className="relative z-10 grid grid-cols-2 sm:grid-cols-4 gap-3 max-w-5xl mx-auto w-full">
        {/* Track Select / Modes */}
        <button
          onClick={onOpenTrackSelect}
          className="p-4 rounded-3xl bg-slate-900/80 hover:bg-slate-800/90 backdrop-blur-md border border-white/10 hover:border-cyan-400 text-left flex flex-col justify-between active:scale-95 transition-all"
        >
          <Compass className="w-6 h-6 text-cyan-400 mb-2" />
          <div>
            <div className="text-sm font-black italic uppercase text-white">Circuits</div>
            <p className="text-[10px] text-slate-400">6 pistes thématiques</p>
          </div>
        </button>

        {/* Endless Traffic Mode */}
        <button
          onClick={() => onStartRace('endless_traffic', 'endless_highway')}
          className="p-4 rounded-3xl bg-slate-900/80 hover:bg-slate-800/90 backdrop-blur-md border border-white/10 hover:border-amber-400 text-left flex flex-col justify-between active:scale-95 transition-all"
        >
          <InfinityIcon className="w-6 h-6 text-amber-400 mb-2" />
          <div>
            <div className="text-sm font-black italic uppercase text-white">Autoroute</div>
            <p className="text-[10px] text-slate-400">Trafic infini & aspi</p>
          </div>
        </button>

        {/* Global Leaderboard */}
        <button
          onClick={onOpenLeaderboard}
          className="p-4 rounded-3xl bg-slate-900/80 hover:bg-slate-800/90 backdrop-blur-md border border-white/10 hover:border-emerald-400 text-left flex flex-col justify-between active:scale-95 transition-all"
        >
          <Flag className="w-6 h-6 text-emerald-400 mb-2" />
          <div>
            <div className="text-sm font-black italic uppercase text-white">Classements</div>
            <p className="text-[10px] text-slate-400">Records mondiaux en ligne</p>
          </div>
        </button>

        {/* Achievements */}
        <button
          onClick={onOpenAchievements}
          className="p-4 rounded-3xl bg-slate-900/80 hover:bg-slate-800/90 backdrop-blur-md border border-white/10 hover:border-fuchsia-400 text-left flex flex-col justify-between active:scale-95 transition-all"
        >
          <Trophy className="w-6 h-6 text-fuchsia-400 mb-2" />
          <div>
            <div className="text-sm font-black italic uppercase text-white">Trophées</div>
            <p className="text-[10px] text-slate-400">Défis & primes cash</p>
          </div>
        </button>
      </div>
    </div>
  );
};
