import { useCallback, useEffect, useRef, useState } from "react";
import type { InputState } from "../game/types";

type Props = {
  inputRef: React.MutableRefObject<InputState>;
  autoAccel: boolean;
};

export function TouchControls({ inputRef, autoAccel }: Props) {
  const [knob, setKnob] = useState({ x: 0, y: 0 });
  const [gas, setGas] = useState(false);
  const [brake, setBrake] = useState(false);
  const [nitro, setNitro] = useState(false);
  const origin = useRef<{ x: number; y: number; id: number } | null>(null);

  const apply = useCallback(
    (partial: Partial<InputState>) => {
      Object.assign(inputRef.current, partial);
    },
    [inputRef],
  );

  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      if (e.repeat) return;
      if (e.code === "ArrowLeft" || e.code === "KeyA") apply({ steer: -1 });
      if (e.code === "ArrowRight" || e.code === "KeyD") apply({ steer: 1 });
      if (e.code === "ArrowUp" || e.code === "KeyW") {
        apply({ throttle: 1 });
        setGas(true);
      }
      if (e.code === "ArrowDown" || e.code === "KeyS" || e.code === "Space") {
        apply({ brake: 1, throttle: 0 });
        setBrake(true);
      }
      if (e.code === "ShiftLeft" || e.code === "ShiftRight" || e.code === "KeyN") {
        apply({ nitro: true });
        setNitro(true);
      }
    };
    const up = (e: KeyboardEvent) => {
      if (e.code === "ArrowLeft" || e.code === "KeyA" || e.code === "ArrowRight" || e.code === "KeyD")
        apply({ steer: 0 });
      if (e.code === "ArrowUp" || e.code === "KeyW") {
        apply({ throttle: autoAccel ? 1 : 0 });
        setGas(false);
      }
      if (e.code === "ArrowDown" || e.code === "KeyS" || e.code === "Space") {
        apply({ brake: 0 });
        setBrake(false);
      }
      if (e.code === "ShiftLeft" || e.code === "ShiftRight" || e.code === "KeyN") {
        apply({ nitro: false });
        setNitro(false);
      }
    };
    window.addEventListener("keydown", down);
    window.addEventListener("keyup", up);
    return () => {
      window.removeEventListener("keydown", down);
      window.removeEventListener("keyup", up);
    };
  }, [apply, autoAccel]);

  const onStickStart = (e: React.PointerEvent) => {
    const el = e.currentTarget as HTMLElement;
    el.setPointerCapture(e.pointerId);
    const r = el.getBoundingClientRect();
    origin.current = { x: r.left + r.width / 2, y: r.top + r.height / 2, id: e.pointerId };
    moveStick(e.clientX, e.clientY);
  };
  const moveStick = (x: number, y: number) => {
    if (!origin.current) return;
    let dx = x - origin.current.x;
    let dy = y - origin.current.y;
    const max = 48;
    const len = Math.hypot(dx, dy) || 1;
    if (len > max) {
      dx = (dx / len) * max;
      dy = (dy / len) * max;
    }
    setKnob({ x: dx, y: dy });
    apply({ steer: Math.max(-1, Math.min(1, dx / max)) });
  };
  const onStickMove = (e: React.PointerEvent) => {
    if (!origin.current || origin.current.id !== e.pointerId) return;
    moveStick(e.clientX, e.clientY);
  };
  const onStickEnd = (e: React.PointerEvent) => {
    if (origin.current && origin.current.id !== e.pointerId) return;
    origin.current = null;
    setKnob({ x: 0, y: 0 });
    apply({ steer: 0 });
  };

  const hold = (key: "throttle" | "brake" | "nitro", on: boolean) => {
    if (key === "throttle") {
      setGas(on);
      apply({ throttle: on ? 1 : autoAccel ? 1 : 0, brake: on ? 0 : inputRef.current.brake });
    } else if (key === "brake") {
      setBrake(on);
      apply({ brake: on ? 1 : 0, throttle: on ? 0 : autoAccel || gas ? 1 : 0 });
    } else {
      setNitro(on);
      apply({ nitro: on });
    }
  };

  return (
    <div className="controls">
      <div
        className="joystick"
        onPointerDown={onStickStart}
        onPointerMove={onStickMove}
        onPointerUp={onStickEnd}
        onPointerCancel={onStickEnd}
      >
        <div className="joy-ring" />
        <div className="joy-knob" style={{ transform: `translate(${knob.x}px, ${knob.y}px)` }} />
        <span className="joy-label">DIR</span>
      </div>
      <div className="pedals">
        <button
          className={`pedal nitro ${nitro ? "hot" : ""}`}
          onPointerDown={(e) => {
            e.currentTarget.setPointerCapture(e.pointerId);
            hold("nitro", true);
          }}
          onPointerUp={() => hold("nitro", false)}
          onPointerCancel={() => hold("nitro", false)}
        >
          NITRO
        </button>
        <div className="pedal-row">
          <button
            className={`pedal brake ${brake ? "hot" : ""}`}
            onPointerDown={(e) => {
              e.currentTarget.setPointerCapture(e.pointerId);
              hold("brake", true);
            }}
            onPointerUp={() => hold("brake", false)}
            onPointerCancel={() => hold("brake", false)}
          >
            FREIN
          </button>
          <button
            className={`pedal gas ${gas ? "hot" : ""}`}
            onPointerDown={(e) => {
              e.currentTarget.setPointerCapture(e.pointerId);
              hold("throttle", true);
            }}
            onPointerUp={() => hold("throttle", false)}
            onPointerCancel={() => hold("throttle", false)}
          >
            GAZ
          </button>
        </div>
      </div>
    </div>
  );
}
