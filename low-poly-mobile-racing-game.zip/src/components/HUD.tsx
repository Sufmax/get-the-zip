import { useEffect, useRef } from "react";
import { formatTime, posLabel } from "../game/math";
import { buildTrack } from "../game/tracks";
import type { HudSnapshot, RaceResults } from "../game/types";

export function HUD({
  hud,
  trackId,
  onPause,
}: {
  hud: HudSnapshot;
  trackId: string;
  onPause: () => void;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const track = useRef(buildTrack(trackId));
  useEffect(() => {
    track.current = buildTrack(trackId);
  }, [trackId]);

  useEffect(() => {
    const c = canvasRef.current;
    if (!c) return;
    const ctx = c.getContext("2d");
    if (!ctx) return;
    const t = track.current;
    const w = c.width;
    const h = c.height;
    ctx.clearRect(0, 0, w, h);
    let minX = Infinity,
      minZ = Infinity,
      maxX = -Infinity,
      maxZ = -Infinity;
    for (const p of t.points) {
      if (p.x < minX) minX = p.x;
      if (p.z < minZ) minZ = p.z;
      if (p.x > maxX) maxX = p.x;
      if (p.z > maxZ) maxZ = p.z;
    }
    const pad = 10;
    const sx = (w - pad * 2) / (maxX - minX);
    const sz = (h - pad * 2) / (maxZ - minZ);
    const s = Math.min(sx, sz);
    const mapX = (x: number) => pad + (x - minX) * s;
    const mapZ = (z: number) => pad + (z - minZ) * s;
    ctx.strokeStyle = "rgba(255,255,255,0.7)";
    ctx.lineWidth = 3;
    ctx.beginPath();
    t.points.forEach((p, i) => {
      if (i === 0) ctx.moveTo(mapX(p.x), mapZ(p.z));
      else ctx.lineTo(mapX(p.x), mapZ(p.z));
    });
    ctx.closePath();
    ctx.stroke();
    for (const car of hud.minimap) {
      ctx.fillStyle = car.player ? "#fff" : car.color;
      ctx.beginPath();
      ctx.arc(mapX(car.x), mapZ(car.z), car.player ? 4.2 : 3, 0, Math.PI * 2);
      ctx.fill();
      if (car.player) {
        ctx.strokeStyle = "#111";
        ctx.lineWidth = 1;
        ctx.stroke();
      }
    }
  }, [hud.minimap]);

  const speedPct = Math.min(1, hud.speed / Math.max(1, hud.maxSpeed));
  const count = hud.phase === "countdown" ? Math.min(3, Math.ceil(hud.countdown)) : 0;
  const showGo = hud.phase === "countdown" && hud.countdown < 0.35;
  const angle = -Math.PI * 0.75 + speedPct * Math.PI * 1.5;

  return (
    <div className="hud">
      <div className="hud-top">
        <div className="pos-badge">
          <strong>{posLabel(hud.position)}</strong>
          <span>/ {hud.totalCars}</span>
        </div>
        <div className="lap-box">
          <em>TOUR</em>
          <strong>
            {hud.lap}/{hud.totalLaps}
          </strong>
        </div>
        <div className="times">
          <div>
            <em>TEMPS</em> {formatTime(hud.raceTime)}
          </div>
          <div>
            <em>TOUR</em> {formatTime(hud.lapTime)}
          </div>
        </div>
        <button className="pause-btn" onClick={onPause} aria-label="Pause">
          II
        </button>
      </div>

      <canvas ref={canvasRef} className="minimap" width={128} height={128} />

      {hud.phase === "countdown" && (showGo || (count > 0 && hud.countdown > 0.25)) ? (
        <div className={`countdown ${showGo ? "go" : ""}`}>{showGo ? "GO !" : count}</div>
      ) : null}

      {hud.finished && (
        <div className="finish-banner">
          ARRIVÉE — {posLabel(hud.position)}
        </div>
      )}

      <div className="speed-wrap">
        <svg viewBox="0 0 120 90" className="speedo">
          <path d="M15 75 A45 45 0 1 1 105 75" fill="none" stroke="rgba(255,255,255,0.18)" strokeWidth="8" />
          <path
            d="M15 75 A45 45 0 1 1 105 75"
            fill="none"
            stroke={hud.boosting ? "#7dffff" : "#ffd21f"}
            strokeWidth="8"
            strokeDasharray={`${speedPct * 165} 165`}
            strokeLinecap="round"
          />
          <text x="60" y="58" textAnchor="middle" className="spd-num">
            {Math.round(hud.speed)}
          </text>
          <text x="60" y="74" textAnchor="middle" className="spd-unit">
            KM/H
          </text>
        </svg>
        <div className="gear">N{hud.gear}</div>
        <div className="nitro-bar">
          <div className="nitro-fill" style={{ width: `${hud.nitro}%` }} />
          <span>NITRO</span>
        </div>
        <div className="rpm">
          <div className="rpm-fill" style={{ width: `${hud.rpm * 100}%` }} />
        </div>
      </div>

      {hud.drift > 0.28 && <div className="drift-tag">DRIFT</div>}

      <div
        className="vignette"
        style={{
          opacity: Math.max(0, speedPct - 0.25) * 0.9 + (hud.boosting ? 0.25 : 0),
        }}
      />
      <svg className="speed-arc" viewBox="0 0 10 10" style={{ opacity: 0 }}>
        <circle cx={5 + Math.cos(angle)} cy={5} r="0.1" />
      </svg>
    </div>
  );
}

export function ResultsOverlay({
  results,
  onReplay,
  onMenu,
}: {
  results: RaceResults;
  onReplay: () => void;
  onMenu: () => void;
}) {
  return (
    <div className="results">
      <div className="results-card">
        <p className="results-kicker">COURSE TERMINÉE</p>
        <h2>{posLabel(results.position)}</h2>
        <p className="results-sub">
          {formatTime(results.time)} · meilleur tour {formatTime(results.bestLap)} · top {Math.round(results.topSpeed)} km/h
        </p>
        <ol className="board">
          {results.board.map((r) => (
            <li key={r.pos} className={r.player ? "you" : ""}>
              <span className="b-pos">{r.pos}</span>
              <i style={{ background: r.color }} />
              <span className="b-name">{r.name}</span>
              <span className="b-time">{r.finished ? formatTime(r.time) : "DNF"}</span>
            </li>
          ))}
        </ol>
        <div className="results-actions">
          <button className="btn primary" onClick={onReplay}>
            REVANCHE
          </button>
          <button className="btn ghost" onClick={onMenu}>
            MENU
          </button>
        </div>
      </div>
    </div>
  );
}
