import {
  IconAnalyze,
  IconBacktest,
  IconBars,
  IconChart,
  IconClock,
  IconExport,
  IconHome,
  IconSettings,
  LogoMark,
} from '../components/icons';
import { useApp } from '../context/AppContext';
import type { ScreenId } from '../types';

const ITEMS: { id: ScreenId; label: string; icon: typeof IconHome }[] = [
  { id: 'welcome', label: 'Accueil', icon: IconHome },
  { id: 'assets', label: 'Analyser', icon: IconAnalyze },
  { id: 'history', label: 'Historique', icon: IconClock },
  { id: 'favorites', label: 'Favoris', icon: IconChart },
  { id: 'backtest', label: 'Statistiques', icon: IconBars },
  { id: 'backtest', label: 'Backtest', icon: IconBacktest },
];

const EXTRA: { id: ScreenId; label: string; icon: typeof IconHome }[] = [
  { id: 'settings', label: 'Paramètres', icon: IconSettings },
  { id: 'export', label: 'Exporter les résultats', icon: IconExport },
];

export function MenuScreen() {
  const { navigate, back, resetSession } = useApp();

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <div className="flex items-center gap-2 px-4 pb-3 pt-1">
        <button onClick={back} className="flex h-9 w-9 items-center justify-center text-white/80" aria-label="Retour">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M15 6l-6 6 6 6" />
          </svg>
        </button>
        <LogoMark size={28} />
        <span className="text-[18px] font-semibold text-white">MarketScope</span>
      </div>

      <div className="min-h-0 flex-1 overflow-y-auto px-4">
        <div className="overflow-hidden rounded-2xl border border-white/5 bg-[#101c31]">
          {ITEMS.map((it, i) => (
            <button
              key={`${it.label}-${i}`}
              onClick={() => navigate(it.id)}
              className="flex w-full items-center gap-3 border-b border-white/5 px-4 py-3.5 last:border-0"
            >
              <it.icon className="text-slate-400" size={18} />
              <span className="text-[14px] text-white">{it.label}</span>
            </button>
          ))}
        </div>

        <div className="mt-3 overflow-hidden rounded-2xl border border-white/5 bg-[#101c31]">
          {EXTRA.map((it) => (
            <button
              key={it.label}
              onClick={() => navigate(it.id)}
              className="flex w-full items-center justify-between border-b border-white/5 px-4 py-3.5 last:border-0"
            >
              <span className="flex items-center gap-3">
                <it.icon className="text-slate-400" size={18} />
                <span className="text-[14px] text-white">{it.label}</span>
              </span>
              <span className="text-slate-600">›</span>
            </button>
          ))}
        </div>
      </div>

      <button
        onClick={() => {
          resetSession();
        }}
        className="px-5 py-5 text-center text-[14px] font-medium text-rose-400"
      >
        Se déconnecter
      </button>
    </div>
  );
}
