import React, { useState } from 'react';
import { PlayerProgress, CarDefinition, PlayerCarCustomization } from '../types/game';
import { CARS_CATALOG, NEON_COLORS, UPGRADE_PRICES } from '../game/carsData';
import { X, Check, Lock, Zap, Gauge, Disc, Shield, Sparkles, ChevronLeft, ChevronRight } from 'lucide-react';
import { triggerHaptic } from '../services/storage';

interface GarageModalProps {
  progress: PlayerProgress;
  onUpdateProgress: (newProgress: PlayerProgress) => void;
  onClose: () => void;
}

export const GarageModal: React.FC<GarageModalProps> = ({
  progress,
  onUpdateProgress,
  onClose,
}) => {
  const [selectedCarIndex, setSelectedCarIndex] = useState(() => {
    const idx = CARS_CATALOG.findIndex((c) => c.id === progress.selectedCarId);
    return idx >= 0 ? idx : 0;
  });

  const car: CarDefinition = CARS_CATALOG[selectedCarIndex] || CARS_CATALOG[0];
  const isUnlocked = progress.unlockedCars.includes(car.id);
  const isEquipped = progress.selectedCarId === car.id;

  const currentCustom: PlayerCarCustomization = progress.carCustomizations[car.id] || {
    selectedColor: car.baseColor,
    neonColor: 'none',
    upgrades: { engine: 0, brakes: 0, handling: 0, nitro: 0 },
  };

  const handleNextCar = () => {
    setSelectedCarIndex((prev) => (prev + 1) % CARS_CATALOG.length);
    triggerHaptic(15);
  };

  const handlePrevCar = () => {
    setSelectedCarIndex((prev) => (prev - 1 + CARS_CATALOG.length) % CARS_CATALOG.length);
    triggerHaptic(15);
  };

  const handleBuyCar = () => {
    if (progress.cash < car.price) return;
    const newProgress: PlayerProgress = {
      ...progress,
      cash: progress.cash - car.price,
      unlockedCars: [...progress.unlockedCars, car.id],
      selectedCarId: car.id,
      carCustomizations: {
        ...progress.carCustomizations,
        [car.id]: {
          selectedColor: car.baseColor,
          neonColor: 'none',
          upgrades: { engine: 0, brakes: 0, handling: 0, nitro: 0 },
        },
      },
    };
    onUpdateProgress(newProgress);
    triggerHaptic(50);
  };

  const handleEquipCar = () => {
    if (!isUnlocked) return;
    onUpdateProgress({
      ...progress,
      selectedCarId: car.id,
    });
    triggerHaptic(20);
  };

  const handleSelectColor = (hex: string) => {
    const newProgress: PlayerProgress = {
      ...progress,
      carCustomizations: {
        ...progress.carCustomizations,
        [car.id]: {
          ...currentCustom,
          selectedColor: hex,
        },
      },
    };
    onUpdateProgress(newProgress);
    triggerHaptic(15);
  };

  const handleSelectNeon = (neonId: string, hex: string | null) => {
    const newProgress: PlayerProgress = {
      ...progress,
      carCustomizations: {
        ...progress.carCustomizations,
        [car.id]: {
          ...currentCustom,
          neonColor: hex || 'none',
        },
      },
    };
    onUpdateProgress(newProgress);
    triggerHaptic(15);
  };

  const handleUpgrade = (type: 'engine' | 'brakes' | 'handling' | 'nitro') => {
    const curLevel = currentCustom.upgrades[type];
    if (curLevel >= 3) return;
    const cost = UPGRADE_PRICES[type][curLevel];
    if (progress.cash < cost) return;

    const newProgress: PlayerProgress = {
      ...progress,
      cash: progress.cash - cost,
      carCustomizations: {
        ...progress.carCustomizations,
        [car.id]: {
          ...currentCustom,
          upgrades: {
            ...currentCustom.upgrades,
            [type]: curLevel + 1,
          },
        },
      },
    };
    onUpdateProgress(newProgress);
    triggerHaptic(40);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-xl flex flex-col p-4 md:p-8 overflow-y-auto select-none">
      {/* Header */}
      <div className="flex justify-between items-center w-full max-w-5xl mx-auto pb-4 border-b border-white/10">
        <div>
          <h2 className="text-xl md:text-3xl font-black italic tracking-tight text-white uppercase flex items-center gap-2">
            <span>GARAGE</span>
            <span className="text-cyan-400">&amp; PRÉPARATION</span>
          </h2>
          <p className="text-xs text-slate-400">8 bolides low-poly, peintures, néons et pièces compétition</p>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 px-4 py-2 rounded-2xl bg-slate-900 border border-amber-400/40">
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span className="text-sm md:text-base font-black italic text-amber-300">
              {progress.cash.toLocaleString()} Cr
            </span>
          </div>

          <button
            onClick={onClose}
            className="w-10 h-10 rounded-2xl bg-slate-800 hover:bg-slate-700 text-white flex items-center justify-center border border-white/10 active:scale-95 transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="w-full max-w-5xl mx-auto flex-1 grid grid-cols-1 md:grid-cols-2 gap-6 py-6 items-start">
        {/* Left Column: Car Showcase & Selector */}
        <div className="flex flex-col items-center p-6 rounded-3xl bg-slate-900/80 border border-white/10 shadow-2xl relative">
          {/* Navigation Arrows */}
          <div className="flex justify-between items-center w-full mb-4">
            <button
              onClick={handlePrevCar}
              className="w-10 h-10 rounded-2xl bg-slate-800 hover:bg-slate-700 text-white flex items-center justify-center border border-white/10 active:scale-95"
            >
              <ChevronLeft className="w-6 h-6" />
            </button>
            <span className="text-xs font-mono font-bold text-slate-400">
              {selectedCarIndex + 1} / {CARS_CATALOG.length}
            </span>
            <button
              onClick={handleNextCar}
              className="w-10 h-10 rounded-2xl bg-slate-800 hover:bg-slate-700 text-white flex items-center justify-center border border-white/10 active:scale-95"
            >
              <ChevronRight className="w-6 h-6" />
            </button>
          </div>

          {/* Car Name & Badges */}
          <div className="text-center mb-6">
            <div className="text-[10px] font-black uppercase tracking-widest text-cyan-400">
              {car.category}
            </div>
            <h3 className="text-2xl md:text-3xl font-black italic text-white tracking-tight">
              {car.name}
            </h3>
            <p className="text-xs text-slate-400">{car.subtitle}</p>
          </div>

          {/* Color Display Preview */}
          <div
            className="w-48 h-28 rounded-2xl border-2 border-white/20 shadow-2xl flex items-center justify-center mb-6 transition-colors duration-200"
            style={{
              backgroundColor: currentCustom.selectedColor || car.baseColor,
              boxShadow: currentCustom.neonColor && currentCustom.neonColor !== 'none'
                ? `0 20px 40px ${currentCustom.neonColor}60`
                : 'none',
            }}
          >
            <span className="text-black/60 font-black italic text-lg drop-shadow uppercase">
              {car.shape}
            </span>
          </div>

          {/* Action Button: Equip or Buy */}
          {isUnlocked ? (
            <button
              onClick={handleEquipCar}
              disabled={isEquipped}
              className={`w-full py-3.5 rounded-2xl font-black italic text-base tracking-wide flex items-center justify-center gap-2 transition-all ${
                isEquipped
                  ? 'bg-slate-800 text-cyan-400 border border-cyan-500/30'
                  : 'bg-cyan-500 hover:bg-cyan-400 text-white shadow-lg shadow-cyan-500/30 active:scale-95'
              }`}
            >
              {isEquipped ? (
                <>
                  <Check className="w-5 h-5" />
                  <span>VÉHICULE ÉQUIPÉ</span>
                </>
              ) : (
                <span>PILOTER CE BOLIDE</span>
              )}
            </button>
          ) : (
            <button
              onClick={handleBuyCar}
              disabled={progress.cash < car.price}
              className={`w-full py-3.5 rounded-2xl font-black italic text-base tracking-wide flex items-center justify-center gap-2 transition-all ${
                progress.cash >= car.price
                  ? 'bg-gradient-to-r from-amber-500 to-orange-500 hover:brightness-110 text-white shadow-lg shadow-orange-500/30 active:scale-95'
                  : 'bg-slate-800 text-slate-500 border border-white/5 cursor-not-allowed'
              }`}
            >
              <Lock className="w-5 h-5" />
              <span>ACHETER ({car.price.toLocaleString()} Cr)</span>
            </button>
          )}

          <p className="text-[11px] text-slate-400 text-center mt-3 leading-relaxed">
            {car.descriptionFr}
          </p>
        </div>

        {/* Right Column: Customization & Upgrades */}
        <div className="flex flex-col gap-6">
          {/* Paint Swatches */}
          <div className="p-5 rounded-3xl bg-slate-900/80 border border-white/10">
            <h4 className="text-xs font-black uppercase tracking-wider text-slate-300 mb-3">
              Couleur de Carrosserie
            </h4>
            <div className="flex flex-wrap gap-2.5">
              {car.availableColors.map((hex) => {
                const isSelected = (currentCustom.selectedColor || car.baseColor) === hex;
                return (
                  <button
                    key={hex}
                    onClick={() => handleSelectColor(hex)}
                    className={`w-9 h-9 rounded-2xl border-2 transition-all ${
                      isSelected ? 'border-white scale-110 shadow-lg shadow-white/40' : 'border-transparent opacity-80 hover:opacity-100'
                    }`}
                    style={{ backgroundColor: hex }}
                  />
                );
              })}
            </div>
          </div>

          {/* Neon Underglow Kit */}
          <div className="p-5 rounded-3xl bg-slate-900/80 border border-white/10">
            <h4 className="text-xs font-black uppercase tracking-wider text-slate-300 mb-3">
              Kit Néon Sous Châssis
            </h4>
            <div className="flex flex-wrap gap-2">
              {NEON_COLORS.map((neon) => {
                const isSelected = (currentCustom.neonColor || 'none') === (neon.hex || 'none');
                return (
                  <button
                    key={neon.id}
                    onClick={() => handleSelectNeon(neon.id, neon.hex)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition-all ${
                      isSelected
                        ? 'bg-slate-800 border-cyan-400 text-cyan-300 shadow-md shadow-cyan-500/30'
                        : 'bg-slate-950/60 border-white/10 text-slate-400 hover:text-white'
                    }`}
                  >
                    {neon.label}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Performance Upgrades */}
          <div className="p-5 rounded-3xl bg-slate-900/80 border border-white/10">
            <h4 className="text-xs font-black uppercase tracking-wider text-slate-300 mb-4">
              Pièces Compétition (Améliorations)
            </h4>

            <div className="flex flex-col gap-3.5">
              {/* Turbo / Moteur */}
              <UpgradeRow
                label="Moteur & Turbo"
                icon={<Gauge className="w-4 h-4 text-cyan-400" />}
                level={currentCustom.upgrades.engine}
                prices={UPGRADE_PRICES.engine}
                cash={progress.cash}
                onUpgrade={() => handleUpgrade('engine')}
              />

              {/* Freins */}
              <UpgradeRow
                label="Freins Sport & ABS"
                icon={<Disc className="w-4 h-4 text-rose-400" />}
                level={currentCustom.upgrades.brakes}
                prices={UPGRADE_PRICES.brakes}
                cash={progress.cash}
                onUpgrade={() => handleUpgrade('brakes')}
              />

              {/* Maniabilité */}
              <UpgradeRow
                label="Suspension & Pneus"
                icon={<Shield className="w-4 h-4 text-emerald-400" />}
                level={currentCustom.upgrades.handling}
                prices={UPGRADE_PRICES.handling}
                cash={progress.cash}
                onUpgrade={() => handleUpgrade('handling')}
              />

              {/* Nitro */}
              <UpgradeRow
                label="Réservoir Nitro N2O"
                icon={<Zap className="w-4 h-4 text-amber-400" />}
                level={currentCustom.upgrades.nitro}
                prices={UPGRADE_PRICES.nitro}
                cash={progress.cash}
                onUpgrade={() => handleUpgrade('nitro')}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

function UpgradeRow({
  label,
  icon,
  level,
  prices,
  cash,
  onUpgrade,
}: {
  label: string;
  icon: React.ReactNode;
  level: number;
  prices: number[];
  cash: number;
  onUpgrade: () => void;
}) {
  const isMax = level >= 3;
  const cost = !isMax ? prices[level] : 0;
  const canAfford = cash >= cost;

  return (
    <div className="flex items-center justify-between p-2.5 rounded-2xl bg-slate-950/60 border border-white/5">
      <div className="flex items-center gap-2.5">
        {icon}
        <div>
          <div className="text-xs font-bold text-white">{label}</div>
          {/* Level Pips */}
          <div className="flex gap-1 mt-1">
            {[0, 1, 2].map((i) => (
              <div
                key={i}
                className={`w-3.5 h-1.5 rounded-full ${
                  i < level ? 'bg-cyan-400 shadow-sm shadow-cyan-400' : 'bg-slate-800'
                }`}
              />
            ))}
          </div>
        </div>
      </div>

      <div>
        {isMax ? (
          <span className="text-[10px] font-black uppercase tracking-wider text-emerald-400 bg-emerald-950/60 px-2.5 py-1 rounded-xl border border-emerald-500/30">
            MAX
          </span>
        ) : (
          <button
            onClick={onUpgrade}
            disabled={!canAfford}
            className={`px-3 py-1.5 rounded-xl text-xs font-black uppercase tracking-wider transition-all ${
              canAfford
                ? 'bg-cyan-500 hover:bg-cyan-400 text-white shadow-md shadow-cyan-500/30 active:scale-95'
                : 'bg-slate-800 text-slate-500 cursor-not-allowed'
            }`}
          >
            {cost.toLocaleString()} Cr
          </button>
        )}
      </div>
    </div>
  );
}
