import * as THREE from 'three';
import { CarDefinition, PlayerCarCustomization } from '../types/game';
import { TrackData } from './proceduralTrack';

export interface VehicleInputs {
  throttle: number; // 0 to 1
  brake: number; // 0 to 1
  steer: number; // -1 to 1
  handbrake: boolean;
  nitro: boolean;
}

export interface VehicleState {
  position: THREE.Vector3;
  velocity: THREE.Vector3;
  heading: number; // yaw in radians
  angularVelocity: number;
  speed: number; // m/s
  speedKmh: number;
  gear: number;
  rpm: number; // 0 to 1
  isDrifting: boolean;
  driftAngle: number;
  driftScore: number;
  driftMultiplier: number;
  nitroPercent: number; // 0 to 100
  isNitroActive: boolean;
  slipstreamActive: boolean;
  slipstreamTimer: number;
  progressT: number; // 0 to 1 along track
  currentSampleIndex: number;
  hasReachedHalfway: boolean;
  lap: number;
  collisionCooldown: number;
  isAI: boolean;
  aiTargetSpeed: number;
  aiLaneOffset: number; // offset from track center
}

export class PhysicsEngine {
  private trackData: TrackData;

  constructor(trackData: TrackData) {
    this.trackData = trackData;
  }

  public setTrack(trackData: TrackData) {
    this.trackData = trackData;
  }

  public createInitialState(
    startPos: THREE.Vector3,
    startHeading: number,
    isAI = false,
    laneOffset = 0
  ): VehicleState {
    const pos = startPos.clone();
    if (laneOffset !== 0) {
      // Offset perpendicular to heading (right vector)
      pos.x += Math.cos(startHeading) * laneOffset;
      pos.z -= Math.sin(startHeading) * laneOffset;
    }

    // Find initial closest sample index
    let initialIndex = 0;
    let initialT = 0;
    if (this.trackData && this.trackData.samplePoints && this.trackData.samplePoints.length > 0) {
      const samples = this.trackData.samplePoints;
      let minDSq = Infinity;
      for (let i = 0; i < samples.length; i++) {
        const dSq = samples[i].pos.distanceToSquared(pos);
        if (dSq < minDSq) {
          minDSq = dSq;
          initialIndex = i;
        }
      }
      initialT = samples[initialIndex].t;
    }

    return {
      position: pos,
      velocity: new THREE.Vector3(0, 0, 0),
      heading: startHeading,
      angularVelocity: 0,
      speed: 0,
      speedKmh: 0,
      gear: 1,
      rpm: 0.1,
      isDrifting: false,
      driftAngle: 0,
      driftScore: 0,
      driftMultiplier: 1.0,
      nitroPercent: 100,
      isNitroActive: false,
      slipstreamActive: false,
      slipstreamTimer: 0,
      progressT: initialT,
      currentSampleIndex: initialIndex,
      hasReachedHalfway: false,
      lap: 1,
      collisionCooldown: 0,
      isAI,
      aiTargetSpeed: 52 + Math.random() * 18, // 187 - 252 km/h
      aiLaneOffset: laneOffset,
    };
  }

  public updateVehicle(
    state: VehicleState,
    inputs: VehicleInputs,
    carDef: CarDefinition,
    customization: PlayerCarCustomization | undefined,
    dt: number,
    otherVehicles: VehicleState[] = []
  ): {
    collidedBarrier: boolean;
    collidedCar: boolean;
    nearMiss: boolean;
    gearShift: boolean;
    driftJustStarted: boolean;
  } {
    let collidedBarrier = false;
    let collidedCar = false;
    let nearMiss = false;
    let gearShift = false;
    const wasDrifting = state.isDrifting;

    if (state.collisionCooldown > 0) {
      state.collisionCooldown -= dt;
    }

    // Upgrades modifiers
    const upgrades = customization?.upgrades || { engine: 1, turbo: 1, handling: 1, nitro: 1, brakes: 1 };
    const engineMod = 1 + (upgrades.engine - 1) * 0.07;
    const turboMod = 1 + (upgrades.turbo - 1) * 0.08;
    const handlingMod = 1 + (upgrades.handling - 1) * 0.07;
    const nitroMod = 1 + (upgrades.nitro - 1) * 0.1;
    const brakesMod = 1 + (upgrades.brakes - 1) * 0.1;

    const baseTopSpeedKmh = carDef.specs.topSpeed * engineMod;
    let maxSpeedMs = (baseTopSpeedKmh * 1000) / 3600;

    // Nitro handling
    if (inputs.nitro && state.nitroPercent > 0 && inputs.throttle > 0.1) {
      state.isNitroActive = true;
      state.nitroPercent = Math.max(0, state.nitroPercent - dt * (18 / nitroMod));
      maxSpeedMs *= 1.25; // 25% top speed surge on nitro
    } else {
      state.isNitroActive = false;
      // Passive slow nitro regen
      state.nitroPercent = Math.min(100, state.nitroPercent + dt * 4.0);
    }

    // Slipstream (Aspiration) mechanics
    let inSlipstream = false;
    for (const other of otherVehicles) {
      if (other === state) continue;
      const toOther = other.position.clone().sub(state.position);
      toOther.y = 0; // horizontal only
      const dist = toOther.length();

      // Near-miss (passing very close at high speed)
      if (dist < 3.2 && dist > 1.6 && state.speedKmh > 110 && !state.isAI) {
        nearMiss = true;
      }

      // Check if directly behind other car within 28m
      if (dist < 28 && dist > 3.5) {
        const carFwd = new THREE.Vector3(Math.sin(state.heading), 0, Math.cos(state.heading));
        const dot = toOther.normalize().dot(carFwd);
        if (dot > 0.90) {
          inSlipstream = true;
          break;
        }
      }
    }

    state.slipstreamActive = inSlipstream;
    if (inSlipstream) {
      state.slipstreamTimer += dt;
      maxSpeedMs *= 1.12; // 12% slipstream speed boost
      state.nitroPercent = Math.min(100, state.nitroPercent + dt * 7.5);
    } else {
      state.slipstreamTimer = Math.max(0, state.slipstreamTimer - dt * 2);
    }

    // Forward and Right direction vectors
    const forward = new THREE.Vector3(Math.sin(state.heading), 0, Math.cos(state.heading));
    const right = new THREE.Vector3(Math.cos(state.heading), 0, -Math.sin(state.heading));

    // Current forward & lateral speeds
    const currentForwardSpeed = state.velocity.dot(forward);
    const currentLateralSpeed = state.velocity.dot(right);
    const speedMag = state.velocity.length();

    // 1. Throttle / Acceleration
    const baseAccel = (carDef.specs.acceleration * 4.2 * turboMod) * (state.isNitroActive ? 1.85 : inSlipstream ? 1.25 : 1.0);
    let forwardForce = 0;

    if (inputs.throttle > 0) {
      const speedRatio = Math.max(0, currentForwardSpeed / maxSpeedMs);
      const torqueCurve = Math.max(0.12, 1 - Math.pow(Math.min(1, speedRatio), 1.8));
      forwardForce = inputs.throttle * baseAccel * torqueCurve;
    }

    // 2. Braking & Reverse
    if (inputs.brake > 0) {
      if (currentForwardSpeed > 0.8) {
        // Normal braking
        forwardForce -= inputs.brake * 30 * brakesMod;
      } else {
        // Reverse
        forwardForce -= inputs.brake * 12;
      }
    }

    // 3. Rolling resistance & aerodynamic drag
    const dragCoeff = 0.0016;
    const rollingResistance = 0.9;
    if (Math.abs(currentForwardSpeed) > 0.25) {
      forwardForce -= Math.sign(currentForwardSpeed) * (rollingResistance + dragCoeff * currentForwardSpeed * currentForwardSpeed);
    } else if (inputs.throttle === 0 && inputs.brake === 0) {
      // Clamping near zero to avoid micro-jitter at stop
      state.velocity.set(0, 0, 0);
    }

    // 4. Drift mechanics & lateral grip
    const driftEaseFactor = carDef.specs.driftEase / 10;
    const initiatesDrift =
      (inputs.handbrake || (Math.abs(inputs.steer) > 0.55 && inputs.brake > 0.15)) &&
      currentForwardSpeed > 9;

    if (initiatesDrift) {
      state.isDrifting = true;
    } else if (state.isDrifting) {
      if (Math.abs(inputs.steer) < 0.15 && Math.abs(currentLateralSpeed) < 1.8 && !inputs.handbrake) {
        state.isDrifting = false;
      } else if (currentForwardSpeed < 6) {
        state.isDrifting = false;
      }
    }

    // Lateral grip
    const baseGrip = state.isDrifting ? 0.32 + (1 - driftEaseFactor) * 0.14 : 0.96 * handlingMod;
    const lateralFriction = -currentLateralSpeed * baseGrip * 16;

    // Apply forces
    const accelVector = forward.clone().multiplyScalar(forwardForce).add(right.clone().multiplyScalar(lateralFriction));
    state.velocity.addScaledVector(accelVector, dt);

    // Grip alignment in normal driving (responsive arcade handling)
    if (!state.isDrifting && speedMag > 1.0) {
      const targetForwardVel = forward.clone().multiplyScalar(state.velocity.dot(forward));
      const gripRate = Math.min(1, dt * 12 * handlingMod);
      state.velocity.lerp(targetForwardVel, gripRate);
    }

    // Speed calculation
    state.speed = state.velocity.length();
    state.speedKmh = Math.round(state.speed * 3.6);

    // 5. Steering & Yaw Rotation (Positive steer = turn RIGHT)
    const steerSpeedFactor = Math.min(1, Math.max(0.22, speedMag / 9));
    const maxSteerRate = (carDef.specs.handling / 10) * 2.85 * handlingMod;
    const steerDir = currentForwardSpeed < -0.5 ? -1 : 1;
    let targetAngularVel = steerDir * inputs.steer * maxSteerRate * steerSpeedFactor;

    if (state.isDrifting) {
      // Oversteer in drift
      targetAngularVel *= 1.45;
      // Drift score accumulation
      const driftDelta = Math.abs(currentLateralSpeed) * dt * 50 * state.driftMultiplier;
      state.driftScore += Math.round(driftDelta);
      state.driftMultiplier = Math.min(5.0, state.driftMultiplier + dt * 0.35);
      // Nitro bonus for drifting
      state.nitroPercent = Math.min(100, state.nitroPercent + dt * 9);
    } else {
      state.driftMultiplier = 1.0;
    }

    state.angularVelocity += (targetAngularVel - state.angularVelocity) * 12 * dt;
    state.heading += state.angularVelocity * dt;

    // Drift Angle (difference between heading and velocity vector)
    if (state.speed > 4) {
      const velAngle = Math.atan2(state.velocity.x, state.velocity.z);
      let angleDiff = state.heading - velAngle;
      while (angleDiff > Math.PI) angleDiff -= Math.PI * 2;
      while (angleDiff < -Math.PI) angleDiff += Math.PI * 2;
      state.driftAngle = angleDiff;
    } else {
      state.driftAngle = 0;
    }

    // 6. 6-Speed Transmission & RPM
    const gearMaxSpeeds = [
      maxSpeedMs * 0.22,
      maxSpeedMs * 0.38,
      maxSpeedMs * 0.55,
      maxSpeedMs * 0.72,
      maxSpeedMs * 0.88,
      maxSpeedMs * 1.15,
    ];

    const prevGear = state.gear;
    let currentGear = 1;
    for (let g = 0; g < gearMaxSpeeds.length; g++) {
      if (currentForwardSpeed > gearMaxSpeeds[g] && g < 5) {
        currentGear = g + 2;
      }
    }
    state.gear = currentGear;
    if (state.gear !== prevGear) {
      gearShift = true;
    }

    // RPM computation (0 to 1)
    const prevGearSpeed = currentGear === 1 ? 0 : gearMaxSpeeds[currentGear - 2];
    const nextGearSpeed = gearMaxSpeeds[currentGear - 1];
    state.rpm = Math.min(1, Math.max(0.12, (currentForwardSpeed - prevGearSpeed) / Math.max(1, nextGearSpeed - prevGearSpeed)));

    // 7. Update Position
    state.position.addScaledVector(state.velocity, dt);

    // 8. Track Progress & Elevation
    this.updateTrackProgress(state);

    // 9. Barrier Collisions
    if (this.checkBarrierCollisions(state)) {
      collidedBarrier = true;
      state.collisionCooldown = 0.2;
    }

    // 10. Car-to-Car 2D Horizontal Collisions
    for (const other of otherVehicles) {
      if (other === state) continue;
      const diff = state.position.clone().sub(other.position);
      diff.y = 0; // horizontal collision only
      const dist = diff.length();
      const minDistance = 2.4; // vehicle collision diameter

      if (dist < minDistance && dist > 0.001) {
        collidedCar = true;
        const pushDir = diff.normalize();
        const overlap = minDistance - dist;

        // Separate cars horizontally
        state.position.addScaledVector(pushDir, overlap * 0.52);
        other.position.addScaledVector(pushDir, -overlap * 0.52);

        // Exchange momentum
        const impulse = pushDir.multiplyScalar(state.velocity.dot(pushDir) - other.velocity.dot(pushDir));
        state.velocity.addScaledVector(impulse, -0.65);
        other.velocity.addScaledVector(impulse, 0.65);
      }
    }

    return {
      collidedBarrier,
      collidedCar,
      nearMiss,
      gearShift,
      driftJustStarted: state.isDrifting && !wasDrifting,
    };
  }

  private updateTrackProgress(state: VehicleState) {
    if (this.trackData.isEndlessHighway) {
      // In endless mode, progress is measured along -Z
      state.progressT = Math.max(0, -state.position.z / Math.max(1, this.trackData.trackLength));
      return;
    }

    const samples = this.trackData.samplePoints;
    if (!samples || samples.length === 0) return;

    // Local window search around current index (prevents cross-track jumping)
    let closestDistSq = Infinity;
    let closestIndex = state.currentSampleIndex;
    const windowStart = -12;
    const windowEnd = 35;

    for (let offset = windowStart; offset <= windowEnd; offset++) {
      const idx = (state.currentSampleIndex + offset + samples.length) % samples.length;
      const distSq = samples[idx].pos.distanceToSquared(state.position);
      if (distSq < closestDistSq) {
        closestDistSq = distSq;
        closestIndex = idx;
      }
    }

    const currentSample = samples[closestIndex];
    const prevT = state.progressT;
    const newT = currentSample.t;

    // Track when vehicle reaches halfway through circuit
    if (newT > 0.40 && newT < 0.60) {
      state.hasReachedHalfway = true;
    }

    // Only award lap completion if vehicle has legitimately traveled halfway around
    if (state.hasReachedHalfway && prevT > 0.82 && newT < 0.18) {
      state.lap += 1;
      state.hasReachedHalfway = false;
    }

    state.currentSampleIndex = closestIndex;
    state.progressT = newT;

    // Elevation soft snap to road surface
    const targetY = currentSample.pos.y + 0.04;
    state.position.y += (targetY - state.position.y) * 0.22;
  }

  private checkBarrierCollisions(state: VehicleState): boolean {
    if (this.trackData.isEndlessHighway) {
      // Highway left/right bounds
      const halfW = this.trackData.roadWidth * 0.5 - 1.2;
      if (Math.abs(state.position.x) > halfW) {
        state.position.x = Math.sign(state.position.x) * halfW;
        state.velocity.x *= -0.45;
        state.velocity.z *= 0.88;
        return true;
      }
      return false;
    }

    // Circuit track: test lateral distance from track centerline
    const samples = this.trackData.samplePoints;
    const centerPt = samples[state.currentSampleIndex] || samples[0];
    if (!centerPt) return false;

    const toCar = state.position.clone().sub(centerPt.pos);
    const lateralDist = toCar.dot(centerPt.normal);
    const maxHalfW = this.trackData.roadWidth * 0.5 - 0.8;

    if (Math.abs(lateralDist) > maxHalfW) {
      const excess = Math.abs(lateralDist) - maxHalfW;
      const pushSign = Math.sign(lateralDist);

      // Push car back onto track along normal vector without snapping tangent progress
      state.position.addScaledVector(centerPt.normal, -pushSign * (excess + 0.12));

      // Rebound lateral velocity
      const normalVel = state.velocity.dot(centerPt.normal);
      if (Math.sign(normalVel) === pushSign) {
        state.velocity.addScaledVector(centerPt.normal, -normalVel * 1.35);
        state.velocity.multiplyScalar(0.85); // friction loss on wall contact
      }
      return true;
    }

    return false;
  }

  // AI Opponent steering and throttle AI
  public updateAI(
    aiState: VehicleState,
    _aiDef: CarDefinition,
    dt: number,
    otherVehicles: VehicleState[]
  ): VehicleInputs {
    if (this.trackData.isEndlessHighway) {
      // Highway traffic traveling steadily forward along -Z
      return {
        throttle: 0.65,
        brake: 0,
        steer: 0,
        handbrake: false,
        nitro: false,
      };
    }

    // Look ahead on spline
    const samples = this.trackData.samplePoints;
    const lookAheadSteps = 14;
    const targetIdx = (aiState.currentSampleIndex + lookAheadSteps) % samples.length;
    const targetPt = samples[targetIdx];

    // Compute target position with lane offset
    const targetPos = targetPt.pos.clone().addScaledVector(targetPt.normal, aiState.aiLaneOffset);
    const toTarget = targetPos.clone().sub(aiState.position);

    // Compute desired heading
    const desiredHeading = Math.atan2(toTarget.x, toTarget.z);
    let headingDiff = desiredHeading - aiState.heading;
    while (headingDiff > Math.PI) headingDiff -= Math.PI * 2;
    while (headingDiff < -Math.PI) headingDiff += Math.PI * 2;

    // AI steering (positive steer turns right)
    const steer = Math.max(-1, Math.min(1, headingDiff * 2.8));

    // Dynamic AI throttle and cornering speed control
    const absHeadingDiff = Math.abs(headingDiff);
    const isSharpTurn = absHeadingDiff > 0.42;
    const isMediumTurn = absHeadingDiff > 0.22;

    const cornerMaxSpeed = isSharpTurn ? 105 : isMediumTurn ? 155 : 260;
    const targetSpeedKmh = Math.min(aiState.aiTargetSpeed * 3.6, cornerMaxSpeed);

    let throttle = 1.0;
    let brake = 0;

    if (aiState.speedKmh > targetSpeedKmh + 8) {
      throttle = 0;
      brake = Math.min(1, (aiState.speedKmh - targetSpeedKmh) / 20);
    } else if (aiState.speedKmh > targetSpeedKmh) {
      throttle = 0.35;
      brake = 0;
    } else {
      throttle = 1.0;
      brake = 0;
    }

    // AI nitro usage on straights
    const useNitro = !isSharpTurn && !isMediumTurn && aiState.nitroPercent > 45 && Math.random() < 0.04;

    // Avoid other cars ahead
    for (const other of otherVehicles) {
      if (other === aiState) continue;
      const toOther = other.position.clone().sub(aiState.position);
      const fwd = new THREE.Vector3(Math.sin(aiState.heading), 0, Math.cos(aiState.heading));
      const dist = toOther.length();
      const dot = toOther.dot(fwd);

      if (dist < 10 && dot > 0) {
        // Shift lane to overtake
        aiState.aiLaneOffset += (aiState.aiLaneOffset >= 0 ? 1 : -1) * dt * 4;
        aiState.aiLaneOffset = Math.max(-5, Math.min(5, aiState.aiLaneOffset));
        if (dist < 4.5 && aiState.speed > other.speed) {
          brake = 0.35;
        }
      }
    }

    return {
      throttle,
      brake,
      steer,
      handbrake: isSharpTurn && aiState.speedKmh > 135,
      nitro: useNitro,
    };
  }
}
