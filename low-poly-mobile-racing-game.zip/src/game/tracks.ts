import type { BuiltTrack, Decoration, TrackDef, Vec2 } from "./types";
import { catmullRomClosed, mulberry32 } from "./math";

export const TRACKS: TrackDef[] = [
  {
    id: "azure",
    name: "Circuit Azure",
    desc: "Grandes courbes côtières. Idéal pour la vitesse.",
    difficulty: 2,
    laps: 3,
    width: 20,
    grip: 1,
    theme: "coast",
    skyTop: "#3aa0ff",
    skyBot: "#d7f0ff",
    fog: "#b9dcf5",
    ground: "#3aa24a",
    ground2: "#e7d28a",
    ambient: 0.72,
    sun: 1.15,
    sunColor: "#fff4d2",
    fn: (t) => {
      const a = t * Math.PI * 2;
      const r = 255 + 48 * Math.sin(2 * a) + 18 * Math.sin(5 * a);
      return { x: Math.cos(a) * r * 1.42, z: Math.sin(a) * r };
    },
  },
  {
    id: "canyon",
    name: "Canyon Solaire",
    desc: "Épingles de désert et dévers de sable.",
    difficulty: 3,
    laps: 3,
    width: 16,
    grip: 0.86,
    theme: "desert",
    skyTop: "#ff8a3a",
    skyBot: "#ffd9a0",
    fog: "#efc08a",
    ground: "#d2a15c",
    ground2: "#c4893d",
    ambient: 0.7,
    sun: 1.25,
    sunColor: "#ffd19a",
    fn: (t) => {
      const a = t * Math.PI * 2;
      const r = 210 + 78 * Math.sin(3 * a) + 28 * Math.cos(5 * a);
      return { x: Math.cos(a) * r * 1.18, z: Math.sin(a) * r * 0.96 };
    },
  },
  {
    id: "neon",
    name: "Nuit Néon",
    desc: "Métro de minuit, néons et chicanes urbaines.",
    difficulty: 3,
    laps: 3,
    width: 17.5,
    grip: 0.95,
    theme: "city",
    skyTop: "#070414",
    skyBot: "#1a0a3a",
    fog: "#140822",
    ground: "#16161f",
    ground2: "#0e0e16",
    ambient: 0.28,
    sun: 0.35,
    sunColor: "#8a7cff",
    fn: (t) => {
      const a = t * Math.PI * 2;
      const s = 0.62;
      const r = 236 + 16 * Math.sin(8 * a) + 10 * Math.sin(3 * a);
      const x = Math.sign(Math.cos(a)) * Math.pow(Math.abs(Math.cos(a)), s) * r * 1.38;
      const z = Math.sign(Math.sin(a)) * Math.pow(Math.abs(Math.sin(a)), s) * r * 0.95;
      return { x, z };
    },
  },
  {
    id: "foret",
    name: "Forêt Tunnel",
    desc: "Couloir d'arbres. Sensation de vitesse maximale.",
    difficulty: 4,
    laps: 4,
    width: 15,
    grip: 0.92,
    theme: "forest",
    skyTop: "#1e5a8c",
    skyBot: "#9ec8c0",
    fog: "#7aa090",
    ground: "#2d6a38",
    ground2: "#1e4a28",
    ambient: 0.5,
    sun: 0.7,
    sunColor: "#d0e8c8",
    fn: (t) => {
      const a = t * Math.PI * 2;
      const r = 200 + 55 * Math.sin(4 * a) + 22 * Math.sin(7 * a);
      return { x: Math.cos(a) * r * 1.22, z: Math.sin(a) * r * 1.05 };
    },
  },
];

function wrapAngle(a: number) {
  while (a > Math.PI) a -= Math.PI * 2;
  while (a < -Math.PI) a += Math.PI * 2;
  return a;
}

function rotate<T>(arr: T[], start: number): T[] {
  return arr.slice(start).concat(arr.slice(0, start));
}

function findStart(points: Vec2[], tangents: Vec2[]) {
  const n = points.length;
  let best = 0;
  let bestScore = Infinity;
  for (let i = 0; i < n; i++) {
    let score = 0;
    for (let k = 0; k < 28; k++) {
      const a = Math.atan2(tangents[(i + k) % n].x, tangents[(i + k) % n].z);
      const b = Math.atan2(tangents[(i + k + 1) % n].x, tangents[(i + k + 1) % n].z);
      score += Math.abs(wrapAngle(a - b));
    }
    if (score < bestScore) {
      bestScore = score;
      best = i;
    }
  }
  return best;
}

function placeDecorations(
  def: TrackDef,
  points: Vec2[],
  normals: Vec2[],
  tangents: Vec2[],
): { decorations: Decoration[]; mountains: BuiltTrack["mountains"] } {
  const rng = mulberry32(def.id.split("").reduce((s, c) => s + c.charCodeAt(0), 1));
  const decorations: Decoration[] = [];
  const n = points.length;
  const treeKind = def.theme === "coast" ? "palm" : def.theme === "forest" ? "pine" : def.theme === "desert" ? "cactus" : "lamp";
  const step = def.theme === "forest" ? 1 : def.theme === "city" ? 3 : 2;

  for (let i = 0; i < n; i += step) {
    const p = points[i];
    const nor = normals[i];
    const both = def.theme === "forest" || i % 2 === 0;
    const sides = both ? [1, -1] : [i % 4 === 0 ? 1 : -1];
    for (const side of sides) {
      const dist = def.width / 2 + 3.2 + rng() * (def.theme === "forest" ? 2.2 : 6);
      const kind =
        def.theme === "city"
          ? rng() > 0.55
            ? "lamp"
            : "sign"
          : def.theme === "desert" && rng() > 0.7
            ? "rock"
            : treeKind;
      decorations.push({
        kind,
        x: p.x + nor.x * side * dist,
        z: p.z + nor.z * side * dist,
        rot: Math.atan2(tangents[i].x, tangents[i].z) + (rng() - 0.5) * 0.4,
        scale: 0.75 + rng() * 0.7,
        h: 1,
        color: "#ffffff",
      });
    }
  }

  if (def.theme === "city") {
    for (let i = 0; i < 90; i++) {
      const t = rng();
      const p = points[Math.floor(t * n) % n];
      const nor = normals[Math.floor(t * n) % n];
      const side = rng() > 0.5 ? 1 : -1;
      const dist = def.width / 2 + 14 + rng() * 70;
      decorations.push({
        kind: "building",
        x: p.x + nor.x * side * dist,
        z: p.z + nor.z * side * dist,
        rot: rng() * Math.PI * 2,
        scale: 0.8 + rng() * 1.8,
        h: 8 + rng() * 28,
        color: rng() > 0.5 ? "#1b1630" : "#241a3a",
      });
    }
  }

  if (def.theme === "desert") {
    for (let i = 0; i < 70; i++) {
      const t = rng();
      const p = points[Math.floor(t * n) % n];
      const nor = normals[Math.floor(t * n) % n];
      const side = rng() > 0.5 ? 1 : -1;
      const dist = def.width / 2 + 10 + rng() * 55;
      decorations.push({
        kind: "rock",
        x: p.x + nor.x * side * dist,
        z: p.z + nor.z * side * dist,
        rot: rng() * Math.PI,
        scale: 0.6 + rng() * 2.2,
        h: 1 + rng() * 3,
        color: rng() > 0.5 ? "#c4893d" : "#a86c2e",
      });
    }
  }

  if (def.theme === "forest") {
    for (let i = 0; i < 160; i++) {
      const t = rng();
      const p = points[Math.floor(t * n) % n];
      const nor = normals[Math.floor(t * n) % n];
      const side = rng() > 0.5 ? 1 : -1;
      const dist = def.width / 2 + 8 + rng() * 40;
      decorations.push({
        kind: "pine",
        x: p.x + nor.x * side * dist,
        z: p.z + nor.z * side * dist,
        rot: rng() * Math.PI,
        scale: 0.9 + rng() * 1.4,
        h: 1,
        color: "#1f6a32",
      });
    }
  }

  if (def.theme === "coast") {
    for (let i = 0; i < 40; i++) {
      const t = rng();
      const p = points[Math.floor(t * n) % n];
      const nor = normals[Math.floor(t * n) % n];
      const side = rng() > 0.5 ? 1 : -1;
      const dist = def.width / 2 + 16 + rng() * 40;
      decorations.push({
        kind: "palm",
        x: p.x + nor.x * side * dist,
        z: p.z + nor.z * side * dist,
        rot: rng() * Math.PI,
        scale: 0.9 + rng() * 0.8,
        h: 1,
        color: "#2f8a3a",
      });
    }
  }

  const mountains: BuiltTrack["mountains"] = [];
  for (let i = 0; i < 18; i++) {
    const a = (i / 18) * Math.PI * 2 + rng() * 0.2;
    const rr = 520 + rng() * 180;
    mountains.push({
      x: Math.cos(a) * rr,
      z: Math.sin(a) * rr,
      s: 40 + rng() * 90,
      h: 40 + rng() * 110,
      color:
        def.theme === "desert"
          ? "#c47a3a"
          : def.theme === "city"
            ? "#1a1230"
            : def.theme === "forest"
              ? "#2a4a38"
              : "#4a8a58",
    });
  }

  return { decorations, mountains };
}

const cache = new Map<string, BuiltTrack>();

export function buildTrack(id: string): BuiltTrack {
  const hit = cache.get(id);
  if (hit) return hit;
  const def = TRACKS.find((t) => t.id === id) ?? TRACKS[0];
  const controls: Vec2[] = [];
  for (let i = 0; i < 32; i++) controls.push(def.fn(i / 32));
  let points = catmullRomClosed(controls, 12);

  const n = points.length;
  const tangents: Vec2[] = [];
  const normals: Vec2[] = [];
  const cumlen: number[] = [];
  let length = 0;
  for (let i = 0; i < n; i++) {
    const a = points[(i - 1 + n) % n];
    const b = points[(i + 1) % n];
    let tx = b.x - a.x;
    let tz = b.z - a.z;
    const len = Math.hypot(tx, tz) || 1;
    tx /= len;
    tz /= len;
    tangents.push({ x: tx, z: tz });
    normals.push({ x: -tz, z: tx });
  }
  cumlen.push(0);
  for (let i = 1; i < n; i++) {
    length += Math.hypot(points[i].x - points[i - 1].x, points[i].z - points[i - 1].z);
    cumlen.push(length);
  }
  length += Math.hypot(points[0].x - points[n - 1].x, points[0].z - points[n - 1].z);

  const start = findStart(points, tangents);
  points = rotate(points, start);
  const tangentsR = rotate(tangents, start);
  const normalsR = rotate(normals, start);
  const cum0 = cumlen[start];
  const cumR = cumlen.map((c) => {
    const v = c - cum0;
    return v < 0 ? v + length : v;
  });
  const cumRR = rotate(cumR, start);
  cumRR[0] = 0;

  const { decorations, mountains } = placeDecorations(def, points, normalsR, tangentsR);

  const built: BuiltTrack = {
    id: def.id,
    name: def.name,
    desc: def.desc,
    difficulty: def.difficulty,
    laps: def.laps,
    width: def.width,
    grip: def.grip,
    theme: def.theme,
    skyTop: def.skyTop,
    skyBot: def.skyBot,
    fog: def.fog,
    ground: def.ground,
    ground2: def.ground2,
    ambient: def.ambient,
    sun: def.sun,
    sunColor: def.sunColor,
    length,
    points,
    tangents: tangentsR,
    normals: normalsR,
    cumlen: cumRR,
    decorations,
    mountains,
  };
  cache.set(id, built);
  return built;
}

export function getTrackDef(id: string) {
  return TRACKS.find((t) => t.id === id) ?? TRACKS[0];
}

export function pointAt(track: BuiltTrack, dist: number) {
  const d = ((dist % track.length) + track.length) % track.length;
  const n = track.points.length;
  let lo = 0;
  let hi = n - 1;
  while (lo < hi) {
    const mid = (lo + hi) >> 1;
    if (track.cumlen[mid] < d) lo = mid + 1;
    else hi = mid;
  }
  const i = lo % n;
  return {
    i,
    x: track.points[i].x,
    z: track.points[i].z,
    tx: track.tangents[i].x,
    tz: track.tangents[i].z,
    nx: track.normals[i].x,
    nz: track.normals[i].z,
  };
}
