import { CategoryGlyph, IconChevronRight, LogoMark } from '../components/icons';
import { Button } from '../components/ui/primitives';
import { useApp } from '../context/AppContext';
import type { AssetCategory } from '../types';
import welcomeBg from '../assets/welcome-bg.jpg';

const CATEGORIES: { id: AssetCategory; title: string; subtitle: string }[] = [
  { id: 'crypto', title: 'Cryptomonnaies', subtitle: 'BTC, ETH, etc.' },
  { id: 'forex', title: 'Forex', subtitle: 'EUR/USD, GBP/USD, etc.' },
  { id: 'stock', title: 'Actions', subtitle: 'AAPL, MSFT, etc.' },
  { id: 'commodity', title: 'Matières premières', subtitle: 'Or, pétrole, etc.' },
];

export function WelcomeScreen() {
  const { navigate, setCategory } = useApp();

  const open = (cat: AssetCategory | 'all') => {
    setCategory(cat);
    navigate('assets');
  };

  return (
    <div className="relative flex min-h-0 flex-1 flex-col overflow-hidden">
      <img
        src={welcomeBg}
        alt=""
        className="pointer-events-none absolute inset-x-0 top-[-52px] h-[46%] w-full object-cover opacity-80"
      />
      <div className="pointer-events-none absolute inset-x-0 top-[-52px] h-[50%] bg-gradient-to-b from-transparent via-[#07111f]/20 to-[#07111f]" />

      <div className="relative z-10 flex flex-1 flex-col px-6 pb-2 pt-6">
        <div className="flex flex-col items-center pt-6 text-center">
          <LogoMark size={64} />
          <h1 className="mt-3 text-[34px] font-bold tracking-tight text-white">MarketScope</h1>
          <p className="mt-2 max-w-[240px] text-[14px] leading-snug text-slate-400">
            Analysez les marchés,
            <br />
            repérez les opportunités
          </p>
        </div>

        <div className="mt-8 flex flex-col gap-2.5">
          {CATEGORIES.map((c) => (
            <button
              key={c.id}
              onClick={() => open(c.id)}
              className="flex items-center gap-3 rounded-2xl border border-white/6 bg-[#121e33]/85 px-3.5 py-3 text-left backdrop-blur-md transition active:scale-[0.99]"
            >
              <CategoryGlyph category={c.id} size={40} />
              <div className="min-w-0 flex-1">
                <div className="text-[15px] font-semibold text-white">{c.title}</div>
                <div className="text-[12px] text-slate-400">{c.subtitle}</div>
              </div>
              <IconChevronRight className="text-slate-500" />
            </button>
          ))}
        </div>

        <div className="mt-auto pt-6">
          <Button variant="blue" onClick={() => open('all')}>
            Commencer
          </Button>
        </div>
      </div>
    </div>
  );
}
