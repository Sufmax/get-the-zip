import { db } from "@/db";
import { playerProfiles } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get("id");

    if (!id) {
      return NextResponse.json({ success: false, error: "Missing player ID" }, { status: 400 });
    }

    const profiles = await db
      .select()
      .from(playerProfiles)
      .where(eq(playerProfiles.id, id))
      .limit(1);

    if (profiles.length === 0) {
      return NextResponse.json({ success: true, profile: null });
    }

    return NextResponse.json({ success: true, profile: profiles[0] });
  } catch (err) {
    console.error("Profile GET error:", err);
    return NextResponse.json({ success: false, error: "Failed to load profile" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { id, playerName, cash, unlockedCars, carCustomizations, achievements } = body;

    if (!id || !playerName) {
      return NextResponse.json({ success: false, error: "Missing required fields" }, { status: 400 });
    }

    const existing = await db
      .select()
      .from(playerProfiles)
      .where(eq(playerProfiles.id, id))
      .limit(1);

    let savedProfile;
    if (existing.length > 0) {
      savedProfile = await db
        .update(playerProfiles)
        .set({
          playerName: String(playerName).slice(0, 30),
          cash: Number(cash) || 0,
          unlockedCars: Array.isArray(unlockedCars) ? unlockedCars : ["apex_gt"],
          carCustomizations: carCustomizations || {},
          achievements: Array.isArray(achievements) ? achievements : [],
          updatedAt: new Date(),
        })
        .where(eq(playerProfiles.id, id))
        .returning();
    } else {
      savedProfile = await db
        .insert(playerProfiles)
        .values({
          id: String(id),
          playerName: String(playerName).slice(0, 30),
          cash: Number(cash) || 5000,
          unlockedCars: Array.isArray(unlockedCars) ? unlockedCars : ["apex_gt"],
          carCustomizations: carCustomizations || {},
          achievements: Array.isArray(achievements) ? achievements : [],
        })
        .returning();
    }

    return NextResponse.json({ success: true, profile: savedProfile[0] });
  } catch (err) {
    console.error("Profile POST error:", err);
    return NextResponse.json({ success: false, error: "Failed to save profile" }, { status: 500 });
  }
}
