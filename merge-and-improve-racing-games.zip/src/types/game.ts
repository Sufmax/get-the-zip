export type GameMode = 'circuit' | 'time_trial' | 'endless_traffic';

export type CarShape = 'sport' | 'muscle' | 'tuner' | 'formula' | 'buggy' | 'suv' | 'hyper' | 'van';

export interface CarSpecs {
  topSpeed: number; // km/h (e.g. 240)
  acceleration: number; // 1-10
  handling: number; // 1-10
  driftEase: number; // 1-10
  nitroBoost: number; // 1-10
  weight: number; // kg
}

export interface CarDefinition {
  id: string;
  name: string;
  subtitle: string;
  category: 'sport' | 'muscle' | 'tuner' | 'hypercar' | 'formula' | 'offroad' | 'retro' | 'suv';
  shape: CarShape;
  price: number;
  unlockedByDefault: boolean;
  baseColor: string;
  availableColors: string[];
  specs: CarSpecs;
  descriptionFr: string;
  descriptionEn: string;
  soundType: 'turbo' | 'v8' | 'supercar' | 'electric';
}

export interface TrackDefinition {
  id: string;
  nameFr: string;
  nameEn: string;
  subtitleFr: string;
  subtitleEn: string;
  lengthMeters: number;
  defaultLaps: number;
  difficulty: 'Facile' | 'Moyen' | 'Difficile' | 'Expert';
  theme: 'coast' | 'desert' | 'cyber' | 'snow' | 'forest' | 'highway';
  skyColor: string;
  ambientLight: string;
  sunColor: string;
  fogColor: string;
  fogDensity: number;
  groundColor: string;
  roadColor: string;
  curbColor1: string;
  curbColor2: string;
  recordTime: number;
}

export interface PlayerCarCustomization {
  selectedColor?: string;
  neonColor?: string; // hex or 'none'
  rimType?: 'stock' | 'sport' | 'deep_dish' | 'aerodisc';
  upgrades: {
    engine: number; // 0 to 3
    brakes: number; // 0 to 3
    handling: number; // 0 to 3
    nitro: number; // 0 to 3
  };
}

export interface PlayerProgress {
  cash: number;
  unlockedCars: string[];
  selectedCarId: string;
  carCustomizations: Record<string, PlayerCarCustomization>;
  bestLapTimes: Record<string, number>;
  completedTracks: Record<string, number>; // trackId -> max stars (1-3)
  highScores: {
    endlessDistance: number;
    maxDriftScore: number;
  };
  achievementsUnlocked: string[];
}

export type ControlScheme = 'joystick' | 'buttons' | 'wheel';

export interface ControlSettings {
  scheme: ControlScheme;
  steeringSensitivity: number; // 0.4 to 1.8
  autoAccelerate: boolean;
  cameraView: 'chase' | 'action' | 'hood' | 'topdown';
  cameraFovBoost: boolean;
  audioMaster: number;
  soundEnabled: boolean;
  musicEnabled: boolean;
  quality: 'low' | 'medium' | 'high';
}

export interface RaceState {
  mode: GameMode;
  trackId: string;
  lap: number;
  totalLaps: number;
  position: number;
  totalRacers: number;
  currentLapTime: number;
  lastLapTime: number;
  bestLapTime: number;
  raceTime: number;
  speedKmh: number;
  rpm: number;
  gear: number;
  driftScore: number;
  driftMultiplier: number;
  isDrifting: boolean;
  nitroPercent: number;
  isNitroActive: boolean;
  nearMissCount: number;
  slipstreamActive: boolean;
  finished: boolean;
  countdown: number;
  distanceTraveled: number;
  playerCoord: { x: number; z: number };
  playerHeading: number;
  aiCoords: { x: number; z: number }[];
}

export interface VehicleInputs {
  throttle: number;
  brake: number;
  steer: number;
  handbrake: boolean;
  nitro: boolean;
}

export interface Achievement {
  id: string;
  titleFr: string;
  titleEn: string;
  descFr: string;
  descEn: string;
  icon: string;
  rewardCash: number;
  progressMax: number;
}
