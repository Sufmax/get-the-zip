import * as THREE from 'three';
import { GameMode, RaceState, PlayerProgress, ControlSettings, CarDefinition } from '../types/game';
import { CARS_CATALOG } from './carsData';
import { TRACKS_CATALOG } from './tracksData';
import { buildLowPolyCar, Car3DObject } from './proceduralCar';
import { buildProceduralTrack, TrackData } from './proceduralTrack';
import { PhysicsEngine, VehicleInputs, VehicleState } from './physics';
import { ParticleSystem } from './particles';
import { audio } from '../services/audio';
import { triggerHaptic } from '../services/storage';

export type CameraView = 'chase' | 'action' | 'hood' | 'topdown';

export class GameEngine {
  private container: HTMLDivElement;
  private renderer: THREE.WebGLRenderer;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private sunLight: THREE.DirectionalLight;
  private ambientLight: THREE.AmbientLight;

  private trackData!: TrackData;
  private physics!: PhysicsEngine;
  private particles!: ParticleSystem;

  // Player
  private playerCar3D!: Car3DObject;
  private playerState!: VehicleState;
  private playerCarDef!: CarDefinition;
  private playerInputs: VehicleInputs = {
    throttle: 0,
    brake: 0,
    steer: 0,
    handbrake: false,
    nitro: false,
  };

  // AI Opponents / Traffic
  private aiCars3D: Car3DObject[] = [];
  private aiStates: VehicleState[] = [];
  private aiDefs: CarDefinition[] = [];

  // Camera settings
  private cameraView: CameraView = 'chase';
  private cameraShakeIntensity = 0;
  private cameraTarget = new THREE.Vector3();
  private baseFov = 65;

  // Race & Mode State
  private mode: GameMode;
  private trackId: string;
  private progress: PlayerProgress;
  private settings: ControlSettings;
  private onStateChange: (state: RaceState) => void;
  private onRaceFinish: (result: {
    position: number;
    totalTime: number;
    bestLap: number;
    driftScore: number;
    distance: number;
    cashEarned: number;
    nearMisses: number;
  }) => void;

  private isRunning = false;
  private isPaused = false;
  private animationFrameId: number | null = null;
  private lastTime = 0;

  // Timers
  private countdown = 3.6; // 3, 2, 1, GO
  private raceTime = 0;
  private currentLapTime = 0;
  private lastLapTime = 0;
  private bestLapTime = Infinity;
  private lastRecordedLap = 1;
  private totalLaps = 3;
  private nearMissCount = 0;
  private totalDistanceTraveled = 0;
  private isFinished = false;

  constructor(
    container: HTMLDivElement,
    mode: GameMode,
    trackId: string,
    progress: PlayerProgress,
    settings: ControlSettings,
    onStateChange: (state: RaceState) => void,
    onRaceFinish: (result: {
      position: number;
      totalTime: number;
      bestLap: number;
      driftScore: number;
      distance: number;
      cashEarned: number;
      nearMisses: number;
    }) => void
  ) {
    this.container = container;
    this.mode = mode;
    this.trackId = trackId;
    this.progress = progress;
    this.settings = settings;
    this.cameraView = settings.cameraView;
    this.onStateChange = onStateChange;
    this.onRaceFinish = onRaceFinish;

    // 1. Scene & Renderer
    this.scene = new THREE.Scene();
    const pixelRatio = Math.min(window.devicePixelRatio || 1, settings.quality === 'high' ? 2 : settings.quality === 'medium' ? 1.5 : 1);
    this.renderer = new THREE.WebGLRenderer({
      antialias: settings.quality !== 'low',
      powerPreference: 'high-performance',
    });
    this.renderer.setSize(container.clientWidth, container.clientHeight);
    this.renderer.setPixelRatio(pixelRatio);
    this.renderer.shadowMap.enabled = settings.quality === 'high';
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.05;
    container.appendChild(this.renderer.domElement);

    // 2. Camera Setup
    this.camera = new THREE.PerspectiveCamera(
      this.baseFov,
      container.clientWidth / container.clientHeight,
      0.15,
      1200
    );

    // 3. Lighting & Environment
    const trackDef = TRACKS_CATALOG.find((t) => t.id === trackId) || TRACKS_CATALOG[0];
    this.scene.background = new THREE.Color(trackDef.skyColor);
    this.scene.fog = new THREE.FogExp2(trackDef.fogColor, trackDef.fogDensity);

    this.ambientLight = new THREE.AmbientLight(trackDef.ambientLight, 0.75);
    this.scene.add(this.ambientLight);

    this.sunLight = new THREE.DirectionalLight(trackDef.sunColor, 1.25);
    this.sunLight.position.set(60, 120, 60);
    this.sunLight.castShadow = settings.quality === 'high';
    if (this.sunLight.castShadow) {
      this.sunLight.shadow.mapSize.width = 1024;
      this.sunLight.shadow.mapSize.height = 1024;
      this.sunLight.shadow.camera.near = 10;
      this.sunLight.shadow.camera.far = 300;
      const d = 50;
      this.sunLight.shadow.camera.left = -d;
      this.sunLight.shadow.camera.right = d;
      this.sunLight.shadow.camera.top = d;
      this.sunLight.shadow.camera.bottom = -d;
      this.sunLight.shadow.bias = -0.001;
    }
    this.scene.add(this.sunLight);

    // 4. Build Procedural Track
    this.totalLaps = this.mode === 'endless_traffic' ? 1 : trackDef.defaultLaps;
    this.trackData = buildProceduralTrack(trackDef, mode);
    this.scene.add(this.trackData.group);

    // 5. Physics & Particles
    this.physics = new PhysicsEngine(this.trackData);
    this.particles = new ParticleSystem(this.scene);

    // 6. Spawn Vehicles
    this.spawnVehicles();

    // 7. Initialize Audio
    if (settings.soundEnabled) {
      audio.init();
      audio.startEngine(this.playerCarDef.soundType);
    }
    if (settings.musicEnabled) {
      audio.startMusic();
    }

    // 8. Event Listeners
    window.addEventListener('resize', this.onResize);

    // 9. Start Loop
    this.isRunning = true;
    this.lastTime = performance.now();
    this.animationFrameId = requestAnimationFrame(this.loop);
  }

  private spawnVehicles() {
    const isEndless = this.mode === 'endless_traffic';
    const samples = this.trackData.samplePoints;

    // 1. Player Vehicle
    const playerDef = CARS_CATALOG.find((c) => c.id === this.progress.selectedCarId) || CARS_CATALOG[0];
    this.playerCarDef = playerDef;
    const playerCustom = this.progress.carCustomizations[playerDef.id];
    this.playerCar3D = buildLowPolyCar(playerDef, playerCustom);
    this.scene.add(this.playerCar3D.root);

    let startPos: THREE.Vector3;
    let startHeading: number;

    if (isEndless) {
      startPos = new THREE.Vector3(0, 0.1, 0);
      startHeading = Math.PI; // heading towards -Z
    } else {
      // Place player on the grid ahead of start line
      const poleIdx = Math.min(samples.length - 1, 8);
      const poleSample = samples[poleIdx];
      startPos = poleSample.pos.clone();
      startPos.y += 0.05;
      startHeading = Math.atan2(poleSample.tangent.x, poleSample.tangent.z);
    }

    this.playerState = this.physics.createInitialState(startPos, startHeading, false, 0);

    // 2. AI Competitors / Traffic
    const numRacers = this.mode === 'time_trial' ? 0 : isEndless ? 8 : 6;
    const otherCars = CARS_CATALOG.filter((c) => c.id !== this.playerCarDef.id);

    const laneOffsets = [-3.8, 3.8, -2.2, 2.2, -4.2, 4.2, -1.5, 1.5];
    const gridIndices = [7, 6, 4, 3, 1, 0];

    for (let i = 0; i < numRacers; i++) {
      const aiDef = otherCars[i % otherCars.length];
      const aiCar = buildLowPolyCar(aiDef);
      this.scene.add(aiCar.root);
      this.aiCars3D.push(aiCar);
      this.aiDefs.push(aiDef);

      let aiPos: THREE.Vector3;
      let aiRotY: number;

      if (isEndless) {
        // Scatter traffic cars ahead on highway
        const zDist = -60 - i * 45;
        const lane = laneOffsets[i % laneOffsets.length];
        aiPos = new THREE.Vector3(lane, 0.1, zDist);
        aiRotY = Math.PI;
      } else {
        // Grid lineup behind player
        const gridIdx = gridIndices[i % gridIndices.length];
        const gridSample = samples[gridIdx] || samples[0];
        const rightVec = gridSample.normal.clone();
        const lane = laneOffsets[i % laneOffsets.length];
        aiPos = gridSample.pos.clone().addScaledVector(rightVec, lane * 0.75);
        aiPos.y += 0.05;
        aiRotY = Math.atan2(gridSample.tangent.x, gridSample.tangent.z);
      }

      const aiState = this.physics.createInitialState(
        aiPos,
        aiRotY,
        true,
        laneOffsets[i % laneOffsets.length]
      );

      if (isEndless) {
        aiState.velocity.set(0, 0, -22 - Math.random() * 8);
      }

      this.aiStates.push(aiState);
    }
  }

  private onResize = () => {
    if (!this.container || !this.renderer || !this.camera) return;
    const w = this.container.clientWidth;
    const h = this.container.clientHeight;
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h);
  };

  public setInputs(inputs: Partial<VehicleInputs>) {
    this.playerInputs = { ...this.playerInputs, ...inputs };
  }

  public setCameraView(view: CameraView) {
    this.cameraView = view;
  }

  public getCameraView(): CameraView {
    return this.cameraView;
  }

  public resetCar() {
    if (!this.trackData || !this.trackData.samplePoints) return;
    const centerPt = this.trackData.samplePoints[this.playerState.currentSampleIndex];
    if (!centerPt) return;

    this.playerState.position.copy(centerPt.pos);
    this.playerState.position.y += 0.15;
    this.playerState.velocity.set(0, 0, 0);
    this.playerState.heading = Math.atan2(centerPt.tangent.x, centerPt.tangent.z);
    this.playerState.angularVelocity = 0;
    this.playerState.speed = 0;
    this.playerState.speedKmh = 0;
    this.playerState.isDrifting = false;
  }

  public setPaused(paused: boolean) {
    this.isPaused = paused;
  }

  private loop = (time: number) => {
    if (!this.isRunning) return;

    this.animationFrameId = requestAnimationFrame(this.loop);
    let dt = (time - this.lastTime) / 1000;
    this.lastTime = time;

    if (dt > 0.08) dt = 0.08;
    if (dt <= 0) return;

    if (!this.isPaused) {
      this.update(dt);
    }

    this.renderer.render(this.scene, this.camera);
  };

  private update(dt: number) {
    // 1. Countdown update (Fixed: No reversing during countdown!)
    let isCountingDown = false;
    if (this.countdown > 0) {
      isCountingDown = true;
      const prevInt = Math.ceil(this.countdown);
      this.countdown -= dt;
      const newInt = Math.ceil(this.countdown);

      if (newInt < prevInt) {
        if (newInt > 0) {
          audio.playCountdownBeep(false);
          triggerHaptic(30);
        } else {
          audio.playCountdownBeep(true);
          triggerHaptic(60);
        }
      }

      if (this.countdown <= 0) {
        this.countdown = 0;
      }
    }

    // Freeze inputs while counting down (ZERO throttle, ZERO velocity, NO reverse!)
    let activeInputs: VehicleInputs;
    if (isCountingDown) {
      activeInputs = { throttle: 0, brake: 0, steer: 0, handbrake: true, nitro: false };
      // Completely immobilize velocity during countdown
      this.playerState.velocity.set(0, 0, 0);
      this.playerState.speed = 0;
      this.playerState.speedKmh = 0;
    } else {
      activeInputs = {
        ...this.playerInputs,
        throttle: this.settings.autoAccelerate && this.playerInputs.brake <= 0 ? 1 : this.playerInputs.throttle,
      };
    }

    // 2. Update Player Physics
    const allVehicles = [this.playerState, ...this.aiStates];
    const playerResult = this.physics.updateVehicle(
      this.playerState,
      activeInputs,
      this.playerCarDef,
      this.progress.carCustomizations[this.playerCarDef.id],
      dt,
      allVehicles
    );

    // Audio & Haptics on physics events
    if (playerResult.collidedBarrier || playerResult.collidedCar) {
      audio.playCrash(1);
      triggerHaptic(40);
      // Gentle impact camera shake
      this.cameraShakeIntensity = Math.min(0.28, this.cameraShakeIntensity + 0.18);
      const sparkDir = new THREE.Vector3(Math.random() - 0.5, 0.5, Math.random() - 0.5).normalize();
      this.particles.emitSparks(this.playerState.position, sparkDir, 14);

      if (this.mode === 'endless_traffic' && playerResult.collidedCar && this.playerState.speedKmh > 75) {
        this.finishRace();
        return;
      }
    }

    if (playerResult.gearShift) {
      audio.playTurboBlowOff();
    }

    if (playerResult.nearMiss) {
      this.nearMissCount++;
      triggerHaptic(20);
    }

    // Engine Audio Pitch
    const speedRatio = Math.min(1, this.playerState.speed / 85);
    audio.updateEnginePitch(this.playerState.rpm, this.playerState.gear, speedRatio, this.playerCarDef.soundType);
    audio.setTireScreech(this.playerState.isDrifting ? 0.9 : 0);
    audio.setNitroWhoosh(this.playerState.isNitroActive);

    // 3. Update 3D Visual Mesh for Player
    this.updateCarMesh(this.playerCar3D, this.playerState, activeInputs, dt);

    // Tire smoke emission
    if (this.playerState.isDrifting || (this.playerState.speed < 8 && activeInputs.throttle > 0.8 && !isCountingDown)) {
      const rearLeftPos = this.playerCar3D.rearWheels[0].getWorldPosition(new THREE.Vector3());
      const rearRightPos = this.playerCar3D.rearWheels[1].getWorldPosition(new THREE.Vector3());
      this.particles.emitSmoke(rearLeftPos, this.playerState.velocity);
      this.particles.emitSmoke(rearRightPos, this.playerState.velocity);
    }

    // Nitro exhaust flames
    const exhaustWorldPos = this.playerCar3D.exhaustPoints.map((pt) => {
      return this.playerCar3D.root.localToWorld(pt.clone());
    });
    const playerFwd = new THREE.Vector3(Math.sin(this.playerState.heading), 0, Math.cos(this.playerState.heading));
    this.particles.updateNitroFlames(exhaustWorldPos, playerFwd, this.playerState.isNitroActive);

    // 4. Update AI Opponents / Traffic
    for (let i = 0; i < this.aiStates.length; i++) {
      const aiState = this.aiStates[i];
      const aiCar3D = this.aiCars3D[i];
      const aiDef = this.aiDefs[i];

      let aiInputs: VehicleInputs;
      if (isCountingDown) {
        aiInputs = { throttle: 0, brake: 0, steer: 0, handbrake: true, nitro: false };
        aiState.velocity.set(0, 0, 0);
        aiState.speed = 0;
        aiState.speedKmh = 0;
      } else {
        aiInputs = this.physics.updateAI(aiState, aiDef, dt, allVehicles);
      }

      this.physics.updateVehicle(aiState, aiInputs, aiDef, undefined, dt, allVehicles);
      this.updateCarMesh(aiCar3D, aiState, aiInputs, dt);

      // In endless traffic mode: recycle cars that fall behind
      if (this.mode === 'endless_traffic') {
        const distFromPlayer = aiState.position.z - this.playerState.position.z;
        if (distFromPlayer > 30) {
          aiState.position.z = this.playerState.position.z - (160 + Math.random() * 90);
          aiState.position.x = [-5, -2, 2, 5][Math.floor(Math.random() * 4)];
          aiState.velocity.set(0, 0, -22 - Math.random() * 8);
          aiState.heading = Math.PI;
        }
      }
    }

    // 5. Update Lap Times & Race Progression
    if (!isCountingDown && !this.isFinished) {
      this.raceTime += dt;
      this.currentLapTime += dt;
      this.totalDistanceTraveled += this.playerState.speed * dt;

      if (this.playerState.lap > this.lastRecordedLap) {
        this.lastLapTime = this.currentLapTime;
        if (this.lastLapTime < this.bestLapTime) {
          this.bestLapTime = this.lastLapTime;
        }
        this.currentLapTime = 0;
        this.lastRecordedLap = this.playerState.lap;
        audio.playCheckpoint();
        triggerHaptic(40);

        if (this.playerState.lap > this.totalLaps && this.mode !== 'endless_traffic') {
          this.finishRace();
        }
      }
    }

    // 6. Compute Position
    let playerPosition = 1;
    if (this.mode !== 'endless_traffic') {
      for (const ai of this.aiStates) {
        if (ai.lap > this.playerState.lap || (ai.lap === this.playerState.lap && ai.progressT > this.playerState.progressT)) {
          playerPosition++;
        }
      }
    }

    // 7. Update Particles
    this.particles.update(dt);

    // 8. Update Camera with Speed-based Shake (STRICTLY 0 AT REST!)
    this.updateCamera(dt, speedRatio);

    // 9. Dispatch UI State Update
    this.onStateChange({
      mode: this.mode,
      trackId: this.trackId,
      lap: Math.min(this.totalLaps, this.playerState.lap),
      totalLaps: this.totalLaps,
      position: playerPosition,
      totalRacers: this.aiStates.length + 1,
      currentLapTime: this.currentLapTime,
      lastLapTime: this.lastLapTime,
      bestLapTime: this.bestLapTime === Infinity ? 0 : this.bestLapTime,
      raceTime: this.raceTime,
      speedKmh: this.playerState.speedKmh,
      rpm: this.playerState.rpm,
      gear: this.playerState.gear,
      driftScore: this.playerState.driftScore,
      driftMultiplier: this.playerState.driftMultiplier,
      isDrifting: this.playerState.isDrifting,
      nitroPercent: this.playerState.nitroPercent,
      isNitroActive: this.playerState.isNitroActive,
      nearMissCount: this.nearMissCount,
      slipstreamActive: this.playerState.slipstreamActive,
      finished: this.isFinished,
      countdown: this.countdown,
      distanceTraveled: Math.round(this.totalDistanceTraveled),
      playerCoord: { x: this.playerState.position.x, z: this.playerState.position.z },
      playerHeading: this.playerState.heading,
      aiCoords: this.aiStates.map((ai) => ({ x: ai.position.x, z: ai.position.z })),
    });
  }

  private updateCarMesh(
    car3D: Car3DObject,
    state: VehicleState,
    inputs: VehicleInputs,
    dt: number
  ) {
    car3D.root.position.copy(state.position);
    car3D.root.rotation.set(0, state.heading, 0);

    // Body Roll & Pitch
    const lateralG = state.angularVelocity * (state.speed / 18);
    const targetRoll = Math.max(-0.1, Math.min(0.1, lateralG * 0.05));
    const targetPitch = inputs.brake > 0 ? 0.04 : inputs.throttle > 0 ? -0.03 : 0;

    car3D.bodyGroup.rotation.z += (targetRoll - car3D.bodyGroup.rotation.z) * Math.min(1, 10 * dt);
    car3D.bodyGroup.rotation.x += (targetPitch - car3D.bodyGroup.rotation.x) * Math.min(1, 10 * dt);

    // Front wheels steering angle
    // Note: inputs.steer > 0 means turning RIGHT, so wheels pivot right!
    const targetSteerAngle = -inputs.steer * 0.45;
    car3D.steerAngle += (targetSteerAngle - car3D.steerAngle) * Math.min(1, 16 * dt);
    car3D.frontWheels.forEach((w) => (w.rotation.y = car3D.steerAngle));

    // Wheels spinning
    car3D.wheelSpin += (state.speed / 0.35) * dt;
    car3D.frontWheels.forEach((w) => {
      if (w.children[0]) w.children[0].rotation.x = car3D.wheelSpin;
    });
    car3D.rearWheels.forEach((w) => {
      if (w.children[0]) w.children[0].rotation.x = car3D.wheelSpin;
    });

    // Brake lights
    const isBraking = inputs.brake > 0.1 || inputs.handbrake;
    car3D.brakeLightMaterial.color.setHex(isBraking ? 0xff0000 : 0x7f1d1d);
  }

  private updateCamera(dt: number, speedRatio: number) {
    // 1. Dynamic FOV
    let targetFov = this.baseFov;
    if (this.settings.cameraFovBoost) {
      targetFov += speedRatio * 15;
      if (this.playerState.isNitroActive) targetFov += 9;
      if (this.playerState.slipstreamActive) targetFov += 4;
    }
    this.camera.fov += (targetFov - this.camera.fov) * Math.min(1, 8 * dt);
    this.camera.updateProjectionMatrix();

    // 2. Camera Shake (FIXED: STRICTLY 0 at rest, only scales with high speed > 120km/h!)
    if (this.cameraShakeIntensity > 0) {
      this.cameraShakeIntensity = Math.max(0, this.cameraShakeIntensity - dt * 3.0);
    }

    let speedShake = 0;
    if (this.playerState.speedKmh > 120) {
      // Gentle high-speed road vibration
      speedShake = ((this.playerState.speedKmh - 120) / 180) * 0.045;
      if (this.playerState.isNitroActive) speedShake += 0.025;
    } else {
      // At rest or low speed: STRICTLY ZERO
      speedShake = 0;
    }

    const totalShake = (this.cameraShakeIntensity * 0.6) + speedShake;
    const shakeOffsetX = (Math.random() - 0.5) * totalShake;
    const shakeOffsetY = (Math.random() - 0.5) * totalShake;

    // 3. Camera Position according to selected view
    const fwd = new THREE.Vector3(Math.sin(this.playerState.heading), 0, Math.cos(this.playerState.heading));

    if (this.cameraView === 'hood') {
      // First person front bonnet camera (clean unobstructed view)
      const hoodPos = this.playerState.position.clone().add(new THREE.Vector3(0, 0.95, 0)).addScaledVector(fwd, 0.85);
      this.camera.position.copy(hoodPos);
      this.camera.position.x += shakeOffsetX;
      this.camera.position.y += shakeOffsetY;
      const lookTarget = hoodPos.clone().addScaledVector(fwd, 30);
      this.camera.up.set(0, 1, 0);
      this.camera.lookAt(lookTarget);
    } else if (this.cameraView === 'topdown') {
      // Top-Down / Retro Arcade Heli-Cam
      const height = 18;
      const camPos = this.playerState.position.clone().add(new THREE.Vector3(0, height, -2));
      this.camera.position.lerp(camPos, Math.min(1, 10 * dt));
      this.camera.position.x += shakeOffsetX;
      this.camera.position.y += shakeOffsetY;
      const lookAhead = 8;
      const targetLook = this.playerState.position.clone().addScaledVector(fwd, lookAhead);
      this.camera.up.set(fwd.x, 0, fwd.z).normalize();
      this.camera.lookAt(targetLook);
    } else if (this.cameraView === 'action') {
      // Action close sports cam
      const dist = 5.2 + speedRatio * 1.6;
      const height = 1.85;
      const idealCamPos = this.playerState.position.clone().add(new THREE.Vector3(0, height, 0)).addScaledVector(fwd, -dist);
      this.camera.position.lerp(idealCamPos, Math.min(1, 12 * dt));
      this.camera.position.x += shakeOffsetX;
      this.camera.position.y += shakeOffsetY;

      const targetLook = this.playerState.position.clone().add(new THREE.Vector3(0, 1.1, 0)).addScaledVector(fwd, 8.0);
      this.cameraTarget.lerp(targetLook, Math.min(1, 14 * dt));
      this.camera.up.set(0, 1, 0);
      this.camera.lookAt(this.cameraTarget);
    } else {
      // Standard Dynamic 3rd Person Chase
      const dist = 6.8 + speedRatio * 2.2;
      const height = 2.4 + speedRatio * 0.4;
      const idealCamPos = this.playerState.position.clone().add(new THREE.Vector3(0, height, 0)).addScaledVector(fwd, -dist);

      this.camera.position.lerp(idealCamPos, Math.min(1, 10 * dt));
      this.camera.position.x += shakeOffsetX;
      this.camera.position.y += shakeOffsetY;

      const lookAhead = 8.0 + speedRatio * 12;
      const targetLook = this.playerState.position.clone().add(new THREE.Vector3(0, 1.2, 0)).addScaledVector(fwd, lookAhead);
      this.cameraTarget.lerp(targetLook, Math.min(1, 12 * dt));

      // Gentle banking tilt during fast turns
      const lateralG = this.playerState.angularVelocity * (this.playerState.speed / 20);
      const rollTilt = Math.max(-0.06, Math.min(0.06, lateralG * 0.035));
      this.camera.up.set(rollTilt, 1, 0).normalize();
      this.camera.lookAt(this.cameraTarget);
    }

    // Sun follows car
    this.sunLight.position.set(
      this.playerState.position.x + 60,
      this.playerState.position.y + 120,
      this.playerState.position.z + 60
    );
    this.sunLight.target.position.copy(this.playerState.position);
  }

  private finishRace() {
    if (this.isFinished) return;
    this.isFinished = true;

    let position = 1;
    if (this.mode !== 'endless_traffic') {
      for (const ai of this.aiStates) {
        if (ai.lap > this.playerState.lap || (ai.lap === this.playerState.lap && ai.progressT > this.playerState.progressT)) {
          position++;
        }
      }
    }

    let cashEarned = 0;
    if (this.mode === 'endless_traffic') {
      cashEarned = Math.round(this.totalDistanceTraveled * 0.4) + this.nearMissCount * 150 + Math.round(this.playerState.driftScore * 0.1);
    } else {
      const basePrize = position === 1 ? 5000 : position === 2 ? 3000 : position === 3 ? 1800 : 800;
      const driftBonus = Math.round(this.playerState.driftScore * 0.15);
      cashEarned = basePrize + driftBonus;
    }

    this.onRaceFinish({
      position,
      totalTime: this.raceTime,
      bestLap: this.bestLapTime === Infinity ? this.raceTime : this.bestLapTime,
      driftScore: this.playerState.driftScore,
      distance: Math.round(this.totalDistanceTraveled),
      cashEarned,
      nearMisses: this.nearMissCount,
    });
  }

  public destroy() {
    this.isRunning = false;
    window.removeEventListener('resize', this.onResize);
    if (this.animationFrameId) {
      cancelAnimationFrame(this.animationFrameId);
    }
    audio.stopAll();
    this.renderer.dispose();
    if (this.container && this.renderer.domElement) {
      this.container.removeChild(this.renderer.domElement);
    }
  }
}
