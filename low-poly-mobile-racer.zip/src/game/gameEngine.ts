import * as THREE from 'three';
import { GameMode, RaceState, PlayerProgress, ControlSettings, CarDefinition } from '../types/game';
import { CARS_CATALOG } from './carsData';
import { TRACKS_CATALOG } from './tracksData';
import { buildLowPolyCar, Car3DObject } from './proceduralCar';
import { buildProceduralTrack, TrackData } from './proceduralTrack';
import { PhysicsEngine, VehicleInputs, VehicleState } from './physics';
import { ParticleSystem } from './particles';
import { audio } from '../services/audio';
import { triggerHaptic } from '../services/storage';

export type CameraView = 'chase' | 'hood' | 'action';

export class GameEngine {
  private container: HTMLDivElement;
  private renderer: THREE.WebGLRenderer;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private sunLight: THREE.DirectionalLight;
  private ambientLight: THREE.AmbientLight;

  private trackData!: TrackData;
  private physics!: PhysicsEngine;
  private particles!: ParticleSystem;

  // Player
  private playerCar3D!: Car3DObject;
  private playerState!: VehicleState;
  private playerCarDef!: CarDefinition;
  private playerInputs: VehicleInputs = {
    throttle: 0,
    brake: 0,
    steer: 0,
    handbrake: false,
    nitro: false,
  };

  // AI Opponents / Traffic
  private aiCars3D: Car3DObject[] = [];
  private aiStates: VehicleState[] = [];
  private aiDefs: CarDefinition[] = [];

  // Camera settings
  private cameraView: CameraView = 'chase';
  private cameraShakeIntensity = 0;
  private cameraTarget = new THREE.Vector3();
  private baseFov = 65;

  // Race & Mode State
  private mode: GameMode;
  private trackId: string;
  private progress: PlayerProgress;
  private settings: ControlSettings;
  private onStateChange: (state: RaceState) => void;
  private onRaceFinish: (result: {
    position: number;
    totalTime: number;
    bestLap: number;
    driftScore: number;
    distance: number;
    cashEarned: number;
    nearMisses: number;
  }) => void;

  private isRunning = false;
  private isPaused = false;
  private animationFrameId: number | null = null;
  private lastTime = 0;

  // Lap and Race Timers
  private countdown = 3.8; // >0 countdown, 0 racing
  private raceTime = 0;
  private currentLapTime = 0;
  private lastLapTime = 0;
  private bestLapTime = Infinity;
  private totalLaps = 3;
  private nearMissCount = 0;
  private totalDistanceTraveled = 0;
  private isFinished = false;

  constructor(
    container: HTMLDivElement,
    mode: GameMode,
    trackId: string,
    progress: PlayerProgress,
    settings: ControlSettings,
    onStateChange: (state: RaceState) => void,
    onRaceFinish: (result: {
      position: number;
      totalTime: number;
      bestLap: number;
      driftScore: number;
      distance: number;
      cashEarned: number;
      nearMisses: number;
    }) => void
  ) {
    this.container = container;
    this.mode = mode;
    this.trackId = trackId;
    this.progress = progress;
    this.settings = settings;
    this.onStateChange = onStateChange;
    this.onRaceFinish = onRaceFinish;

    // 1. Scene & Renderer
    this.scene = new THREE.Scene();
    const pixelRatio = Math.min(window.devicePixelRatio, settings.quality === 'high' ? 2 : settings.quality === 'medium' ? 1.5 : 1);
    this.renderer = new THREE.WebGLRenderer({
      antialias: settings.quality !== 'low',
      powerPreference: 'high-performance',
    });
    this.renderer.setSize(container.clientWidth, container.clientHeight);
    this.renderer.setPixelRatio(pixelRatio);
    this.renderer.shadowMap.enabled = settings.quality === 'high';
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.05;
    container.appendChild(this.renderer.domElement);

    // 2. Camera
    this.camera = new THREE.PerspectiveCamera(
      this.baseFov,
      container.clientWidth / container.clientHeight,
      0.1,
      1200
    );

    // 3. Lights
    this.ambientLight = new THREE.AmbientLight(0xffffff, 0.7);
    this.scene.add(this.ambientLight);

    this.sunLight = new THREE.DirectionalLight(0xffffff, 1.4);
    this.sunLight.position.set(60, 120, 60);
    this.sunLight.castShadow = settings.quality === 'high';
    if (this.sunLight.castShadow) {
      this.sunLight.shadow.mapSize.width = 1024;
      this.sunLight.shadow.mapSize.height = 1024;
      this.sunLight.shadow.camera.near = 10;
      this.sunLight.shadow.camera.far = 400;
      const d = 50;
      this.sunLight.shadow.camera.left = -d;
      this.sunLight.shadow.camera.right = d;
      this.sunLight.shadow.camera.top = d;
      this.sunLight.shadow.camera.bottom = -d;
    }
    this.scene.add(this.sunLight);

    // 4. Track & Environment
    this.setupTrack();

    // 5. Particles
    this.particles = new ParticleSystem();
    this.scene.add(this.particles.group);

    // 6. Spawn Vehicles
    this.setupCars();

    // 7. Window resize
    window.addEventListener('resize', this.handleResize);

    // 8. Start audio engine
    audio.startEngine(this.playerCarDef.soundType);
    audio.startSynthwaveMusic();
  }

  private setupTrack() {
    const trackDef = TRACKS_CATALOG.find((t) => t.id === this.trackId) || TRACKS_CATALOG[0];

    // Total laps based on mode
    if (this.mode === 'time_trial') {
      this.totalLaps = 2;
    } else if (this.mode === 'drift_mode') {
      this.totalLaps = 2;
    } else {
      this.totalLaps = trackDef.defaultLaps;
    }

    // Sky & Fog
    this.scene.background = new THREE.Color(trackDef.skyColor);
    this.scene.fog = new THREE.FogExp2(trackDef.fogColor, trackDef.fogDensity);

    this.ambientLight.color.set(trackDef.ambientLight);
    this.sunLight.color.set(trackDef.sunColor);

    // Build Track
    this.trackData = buildProceduralTrack(trackDef, this.mode);
    this.scene.add(this.trackData.group);

    this.physics = new PhysicsEngine(this.trackData);
  }

  private setupCars() {
    // 1. Player Car
    const selectedId = this.progress.selectedCarId;
    this.playerCarDef = CARS_CATALOG.find((c) => c.id === selectedId) || CARS_CATALOG[0];
    const playerCustom = this.progress.carCustomizations[this.playerCarDef.id];

    this.playerCar3D = buildLowPolyCar(this.playerCarDef, playerCustom);
    this.scene.add(this.playerCar3D.root);

    const startPos = this.trackData.startPosition.clone();
    startPos.y += 0.1;
    this.playerState = this.physics.createInitialState(startPos, this.trackData.startRotationY, false, 0);

    // 2. AI Competitors / Traffic
    const numRacers = this.mode === 'time_trial' ? 0 : this.mode === 'endless_traffic' ? 8 : 5;
    const otherCars = CARS_CATALOG.filter((c) => c.id !== this.playerCarDef.id);

    const laneOffsets = [-5, 5, -2.5, 2.5, -4, 4, -1, 1];

    for (let i = 0; i < numRacers; i++) {
      const aiDef = otherCars[i % otherCars.length];
      const aiCar = buildLowPolyCar(aiDef);
      this.scene.add(aiCar.root);
      this.aiCars3D.push(aiCar);
      this.aiDefs.push(aiDef);

      let aiPos: THREE.Vector3;
      let aiRotY: number;

      if (this.mode === 'endless_traffic') {
        // Spawn traffic cars ahead along the highway
        const zDist = -40 - i * 65;
        const lane = laneOffsets[i % laneOffsets.length];
        aiPos = new THREE.Vector3(lane, 0.1, zDist);
        aiRotY = 0;
      } else {
        // Grid start behind player on circuit
        const gridDist = -12 * (i + 1);
        const fwd = new THREE.Vector3(Math.sin(this.trackData.startRotationY), 0, Math.cos(this.trackData.startRotationY));
        const right = new THREE.Vector3(Math.cos(this.trackData.startRotationY), 0, -Math.sin(this.trackData.startRotationY));
        const lane = laneOffsets[i % laneOffsets.length];
        aiPos = this.trackData.startPosition.clone().addScaledVector(fwd, gridDist).addScaledVector(right, lane * 0.7);
        aiRotY = this.trackData.startRotationY;
      }

      const aiState = this.physics.createInitialState(
        aiPos,
        aiRotY,
        true,
        laneOffsets[i % laneOffsets.length]
      );
      this.aiStates.push(aiState);
    }
  }

  public setInputs(inputs: Partial<VehicleInputs>) {
    this.playerInputs = { ...this.playerInputs, ...inputs };
  }

  public switchCamera() {
    const views: CameraView[] = ['chase', 'hood', 'action'];
    const idx = (views.indexOf(this.cameraView) + 1) % views.length;
    this.cameraView = views[idx];
    audio.playClick();
    triggerHaptic(20);
  }

  public togglePause(): boolean {
    this.isPaused = !this.isPaused;
    if (this.isPaused) {
      audio.stopEngine();
    } else {
      audio.startEngine(this.playerCarDef.soundType);
    }
    return this.isPaused;
  }

  public resetCarOnTrack() {
    // Reset player car orientation and position on current track segment
    const samples = this.trackData.samplePoints;
    const idx = Math.round(this.playerState.progressT * (samples.length - 1));
    const sample = samples[Math.max(0, Math.min(samples.length - 1, idx))];

    if (sample) {
      this.playerState.position.copy(sample.pos);
      this.playerState.position.y += 0.2;
      this.playerState.velocity.set(0, 0, 0);
      this.playerState.heading = Math.atan2(sample.tangent.x, sample.tangent.z);
      this.playerState.angularVelocity = 0;
      this.playerState.speed = 0;
      this.playerState.speedKmh = 0;
      audio.playCrash(0.5);
      triggerHaptic(40);
    }
  }

  public start() {
    this.isRunning = true;
    this.lastTime = performance.now();
    this.loop(this.lastTime);
  }

  public stop() {
    this.isRunning = false;
    if (this.animationFrameId !== null) {
      cancelAnimationFrame(this.animationFrameId);
    }
    audio.stopEngine();
    audio.stopSynthwaveMusic();
    window.removeEventListener('resize', this.handleResize);
    if (this.renderer.domElement.parentNode) {
      this.renderer.domElement.parentNode.removeChild(this.renderer.domElement);
    }
    this.renderer.dispose();
  }

  private handleResize = () => {
    if (!this.container) return;
    const width = this.container.clientWidth;
    const height = this.container.clientHeight;
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  };

  private loop = (time: number) => {
    if (!this.isRunning) return;

    this.animationFrameId = requestAnimationFrame(this.loop);
    let dt = (time - this.lastTime) / 1000;
    this.lastTime = time;

    // Clamp dt to prevent tunneling on frame hitch
    if (dt > 0.1) dt = 0.1;
    if (dt <= 0) return;

    if (!this.isPaused) {
      this.update(dt);
    }

    this.renderer.render(this.scene, this.camera);
  };

  private update(dt: number) {
    // 1. Countdown update
    let isCountingDown = false;
    if (this.countdown > 0) {
      isCountingDown = true;
      const prevInt = Math.ceil(this.countdown);
      this.countdown -= dt;
      const newInt = Math.ceil(this.countdown);

      if (newInt < prevInt) {
        if (newInt > 0) {
          audio.playCountdownBeep(false);
          triggerHaptic(30);
        } else {
          audio.playCountdownBeep(true);
          triggerHaptic(60);
        }
      }

      if (this.countdown <= 0) {
        this.countdown = 0;
      }
    }

    // Freeze throttle input while countdown > 0
    const activeInputs: VehicleInputs = isCountingDown
      ? { throttle: 0, brake: 1, steer: 0, handbrake: true, nitro: false }
      : {
          ...this.playerInputs,
          throttle: this.settings.autoAccelerate && this.playerInputs.brake <= 0 ? 1 : this.playerInputs.throttle,
        };

    // 2. Update Player Physics
    const allVehicles = [this.playerState, ...this.aiStates];
    const playerResult = this.physics.updateVehicle(
      this.playerState,
      activeInputs,
      this.playerCarDef,
      this.progress.carCustomizations[this.playerCarDef.id],
      dt,
      allVehicles
    );

    // Audio & Haptics on physics events
    if (playerResult.collidedBarrier || playerResult.collidedCar) {
      audio.playCrash(1);
      triggerHaptic(50);
      this.cameraShakeIntensity = 0.45;
      // Emit sparks
      const sparkDir = new THREE.Vector3((Math.random() - 0.5), 0.5, (Math.random() - 0.5)).normalize();
      this.particles.emitSparks(this.playerState.position, sparkDir, 16);
    }

    if (playerResult.gearShift) {
      audio.playTurboBlowOff();
    }

    if (playerResult.nearMiss) {
      this.nearMissCount++;
      triggerHaptic(20);
    }

    // Engine Audio Pitch
    const speedRatio = this.playerState.speed / 100;
    audio.updateEnginePitch(this.playerState.rpm, this.playerState.gear, speedRatio, this.playerCarDef.soundType);
    audio.setTireScreech(this.playerState.isDrifting ? 0.9 : 0);
    audio.setNitroWhoosh(this.playerState.isNitroActive);

    // 3. Update 3D Visual Mesh for Player
    this.updateCarMesh(this.playerCar3D, this.playerState, activeInputs, dt);

    // Tire smoke emission when drifting or hard acceleration
    if (this.playerState.isDrifting || (this.playerState.speed < 8 && activeInputs.throttle > 0.8)) {
      const rearLeftPos = this.playerCar3D.rearWheels[0].getWorldPosition(new THREE.Vector3());
      const rearRightPos = this.playerCar3D.rearWheels[1].getWorldPosition(new THREE.Vector3());
      this.particles.emitSmoke(rearLeftPos, this.playerState.velocity);
      this.particles.emitSmoke(rearRightPos, this.playerState.velocity);
    }

    // Nitro exhaust flames
    const exhaustWorldPos = this.playerCar3D.exhaustPoints.map((pt) => {
      return this.playerCar3D.root.localToWorld(pt.clone());
    });
    const playerFwd = new THREE.Vector3(Math.sin(this.playerState.heading), 0, Math.cos(this.playerState.heading));
    this.particles.updateNitroFlames(exhaustWorldPos, playerFwd, this.playerState.isNitroActive);

    // 4. Update AI Competitors / Traffic Physics
    for (let i = 0; i < this.aiStates.length; i++) {
      const aiState = this.aiStates[i];
      const aiCar3D = this.aiCars3D[i];
      const aiDef = this.aiDefs[i];

      const aiInputs = isCountingDown
        ? { throttle: 0, brake: 1, steer: 0, handbrake: true, nitro: false }
        : this.physics.updateAI(aiState, aiDef, dt, allVehicles);

      this.physics.updateVehicle(aiState, aiInputs, aiDef, undefined, dt, allVehicles);
      this.updateCarMesh(aiCar3D, aiState, aiInputs, dt);

      // In endless traffic mode: recycle cars that fall too far behind player
      if (this.mode === 'endless_traffic') {
        const distFromPlayer = aiState.position.z - this.playerState.position.z;
        if (distFromPlayer > 35) {
          // Recycle ahead
          aiState.position.z = this.playerState.position.z - (160 + Math.random() * 80);
          aiState.position.x = [-5, -2, 2, 5][Math.floor(Math.random() * 4)];
          aiState.velocity.set(0, 0, -28 - Math.random() * 15);
        }
      }
    }

    // 5. Update Lap Times & Race Progression
    if (!isCountingDown && !this.isFinished) {
      this.raceTime += dt;
      this.currentLapTime += dt;
      this.totalDistanceTraveled += this.playerState.speed * dt;

      // Check lap transitions
      const prevLap = this.playerState.lap;
      if (prevLap > 1 && this.currentLapTime > 5) {
        // Lap completed!
        this.lastLapTime = this.currentLapTime;
        if (this.lastLapTime < this.bestLapTime) {
          this.bestLapTime = this.lastLapTime;
        }
        this.currentLapTime = 0;
        audio.playCheckpoint();
        triggerHaptic(40);

        if (this.playerState.lap > this.totalLaps && this.mode !== 'endless_traffic') {
          this.finishRace();
        }
      }
    }

    // 6. Compute Position (Leaderboard)
    let playerPosition = 1;
    if (this.mode !== 'endless_traffic') {
      for (const ai of this.aiStates) {
        if (ai.lap > this.playerState.lap || (ai.lap === this.playerState.lap && ai.progressT > this.playerState.progressT)) {
          playerPosition++;
        }
      }
    }

    // 7. Update Particles (Smoke, Sparks, Speed lines)
    this.particles.update(dt);
    if (this.settings.speedLines) {
      this.particles.updateSpeedLines(this.camera, speedRatio, this.playerState.isNitroActive);
    }

    // 8. Camera Physics & Dynamic Sensation of Speed
    this.updateCamera(dt, speedRatio);

    // 9. Dispatch UI State Update
    this.onStateChange({
      mode: this.mode,
      trackId: this.trackId as any,
      lap: Math.min(this.totalLaps, this.playerState.lap),
      totalLaps: this.totalLaps,
      position: playerPosition,
      totalRacers: this.aiStates.length + 1,
      currentLapTime: this.currentLapTime,
      lastLapTime: this.lastLapTime,
      bestLapTime: this.bestLapTime === Infinity ? 0 : this.bestLapTime,
      raceTime: this.raceTime,
      speedKmh: this.playerState.speedKmh,
      rpm: this.playerState.rpm,
      gear: this.playerState.gear,
      driftScore: this.playerState.driftScore,
      driftMultiplier: this.playerState.driftMultiplier,
      isDrifting: this.playerState.isDrifting,
      nitroPercent: this.playerState.nitroPercent,
      isNitroActive: this.playerState.isNitroActive,
      nearMissCount: this.nearMissCount,
      slipstreamActive: this.playerState.slipstreamActive,
      finished: this.isFinished,
      countdown: this.countdown,
      distanceTraveled: Math.round(this.totalDistanceTraveled),
      playerCoord: { x: this.playerState.position.x, z: this.playerState.position.z },
      playerHeading: this.playerState.heading,
      aiCoords: this.aiStates.map((ai) => ({ x: ai.position.x, z: ai.position.z })),
    });
  }

  private updateCarMesh(
    car3D: Car3DObject,
    state: VehicleState,
    inputs: VehicleInputs,
    dt: number
  ) {
    // Position & Heading
    car3D.root.position.copy(state.position);
    car3D.root.rotation.y = state.heading;

    // Body Roll on turns & pitch on acceleration/braking
    const lateralG = state.angularVelocity * (state.speed / 18);
    const targetRoll = Math.max(-0.15, Math.min(0.15, -lateralG * 0.08));
    const targetPitch = inputs.brake > 0 ? 0.05 : inputs.throttle > 0 ? -0.04 : 0;

    car3D.root.rotation.z += (targetRoll - car3D.root.rotation.z) * 10 * dt;
    car3D.root.rotation.x += (targetPitch - car3D.root.rotation.x) * 10 * dt;

    // Front wheels steering angle
    const targetSteerAngle = -inputs.steer * 0.48;
    car3D.steerAngle += (targetSteerAngle - car3D.steerAngle) * 14 * dt;
    car3D.frontWheels.forEach((w) => (w.rotation.y = car3D.steerAngle));

    // Wheels rotation spin
    car3D.wheelSpin += (state.speed / 0.35) * dt;
    car3D.frontWheels.forEach((w) => {
      if (w.children[0]) w.children[0].rotation.x = car3D.wheelSpin;
    });
    car3D.rearWheels.forEach((w) => {
      if (w.children[0]) w.children[0].rotation.x = car3D.wheelSpin;
    });

    // Brake lights brightness
    const isBraking = inputs.brake > 0.1;
    car3D.brakeLightMaterial.color.setHex(isBraking ? 0xff0000 : 0x7f1d1d);
  }

  private updateCamera(dt: number, speedRatio: number) {
    // 1. Dynamic FOV Warp (expands with speed & nitro boost)
    let targetFov = this.baseFov;
    if (this.settings.cameraFovBoost) {
      targetFov += speedRatio * 18;
      if (this.playerState.isNitroActive) targetFov += 12;
      if (this.playerState.slipstreamActive) targetFov += 5;
    }
    this.camera.fov += (targetFov - this.camera.fov) * 8 * dt;
    this.camera.updateProjectionMatrix();

    // 2. Camera Shake (intensity fades out)
    if (this.cameraShakeIntensity > 0) {
      this.cameraShakeIntensity = Math.max(0, this.cameraShakeIntensity - dt * 2);
    }
    const speedShake = speedRatio > 0.85 ? (speedRatio - 0.85) * 0.12 : 0;
    const totalShake = this.cameraShakeIntensity + speedShake;
    const shakeOffsetX = (Math.random() - 0.5) * totalShake;
    const shakeOffsetY = (Math.random() - 0.5) * totalShake;

    // 3. Camera Position according to selected view
    const fwd = new THREE.Vector3(Math.sin(this.playerState.heading), 0, Math.cos(this.playerState.heading));

    if (this.cameraView === 'hood') {
      // First person bonnet/hood camera
      const hoodPos = this.playerState.position.clone().add(new THREE.Vector3(0, 0.9, 0)).addScaledVector(fwd, 0.4);
      this.camera.position.copy(hoodPos);
      this.camera.position.x += shakeOffsetX;
      this.camera.position.y += shakeOffsetY;
      const lookTarget = hoodPos.clone().addScaledVector(fwd, 20);
      this.camera.lookAt(lookTarget);
    } else if (this.cameraView === 'action') {
      // Low angle cinematic close chase
      const dist = 5.2 + speedRatio * 1.5;
      const height = 1.6;
      const idealCamPos = this.playerState.position.clone().add(new THREE.Vector3(0, height, 0)).addScaledVector(fwd, -dist);
      this.camera.position.lerp(idealCamPos, 14 * dt);
      this.camera.position.x += shakeOffsetX;
      this.camera.position.y += shakeOffsetY;
      this.cameraTarget.lerp(this.playerState.position.clone().add(new THREE.Vector3(0, 0.8, 0)), 16 * dt);
      this.camera.lookAt(this.cameraTarget);
    } else {
      // Standard dynamic 3rd person chase
      const dist = 6.8 + speedRatio * 2.2;
      const height = 2.4;
      const idealCamPos = this.playerState.position.clone().add(new THREE.Vector3(0, height, 0)).addScaledVector(fwd, -dist);
      // Smooth camera lag
      this.camera.position.lerp(idealCamPos, 12 * dt);
      this.camera.position.x += shakeOffsetX;
      this.camera.position.y += shakeOffsetY;

      const lookAhead = 4 + speedRatio * 8;
      this.cameraTarget.lerp(
        this.playerState.position.clone().add(new THREE.Vector3(0, 1.1, 0)).addScaledVector(fwd, lookAhead),
        14 * dt
      );
      this.camera.lookAt(this.cameraTarget);

      // Camera lean / bank into turns
      this.camera.rotation.z = -this.playerCar3D.root.rotation.z * 0.4;
    }

    // Keep SunLight following car
    this.sunLight.position.set(
      this.playerState.position.x + 60,
      this.playerState.position.y + 120,
      this.playerState.position.z + 60
    );
    this.sunLight.target.position.copy(this.playerState.position);
    this.sunLight.target.updateMatrixWorld();
  }

  private finishRace() {
    this.isFinished = true;
    audio.playVictory();
    triggerHaptic(80);

    // Compute earnings
    const basePrizes = [12000, 7000, 4500, 2500, 1500, 1000];
    const pos = Math.min(basePrizes.length, this.getPlayerPosition());
    const prizeMoney = basePrizes[pos - 1] || 1000;
    const driftBonus = Math.round(this.playerState.driftScore * 0.5);
    const nearMissBonus = this.nearMissCount * 150;
    const totalCash = prizeMoney + driftBonus + nearMissBonus;

    this.onRaceFinish({
      position: pos,
      totalTime: this.raceTime,
      bestLap: this.bestLapTime === Infinity ? this.raceTime : this.bestLapTime,
      driftScore: this.playerState.driftScore,
      distance: Math.round(this.totalDistanceTraveled),
      cashEarned: totalCash,
      nearMisses: this.nearMissCount,
    });
  }

  public getTrackData(): TrackData {
    return this.trackData;
  }

  public endEndlessCrash() {
    this.isFinished = true;
    audio.playCrash(1.5);
    triggerHaptic(90);

    const distance = Math.round(this.totalDistanceTraveled);
    const driftBonus = Math.round(this.playerState.driftScore * 0.5);
    const nearMissBonus = this.nearMissCount * 250;
    const distanceBonus = Math.round(distance * 0.8);
    const totalCash = distanceBonus + driftBonus + nearMissBonus;

    this.onRaceFinish({
      position: 1,
      totalTime: this.raceTime,
      bestLap: 0,
      driftScore: this.playerState.driftScore,
      distance,
      cashEarned: totalCash,
      nearMisses: this.nearMissCount,
    });
  }

  private getPlayerPosition(): number {
    let pos = 1;
    for (const ai of this.aiStates) {
      if (ai.lap > this.playerState.lap || (ai.lap === this.playerState.lap && ai.progressT > this.playerState.progressT)) {
        pos++;
      }
    }
    return pos;
  }
}
