import { useEffect } from 'react';
import { MiniSpark } from '../components/chart/CandlestickChart';
import { IconArrowDown, IconArrowUp, IconChevronRight, IconEqual, IconFilter } from '../components/icons';
import { Button, DirectionBadge, ScreenHeader, ScoreColor } from '../components/ui/primitives';
import { useApp } from '../context/AppContext';
import { DEMO_MATCHES } from '../data/mockData';
import { cn } from '../utils/cn';

export function MatchesScreen() {
  const { matches, setMatches, selectMatch, selectedMatch, navigate, back, period } = useApp();

  useEffect(() => {
    if (!matches.length) setMatches(DEMO_MATCHES);
  }, [matches.length, setMatches]);

  const list = matches.length ? matches : DEMO_MATCHES;

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <ScreenHeader title="Correspondances historiques" onBack={back} />

      <div className="flex items-center justify-between px-5 pb-2">
        <p className="text-[13px] text-slate-400">
          {list.length || 20} résultats ({period.candleCount} bougies)
        </p>
        <button onClick={() => navigate('period')} className="text-slate-400" aria-label="Filtrer la période">
          <IconFilter />
        </button>
      </div>

      <div className="min-h-0 flex-1 overflow-y-auto px-3 pb-2">
        {list.map((m) => (
          <button
            key={m.id}
            onClick={() => {
              selectMatch(m);
              navigate('matchDetail');
            }}
            className="mb-2 flex w-full items-center gap-2 rounded-2xl border border-white/5 bg-[#101c31] px-2.5 py-2 text-left"
          >
            <span className="w-7 text-[12px] font-semibold text-slate-500">#{m.rank}</span>
            <MiniSpark candles={m.candles} />
            <div className="min-w-0 flex-1">
              <div className={cn('text-[18px] font-bold leading-tight', ScoreColor(m.score))}>
                {m.score.toFixed(1).replace('.', ',')}
                <span className="text-[12px] font-medium text-slate-500"> /10</span>
              </div>
              <div className="truncate text-[11px] text-slate-400">
                {m.dateShort} · {m.candleCount} bougies
              </div>
              <div className="mt-0.5 flex items-center gap-2">
                <DirectionBadge dir={m.direction} />
                <span className="flex items-center gap-0.5 text-[11px] text-slate-400">
                  Volume
                  {m.volumeTrend === 'up' && <IconArrowUp className="text-emerald-400" size={12} />}
                  {m.volumeTrend === 'down' && <IconArrowDown className="text-rose-400" size={12} />}
                  {m.volumeTrend === 'flat' && <IconEqual className="text-slate-400" size={12} />}
                </span>
              </div>
            </div>
            <IconChevronRight className="text-slate-600" />
          </button>
        ))}
      </div>

      <div className="flex gap-3 px-5 pb-3 pt-1">
        <Button variant="outline" className="flex-1" onClick={back}>
          ‹ Précédent
        </Button>
        <Button
          variant="outline"
          className="flex-1"
          onClick={() => {
            const current = selectedMatch ?? list[0];
            const idx = list.findIndex((m) => m.id === current?.id);
            const next = list[idx + 1] ?? list[0];
            if (next) {
              selectMatch(next);
              navigate('matchDetail');
            }
          }}
        >
          Suivant ›
        </Button>
      </div>
    </div>
  );
}
