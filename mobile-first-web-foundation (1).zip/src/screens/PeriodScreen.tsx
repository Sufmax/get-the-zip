import type { ReactNode } from 'react';
import { IconCalendar } from '../components/icons';
import { Button, Check, ScreenHeader, Stepper } from '../components/ui/primitives';
import { useApp } from '../context/AppContext';
import type { PeriodConfig } from '../types';
import { cn } from '../utils/cn';

function toInput(iso: string) {
  const [y, m, d] = iso.split('-');
  return `${d}/${m}/${y}`;
}

export function PeriodScreen() {
  const { period, setPeriod, back } = useApp();

  const set = (patch: Partial<PeriodConfig>) => setPeriod({ ...period, ...patch });

  const Row = ({
    mode,
    title,
    children,
  }: {
    mode: PeriodConfig['mode'];
    title: string;
    children?: ReactNode;
  }) => {
    const active = period.mode === mode;
    return (
      <div
        className={cn(
          'w-full rounded-2xl border px-4 py-3 text-left transition',
          active ? 'border-cyan-500/30 bg-[#102033]' : 'border-white/5 bg-[#0e1a2c]',
        )}
      >
        <button onClick={() => set({ mode })} className="flex w-full items-center gap-3">
          <Check checked={active} />
          <span className="text-[14px] font-medium text-white">{title}</span>
        </button>
        {children ? <div className="mt-3 pl-8">{children}</div> : null}
      </div>
    );
  };

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <ScreenHeader title="Période de recherche" onBack={back} />

      <div className="min-h-0 flex-1 space-y-2.5 overflow-y-auto px-4 pb-3">
        <Row mode="lastCandles" title="500 dernières bougies">
          <div>
            <p className="mb-2 text-[12px] text-slate-400">Nombre de bougies</p>
            <Stepper value={period.candleCount} onChange={(n) => set({ candleCount: n })} min={50} max={5000} />
          </div>
        </Row>

        <Row mode="customRange" title="Période personnalisée">
          <div className="grid grid-cols-2 gap-2">
            <label className="text-[11px] text-slate-400">
              Début
              <span className="mt-1 flex items-center justify-between rounded-xl bg-[#0b1628] px-3 py-2 text-[13px] text-white">
                {toInput(period.startDate)}
                <IconCalendar size={14} className="text-slate-500" />
              </span>
              <input
                type="date"
                className="sr-only"
                value={period.startDate}
                onChange={(e) => set({ startDate: e.target.value })}
              />
            </label>
            <label className="text-[11px] text-slate-400">
              Fin
              <span className="mt-1 flex items-center justify-between rounded-xl bg-[#0b1628] px-3 py-2 text-[13px] text-white">
                {toInput(period.endDate)}
                <IconCalendar size={14} className="text-slate-500" />
              </span>
              <input
                type="date"
                className="sr-only"
                value={period.endDate}
                onChange={(e) => set({ endDate: e.target.value })}
              />
            </label>
          </div>
        </Row>

        <Row mode="sinceDate" title="Depuis une date">
          <span className="flex items-center justify-between rounded-xl bg-[#0b1628] px-3 py-2 text-[13px] text-white">
            {toInput(period.sinceDate)}
            <IconCalendar size={14} className="text-slate-500" />
          </span>
        </Row>

        <Row mode="allHistory" title="Tout l’historique" />
        <Row mode="onChart" title="Période sur le graphique" />
      </div>

      <div className="px-5 pb-3">
        <Button onClick={back}>Appliquer</Button>
      </div>
    </div>
  );
}
