import React from 'react';
import { ControlSettings } from '../types/game';
import { audio } from '../services/audio';
import { triggerHaptic } from '../services/storage';
import { X, Volume2, Gamepad2, Sparkles, Smartphone } from 'lucide-react';

interface SettingsModalProps {
  settings: ControlSettings;
  onUpdateSettings: (newSettings: ControlSettings) => void;
  onClose: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  settings,
  onUpdateSettings,
  onClose,
}) => {
  const update = (partial: Partial<ControlSettings>) => {
    const updated = { ...settings, ...partial };
    onUpdateSettings(updated);
    if ('audioVolume' in partial || 'engineVolume' in partial || 'musicVolume' in partial) {
      audio.setVolumes(
        updated.audioVolume,
        updated.engineVolume,
        updated.audioVolume,
        updated.musicVolume
      );
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-slate-900 border border-white/20 rounded-3xl p-5 shadow-2xl flex flex-col max-h-[90vh] overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="flex justify-between items-center pb-3 border-b border-white/10 mb-4">
          <div>
            <span className="text-[10px] font-black uppercase tracking-widest text-cyan-400 block -mb-0.5">
              CONFIGURATION
            </span>
            <h2 className="text-xl font-black italic uppercase text-white">
              PARAMÈTRES DU JEU
            </h2>
          </div>
          <button
            onClick={() => {
              audio.playClick();
              onClose();
            }}
            aria-label="Fermer"
            className="w-9 h-9 rounded-xl bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center active:scale-95"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable content */}
        <div className="flex-1 overflow-y-auto flex flex-col gap-5 pr-1">
          {/* Controls Section */}
          <div className="flex flex-col gap-3">
            <span className="text-xs font-black uppercase tracking-wider text-cyan-400 flex items-center gap-1.5">
              <Gamepad2 className="w-4 h-4" /> CONTRÔLES MOBILES
            </span>

            {/* Scheme buttons / wheel */}
            <div className="grid grid-cols-2 gap-2 bg-slate-950 p-1 rounded-xl border border-white/10">
              <button
                onClick={() => {
                  audio.playClick();
                  triggerHaptic(20);
                  update({ scheme: 'buttons' });
                }}
                className={`py-2 rounded-lg text-xs font-black uppercase transition-all ${
                  settings.scheme === 'buttons'
                    ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                TOUCHES FLÈCHES
              </button>
              <button
                onClick={() => {
                  audio.playClick();
                  triggerHaptic(20);
                  update({ scheme: 'wheel' });
                }}
                className={`py-2 rounded-lg text-xs font-black uppercase transition-all ${
                  settings.scheme === 'wheel'
                    ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                VOLANT VIRTUEL
              </button>
            </div>

            {/* Auto Accelerate Toggle */}
            <div className="flex justify-between items-center p-3 rounded-2xl bg-slate-950 border border-white/10">
              <div>
                <span className="text-xs font-black uppercase text-white block">
                  ACCÉLÉRATION AUTO
                </span>
                <span className="text-[10px] text-slate-400 block">
                  Le véhicule accélère seul (idéal sur petit écran)
                </span>
              </div>
              <input
                type="checkbox"
                checked={settings.autoAccelerate}
                onChange={(e) => {
                  audio.playClick();
                  triggerHaptic(20);
                  update({ autoAccelerate: e.target.checked });
                }}
                className="w-5 h-5 accent-cyan-400 rounded cursor-pointer"
              />
            </div>

            {/* Steering Sensitivity Slider */}
            <div className="flex flex-col gap-1 p-3 rounded-2xl bg-slate-950 border border-white/10">
              <div className="flex justify-between text-xs font-black uppercase">
                <span className="text-white">SENSIBILITÉ DE DIRECTION</span>
                <span className="text-cyan-400 font-mono">{settings.steeringSensitivity.toFixed(1)}x</span>
              </div>
              <input
                type="range"
                min="0.5"
                max="1.6"
                step="0.1"
                value={settings.steeringSensitivity}
                onChange={(e) => update({ steeringSensitivity: parseFloat(e.target.value) })}
                className="w-full accent-cyan-400 cursor-pointer"
              />
            </div>

            {/* Vibration */}
            <div className="flex justify-between items-center p-3 rounded-2xl bg-slate-950 border border-white/10">
              <div className="flex items-center gap-2">
                <Smartphone className="w-4 h-4 text-cyan-400" />
                <div>
                  <span className="text-xs font-black uppercase text-white block">
                    VIBRATIONS HAPTIQUES
                  </span>
                  <span className="text-[10px] text-slate-400 block">
                    Retour tactile lors des chocs et drifts
                  </span>
                </div>
              </div>
              <input
                type="checkbox"
                checked={settings.vibrate}
                onChange={(e) => {
                  audio.playClick();
                  triggerHaptic(40);
                  update({ vibrate: e.target.checked });
                }}
                className="w-5 h-5 accent-cyan-400 rounded cursor-pointer"
              />
            </div>
          </div>

          {/* Sensation of speed FX */}
          <div className="flex flex-col gap-3">
            <span className="text-xs font-black uppercase tracking-wider text-cyan-400 flex items-center gap-1.5">
              <Sparkles className="w-4 h-4" /> EFFETS SENSATION DE VITESSE
            </span>

            {/* Dynamic FOV Warp */}
            <div className="flex justify-between items-center p-3 rounded-2xl bg-slate-950 border border-white/10">
              <div>
                <span className="text-xs font-black uppercase text-white block">
                  DISTORSION FOV DYNAMIQUE
                </span>
                <span className="text-[10px] text-slate-400 block">
                  Élargit le champ visuel à très haute vitesse et nitro
                </span>
              </div>
              <input
                type="checkbox"
                checked={settings.cameraFovBoost}
                onChange={(e) => {
                  audio.playClick();
                  update({ cameraFovBoost: e.target.checked });
                }}
                className="w-5 h-5 accent-cyan-400 rounded cursor-pointer"
              />
            </div>

            {/* Speed Lines */}
            <div className="flex justify-between items-center p-3 rounded-2xl bg-slate-950 border border-white/10">
              <div>
                <span className="text-xs font-black uppercase text-white block">
                  LIGNES DE VITESSE RADIALES
                </span>
                <span className="text-[10px] text-slate-400 block">
                  Traînées cinétiques de vent arcade à 200+ km/h
                </span>
              </div>
              <input
                type="checkbox"
                checked={settings.speedLines}
                onChange={(e) => {
                  audio.playClick();
                  update({ speedLines: e.target.checked });
                }}
                className="w-5 h-5 accent-cyan-400 rounded cursor-pointer"
              />
            </div>
          </div>

          {/* Audio Sliders */}
          <div className="flex flex-col gap-3">
            <span className="text-xs font-black uppercase tracking-wider text-cyan-400 flex items-center gap-1.5">
              <Volume2 className="w-4 h-4" /> VOLUMES SONORES
            </span>

            {/* Engine volume */}
            <div className="flex flex-col gap-1 p-3 rounded-2xl bg-slate-950 border border-white/10">
              <div className="flex justify-between text-xs font-black uppercase">
                <span className="text-white">BRUIT MOTEUR & ÉCHAPPEMENT</span>
                <span className="text-cyan-400 font-mono">{Math.round(settings.engineVolume * 100)}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="1"
                step="0.05"
                value={settings.engineVolume}
                onChange={(e) => update({ engineVolume: parseFloat(e.target.value) })}
                className="w-full accent-cyan-400 cursor-pointer"
              />
            </div>

            {/* Synthwave music volume */}
            <div className="flex flex-col gap-1 p-3 rounded-2xl bg-slate-950 border border-white/10">
              <div className="flex justify-between text-xs font-black uppercase">
                <span className="text-white">MUSIQUE SYNTHWAVE</span>
                <span className="text-cyan-400 font-mono">{Math.round(settings.musicVolume * 100)}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="1"
                step="0.05"
                value={settings.musicVolume}
                onChange={(e) => update({ musicVolume: parseFloat(e.target.value) })}
                className="w-full accent-cyan-400 cursor-pointer"
              />
            </div>
          </div>
        </div>

        {/* Save button */}
        <div className="pt-3 border-t border-white/10 mt-2">
          <button
            onClick={() => {
              audio.playClick();
              triggerHaptic(25);
              onClose();
            }}
            className="w-full py-3 rounded-2xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-black text-xs uppercase tracking-wider shadow-lg shadow-cyan-500/20 active:scale-95 transition-all"
          >
            VALIDER & REPRENDRE
          </button>
        </div>
      </div>
    </div>
  );
};
