import * as THREE from 'three';
import { TrackDefinition, GameMode } from '../types/game';

export interface TrackData {
  group: THREE.Group;
  spline: THREE.CatmullRomCurve3;
  trackLength: number;
  roadWidth: number;
  startPosition: THREE.Vector3;
  startRotationY: number;
  samplePoints: { pos: THREE.Vector3; tangent: THREE.Vector3; normal: THREE.Vector3; t: number }[];
  isEndlessHighway: boolean;
  barrierColliders: { left: THREE.Vector3[]; right: THREE.Vector3[] };
}

export function buildProceduralTrack(
  trackDef: TrackDefinition,
  mode: GameMode
): TrackData {
  const group = new THREE.Group();
  const roadWidth = 18; // Wide 3-4 lane track for overtaking and drifting
  const isEndless = mode === 'endless_traffic';

  // Define control points for each track
  let points: THREE.Vector3[] = [];

  if (isEndless) {
    // Endless straight highway extending 12km
    points = [
      new THREE.Vector3(0, 0, 500),
      new THREE.Vector3(0, 0, 0),
      new THREE.Vector3(0, 0, -2000),
      new THREE.Vector3(0, 0, -4500),
      new THREE.Vector3(0, 0, -7000),
      new THREE.Vector3(0, 0, -9500),
      new THREE.Vector3(0, 0, -12000),
    ];
  } else {
    switch (trackDef.id) {
      case 'desert_canyon':
        points = [
          new THREE.Vector3(0, 0, 0),
          new THREE.Vector3(0, 0, -200),
          new THREE.Vector3(120, 8, -360),
          new THREE.Vector3(300, 18, -420),
          new THREE.Vector3(460, 24, -300),
          new THREE.Vector3(500, 16, -100),
          new THREE.Vector3(380, 6, 120),
          new THREE.Vector3(440, -4, 320),
          new THREE.Vector3(300, -10, 480),
          new THREE.Vector3(100, -5, 500),
          new THREE.Vector3(-120, 0, 400),
          new THREE.Vector3(-280, 8, 260),
          new THREE.Vector3(-340, 12, 80),
          new THREE.Vector3(-220, 6, -60),
          new THREE.Vector3(-80, 0, 80),
          new THREE.Vector3(0, 0, 150),
        ];
        break;

      case 'alpine_summit':
        points = [
          new THREE.Vector3(0, 0, 0),
          new THREE.Vector3(0, 0, -180),
          new THREE.Vector3(-100, 12, -320),
          new THREE.Vector3(-140, 28, -460),
          new THREE.Vector3(30, 38, -500),
          new THREE.Vector3(200, 34, -420),
          new THREE.Vector3(320, 22, -280),
          new THREE.Vector3(260, 14, -120),
          new THREE.Vector3(360, 8, 80),
          new THREE.Vector3(300, 2, 280),
          new THREE.Vector3(140, -4, 380),
          new THREE.Vector3(-60, -2, 320),
          new THREE.Vector3(-160, 0, 180),
          new THREE.Vector3(0, 0, 150),
        ];
        break;

      case 'sunset_riviera':
        points = [
          new THREE.Vector3(0, 0, 0),
          new THREE.Vector3(0, 0, -200),
          new THREE.Vector3(140, 0, -360),
          new THREE.Vector3(320, 8, -420),
          new THREE.Vector3(500, 14, -320),
          new THREE.Vector3(540, 10, -140),
          new THREE.Vector3(440, 4, 60),
          new THREE.Vector3(500, -2, 240),
          new THREE.Vector3(380, -6, 420),
          new THREE.Vector3(180, -8, 520),
          new THREE.Vector3(-40, -4, 440),
          new THREE.Vector3(-180, 2, 300),
          new THREE.Vector3(-280, 8, 140),
          new THREE.Vector3(-240, 4, -40),
          new THREE.Vector3(0, 0, 150),
        ];
        break;

      case 'cyber_highway':
      default:
        // Cyber city high speed sweeping course
        points = [
          new THREE.Vector3(0, 0, 0),
          new THREE.Vector3(0, 0, -250),
          new THREE.Vector3(80, 6, -420),
          new THREE.Vector3(220, 14, -480),
          new THREE.Vector3(380, 10, -380),
          new THREE.Vector3(440, 4, -180),
          new THREE.Vector3(360, 0, 0),
          new THREE.Vector3(420, 4, 180),
          new THREE.Vector3(320, 10, 360),
          new THREE.Vector3(140, 8, 440),
          new THREE.Vector3(-80, 4, 380),
          new THREE.Vector3(-200, 0, 240),
          new THREE.Vector3(-220, 0, 80),
          new THREE.Vector3(-120, 0, -20),
          new THREE.Vector3(0, 0, 150),
        ];
        break;
    }
  }

  const spline = new THREE.CatmullRomCurve3(points, !isEndless);
  spline.curveType = 'catmullrom';
  spline.tension = 0.45;

  const sampleCount = isEndless ? 300 : 350;
  const samplePoints: TrackData['samplePoints'] = [];
  const trackLength = spline.getLength();

  // Materials with DoubleSide to ensure full visibility from all angles
  const roadMat = new THREE.MeshStandardMaterial({
    color: new THREE.Color(trackDef.roadColor),
    roughness: 0.8,
    metalness: 0.1,
    flatShading: true,
    side: THREE.DoubleSide,
  });

  const curbMat1 = new THREE.MeshStandardMaterial({
    color: new THREE.Color(trackDef.curbColor1),
    roughness: 0.6,
    metalness: 0.2,
    flatShading: true,
    side: THREE.DoubleSide,
  });

  const curbMat2 = new THREE.MeshStandardMaterial({
    color: new THREE.Color(trackDef.curbColor2),
    roughness: 0.6,
    metalness: 0.2,
    flatShading: true,
    side: THREE.DoubleSide,
  });

  const barrierMat = new THREE.MeshStandardMaterial({
    color: 0x94a3b8,
    roughness: 0.4,
    metalness: 0.7,
    flatShading: true,
    side: THREE.DoubleSide,
  });

  const stripeMat = new THREE.MeshBasicMaterial({
    color: 0xffffff,
  });

  // Sample the spline evenly
  for (let i = 0; i <= sampleCount; i++) {
    const t = i / sampleCount;
    const pos = spline.getPointAt(t);
    const tangent = spline.getTangentAt(t).normalize();
    // Compute normal perpendicular to tangent and up
    const up = new THREE.Vector3(0, 1, 0);
    const normal = new THREE.Vector3().crossVectors(tangent, up).normalize();

    samplePoints.push({ pos, tangent, normal, t });
  }

  // Construct Road Mesh Vertices
  const roadGeom = new THREE.BufferGeometry();
  const roadPositions: number[] = [];
  const roadNormals: number[] = [];
  const roadUvs: number[] = [];

  const curb1Positions: number[] = [];
  const curb2Positions: number[] = [];
  const barrierLPositions: number[] = [];
  const barrierRPositions: number[] = [];

  const barrierLeftPoints: THREE.Vector3[] = [];
  const barrierRightPoints: THREE.Vector3[] = [];

  const halfW = roadWidth * 0.5;
  const curbW = 1.2;
  const curbH = 0.25;
  const barrierH = 1.0;

  const loopLimit = isEndless ? samplePoints.length - 1 : samplePoints.length;

  for (let i = 0; i < loopLimit; i++) {
    const p1 = samplePoints[i];
    const p2 = samplePoints[(i + 1) % samplePoints.length];

    // Left and Right road edges
    const l1 = p1.pos.clone().addScaledVector(p1.normal, -halfW);
    const r1 = p1.pos.clone().addScaledVector(p1.normal, halfW);
    const l2 = p2.pos.clone().addScaledVector(p2.normal, -halfW);
    const r2 = p2.pos.clone().addScaledVector(p2.normal, halfW);

    barrierLeftPoints.push(l1);
    barrierRightPoints.push(r1);

    // Quad for road (2 triangles - CCW winding for upward normal)
    roadPositions.push(
      l1.x, l1.y, l1.z,
      l2.x, l2.y, l2.z,
      r1.x, r1.y, r1.z,

      r1.x, r1.y, r1.z,
      l2.x, l2.y, l2.z,
      r2.x, r2.y, r2.z
    );

    for (let k = 0; k < 6; k++) {
      roadNormals.push(0, 1, 0);
      roadUvs.push(0, 0);
    }

    // Curbs on left and right
    const cl1 = l1.clone().addScaledVector(p1.normal, -curbW);
    cl1.y += curbH;
    const cl2 = l2.clone().addScaledVector(p2.normal, -curbW);
    cl2.y += curbH;

    const cr1 = r1.clone().addScaledVector(p1.normal, curbW);
    cr1.y += curbH;
    const cr2 = r2.clone().addScaledVector(p2.normal, curbW);
    cr2.y += curbH;

    const curbTarget = (i % 4 < 2) ? curb1Positions : curb2Positions;
    curbTarget.push(
      cl1.x, cl1.y, cl1.z,
      l1.x, l1.y, l1.z,
      cl2.x, cl2.y, cl2.z,

      l1.x, l1.y, l1.z,
      l2.x, l2.y, l2.z,
      cl2.x, cl2.y, cl2.z,

      r1.x, r1.y, r1.z,
      cr1.x, cr1.y, cr1.z,
      r2.x, r2.y, r2.z,

      cr1.x, cr1.y, cr1.z,
      cr2.x, cr2.y, cr2.z,
      r2.x, r2.y, r2.z
    );

    // Barriers on edges
    const bl1 = cl1.clone();
    bl1.y += barrierH;
    const bl2 = cl2.clone();
    bl2.y += barrierH;

    const br1 = cr1.clone();
    br1.y += barrierH;
    const br2 = cr2.clone();
    br2.y += barrierH;

    barrierLPositions.push(
      cl1.x, cl1.y, cl1.z,
      cl2.x, cl2.y, cl2.z,
      bl1.x, bl1.y, bl1.z,

      cl2.x, cl2.y, cl2.z,
      bl2.x, bl2.y, bl2.z,
      bl1.x, bl1.y, bl1.z
    );

    barrierRPositions.push(
      cr1.x, cr1.y, cr1.z,
      br1.x, br1.y, br1.z,
      cr2.x, cr2.y, cr2.z,

      cr2.x, cr2.y, cr2.z,
      br1.x, br1.y, br1.z,
      br2.x, br2.y, br2.z
    );
  }

  roadGeom.setAttribute('position', new THREE.Float32BufferAttribute(roadPositions, 3));
  roadGeom.setAttribute('normal', new THREE.Float32BufferAttribute(roadNormals, 3));
  roadGeom.computeVertexNormals();
  const roadMesh = new THREE.Mesh(roadGeom, roadMat);
  roadMesh.receiveShadow = true;
  group.add(roadMesh);

  // Curbs mesh
  const curb1Geom = new THREE.BufferGeometry();
  curb1Geom.setAttribute('position', new THREE.Float32BufferAttribute(curb1Positions, 3));
  curb1Geom.computeVertexNormals();
  group.add(new THREE.Mesh(curb1Geom, curbMat1));

  const curb2Geom = new THREE.BufferGeometry();
  curb2Geom.setAttribute('position', new THREE.Float32BufferAttribute(curb2Positions, 3));
  curb2Geom.computeVertexNormals();
  group.add(new THREE.Mesh(curb2Geom, curbMat2));

  // Barriers mesh
  const barrierGeom = new THREE.BufferGeometry();
  barrierGeom.setAttribute('position', new THREE.Float32BufferAttribute([...barrierLPositions, ...barrierRPositions], 3));
  barrierGeom.computeVertexNormals();
  const barrierMesh = new THREE.Mesh(barrierGeom, barrierMat);
  barrierMesh.castShadow = true;
  group.add(barrierMesh);

  // Center dashed white road stripes
  const stripeGeom = new THREE.BoxGeometry(0.3, 0.05, 3.5);
  for (let i = 0; i < samplePoints.length; i += 3) {
    const pt = samplePoints[i];
    const stripe = new THREE.Mesh(stripeGeom, stripeMat);
    stripe.position.copy(pt.pos);
    stripe.position.y += 0.05;
    stripe.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), pt.tangent);
    group.add(stripe);
  }

  // Start / Finish Line Gantry (for circuit tracks)
  const startPt = samplePoints[0];
  const startRotY = Math.atan2(startPt.tangent.x, startPt.tangent.z);

  if (!isEndless) {
    const gantryGroup = new THREE.Group();
    gantryGroup.position.copy(startPt.pos);
    gantryGroup.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), startPt.tangent);

    const postGeo = new THREE.BoxGeometry(0.8, 7, 0.8);
    const postMat = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.5, metalness: 0.8 });
    const postL = new THREE.Mesh(postGeo, postMat);
    postL.position.set(-halfW - 1.5, 3.5, 0);
    const postR = new THREE.Mesh(postGeo, postMat);
    postR.position.set(halfW + 1.5, 3.5, 0);

    const crossbeamGeo = new THREE.BoxGeometry(roadWidth + 4, 1.4, 1.2);
    const crossbeam = new THREE.Mesh(crossbeamGeo, postMat);
    crossbeam.position.set(0, 6.5, 0);

    // Banner board
    const bannerGeo = new THREE.BoxGeometry(roadWidth * 0.8, 1.2, 0.1);
    const bannerMat = new THREE.MeshBasicMaterial({ color: 0x06b6d4 });
    const banner = new THREE.Mesh(bannerGeo, bannerMat);
    banner.position.set(0, 6.5, 0.65);

    // Chequered start line on ground
    const checkLineGeo = new THREE.BoxGeometry(roadWidth, 0.08, 1.8);
    const checkMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
    const checkLine = new THREE.Mesh(checkLineGeo, checkMat);
    checkLine.position.set(0, 0.06, 0);

    gantryGroup.add(postL, postR, crossbeam, banner, checkLine);
    group.add(gantryGroup);
  }

  // Generate Low Poly Thematic Scenery around the track!
  buildScenery(group, trackDef, samplePoints, roadWidth);

  return {
    group,
    spline,
    trackLength,
    roadWidth,
    startPosition: startPt.pos.clone(),
    startRotationY: startRotY,
    samplePoints,
    isEndlessHighway: isEndless,
    barrierColliders: { left: barrierLeftPoints, right: barrierRightPoints },
  };
}

function buildScenery(
  parent: THREE.Group,
  trackDef: TrackDefinition,
  samples: TrackData['samplePoints'],
  roadWidth: number
) {
  const sceneryGroup = new THREE.Group();
  parent.add(sceneryGroup);

  const theme = trackDef.theme;

  // Ground plane under everything
  const groundGeo = new THREE.PlaneGeometry(2400, 2400, 32, 32);
  groundGeo.rotateX(-Math.PI / 2);
  const groundMat = new THREE.MeshStandardMaterial({
    color: new THREE.Color(trackDef.groundColor),
    roughness: 0.95,
    metalness: 0.05,
    flatShading: true,
  });
  const groundMesh = new THREE.Mesh(groundGeo, groundMat);
  groundMesh.position.y = -0.5;
  groundMesh.receiveShadow = true;
  sceneryGroup.add(groundMesh);

  // Common materials for low-poly assets
  const neonBlue = new THREE.MeshBasicMaterial({ color: 0x06b6d4 });
  const neonPink = new THREE.MeshBasicMaterial({ color: 0xf43f5e });
  const neonYellow = new THREE.MeshBasicMaterial({ color: 0xfacc15 });

  // Low poly tree meshes
  const pineTrunkMat = new THREE.MeshStandardMaterial({ color: 0x451a03, roughness: 0.9, flatShading: true });
  const pineNeedleMat = new THREE.MeshStandardMaterial({
    color: theme === 'snow' ? 0xe2e8f0 : 0x166534,
    roughness: 0.8,
    flatShading: true,
  });

  const rockMat = new THREE.MeshStandardMaterial({
    color: theme === 'desert' ? 0x9a3412 : 0x64748b,
    roughness: 0.9,
    flatShading: true,
  });

  const palmWoodMat = new THREE.MeshStandardMaterial({ color: 0x78350f, roughness: 0.9, flatShading: true });
  const palmLeafMat = new THREE.MeshStandardMaterial({ color: 0x15803d, roughness: 0.8, flatShading: true });

  const buildingMat = new THREE.MeshStandardMaterial({
    color: 0x0f172a,
    roughness: 0.5,
    metalness: 0.8,
    flatShading: true,
  });

  // Distribute objects along the track outside barriers
  const step = 6;
  for (let i = 0; i < samples.length; i += step) {
    const pt = samples[i];
    const distLeft = roadWidth * 0.5 + 8 + (Math.sin(i * 1.5) + 1) * 15;
    const distRight = roadWidth * 0.5 + 8 + (Math.cos(i * 1.2) + 1) * 15;

    const leftPos = pt.pos.clone().addScaledVector(pt.normal, -distLeft);
    const rightPos = pt.pos.clone().addScaledVector(pt.normal, distRight);

    if (theme === 'cyber') {
      // Skyscrapers and neon signs
      if (i % 12 === 0) {
        const height = 40 + Math.random() * 80;
        const bWidth = 18 + Math.random() * 14;
        const bGeo = new THREE.BoxGeometry(bWidth, height, bWidth);
        const building = new THREE.Mesh(bGeo, buildingMat);
        building.position.set(leftPos.x, height * 0.5, leftPos.z);
        sceneryGroup.add(building);

        // Neon roof trim
        const trimGeo = new THREE.BoxGeometry(bWidth * 0.98, 1.2, bWidth * 0.98);
        const trim = new THREE.Mesh(trimGeo, i % 24 === 0 ? neonBlue : neonPink);
        trim.position.set(leftPos.x, height, leftPos.z);
        sceneryGroup.add(trim);
      }

      if (i % 18 === 0) {
        const height = 50 + Math.random() * 90;
        const bWidth = 20 + Math.random() * 16;
        const bGeo = new THREE.BoxGeometry(bWidth, height, bWidth);
        const buildingR = new THREE.Mesh(bGeo, buildingMat);
        buildingR.position.set(rightPos.x, height * 0.5, rightPos.z);
        sceneryGroup.add(buildingR);

        // Hologram billboard
        const holoGeo = new THREE.PlaneGeometry(16, 8);
        const holo = new THREE.Mesh(holoGeo, neonYellow);
        holo.position.set(rightPos.x, 15, rightPos.z);
        holo.lookAt(pt.pos);
        sceneryGroup.add(holo);
      }

      // Streetlights along cyber highway
      if (i % 6 === 0) {
        const lightPoleGeo = new THREE.CylinderGeometry(0.15, 0.2, 9, 6);
        const poleMat = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.5 });
        const pole = new THREE.Mesh(lightPoleGeo, poleMat);
        const lightPos = pt.pos.clone().addScaledVector(pt.normal, -roadWidth * 0.55);
        pole.position.set(lightPos.x, pt.pos.y + 4.5, lightPos.z);
        const bulb = new THREE.Mesh(new THREE.SphereGeometry(0.35, 6, 6), neonBlue);
        bulb.position.set(0, 4.5, 0);
        pole.add(bulb);
        sceneryGroup.add(pole);
      }
    } else if (theme === 'desert') {
      // Sandstone rocks and Cacti
      if (i % 6 === 0) {
        // Cacti
        const cactus = new THREE.Group();
        const trunkGeo = new THREE.CylinderGeometry(0.4, 0.45, 4.5, 6);
        const trunk = new THREE.Mesh(trunkGeo, new THREE.MeshStandardMaterial({ color: 0x15803d, flatShading: true }));
        cactus.add(trunk);
        const armGeo = new THREE.CylinderGeometry(0.25, 0.25, 2.2, 5);
        const arm1 = new THREE.Mesh(armGeo, trunk.material);
        arm1.position.set(0.6, 0.5, 0);
        arm1.rotation.z = Math.PI / 4;
        cactus.add(arm1);
        cactus.position.set(leftPos.x, leftPos.y + 2.2, leftPos.z);
        sceneryGroup.add(cactus);
      }

      // Massive canyon rock mesa
      if (i % 12 === 0) {
        const rockGeo = new THREE.DodecahedronGeometry(8 + Math.random() * 10, 0);
        const rock = new THREE.Mesh(rockGeo, rockMat);
        rock.position.set(rightPos.x, rightPos.y + 6, rightPos.z);
        rock.scale.set(1.5, 1.2, 1.5);
        sceneryGroup.add(rock);
      }
    } else if (theme === 'snow') {
      // Snow pines and icy boulders
      if (i % 6 === 0) {
        const pine = new THREE.Group();
        const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.45, 3, 6), pineTrunkMat);
        pine.add(trunk);
        for (let lvl = 0; lvl < 3; lvl++) {
          const cone = new THREE.Mesh(new THREE.ConeGeometry(2.5 - lvl * 0.6, 2.5, 6), pineNeedleMat);
          cone.position.y = 2 + lvl * 1.5;
          pine.add(cone);
        }
        pine.position.set(leftPos.x, leftPos.y + 1.5, leftPos.z);
        sceneryGroup.add(pine);
      }

      if (i % 14 === 0) {
        const iceRockGeo = new THREE.IcosahedronGeometry(7 + Math.random() * 6, 0);
        const iceRock = new THREE.Mesh(iceRockGeo, new THREE.MeshStandardMaterial({ color: 0x94a3b8, roughness: 0.3, flatShading: true }));
        iceRock.position.set(rightPos.x, rightPos.y + 4, rightPos.z);
        sceneryGroup.add(iceRock);
      }
    } else if (theme === 'sunset') {
      // Palm trees and coastal cliffs
      if (i % 6 === 0) {
        const palm = new THREE.Group();
        const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.25, 0.4, 6, 6), palmWoodMat);
        palm.add(trunk);
        for (let l = 0; l < 5; l++) {
          const leafGeo = new THREE.BoxGeometry(0.3, 0.08, 3.2);
          const leaf = new THREE.Mesh(leafGeo, palmLeafMat);
          leaf.position.y = 3;
          leaf.rotation.y = (l * Math.PI * 2) / 5;
          leaf.rotation.x = 0.35;
          palm.add(leaf);
        }
        palm.position.set(rightPos.x, rightPos.y + 3, rightPos.z);
        sceneryGroup.add(palm);
      }

      // Distant ocean plane
      if (i === 0) {
        const oceanGeo = new THREE.PlaneGeometry(1600, 1600, 12, 12);
        oceanGeo.rotateX(-Math.PI / 2);
        const oceanMat = new THREE.MeshStandardMaterial({
          color: 0x0284c7,
          roughness: 0.1,
          metalness: 0.8,
          flatShading: true,
        });
        const ocean = new THREE.Mesh(oceanGeo, oceanMat);
        ocean.position.set(300, -8, 200);
        sceneryGroup.add(ocean);
      }
    }
  }
}
