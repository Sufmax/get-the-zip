import { IconChevronRight } from '../components/icons';
import { ScreenHeader, Stepper, Toggle } from '../components/ui/primitives';
import { useApp } from '../context/AppContext';
import type { Timeframe } from '../types';

const TFS: Timeframe[] = ['1m', '15m', '1h', '1j', '1s', '1M'];

export function SettingsScreen() {
  const { settings, setSettings, back, navigate } = useApp();
  const patch = <K extends keyof typeof settings>(k: K, v: (typeof settings)[K]) =>
    setSettings({ ...settings, [k]: v });

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <ScreenHeader title="Paramètres" onBack={back} />

      <div className="min-h-0 flex-1 overflow-y-auto px-4 pb-4">
        <h3 className="mb-2 px-1 text-[13px] font-semibold text-slate-400">Source de données</h3>
        <div className="rounded-2xl border border-white/5 bg-[#101c31] p-4">
          <div className="mb-3 flex items-center justify-between">
            <span className="text-[14px] text-white">Mode</span>
            <button
              onClick={() => patch('dataMode', settings.dataMode === 'auto' ? 'manual' : 'auto')}
              className="rounded-full bg-[#1a3358] px-4 py-1 text-[12px] font-semibold text-white"
            >
              {settings.dataMode === 'auto' ? 'Auto' : 'Manuel'}
            </button>
          </div>
          <RowToggle
            label="Cloudflare (si disponible)"
            checked={settings.cloudflare}
            onChange={(v) => patch('cloudflare', v)}
          />
          <RowToggle
            label="Fournisseurs directs"
            checked={settings.directProviders}
            onChange={(v) => patch('directProviders', v)}
          />
          <RowToggle label="Dossier local" checked={settings.localFolder} onChange={(v) => patch('localFolder', v)} />
        </div>

        <div className="mt-3 space-y-0 overflow-hidden rounded-2xl border border-white/5 bg-[#101c31]">
          <div className="flex items-center justify-between px-4 py-3">
            <span className="text-[14px] text-white">Granularité</span>
            <select
              value={settings.granularity}
              onChange={(e) => patch('granularity', e.target.value as Timeframe)}
              className="rounded-lg bg-[#0b1628] px-3 py-1 text-[13px] text-white outline-none"
            >
              {TFS.map((t) => (
                <option key={t} value={t}>
                  {t}
                </option>
              ))}
            </select>
          </div>
          <div className="flex items-center justify-between border-t border-white/5 px-4 py-3">
            <span className="text-[14px] text-white">Nombre de résultats</span>
            <Stepper
              value={settings.resultCount}
              onChange={(n) => patch('resultCount', n)}
              min={5}
              max={100}
            />
          </div>
          <div className="flex items-center justify-between border-t border-white/5 px-4 py-3">
            <span className="text-[14px] text-white">Limite de recherche</span>
            <Stepper
              value={settings.searchLimit}
              onChange={(n) => patch('searchLimit', n)}
              min={50}
              max={5000}
              suffix="bougies"
            />
          </div>
        </div>

        <div className="mt-3 overflow-hidden rounded-2xl border border-white/5 bg-[#101c31]">
          <LinkRow label="Fournisseurs" onClick={() => navigate('dataSources')} />
          <LinkRow label="Cache" onClick={() => navigate('sync')} />
          <LinkRow label="Aide" onClick={() => navigate('help')} last={false} />
          <LinkRow label="Avancé" onClick={() => navigate('backtest')} last />
        </div>
      </div>
    </div>
  );
}

function RowToggle({ label, checked, onChange }: { label: string; checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <div className="flex items-center justify-between py-2.5">
      <span className="text-[14px] text-white">{label}</span>
      <Toggle checked={checked} onChange={onChange} />
    </div>
  );
}

function LinkRow({ label, onClick, last }: { label: string; onClick: () => void; last?: boolean }) {
  return (
    <button
      onClick={onClick}
      className={`flex w-full items-center justify-between px-4 py-3.5 text-left ${last ? '' : 'border-b border-white/5'}`}
    >
      <span className="text-[14px] text-white">{label}</span>
      <IconChevronRight className="text-slate-500" />
    </button>
  );
}
