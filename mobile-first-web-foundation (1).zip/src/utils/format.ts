/** Formatage FR — les valeurs restent des données de présentation. */

export function formatNumber(value: number, decimals = 2): string {
  const [int, frac] = value.toFixed(decimals).split('.');
  const withSpaces = int.replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
  return decimals > 0 ? `${withSpaces},${frac}` : withSpaces;
}

export function formatPrice(value: number, decimals: number, quoteCurrency: string): string {
  const n = formatNumber(value, decimals);
  if (!quoteCurrency || quoteCurrency === '') return n;
  if (quoteCurrency === 'USD') return `${n} $`;
  return `${n} ${quoteCurrency}`;
}

export function formatPct(value: number, decimals = 2): string {
  const sign = value > 0 ? '+' : '';
  return `${sign}${formatNumber(value, decimals)}%`;
}

export function formatDateTick(ts: number): string {
  const d = new Date(ts);
  const months = ['jan.', 'fév.', 'mar.', 'avr.', 'mai', 'juin', 'juil.', 'août', 'sep.', 'oct.', 'nov.', 'déc.'];
  return `${d.getDate()} ${months[d.getMonth()]}`;
}

export function clamp(n: number, min: number, max: number) {
  return Math.min(max, Math.max(min, n));
}
