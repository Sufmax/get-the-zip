import * as THREE from 'three';
import { CarDefinition, PlayerCarCustomization } from '../types/game';

export interface Car3DObject {
  root: THREE.Group;
  bodyGroup: THREE.Group;
  bodyMesh: THREE.Mesh;
  bodyMaterial: THREE.MeshStandardMaterial;
  frontWheels: THREE.Group[];
  rearWheels: THREE.Group[];
  exhaustPoints: THREE.Vector3[];
  headlights: THREE.Mesh[];
  taillights: THREE.Mesh[];
  brakeLightMaterial: THREE.MeshBasicMaterial;
  underglowMesh?: THREE.Mesh;
  steerAngle: number;
  wheelSpin: number;
}

export function buildLowPolyCar(
  carDef: CarDefinition,
  customization?: PlayerCarCustomization
): Car3DObject {
  const root = new THREE.Group();
  const bodyGroup = new THREE.Group();
  root.add(bodyGroup);

  const activeColor = customization?.selectedColor || carDef.baseColor;

  const bodyMaterial = new THREE.MeshStandardMaterial({
    color: new THREE.Color(activeColor),
    roughness: 0.35,
    metalness: 0.45,
    flatShading: true,
  });

  const blackTrimMaterial = new THREE.MeshStandardMaterial({
    color: 0x18181b,
    roughness: 0.85,
    metalness: 0.2,
    flatShading: true,
  });

  const glassMaterial = new THREE.MeshStandardMaterial({
    color: 0x1e293b,
    roughness: 0.1,
    metalness: 0.9,
    flatShading: true,
  });

  const chromeMaterial = new THREE.MeshStandardMaterial({
    color: 0xe2e8f0,
    roughness: 0.15,
    metalness: 0.95,
    flatShading: true,
  });

  const headlightMaterial = new THREE.MeshBasicMaterial({ color: 0xffffff });
  const taillightMaterial = new THREE.MeshBasicMaterial({ color: 0xef4444 });
  const brakeLightMaterial = new THREE.MeshBasicMaterial({ color: 0x7f1d1d });

  const frontWheels: THREE.Group[] = [];
  const rearWheels: THREE.Group[] = [];
  const exhaustPoints: THREE.Vector3[] = [];
  const headlights: THREE.Mesh[] = [];
  const taillights: THREE.Mesh[] = [];

  let carLength = 4.2;
  let carWidth = 1.9;
  let carHeight = 1.1;
  let wheelRadius = 0.34;
  let wheelWidth = 0.28;

  let mainBodyMesh: THREE.Mesh;

  switch (carDef.shape) {
    case 'formula': {
      carLength = 4.6;
      carWidth = 1.8;
      wheelRadius = 0.32;
      wheelWidth = 0.38;

      // Central narrow fuselage
      const fuseGeo = new THREE.BoxGeometry(0.8, 0.42, 3.8);
      mainBodyMesh = new THREE.Mesh(fuseGeo, bodyMaterial);
      mainBodyMesh.position.set(0, 0.28, 0);
      bodyGroup.add(mainBodyMesh);

      // Nose cone
      const noseGeo = new THREE.ConeGeometry(0.38, 1.4, 5);
      const nose = new THREE.Mesh(noseGeo, bodyMaterial);
      nose.rotation.x = Math.PI / 2;
      nose.position.set(0, 0.26, 2.3);
      bodyGroup.add(nose);

      // Front wing
      const fWingGeo = new THREE.BoxGeometry(1.9, 0.06, 0.45);
      const fWing = new THREE.Mesh(fWingGeo, blackTrimMaterial);
      fWing.position.set(0, 0.15, 2.2);
      bodyGroup.add(fWing);

      // Rear wing
      const rWingGeo = new THREE.BoxGeometry(1.6, 0.08, 0.5);
      const rWing = new THREE.Mesh(rWingGeo, blackTrimMaterial);
      rWing.position.set(0, 0.95, -1.8);
      const rPostL = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.6, 0.1), blackTrimMaterial);
      rPostL.position.set(-0.5, 0.65, -1.8);
      const rPostR = rPostL.clone();
      rPostR.position.x = 0.5;
      bodyGroup.add(rWing, rPostL, rPostR);

      // Open cockpit helmet
      const helmetGeo = new THREE.SphereGeometry(0.2, 8, 8);
      const helmet = new THREE.Mesh(helmetGeo, chromeMaterial);
      helmet.position.set(0, 0.58, -0.2);
      bodyGroup.add(helmet);
      break;
    }

    case 'muscle': {
      carLength = 4.4;
      carWidth = 2.0;
      wheelRadius = 0.38;

      // Heavy body
      const muscleGeo = new THREE.BoxGeometry(carWidth, 0.56, carLength);
      mainBodyMesh = new THREE.Mesh(muscleGeo, bodyMaterial);
      mainBodyMesh.position.set(0, 0.38, 0);
      bodyGroup.add(mainBodyMesh);

      // Fastback roof
      const roofGeo = new THREE.BoxGeometry(carWidth * 0.85, 0.45, carLength * 0.46);
      const roof = new THREE.Mesh(roofGeo, glassMaterial);
      roof.position.set(0, 0.8, -0.3);
      bodyGroup.add(roof);

      // Supercharger blower
      const blowerGeo = new THREE.BoxGeometry(0.48, 0.22, 0.65);
      const blower = new THREE.Mesh(blowerGeo, chromeMaterial);
      blower.position.set(0, 0.72, 0.9);
      bodyGroup.add(blower);

      // Ducktail spoiler
      const duckGeo = new THREE.BoxGeometry(carWidth * 0.9, 0.12, 0.2);
      const duck = new THREE.Mesh(duckGeo, blackTrimMaterial);
      duck.position.set(0, 0.72, -carLength * 0.5 + 0.1);
      bodyGroup.add(duck);
      break;
    }

    case 'tuner': {
      carLength = 4.3;
      carWidth = 2.05;
      wheelRadius = 0.35;

      const tunerGeo = new THREE.BoxGeometry(carWidth, 0.46, carLength);
      mainBodyMesh = new THREE.Mesh(tunerGeo, bodyMaterial);
      mainBodyMesh.position.set(0, 0.32, 0);
      bodyGroup.add(mainBodyMesh);

      // Cabin
      const cabinGeo = new THREE.BoxGeometry(carWidth * 0.8, 0.45, carLength * 0.48);
      const cabin = new THREE.Mesh(cabinGeo, glassMaterial);
      cabin.position.set(0, 0.7, -0.2);
      bodyGroup.add(cabin);

      // Massive GT carbon wing
      const wingBlade = new THREE.Mesh(new THREE.BoxGeometry(carWidth * 0.96, 0.06, 0.45), blackTrimMaterial);
      wingBlade.position.set(0, 1.05, -carLength * 0.5 + 0.1);
      const stanchionL = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.55, 0.15), blackTrimMaterial);
      stanchionL.position.set(-0.65, 0.78, -carLength * 0.5 + 0.1);
      const stanchionR = stanchionL.clone();
      stanchionR.position.x = 0.65;
      bodyGroup.add(wingBlade, stanchionL, stanchionR);

      // Front splitter
      const splitter = new THREE.Mesh(new THREE.BoxGeometry(carWidth * 1.02, 0.06, 0.4), blackTrimMaterial);
      splitter.position.set(0, 0.12, carLength * 0.5 + 0.1);
      bodyGroup.add(splitter);
      break;
    }

    case 'hyper': {
      carLength = 4.5;
      carWidth = 2.1;
      wheelRadius = 0.35;

      // Low wedge body
      const hyperGeo = new THREE.BoxGeometry(carWidth, 0.4, carLength);
      mainBodyMesh = new THREE.Mesh(hyperGeo, bodyMaterial);
      mainBodyMesh.position.set(0, 0.28, 0);
      bodyGroup.add(mainBodyMesh);

      // Tear-drop canopy
      const canopyGeo = new THREE.BoxGeometry(carWidth * 0.72, 0.42, carLength * 0.55);
      const canopy = new THREE.Mesh(canopyGeo, glassMaterial);
      canopy.position.set(0, 0.62, -0.1);
      bodyGroup.add(canopy);

      // Shark fin aero stabilizer
      const finGeo = new THREE.BoxGeometry(0.06, 0.45, 1.4);
      const fin = new THREE.Mesh(finGeo, blackTrimMaterial);
      fin.position.set(0, 0.78, -1.2);
      bodyGroup.add(fin);

      // Floating rear spoiler
      const wingGeo = new THREE.BoxGeometry(carWidth * 0.94, 0.06, 0.4);
      const wing = new THREE.Mesh(wingGeo, blackTrimMaterial);
      wing.position.set(0, 0.9, -carLength * 0.5 + 0.05);
      bodyGroup.add(wing);
      break;
    }

    case 'buggy': {
      carLength = 3.9;
      carWidth = 1.95;
      wheelRadius = 0.44;
      wheelWidth = 0.36;

      // Minimalist buggy tub
      const tubGeo = new THREE.BoxGeometry(carWidth * 0.75, 0.45, carLength * 0.75);
      mainBodyMesh = new THREE.Mesh(tubGeo, bodyMaterial);
      mainBodyMesh.position.set(0, 0.45, 0);
      bodyGroup.add(mainBodyMesh);

      // Tubular roll cage
      const cageBarGeo = new THREE.CylinderGeometry(0.05, 0.05, 1.1, 6);
      const bar1 = new THREE.Mesh(cageBarGeo, blackTrimMaterial);
      bar1.position.set(-0.55, 0.95, 0.4);
      const bar2 = bar1.clone();
      bar2.position.x = 0.55;
      const bar3 = bar1.clone();
      bar3.position.z = -0.6;
      const bar4 = bar2.clone();
      bar4.position.z = -0.6;
      const roofBar = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.08, 1.1), blackTrimMaterial);
      roofBar.position.set(0, 1.45, -0.1);
      bodyGroup.add(bar1, bar2, bar3, bar4, roofBar);

      // Spare wheel mounted on rear
      const spareGeo = new THREE.CylinderGeometry(wheelRadius * 0.9, wheelRadius * 0.9, 0.25, 10);
      const spare = new THREE.Mesh(spareGeo, blackTrimMaterial);
      spare.rotation.x = Math.PI / 4;
      spare.position.set(0, 0.85, -carLength * 0.45);
      bodyGroup.add(spare);
      break;
    }

    case 'suv': {
      carLength = 4.5;
      carWidth = 2.15;
      wheelRadius = 0.42;
      wheelWidth = 0.34;

      const suvGeo = new THREE.BoxGeometry(carWidth, 0.7, carLength);
      mainBodyMesh = new THREE.Mesh(suvGeo, bodyMaterial);
      mainBodyMesh.position.set(0, 0.55, 0);
      bodyGroup.add(mainBodyMesh);

      // Tall armored cabin
      const cabinGeo = new THREE.BoxGeometry(carWidth * 0.88, 0.6, carLength * 0.6);
      const cabin = new THREE.Mesh(cabinGeo, glassMaterial);
      cabin.position.set(0, 1.1, -0.2);
      bodyGroup.add(cabin);

      // Roof rack
      const rackGeo = new THREE.BoxGeometry(carWidth * 0.8, 0.08, carLength * 0.5);
      const rack = new THREE.Mesh(rackGeo, blackTrimMaterial);
      rack.position.set(0, 1.45, -0.2);
      bodyGroup.add(rack);
      break;
    }

    case 'van': {
      carLength = 4.4;
      carWidth = 1.95;
      wheelRadius = 0.36;

      // Retro camper van body
      const vanGeo = new THREE.BoxGeometry(carWidth, 0.95, carLength);
      mainBodyMesh = new THREE.Mesh(vanGeo, bodyMaterial);
      mainBodyMesh.position.set(0, 0.65, 0);
      bodyGroup.add(mainBodyMesh);

      // Van windows wrap
      const winGeo = new THREE.BoxGeometry(carWidth * 0.92, 0.42, carLength * 0.75);
      const win = new THREE.Mesh(winGeo, glassMaterial);
      win.position.set(0, 0.95, -0.1);
      bodyGroup.add(win);

      // Surfboard on roof!
      const surfGeo = new THREE.BoxGeometry(0.55, 0.08, 2.2);
      const surfMat = new THREE.MeshStandardMaterial({ color: 0xf43f5e, roughness: 0.3 });
      const surf = new THREE.Mesh(surfGeo, surfMat);
      surf.position.set(0.2, 1.25, -0.1);
      surf.rotation.y = 0.05;
      bodyGroup.add(surf);
      break;
    }

    default: {
      // Default: Sport Coupe
      const sportGeo = new THREE.BoxGeometry(carWidth, 0.5, carLength);
      mainBodyMesh = new THREE.Mesh(sportGeo, bodyMaterial);
      mainBodyMesh.position.set(0, 0.35, 0);
      bodyGroup.add(mainBodyMesh);

      const cabinGeo = new THREE.BoxGeometry(carWidth * 0.82, 0.44, carLength * 0.5);
      const cabin = new THREE.Mesh(cabinGeo, glassMaterial);
      cabin.position.set(0, 0.74, -0.2);
      bodyGroup.add(cabin);

      // Sport rear wing
      const wingGeo = new THREE.BoxGeometry(carWidth * 0.88, 0.06, 0.35);
      const wing = new THREE.Mesh(wingGeo, blackTrimMaterial);
      wing.position.set(0, 0.82, -carLength * 0.5 + 0.15);
      bodyGroup.add(wing);
      break;
    }
  }

  // Headlights (at +Z)
  const headGeo = new THREE.BoxGeometry(0.3, 0.12, 0.05);
  const headL = new THREE.Mesh(headGeo, headlightMaterial);
  headL.position.set(-carWidth * 0.36, 0.4, carLength * 0.5 + 0.01);
  const headR = headL.clone();
  headR.position.x = carWidth * 0.36;
  bodyGroup.add(headL, headR);
  headlights.push(headL, headR);

  // Taillights (at -Z)
  const tailGeo = new THREE.BoxGeometry(0.32, 0.12, 0.05);
  const tailL = new THREE.Mesh(tailGeo, taillightMaterial);
  tailL.position.set(-carWidth * 0.36, 0.4, -carLength * 0.5 - 0.01);
  const tailR = tailL.clone();
  tailR.position.x = carWidth * 0.36;
  bodyGroup.add(tailL, tailR);
  taillights.push(tailL, tailR);

  // Exhaust tips (at -Z)
  exhaustPoints.push(
    new THREE.Vector3(-carWidth * 0.28, 0.22, -carLength * 0.5 - 0.1),
    new THREE.Vector3(carWidth * 0.28, 0.22, -carLength * 0.5 - 0.1)
  );

  const exhPipeGeo = new THREE.CylinderGeometry(0.08, 0.08, 0.2, 8);
  const exhL = new THREE.Mesh(exhPipeGeo, chromeMaterial);
  exhL.rotation.x = Math.PI / 2;
  exhL.position.copy(exhaustPoints[0]);
  const exhR = exhL.clone();
  exhR.position.copy(exhaustPoints[1]);
  bodyGroup.add(exhL, exhR);

  // Build 4 Wheels
  const tireMat = new THREE.MeshStandardMaterial({ color: 0x18181b, roughness: 0.9, flatShading: true });
  const rimMat = new THREE.MeshStandardMaterial({ color: 0xd4d4d8, roughness: 0.2, metalness: 0.9 });

  const createWheel = (isFront: boolean, isLeft: boolean) => {
    const wheelPivot = new THREE.Group();
    const spinGroup = new THREE.Group();
    wheelPivot.add(spinGroup);

    // Tire cylinder
    const tireGeo = new THREE.CylinderGeometry(wheelRadius, wheelRadius, wheelWidth, 12);
    const tire = new THREE.Mesh(tireGeo, tireMat);
    tire.rotation.z = Math.PI / 2;
    spinGroup.add(tire);

    // Rim hubcap
    const rimGeo = new THREE.CylinderGeometry(wheelRadius * 0.62, wheelRadius * 0.62, wheelWidth + 0.01, 8);
    const rim = new THREE.Mesh(rimGeo, rimMat);
    rim.rotation.z = Math.PI / 2;
    spinGroup.add(rim);

    // Wheel position
    const wx = (carWidth * 0.52) * (isLeft ? -1 : 1);
    const wz = (carLength * 0.32) * (isFront ? 1 : -1);
    wheelPivot.position.set(wx, wheelRadius, wz);

    bodyGroup.add(wheelPivot);
    return wheelPivot;
  };

  frontWheels.push(createWheel(true, true), createWheel(true, false));
  rearWheels.push(createWheel(false, true), createWheel(false, false));

  // Neon Underglow (if enabled)
  let underglowMesh: THREE.Mesh | undefined;
  if (customization?.neonColor && customization.neonColor !== 'none') {
    const neonGeo = new THREE.PlaneGeometry(carWidth * 0.85, carLength * 0.8);
    neonGeo.rotateX(-Math.PI / 2);
    const neonMat = new THREE.MeshBasicMaterial({
      color: new THREE.Color(customization.neonColor),
      transparent: true,
      opacity: 0.6,
      side: THREE.DoubleSide,
    });
    underglowMesh = new THREE.Mesh(neonGeo, neonMat);
    underglowMesh.position.y = 0.04;
    bodyGroup.add(underglowMesh);
  }

  return {
    root,
    bodyGroup,
    bodyMesh: mainBodyMesh,
    bodyMaterial,
    frontWheels,
    rearWheels,
    exhaustPoints,
    headlights,
    taillights,
    brakeLightMaterial,
    underglowMesh,
    steerAngle: 0,
    wheelSpin: 0,
  };
}
