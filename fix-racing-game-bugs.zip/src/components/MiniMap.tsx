import React, { useEffect, useRef } from 'react';
import { TrackData } from '../game/proceduralTrack';

interface MiniMapProps {
  trackData: TrackData | null;
  playerPos: { x: number; z: number } | null;
  playerHeading: number;
  aiPositions: { x: number; z: number }[];
  isEndless: boolean;
}

export const MiniMap: React.FC<MiniMapProps> = ({
  trackData,
  playerPos,
  playerHeading,
  aiPositions,
  isEndless,
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const size = canvas.width;
    ctx.clearRect(0, 0, size, size);

    if (isEndless) {
      // Endless highway vertical radar
      ctx.fillStyle = 'rgba(15, 23, 42, 0.75)';
      ctx.fillRect(0, 0, size, size);

      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 1.5;
      ctx.strokeRect(1, 1, size - 2, size - 2);

      // Road lanes
      const mid = size / 2;
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.3)';
      ctx.setLineDash([4, 4]);
      ctx.beginPath();
      ctx.moveTo(mid, 0);
      ctx.lineTo(mid, size);
      ctx.stroke();
      ctx.setLineDash([]);

      // Draw AI traffic relative to player (player at bottom 75%)
      const playerZ = playerPos ? playerPos.z : 0;
      const radarRange = 180; // meters ahead

      aiPositions.forEach((aiPos) => {
        const relZ = aiPos.z - playerZ; // negative is ahead
        if (relZ < 10 && relZ > -radarRange) {
          const y = (size * 0.75) + (relZ / radarRange) * (size * 0.7);
          const x = mid + (aiPos.x / 14) * (size * 0.35);
          ctx.fillStyle = '#ef4444';
          ctx.beginPath();
          ctx.arc(x, y, 3.5, 0, Math.PI * 2);
          ctx.fill();
        }
      });

      // Player marker
      ctx.fillStyle = '#22c55e';
      ctx.beginPath();
      ctx.arc(mid, size * 0.75, 5, 0, Math.PI * 2);
      ctx.fill();
      return;
    }

    if (!trackData || !trackData.samplePoints || trackData.samplePoints.length === 0) return;

    // Calculate bounding box of the track
    const samples = trackData.samplePoints;
    let minX = Infinity, maxX = -Infinity, minZ = Infinity, maxZ = -Infinity;
    for (const p of samples) {
      if (p.pos.x < minX) minX = p.pos.x;
      if (p.pos.x > maxX) maxX = p.pos.x;
      if (p.pos.z < minZ) minZ = p.pos.z;
      if (p.pos.z > maxZ) maxZ = p.pos.z;
    }

    const pad = 12;
    const w = maxX - minX || 1;
    const h = maxZ - minZ || 1;
    const scale = (size - pad * 2) / Math.max(w, h);

    const toMapX = (x: number) => pad + (x - minX) * scale;
    const toMapY = (z: number) => pad + (z - minZ) * scale;

    // Draw Track Outline
    ctx.beginPath();
    ctx.lineWidth = 4;
    ctx.strokeStyle = 'rgba(148, 163, 184, 0.4)';
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    for (let i = 0; i < samples.length; i++) {
      const mx = toMapX(samples[i].pos.x);
      const my = toMapY(samples[i].pos.z);
      if (i === 0) ctx.moveTo(mx, my);
      else ctx.lineTo(mx, my);
    }
    ctx.closePath();
    ctx.stroke();

    // Start/Finish indicator
    const startX = toMapX(samples[0].pos.x);
    const startY = toMapY(samples[0].pos.z);
    ctx.fillStyle = '#facc15';
    ctx.beginPath();
    ctx.arc(startX, startY, 4, 0, Math.PI * 2);
    ctx.fill();

    // Draw AI racers
    aiPositions.forEach((pos) => {
      ctx.fillStyle = '#ef4444';
      ctx.beginPath();
      ctx.arc(toMapX(pos.x), toMapY(pos.z), 3.5, 0, Math.PI * 2);
      ctx.fill();
    });

    // Draw Player marker with heading arrow
    if (playerPos) {
      const px = toMapX(playerPos.x);
      const py = toMapY(playerPos.z);

      ctx.save();
      ctx.translate(px, py);
      ctx.rotate(playerHeading);

      ctx.fillStyle = '#38bdf8';
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 1.5;

      ctx.beginPath();
      ctx.moveTo(0, 6);
      ctx.lineTo(-4, -5);
      ctx.lineTo(0, -3);
      ctx.lineTo(4, -5);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();

      ctx.restore();
    }
  }, [trackData, playerPos, playerHeading, aiPositions, isEndless]);

  return (
    <div className="relative w-24 h-24 md:w-32 md:h-32 bg-slate-900/70 backdrop-blur-md rounded-2xl border border-white/20 p-1 shadow-lg shadow-black/40 overflow-hidden pointer-events-none">
      <canvas
        ref={canvasRef}
        width={128}
        height={128}
        className="w-full h-full block rounded-xl"
      />
      <div className="absolute top-1 left-2 text-[9px] font-black uppercase tracking-wider text-cyan-400">
        GPS
      </div>
    </div>
  );
};
