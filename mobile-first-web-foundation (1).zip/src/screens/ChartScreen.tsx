import { useEffect, useState } from 'react';
import { CandlestickChart } from '../components/chart/CandlestickChart';
import { IconShare, IconStar } from '../components/icons';
import { Button } from '../components/ui/primitives';
import { useApp } from '../context/AppContext';
import { marketApi } from '../services/api';
import type { Candle, Timeframe } from '../types';
import { formatPct, formatPrice } from '../utils/format';
import { cn } from '../utils/cn';

const TFS: Timeframe[] = ['1m', '15m', '1h', '1j', '1s', '1M'];

export function ChartScreen() {
  const {
    selectedAsset,
    timeframe,
    setTimeframe,
    selectionMode,
    setSelectionMode,
    zone,
    navigate,
    back,
    toggleFavorite,
    favorites,
    setAnalyzing,
  } = useApp();
  const [candles, setCandles] = useState<Candle[]>([]);

  useEffect(() => {
    if (!selectedAsset) return;
    marketApi.getCandles(selectedAsset.id, timeframe).then(setCandles);
  }, [selectedAsset, timeframe]);

  if (!selectedAsset) {
    return (
      <div className="flex flex-1 items-center justify-center text-slate-400">
        <button onClick={() => navigate('assets')}>Choisir un actif</button>
      </div>
    );
  }

  const up = selectedAsset.change24h >= 0;
  const fav = favorites.includes(selectedAsset.id);

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <div className="flex items-start justify-between px-3 pt-1">
        <button onClick={back} className="mt-1 flex h-8 w-8 items-center justify-center text-white/80" aria-label="Retour">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M15 6l-6 6 6 6" />
          </svg>
        </button>
        <div className="min-w-0 flex-1 px-1">
          <div className="flex items-center gap-1.5">
            <h2 className="text-[17px] font-semibold text-white">{selectedAsset.pairLabel}</h2>
            <button
              onClick={() => toggleFavorite(selectedAsset.id)}
              className={cn(fav ? 'text-amber-400' : 'text-slate-500')}
              aria-label="Favori"
            >
              <IconStar size={15} filled={fav} />
            </button>
          </div>
          <p className="text-[12px] text-slate-400">{selectedAsset.exchange}</p>
        </div>
        <button onClick={() => navigate('export')} className="mt-1 p-1.5 text-slate-400" aria-label="Partager">
          <IconShare size={18} />
        </button>
      </div>

      <div className="px-5">
        <div className="mt-1 flex items-end gap-2">
          <span className="text-[28px] font-bold leading-none tracking-tight text-white">
            {formatPrice(selectedAsset.price, selectedAsset.decimals, selectedAsset.quoteCurrency)}
          </span>
          <span className={cn('mb-0.5 text-[13px] font-semibold', up ? 'text-emerald-400' : 'text-rose-400')}>
            {formatPct(selectedAsset.change24h)} <span className="text-slate-500">(24h)</span>
          </span>
        </div>
      </div>

      <div className="mt-3 flex gap-1 px-4">
        {TFS.map((t) => (
          <button
            key={t}
            onClick={() => setTimeframe(t)}
            className={cn(
              'flex-1 rounded-md py-1 text-[12px] font-medium',
              timeframe === t ? 'bg-[#1b3354] text-cyan-300' : 'text-slate-400',
            )}
          >
            {t}
          </button>
        ))}
      </div>

      <div className="mt-1 min-h-0 flex-1 px-1">
        <CandlestickChart candles={candles} height={280} showVolume zone={zone} />
      </div>

      <div className="px-5 pb-3 pt-1">
        <p className="mb-2 text-center text-[12px] text-slate-400">Mode sélection</p>
        <div className="mb-3 flex justify-center gap-8">
          {(['auto', 'manual'] as const).map((m) => (
            <button
              key={m}
              onClick={() => setSelectionMode(m)}
              className={cn(
                'rounded-full px-7 py-2 text-[12px] font-bold tracking-wider',
                selectionMode === m ? 'bg-[#3b82f6] text-white' : 'text-slate-400',
              )}
            >
              {m === 'auto' ? 'AUTO' : 'MANUEL'}
            </button>
          ))}
        </div>
        <Button
          onClick={() => {
            setAnalyzing(true);
            navigate('pattern');
          }}
        >
          Lancer l’analyse
        </Button>
      </div>
    </div>
  );
}
