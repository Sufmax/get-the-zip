import type { ButtonHTMLAttributes, ReactNode } from 'react';
import { cn } from '../../utils/cn';
import { IconChevronLeft } from '../icons';

export function StatusBar() {
  return (
    <div className="relative z-30 flex h-[52px] shrink-0 items-end px-7 pb-1.5 text-[13px] font-semibold text-white">
      <span className="w-16">9:41</span>
      <div className="absolute left-1/2 top-[10px] h-[26px] w-[92px] -translate-x-1/2 rounded-full bg-black" />
      <div className="ml-auto flex items-center gap-1.5">
        <svg width="17" height="12" viewBox="0 0 18 14" fill="currentColor">
          <rect x="0" y="9" width="3" height="5" rx="0.6" />
          <rect x="5" y="6.5" width="3" height="7.5" rx="0.6" />
          <rect x="10" y="3.5" width="3" height="10.5" rx="0.6" />
          <rect x="15" y="0.5" width="3" height="13.5" rx="0.6" opacity="0.4" />
        </svg>
        <svg width="16" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2">
          <path d="M5 12.5a9 9 0 0114 0" />
          <path d="M8.2 15.2a5.2 5.2 0 017.6 0" />
          <circle cx="12" cy="18" r="1.2" fill="currentColor" stroke="none" />
        </svg>
        <svg width="25" height="13" viewBox="0 0 28 14" fill="currentColor">
          <rect x="0.6" y="1.2" width="24" height="11.6" rx="2.4" fill="none" stroke="currentColor" strokeWidth="1.6" />
          <rect x="2.4" y="3.2" width="18.2" height="7.6" rx="1.2" />
          <rect x="25.2" y="4.4" width="2.2" height="5.2" rx="0.8" />
        </svg>
      </div>
    </div>
  );
}

export function HomeIndicator() {
  return (
    <div className="pointer-events-none flex h-5 shrink-0 items-start justify-center">
      <div className="h-[5px] w-[128px] rounded-full bg-white/70" />
    </div>
  );
}

export function ScreenHeader({
  title,
  onBack,
  right,
  center = true,
  light = false,
}: {
  title: string;
  onBack?: () => void;
  right?: ReactNode;
  center?: boolean;
  light?: boolean;
}) {
  return (
    <div className="relative flex h-12 shrink-0 items-center px-3">
      {onBack ? (
        <button
          onClick={onBack}
          className="absolute left-2 z-10 flex h-9 w-9 items-center justify-center rounded-full text-white/90 active:bg-white/10"
          aria-label="Retour"
        >
          <IconChevronLeft size={22} />
        </button>
      ) : (
        <span className="w-9" />
      )}
      <h1
        className={cn(
          'flex-1 truncate px-8 text-[16px] font-semibold tracking-wide',
          center ? 'text-center' : 'text-left',
          light ? 'text-white/90' : 'text-white',
        )}
      >
        {title}
      </h1>
      <div className="absolute right-3 flex items-center">{right}</div>
    </div>
  );
}

export function Button({
  variant = 'cyan',
  className,
  children,
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: 'cyan' | 'blue' | 'ghost' | 'outline' | 'danger';
}) {
  return (
    <button
      className={cn(
        'inline-flex h-12 w-full items-center justify-center rounded-full px-5 text-[15px] font-semibold transition active:scale-[0.98] disabled:opacity-50',
        variant === 'cyan' && 'bg-[#2ee6c8] text-[#04241f] shadow-[0_8px_24px_rgba(46,230,200,0.25)]',
        variant === 'blue' && 'bg-[#3b82f6] text-white shadow-[0_8px_24px_rgba(59,130,246,0.28)]',
        variant === 'ghost' && 'bg-transparent text-white/80',
        variant === 'outline' && 'border border-white/15 bg-white/5 text-white/85',
        variant === 'danger' && 'bg-transparent text-rose-400',
        className,
      )}
      {...props}
    >
      {children}
    </button>
  );
}

export function Card({ className, children }: { className?: string; children: ReactNode }) {
  return (
    <div className={cn('rounded-2xl border border-white/6 bg-[#132036]/90', className)}>{children}</div>
  );
}

export function Segmented({
  options,
  value,
  onChange,
}: {
  options: { id: string; label: string }[];
  value: string;
  onChange: (id: string) => void;
}) {
  return (
    <div className="flex rounded-full bg-[#0c1a2e] p-1">
      {options.map((o) => (
        <button
          key={o.id}
          onClick={() => onChange(o.id)}
          className={cn(
            'flex-1 rounded-full py-2 text-[13px] font-semibold transition',
            value === o.id ? 'bg-[#3b82f6] text-white shadow' : 'text-slate-400',
          )}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}

export function Toggle({ checked, onChange }: { checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      role="switch"
      aria-checked={checked}
      onClick={() => onChange(!checked)}
      className={cn(
        'relative h-7 w-12 rounded-full transition',
        checked ? 'bg-[#2ee6c8]' : 'bg-slate-600',
      )}
    >
      <span
        className={cn(
          'absolute top-0.5 h-6 w-6 rounded-full bg-white shadow transition',
          checked ? 'left-[22px]' : 'left-0.5',
        )}
      />
    </button>
  );
}

export function Stepper({
  value,
  onChange,
  min = 1,
  max = 5000,
  suffix,
}: {
  value: number;
  onChange: (n: number) => void;
  min?: number;
  max?: number;
  suffix?: string;
}) {
  return (
    <div className="flex items-center gap-3">
      <button
        className="flex h-8 w-8 items-center justify-center rounded-lg bg-white/8 text-lg text-white/80"
        onClick={() => onChange(Math.max(min, value - 10))}
      >
        −
      </button>
      <div className="min-w-[72px] text-center text-[15px] font-semibold text-white">
        {value}
        {suffix ? <span className="ml-1 text-xs font-normal text-slate-400">{suffix}</span> : null}
      </div>
      <button
        className="flex h-8 w-8 items-center justify-center rounded-lg bg-white/8 text-lg text-white/80"
        onClick={() => onChange(Math.min(max, value + 10))}
      >
        +
      </button>
    </div>
  );
}

export function Radio({ checked }: { checked: boolean }) {
  return (
    <span
      className={cn(
        'flex h-[22px] w-[22px] items-center justify-center rounded-full border-2',
        checked ? 'border-[#2ee6c8]' : 'border-slate-500',
      )}
    >
      {checked && <span className="h-3 w-3 rounded-full bg-[#2ee6c8]" />}
    </span>
  );
}

export function Check({ checked, tone = 'cyan' }: { checked: boolean; tone?: 'cyan' | 'green' }) {
  return (
    <span
      className={cn(
        'flex h-[22px] w-[22px] items-center justify-center rounded-full',
        checked ? (tone === 'green' ? 'bg-emerald-500' : 'bg-[#2ee6c8]') : 'border border-slate-500',
      )}
    >
      {checked && (
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke={tone === 'green' ? 'white' : '#04241f'} strokeWidth="3">
          <path d="M5 12.5l4.2 4.2L19 7.5" />
        </svg>
      )}
    </span>
  );
}

export function Chip({
  active,
  children,
  onClick,
}: {
  active?: boolean;
  children: ReactNode;
  onClick?: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={cn(
        'shrink-0 rounded-full px-3.5 py-1.5 text-[13px] font-medium transition',
        active ? 'bg-[#2ee6c8] text-[#04241f]' : 'bg-[#15263d] text-slate-300',
      )}
    >
      {children}
    </button>
  );
}

export function DirectionBadge({ dir }: { dir: 'bullish' | 'bearish' | 'neutral' }) {
  const map = {
    bullish: { label: 'Haussière', cls: 'bg-emerald-500/15 text-emerald-400' },
    bearish: { label: 'Baissière', cls: 'bg-rose-500/15 text-rose-400' },
    neutral: { label: 'Neutre', cls: 'bg-slate-500/20 text-slate-300' },
  }[dir];
  return <span className={cn('rounded-full px-2 py-0.5 text-[11px] font-medium', map.cls)}>{map.label}</span>;
}

export function ScoreColor(score: number) {
  if (score >= 9.2) return 'text-emerald-400';
  if (score >= 8.9) return 'text-cyan-400';
  if (score >= 8.5) return 'text-amber-400';
  return 'text-orange-400';
}

export function BottomBar({ children }: { children: ReactNode }) {
  return <div className="mt-auto shrink-0 px-5 pb-3 pt-2">{children}</div>;
}
