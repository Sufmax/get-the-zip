export type GameMode = 'career' | 'quick_race' | 'time_trial' | 'drift_mode' | 'endless_traffic';

export type TrackId = 'cyber_highway' | 'desert_canyon' | 'alpine_summit' | 'sunset_riviera';

export interface CarStats {
  topSpeed: number; // in km/h (e.g. 240)
  acceleration: number; // 0-100 rating 1-10
  handling: number; // turn rate & grip 1-10
  driftEase: number; // how easily & smoothly it enters drift
  nitroBoost: number; // multiplier / capacity 1-10
  weight: number; // in kg (e.g. 1100)
}

export interface CarUpgrades {
  engine: number; // level 1-5
  turbo: number; // level 1-5
  handling: number; // level 1-5
  nitro: number; // level 1-5
  brakes: number; // level 1-5
}

export type CarCategory = 'sport' | 'muscle' | 'hypercar' | 'tuner' | 'offroad' | 'formula' | 'electric' | 'prototype';

export interface CarDefinition {
  id: string;
  name: string;
  subtitle: string;
  category: CarCategory;
  price: number;
  unlockedByDefault: boolean;
  baseColor: string;
  availableColors: string[];
  specs: CarStats;
  descriptionFr: string;
  descriptionEn: string;
  soundType: 'v8' | 'turbo' | 'hyper' | 'electric' | 'formula';
}

export interface TrackDefinition {
  id: TrackId;
  nameFr: string;
  nameEn: string;
  subtitleFr: string;
  subtitleEn: string;
  lengthMeters: number;
  defaultLaps: number;
  difficulty: 'Facile' | 'Moyen' | 'Difficile' | 'Expert';
  theme: 'cyber' | 'desert' | 'snow' | 'sunset';
  skyColor: string;
  ambientLight: string;
  sunColor: string;
  fogColor: string;
  fogDensity: number;
  groundColor: string;
  roadColor: string;
  curbColor1: string;
  curbColor2: string;
  recordTime?: number;
}

export interface PlayerCarCustomization {
  color: string;
  spoilerIndex: number;
  underglowColor: string | null;
  upgrades: CarUpgrades;
}

export interface PlayerProgress {
  money: number;
  unlockedCars: string[];
  selectedCarId: string;
  carCustomizations: Record<string, PlayerCarCustomization>;
  bestLaps: Record<string, number>;
  careerCupIndex: number;
  endlessHighScore: number;
  driftHighScore: number;
  totalRaces: number;
  totalWins: number;
  achievementsUnlocked: string[];
}

export interface ControlSettings {
  scheme: 'buttons' | 'wheel' | 'slider';
  autoAccelerate: boolean;
  steeringSensitivity: number;
  vibrate: boolean;
  cameraFovBoost: boolean;
  speedLines: boolean;
  quality: 'low' | 'medium' | 'high';
  audioVolume: number;
  engineVolume: number;
  musicVolume: number;
  language: 'fr' | 'en';
}

export interface Achievement {
  id: string;
  titleFr: string;
  titleEn: string;
  descFr: string;
  descEn: string;
  reward: number;
  icon: string;
}

export interface RaceState {
  mode: GameMode;
  trackId: TrackId;
  lap: number;
  totalLaps: number;
  position: number;
  totalRacers: number;
  currentLapTime: number;
  lastLapTime: number;
  bestLapTime: number;
  raceTime: number;
  speedKmh: number;
  rpm: number;
  gear: number;
  driftScore: number;
  driftMultiplier: number;
  isDrifting: boolean;
  nitroPercent: number;
  isNitroActive: boolean;
  nearMissCount: number;
  slipstreamActive: boolean;
  finished: boolean;
  countdown: number; // >0 countdown, 0 racing
  distanceTraveled: number;
  playerCoord?: { x: number; z: number };
  playerHeading?: number;
  aiCoords?: { x: number; z: number }[];
}
