import { IconCheck } from '../components/icons';
import { Button, ScreenHeader } from '../components/ui/primitives';
import { useApp } from '../context/AppContext';
import { DEMO_OUTCOME, DEMO_SCENARIOS } from '../data/mockData';
import { cn } from '../utils/cn';
import { formatNumber } from '../utils/format';

const DIR: Record<string, { label: string; cls: string }> = {
  bullish: { label: 'Haussière', cls: 'text-emerald-400' },
  bearish: { label: 'Baissière', cls: 'text-rose-400' },
  neutral: { label: 'Neutre', cls: 'text-slate-300' },
};

export function ScenariosScreen() {
  const { back, navigate } = useApp();
  const outcome = DEMO_OUTCOME;
  const scenarios = DEMO_SCENARIOS;

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <ScreenHeader title="Prolongements historiques" onBack={back} />

      <div className="px-5">
        <p className="text-[13px] text-slate-400">Après cette correspondance :</p>
        <div className="mt-3 flex items-center justify-around">
          <div className="flex items-center gap-2">
            <span className="flex h-7 w-7 items-center justify-center rounded-full bg-emerald-500/20 text-emerald-400">
              <IconCheck size={14} />
            </span>
            <div>
              <span className="text-[22px] font-bold text-emerald-400">{outcome.bullish}%</span>
              <span className="ml-1 text-[13px] text-slate-400">hausse</span>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span className="flex h-7 w-7 items-center justify-center rounded-full bg-rose-500/20 text-[11px] font-bold text-rose-400">
              ●
            </span>
            <div>
              <span className="text-[22px] font-bold text-rose-400">{outcome.bearish}%</span>
              <span className="ml-1 text-[13px] text-slate-400">baisse</span>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-5 min-h-0 flex-1 overflow-y-auto px-4">
        <h3 className="mb-2 px-1 text-[14px] font-semibold text-white">Scénarios probabilistes</h3>
        <div className="space-y-2.5">
          {scenarios.map((s) => (
            <div key={s.id} className="rounded-2xl border border-white/5 bg-[#101c31] px-4 py-3">
              <div className="text-[12px] text-slate-400">
                {s.label} <span className="text-slate-500">({s.horizon})</span>
              </div>
              <div className="mt-1 flex items-center justify-between">
                <span className="flex items-center gap-2 text-[14px] font-semibold">
                  <span
                    className={cn(
                      'flex h-5 w-5 items-center justify-center rounded-full',
                      s.direction === 'bullish' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-slate-500/20 text-slate-300',
                    )}
                  >
                    <IconCheck size={12} />
                  </span>
                  <span className={DIR[s.direction].cls}>{DIR[s.direction].label}</span>
                </span>
                <span className="text-[13px] text-slate-300">
                  {s.probability}% <span className="text-slate-500">±{formatNumber(s.deviation, 1)}%</span>
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="px-5 pb-3 pt-3">
        <Button variant="outline" onClick={() => navigate('conditions')}>
          Voir les conditions de modification
        </Button>
      </div>
    </div>
  );
}
