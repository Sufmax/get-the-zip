import { useCallback, useMemo, useRef, useState } from "react";
import { HUD, ResultsOverlay } from "./components/HUD";
import { Garage, MainMenu, Splash, TrackSelect } from "./components/Menus";
import { RaceScene } from "./components/RaceScene";
import { TouchControls } from "./components/TouchControls";
import { audio } from "./game/audio";
import type { HudSnapshot, InputState, RaceResults, Screen, Settings } from "./game/types";

const emptyHud: HudSnapshot = {
  speed: 0,
  maxSpeed: 280,
  nitro: 70,
  boosting: false,
  rpm: 0.2,
  gear: 1,
  position: 5,
  totalCars: 8,
  lap: 1,
  totalLaps: 3,
  lapTime: 0,
  bestLap: 0,
  raceTime: 0,
  drift: 0,
  phase: "countdown",
  countdown: 3,
  finished: false,
  minimap: [],
};

export default function App() {
  const [screen, setScreen] = useState<Screen>("splash");
  const [carId, setCarId] = useState("eclair");
  const [trackId, setTrackId] = useState("azure");
  const [settings, setSettings] = useState<Settings>({
    audio: true,
    autoAccel: true,
    vibration: true,
    quality: "high",
  });
  const [hud, setHud] = useState<HudSnapshot>(emptyHud);
  const [paused, setPaused] = useState(false);
  const [results, setResults] = useState<RaceResults | null>(null);
  const [raceKey, setRaceKey] = useState(0);
  const inputRef = useRef<InputState>({ steer: 0, throttle: 1, brake: 0, nitro: false });

  const startAudio = useCallback(async () => {
    await audio.init();
    audio.setEnabled(settings.audio);
  }, [settings.audio]);

  const goRace = useCallback(() => {
    inputRef.current = { steer: 0, throttle: settings.autoAccel ? 1 : 0, brake: 0, nitro: false };
    setResults(null);
    setPaused(false);
    setHud(emptyHud);
    setRaceKey((k) => k + 1);
    setScreen("race");
    audio.init();
    audio.setEnabled(settings.audio);
  }, [settings.audio, settings.autoAccel]);

  const onFinish = useCallback((r: RaceResults) => {
    setResults(r);
  }, []);

  const setSettingsAndAudio = (s: Settings) => {
    setSettings(s);
    audio.setEnabled(s.audio);
  };

  const raceLive = screen === "race";

  const pauseOverlay = useMemo(() => {
    if (!paused || screen !== "race") return null;
    return (
      <div className="pause">
        <h2>PAUSE</h2>
        <button className="btn primary" onClick={() => setPaused(false)}>
          REPRENDRE
        </button>
        <button className="btn" onClick={() => setScreen("menu")}>
          ABANDONNER
        </button>
      </div>
    );
  }, [paused, screen]);

  return (
    <div className="game-root">
      {screen === "splash" && (
        <Splash
          onStart={() => {
            startAudio();
            setScreen("menu");
          }}
        />
      )}
      {screen === "menu" && (
        <MainMenu
          onPlay={goRace}
          onGarage={() => setScreen("garage")}
          onTracks={() => setScreen("tracks")}
          settings={settings}
          setSettings={setSettingsAndAudio}
        />
      )}
      {screen === "garage" && (
        <Garage carId={carId} onSelect={setCarId} onBack={() => setScreen("menu")} />
      )}
      {screen === "tracks" && (
        <TrackSelect
          trackId={trackId}
          onSelect={setTrackId}
          onBack={() => setScreen("menu")}
          onRace={goRace}
        />
      )}
      {raceLive && (
        <>
          <RaceScene
            key={raceKey}
            carId={carId}
            trackId={trackId}
            settings={settings}
            paused={paused}
            onHud={setHud}
            onFinish={onFinish}
            inputRef={inputRef}
          />
          <HUD hud={hud} trackId={trackId} onPause={() => setPaused(true)} />
          <TouchControls inputRef={inputRef} autoAccel={settings.autoAccel} />
          {pauseOverlay}
          {results && (
            <ResultsOverlay
              results={results}
              onReplay={goRace}
              onMenu={() => {
                setResults(null);
                setScreen("menu");
              }}
            />
          )}
        </>
      )}
    </div>
  );
}
