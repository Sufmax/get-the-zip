import React, { useState, useEffect } from 'react';
import { TRACKS_CATALOG } from '../game/tracksData';
import { CARS_CATALOG } from '../game/carsData';
import { X, Trophy, Flag, Timer, Loader2 } from 'lucide-react';

interface LeaderboardModalProps {
  onClose: () => void;
}

interface Entry {
  id: number;
  playerName: string;
  trackId: string;
  carId: string;
  gameMode: string;
  timeSeconds: number | null;
  driftScore: number;
  distance: number;
  createdAt: string;
}

export const LeaderboardModal: React.FC<LeaderboardModalProps> = ({ onClose }) => {
  const [selectedTrack, setSelectedTrack] = useState('azure');
  const [selectedMode, setSelectedMode] = useState<'circuit' | 'endless_traffic'>('circuit');
  const [entries, setEntries] = useState<Entry[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;
    setLoading(true);

    const actualTrack = selectedMode === 'endless_traffic' ? 'endless_highway' : selectedTrack;
    fetch(`/api/leaderboard?trackId=${actualTrack}&gameMode=${selectedMode}`)
      .then((res) => res.json())
      .then((data) => {
        if (active && data.success) {
          setEntries(data.entries || []);
        }
      })
      .catch((err) => {
        console.error('Failed to load leaderboard:', err);
      })
      .finally(() => {
        if (active) setLoading(false);
      });

    return () => {
      active = false;
    };
  }, [selectedTrack, selectedMode]);

  const formatTime = (seconds: number | null) => {
    if (!seconds || seconds <= 0) return '--:--.--';
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    const ms = Math.floor((seconds % 1) * 100);
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}.${ms.toString().padStart(2, '0')}`;
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-xl flex flex-col p-4 md:p-8 overflow-y-auto select-none">
      {/* Header */}
      <div className="flex justify-between items-center w-full max-w-4xl mx-auto pb-4 border-b border-white/10">
        <div>
          <h2 className="text-xl md:text-3xl font-black italic tracking-tight text-white uppercase flex items-center gap-2">
            <span>CLASSEMENTS</span>
            <span className="text-cyan-400">MONDIAUX</span>
          </h2>
          <p className="text-xs text-slate-400">Meilleurs chronos et records enregistrés en base de données</p>
        </div>

        <button
          onClick={onClose}
          className="w-10 h-10 rounded-2xl bg-slate-800 hover:bg-slate-700 text-white flex items-center justify-center border border-white/10 active:scale-95 transition-all"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Mode & Track Filters */}
      <div className="w-full max-w-4xl mx-auto flex flex-col md:flex-row justify-between gap-3 pt-6 pb-4">
        {/* Mode Selector */}
        <div className="flex gap-2">
          <button
            onClick={() => setSelectedMode('circuit')}
            className={`px-4 py-2 rounded-2xl text-xs font-black italic uppercase tracking-wider border transition-all ${
              selectedMode === 'circuit'
                ? 'bg-cyan-500 border-cyan-400 text-white shadow-lg shadow-cyan-500/30'
                : 'bg-slate-900 border-white/10 text-slate-400 hover:text-white'
            }`}
          >
            Course Circuit
          </button>
          <button
            onClick={() => setSelectedMode('endless_traffic')}
            className={`px-4 py-2 rounded-2xl text-xs font-black italic uppercase tracking-wider border transition-all ${
              selectedMode === 'endless_traffic'
                ? 'bg-amber-500 border-amber-400 text-white shadow-lg shadow-amber-500/30'
                : 'bg-slate-900 border-white/10 text-slate-400 hover:text-white'
            }`}
          >
            Autoroute Infinie
          </button>
        </div>

        {/* Track Pills (if circuit mode) */}
        {selectedMode === 'circuit' && (
          <div className="flex flex-wrap gap-1.5">
            {TRACKS_CATALOG.filter((t) => t.id !== 'endless_highway').map((track) => {
              const isSelected = selectedTrack === track.id;
              return (
                <button
                  key={track.id}
                  onClick={() => setSelectedTrack(track.id)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition-all ${
                    isSelected
                      ? 'bg-slate-800 border-cyan-400 text-cyan-300'
                      : 'bg-slate-950/60 border-white/10 text-slate-400 hover:text-white'
                  }`}
                >
                  {track.nameFr.replace('Circuit ', '')}
                </button>
              );
            })}
          </div>
        )}
      </div>

      {/* Table */}
      <div className="w-full max-w-4xl mx-auto flex-1 bg-slate-900/80 rounded-3xl border border-white/10 p-4 md:p-6 shadow-2xl overflow-hidden flex flex-col">
        {loading ? (
          <div className="flex flex-col items-center justify-center my-auto py-16 text-slate-400">
            <Loader2 className="w-8 h-8 animate-spin text-cyan-400 mb-2" />
            <span className="text-xs font-bold">Chargement des records...</span>
          </div>
        ) : entries.length === 0 ? (
          <div className="flex flex-col items-center justify-center my-auto py-16 text-slate-500">
            <Flag className="w-12 h-12 text-slate-600 mb-2" />
            <p className="text-sm font-bold text-slate-400">Aucun record enregistré pour l’instant.</p>
            <p className="text-xs text-slate-600">Soyez le premier à franchir la ligne d'arrivée !</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr className="border-b border-white/10 text-[10px] font-black uppercase tracking-wider text-slate-400">
                  <th className="pb-3 pl-2">Rang</th>
                  <th className="pb-3">Pilote</th>
                  <th className="pb-3">Bolide</th>
                  {selectedMode === 'circuit' ? (
                    <th className="pb-3 text-right">Temps Total</th>
                  ) : (
                    <th className="pb-3 text-right">Distance</th>
                  )}
                  <th className="pb-3 pr-2 text-right">Drift Score</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 text-xs font-semibold text-slate-200">
                {entries.map((entry, index) => {
                  const car = CARS_CATALOG.find((c) => c.id === entry.carId);
                  const isTop3 = index < 3;
                  const medalColor = index === 0 ? 'text-amber-400' : index === 1 ? 'text-slate-300' : 'text-amber-600';

                  return (
                    <tr key={entry.id} className="hover:bg-white/5 transition-colors">
                      <td className="py-3 pl-2">
                        <div className="flex items-center gap-1.5">
                          {isTop3 ? (
                            <Trophy className={`w-4 h-4 ${medalColor} fill-current`} />
                          ) : (
                            <span className="font-mono text-slate-500 pl-1">{index + 1}</span>
                          )}
                        </div>
                      </td>
                      <td className="py-3 font-bold text-white">{entry.playerName}</td>
                      <td className="py-3 text-slate-400">{car ? car.name : entry.carId}</td>
                      <td className="py-3 text-right font-mono font-bold text-cyan-300">
                        {selectedMode === 'circuit' ? (
                          formatTime(entry.timeSeconds)
                        ) : (
                          <span>{entry.distance.toLocaleString()} m</span>
                        )}
                      </td>
                      <td className="py-3 pr-2 text-right font-mono text-fuchsia-400">
                        +{entry.driftScore.toLocaleString()}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
