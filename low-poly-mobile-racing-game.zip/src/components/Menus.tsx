import { Canvas } from "@react-three/fiber";
import { CARS, getCar } from "../game/cars";
import { TRACKS } from "../game/tracks";
import type { Settings } from "../game/types";
import { LowPolyCar } from "./LowPolyCar";

function StatBar({ label, value }: { label: string; value: number }) {
  return (
    <div className="stat">
      <span>{label}</span>
      <div className="stat-track">
        <div className="stat-fill" style={{ width: `${Math.min(100, value * 100)}%` }} />
      </div>
    </div>
  );
}

export function Splash({ onStart }: { onStart: () => void }) {
  return (
    <div className="splash" onClick={onStart} onPointerDown={onStart}>
      <div className="grid-bg" />
      <div className="sun" />
      <div className="splash-content">
        <p className="kicker">LOW POLY RACING</p>
        <h1>POLY RUSH</h1>
        <p className="tag">Sensations de vitesse · 14 bolides · 4 circuits</p>
        <button className="btn primary pulse">TOUCHE POUR JOUER</button>
      </div>
    </div>
  );
}

export function MainMenu({
  onPlay,
  onGarage,
  onTracks,
  settings,
  setSettings,
}: {
  onPlay: () => void;
  onGarage: () => void;
  onTracks: () => void;
  settings: Settings;
  setSettings: (s: Settings) => void;
}) {
  return (
    <div className="menu-screen">
      <div className="grid-bg dim" />
      <div className="menu-hero">
        <p className="kicker">ARCADE RACING</p>
        <h1>POLY RUSH</h1>
      </div>
      <div className="menu-actions">
        <button className="btn primary big" onClick={onPlay}>
          COURSE
        </button>
        <button className="btn" onClick={onGarage}>
          GARAGE
        </button>
        <button className="btn" onClick={onTracks}>
          CIRCUITS
        </button>
      </div>
      <div className="settings">
        <label>
          <input
            type="checkbox"
            checked={settings.audio}
            onChange={(e) => setSettings({ ...settings, audio: e.target.checked })}
          />
          Audio
        </label>
        <label>
          <input
            type="checkbox"
            checked={settings.autoAccel}
            onChange={(e) => setSettings({ ...settings, autoAccel: e.target.checked })}
          />
          Auto-gaz
        </label>
        <label>
          <input
            type="checkbox"
            checked={settings.vibration}
            onChange={(e) => setSettings({ ...settings, vibration: e.target.checked })}
          />
          Vibration
        </label>
        <label>
          <input
            type="checkbox"
            checked={settings.quality === "high"}
            onChange={(e) => setSettings({ ...settings, quality: e.target.checked ? "high" : "low" })}
          />
          Haute qualité
        </label>
      </div>
    </div>
  );
}

export function Garage({
  carId,
  onSelect,
  onBack,
}: {
  carId: string;
  onSelect: (id: string) => void;
  onBack: () => void;
}) {
  const car = getCar(carId);
  return (
    <div className="garage">
      <header className="screen-head">
        <button className="btn ghost sm" onClick={onBack}>
          RETOUR
        </button>
        <h2>GARAGE</h2>
        <span className="class-pill">{car.class}</span>
      </header>
      <div className="garage-stage">
        <Canvas camera={{ position: [3.4, 1.8, 4.2], fov: 42 }} dpr={[1, 1.5]}>
          <color attach="background" args={["#0b1020"]} />
          <hemisphereLight args={["#9ad0ff", "#201018", 0.7]} />
          <directionalLight position={[4, 6, 2]} intensity={1.4} color="#fff2d0" />
          <pointLight position={[-3, 2, -2]} intensity={1.2} color={car.accent} />
          <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.02, 0]}>
            <circleGeometry args={[3.2, 24]} />
            <meshBasicMaterial color="#141828" />
          </mesh>
          <LowPolyCar def={car} preview boosting={false} />
        </Canvas>
      </div>
      <div className="car-info">
        <div>
          <h3>{car.name}</h3>
          <p>{car.tagline}</p>
        </div>
        <div className="stats">
          <StatBar label="VITESSE" value={car.maxSpeed / 72} />
          <StatBar label="ACCEL." value={car.accel / 52} />
          <StatBar label="TENUE" value={car.handling / 1.1} />
          <StatBar label="NITRO" value={(car.nitroPower - 1.15) / 0.5} />
        </div>
      </div>
      <div className="car-strip">
        {CARS.map((c) => (
          <button
            key={c.id}
            className={`car-chip ${c.id === carId ? "on" : ""}`}
            onClick={() => onSelect(c.id)}
            style={{ ["--c" as string]: c.color }}
          >
            <i style={{ background: c.color }} />
            <span>{c.name}</span>
            <em>{c.class}</em>
          </button>
        ))}
      </div>
    </div>
  );
}

export function TrackSelect({
  trackId,
  onSelect,
  onBack,
  onRace,
}: {
  trackId: string;
  onSelect: (id: string) => void;
  onBack: () => void;
  onRace: () => void;
}) {
  return (
    <div className="tracks-screen">
      <header className="screen-head">
        <button className="btn ghost sm" onClick={onBack}>
          RETOUR
        </button>
        <h2>CIRCUITS</h2>
        <span />
      </header>
      <div className="track-grid">
        {TRACKS.map((t) => (
          <button
            key={t.id}
            className={`track-card ${t.id === trackId ? "on" : ""}`}
            onClick={() => onSelect(t.id)}
            style={{
              background: `linear-gradient(160deg, ${t.skyTop}, ${t.skyBot})`,
            }}
          >
            <div className="stars">{"★".repeat(t.difficulty)}{"☆".repeat(4 - t.difficulty)}</div>
            <h3>{t.name}</h3>
            <p>{t.desc}</p>
            <span>
              {t.laps} tours · {t.theme}
            </span>
          </button>
        ))}
      </div>
      <button className="btn primary big" onClick={onRace}>
        LANCER LA COURSE
      </button>
    </div>
  );
}
