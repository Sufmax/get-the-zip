import React, { useState, useEffect, useRef } from 'react';
import * as THREE from 'three';
import { CARS_CATALOG, UPGRADE_PRICES } from '../game/carsData';
import { CarDefinition, PlayerProgress, CarUpgrades } from '../types/game';
import { buildLowPolyCar, Car3DObject } from '../game/proceduralCar';
import { audio } from '../services/audio';
import { triggerHaptic } from '../services/storage';
import { Check, Lock, ChevronLeft, ChevronRight, Zap, Gauge, Wrench, Palette, ArrowLeft } from 'lucide-react';

interface GarageModalProps {
  progress: PlayerProgress;
  onUpdateProgress: (newProgress: PlayerProgress) => void;
  onClose: () => void;
}

export const GarageModal: React.FC<GarageModalProps> = ({
  progress,
  onUpdateProgress,
  onClose,
}) => {
  const [selectedCarIndex, setSelectedCarIndex] = useState(() => {
    const idx = CARS_CATALOG.findIndex((c) => c.id === progress.selectedCarId);
    return idx >= 0 ? idx : 0;
  });

  const [activeTab, setActiveTab] = useState<'specs' | 'tuning' | 'paint'>('specs');
  const canvasContainerRef = useRef<HTMLDivElement>(null);

  const currentCar: CarDefinition = CARS_CATALOG[selectedCarIndex];
  const isUnlocked = progress.unlockedCars.includes(currentCar.id);
  const isSelected = progress.selectedCarId === currentCar.id;
  const currentCustomization = progress.carCustomizations[currentCar.id];

  // 3D Showroom Turntable
  useEffect(() => {
    const container = canvasContainerRef.current;
    if (!container) return;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0a0f1d);

    const camera = new THREE.PerspectiveCamera(45, container.clientWidth / container.clientHeight, 0.1, 100);
    camera.position.set(4.5, 2.2, 5.5);
    camera.lookAt(0, 0.4, 0);

    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.2;
    container.appendChild(renderer.domElement);

    // Studio Lights
    const ambient = new THREE.AmbientLight(0xffffff, 0.8);
    scene.add(ambient);

    const keyLight = new THREE.DirectionalLight(0xffffff, 1.8);
    keyLight.position.set(5, 8, 5);
    scene.add(keyLight);

    const rimLight = new THREE.DirectionalLight(0x38bdf8, 1.2);
    rimLight.position.set(-5, 4, -5);
    scene.add(rimLight);

    const bottomGlow = new THREE.PointLight(0xa855f7, 2.0, 8);
    bottomGlow.position.set(0, -0.2, 0);
    scene.add(bottomGlow);

    // Turntable circular podium
    const podiumGeo = new THREE.CylinderGeometry(2.8, 3.0, 0.25, 24);
    const podiumMat = new THREE.MeshStandardMaterial({
      color: 0x1e293b,
      metalness: 0.8,
      roughness: 0.2,
      flatShading: true,
    });
    const podium = new THREE.Mesh(podiumGeo, podiumMat);
    podium.position.y = -0.12;
    scene.add(podium);

    // Glowing podium rim
    const ringGeo = new THREE.TorusGeometry(2.85, 0.04, 8, 32);
    ringGeo.rotateX(Math.PI / 2);
    const ringMat = new THREE.MeshBasicMaterial({ color: 0x06b6d4 });
    const ring = new THREE.Mesh(ringGeo, ringMat);
    ring.position.y = 0.01;
    scene.add(ring);

    // Build Car
    let carObj: Car3DObject = buildLowPolyCar(currentCar, currentCustomization);
    scene.add(carObj.root);

    let isDragging = false;
    let prevMouseX = 0;
    let autoRotate = true;

    const onMouseDown = (e: MouseEvent) => {
      isDragging = true;
      prevMouseX = e.clientX;
      autoRotate = false;
    };

    const onMouseMove = (e: MouseEvent) => {
      if (!isDragging) return;
      const deltaX = e.clientX - prevMouseX;
      prevMouseX = e.clientX;
      carObj.root.rotation.y += deltaX * 0.015;
    };

    const onMouseUp = () => {
      isDragging = false;
    };

    const onTouchStart = (e: TouchEvent) => {
      if (e.touches.length === 1) {
        isDragging = true;
        prevMouseX = e.touches[0].clientX;
        autoRotate = false;
      }
    };

    const onTouchMove = (e: TouchEvent) => {
      if (!isDragging || e.touches.length !== 1) return;
      const deltaX = e.touches[0].clientX - prevMouseX;
      prevMouseX = e.touches[0].clientX;
      carObj.root.rotation.y += deltaX * 0.015;
    };

    const onTouchEnd = () => {
      isDragging = false;
    };

    container.addEventListener('mousedown', onMouseDown);
    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onMouseUp);

    container.addEventListener('touchstart', onTouchStart);
    window.addEventListener('touchmove', onTouchMove);
    window.addEventListener('touchend', onTouchEnd);

    let animationId: number;
    const animate = () => {
      animationId = requestAnimationFrame(animate);
      if (autoRotate) {
        carObj.root.rotation.y += 0.008;
      }
      renderer.render(scene, camera);
    };
    animate();

    const onResize = () => {
      if (!container) return;
      camera.aspect = container.clientWidth / container.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(container.clientWidth, container.clientHeight);
    };
    window.addEventListener('resize', onResize);

    return () => {
      cancelAnimationFrame(animationId);
      window.removeEventListener('resize', onResize);
      container.removeEventListener('mousedown', onMouseDown);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);
      container.removeEventListener('touchstart', onTouchStart);
      window.removeEventListener('touchmove', onTouchMove);
      window.removeEventListener('touchend', onTouchEnd);
      if (renderer.domElement.parentNode) {
        renderer.domElement.parentNode.removeChild(renderer.domElement);
      }
      renderer.dispose();
    };
  }, [currentCar, currentCustomization]);

  // Car switching
  const handlePrevCar = () => {
    audio.playClick();
    triggerHaptic(20);
    setSelectedCarIndex((prev) => (prev > 0 ? prev - 1 : CARS_CATALOG.length - 1));
  };

  const handleNextCar = () => {
    audio.playClick();
    triggerHaptic(20);
    setSelectedCarIndex((prev) => (prev < CARS_CATALOG.length - 1 ? prev + 1 : 0));
  };

  // Buy car
  const handleBuyCar = () => {
    if (progress.money < currentCar.price) {
      triggerHaptic(60);
      return;
    }
    audio.playCheckpoint();
    triggerHaptic(50);
    const updated: PlayerProgress = {
      ...progress,
      money: progress.money - currentCar.price,
      unlockedCars: [...progress.unlockedCars, currentCar.id],
      selectedCarId: currentCar.id,
    };
    onUpdateProgress(updated);
  };

  // Select car
  const handleSelectCar = () => {
    audio.playClick();
    triggerHaptic(30);
    onUpdateProgress({
      ...progress,
      selectedCarId: currentCar.id,
    });
  };

  // Change Paint Color
  const handleSelectColor = (hex: string) => {
    audio.playClick();
    triggerHaptic(20);
    const currentCust = progress.carCustomizations[currentCar.id];
    onUpdateProgress({
      ...progress,
      carCustomizations: {
        ...progress.carCustomizations,
        [currentCar.id]: {
          ...currentCust,
          color: hex,
        },
      },
    });
  };

  // Change Underglow Neon
  const handleSelectUnderglow = (hex: string | null) => {
    audio.playClick();
    triggerHaptic(20);
    const currentCust = progress.carCustomizations[currentCar.id];
    onUpdateProgress({
      ...progress,
      carCustomizations: {
        ...progress.carCustomizations,
        [currentCar.id]: {
          ...currentCust,
          underglowColor: hex,
        },
      },
    });
  };

  // Upgrade part
  const handleUpgrade = (part: keyof CarUpgrades) => {
    const currentLvl = currentCustomization.upgrades[part];
    if (currentLvl >= 5) return;
    const price = UPGRADE_PRICES[part][currentLvl - 1];
    if (progress.money < price) {
      triggerHaptic(60);
      return;
    }

    audio.playCheckpoint();
    triggerHaptic(40);
    const currentCust = progress.carCustomizations[currentCar.id];
    onUpdateProgress({
      ...progress,
      money: progress.money - price,
      carCustomizations: {
        ...progress.carCustomizations,
        [currentCar.id]: {
          ...currentCust,
          upgrades: {
            ...currentCust.upgrades,
            [part]: currentLvl + 1,
          },
        },
      },
    });
  };

  // Compute upgraded stats
  const upgrades = currentCustomization?.upgrades || { engine: 1, turbo: 1, handling: 1, nitro: 1, brakes: 1 };
  const effectiveTopSpeed = Math.round(currentCar.specs.topSpeed * (1 + (upgrades.engine - 1) * 0.06));
  const effectiveAccel = Math.min(10, Number((currentCar.specs.acceleration * (1 + (upgrades.turbo - 1) * 0.08)).toFixed(1)));
  const effectiveHandling = Math.min(10, Number((currentCar.specs.handling * (1 + (upgrades.handling - 1) * 0.07)).toFixed(1)));
  const effectiveDrift = Math.min(10, currentCar.specs.driftEase);
  const effectiveNitro = Math.min(10, Number((currentCar.specs.nitroBoost * (1 + (upgrades.nitro - 1) * 0.08)).toFixed(1)));

  return (
    <div className="fixed inset-0 z-40 bg-slate-950 text-white flex flex-col overflow-hidden">
      {/* Top Navbar */}
      <div className="flex justify-between items-center px-4 py-3 bg-slate-900/90 border-b border-white/10 z-10">
        <button
          onClick={() => {
            audio.playClick();
            onClose();
          }}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 border border-white/10 text-slate-300 active:scale-95 transition-transform"
        >
          <ArrowLeft className="w-4 h-4" />
          <span className="text-xs font-black uppercase tracking-wider">RETOUR</span>
        </button>

        <div className="text-center">
          <span className="text-[10px] font-black uppercase tracking-widest text-cyan-400 block -mb-0.5">
            SHOWROOM 3D
          </span>
          <h1 className="text-base md:text-lg font-black uppercase italic tracking-tight text-white">
            GARAGE APEX
          </h1>
        </div>

        {/* Player Cash */}
        <div className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-slate-800/90 border border-amber-400/30 text-amber-300 font-mono font-black text-sm shadow-md shadow-amber-900/20">
          <Zap className="w-4 h-4 fill-amber-300" />
          <span>{progress.money.toLocaleString()} ⚡</span>
        </div>
      </div>

      {/* Main Split Layout: 3D Canvas on Top/Left, Customization on Bottom/Right */}
      <div className="flex-1 flex flex-col md:flex-row overflow-hidden relative">
        {/* 3D Turntable Area */}
        <div className="relative w-full h-[45vh] md:h-full md:w-3/5 bg-slate-900/50">
          <div ref={canvasContainerRef} className="w-full h-full cursor-grab active:cursor-grabbing" />

          {/* Car Navigation Arrows */}
          <button
            onClick={handlePrevCar}
            aria-label="Voiture précédente"
            className="absolute left-3 top-1/2 -translate-y-1/2 w-12 h-12 rounded-2xl bg-slate-900/80 border border-white/20 text-white flex items-center justify-center active:scale-90 transition-transform shadow-xl backdrop-blur-md"
          >
            <ChevronLeft className="w-6 h-6 text-cyan-400" />
          </button>

          <button
            onClick={handleNextCar}
            aria-label="Voiture suivante"
            className="absolute right-3 top-1/2 -translate-y-1/2 w-12 h-12 rounded-2xl bg-slate-900/80 border border-white/20 text-white flex items-center justify-center active:scale-90 transition-transform shadow-xl backdrop-blur-md"
          >
            <ChevronRight className="w-6 h-6 text-cyan-400" />
          </button>

          {/* Car Index Dots */}
          <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-1.5 bg-slate-900/80 backdrop-blur-md px-3 py-1.5 rounded-full border border-white/10">
            {CARS_CATALOG.map((car, idx) => (
              <div
                key={car.id}
                className={`h-2 rounded-full transition-all ${
                  idx === selectedCarIndex ? 'w-6 bg-cyan-400' : 'w-2 bg-slate-600'
                }`}
              />
            ))}
          </div>
        </div>

        {/* Customization & Upgrades Panel */}
        <div className="w-full md:w-2/5 flex-1 bg-slate-900/95 border-t md:border-t-0 md:border-l border-white/10 flex flex-col overflow-y-auto p-4">
          {/* Car Title & Selection State */}
          <div className="flex justify-between items-start mb-3">
            <div>
              <span className="text-[10px] font-black uppercase tracking-wider text-cyan-400">
                {currentCar.subtitle}
              </span>
              <h2 className="text-xl md:text-2xl font-black italic uppercase text-white tracking-tight">
                {currentCar.name}
              </h2>
            </div>

            {/* Selection / Unlock Button */}
            {isUnlocked ? (
              isSelected ? (
                <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-500/20 border border-emerald-400/40 text-emerald-400 text-xs font-black uppercase">
                  <Check className="w-4 h-4" /> SELECTIONNÉE
                </div>
              ) : (
                <button
                  onClick={handleSelectCar}
                  className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-black text-xs uppercase tracking-wider shadow-lg shadow-cyan-500/30 active:scale-95 transition-all"
                >
                  CHOISIR
                </button>
              )
            ) : (
              <button
                onClick={handleBuyCar}
                disabled={progress.money < currentCar.price}
                className={`flex items-center gap-1.5 px-4 py-2 rounded-xl font-black text-xs uppercase tracking-wider transition-all ${
                  progress.money >= currentCar.price
                    ? 'bg-amber-400 hover:bg-amber-300 text-slate-950 shadow-lg shadow-amber-400/30 active:scale-95'
                    : 'bg-slate-800 text-slate-500 border border-slate-700 cursor-not-allowed'
                }`}
              >
                <Lock className="w-3.5 h-3.5" />
                DÉBLOQUER ({currentCar.price.toLocaleString()} ⚡)
              </button>
            )}
          </div>

          <p className="text-xs text-slate-400 mb-4 leading-relaxed">
            {currentCar.descriptionFr}
          </p>

          {/* Navigation Tabs (Specs, Tuning, Peinture) */}
          <div className="flex gap-2 p-1 bg-slate-950 rounded-xl mb-4 border border-white/10">
            <button
              onClick={() => {
                audio.playClick();
                setActiveTab('specs');
              }}
              className={`flex-1 py-1.5 text-xs font-black uppercase rounded-lg transition-all flex items-center justify-center gap-1.5 ${
                activeTab === 'specs'
                  ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Gauge className="w-3.5 h-3.5" /> PERFORMANCES
            </button>
            <button
              onClick={() => {
                audio.playClick();
                setActiveTab('tuning');
              }}
              className={`flex-1 py-1.5 text-xs font-black uppercase rounded-lg transition-all flex items-center justify-center gap-1.5 ${
                activeTab === 'tuning'
                  ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Wrench className="w-3.5 h-3.5" /> AMÉLIORATIONS
            </button>
            <button
              onClick={() => {
                audio.playClick();
                setActiveTab('paint');
              }}
              className={`flex-1 py-1.5 text-xs font-black uppercase rounded-lg transition-all flex items-center justify-center gap-1.5 ${
                activeTab === 'paint'
                  ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Palette className="w-3.5 h-3.5" /> PEINTURE
            </button>
          </div>

          {/* TAB 1: Performance Specs Bars */}
          {activeTab === 'specs' && (
            <div className="flex flex-col gap-3">
              {/* Top Speed */}
              <div>
                <div className="flex justify-between text-xs font-bold mb-1">
                  <span className="text-slate-400">VITESSE DE POINTE</span>
                  <span className="text-white font-mono">{effectiveTopSpeed} km/h</span>
                </div>
                <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-cyan-500 to-sky-400 rounded-full"
                    style={{ width: `${(effectiveTopSpeed / 380) * 100}%` }}
                  />
                </div>
              </div>

              {/* Accel */}
              <div>
                <div className="flex justify-between text-xs font-bold mb-1">
                  <span className="text-slate-400">ACCÉLÉRATION</span>
                  <span className="text-white font-mono">{effectiveAccel} / 10</span>
                </div>
                <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 rounded-full"
                    style={{ width: `${(effectiveAccel / 10) * 100}%` }}
                  />
                </div>
              </div>

              {/* Handling */}
              <div>
                <div className="flex justify-between text-xs font-bold mb-1">
                  <span className="text-slate-400">MANIABILITÉ</span>
                  <span className="text-white font-mono">{effectiveHandling} / 10</span>
                </div>
                <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-violet-500 to-purple-400 rounded-full"
                    style={{ width: `${(effectiveHandling / 10) * 100}%` }}
                  />
                </div>
              </div>

              {/* Drift Ease */}
              <div>
                <div className="flex justify-between text-xs font-bold mb-1">
                  <span className="text-slate-400">FACILITÉ DE DRIFT</span>
                  <span className="text-white font-mono">{effectiveDrift} / 10</span>
                </div>
                <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-amber-500 to-orange-400 rounded-full"
                    style={{ width: `${(effectiveDrift / 10) * 100}%` }}
                  />
                </div>
              </div>

              {/* Nitro Boost */}
              <div>
                <div className="flex justify-between text-xs font-bold mb-1">
                  <span className="text-slate-400">PUISSANCE NITRO</span>
                  <span className="text-white font-mono">{effectiveNitro} / 10</span>
                </div>
                <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-rose-500 to-pink-400 rounded-full"
                    style={{ width: `${(effectiveNitro / 10) * 100}%` }}
                  />
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: Mechanical Performance Tuning */}
          {activeTab === 'tuning' && (
            <div className="flex flex-col gap-3">
              {(['engine', 'turbo', 'handling', 'nitro', 'brakes'] as const).map((part) => {
                const labels: Record<string, { name: string; desc: string }> = {
                  engine: { name: 'Moteur V-Apex', desc: '+ Vitesse maximale' },
                  turbo: { name: 'Turbo Compresseur', desc: '+ Accélération brute' },
                  handling: { name: 'Châssis & Pneus', desc: '+ Adhérence & virages' },
                  nitro: { name: 'Injection Nitro', desc: '+ Puissance & capacité' },
                  brakes: { name: 'Freins Céramique', desc: '+ Puissance de freinage' },
                };

                const lvl = upgrades[part];
                const isMax = lvl >= 5;
                const nextCost = !isMax ? UPGRADE_PRICES[part][lvl - 1] : 0;
                const canAfford = progress.money >= nextCost;

                return (
                  <div
                    key={part}
                    className="flex justify-between items-center p-2.5 rounded-xl bg-slate-950 border border-white/10"
                  >
                    <div>
                      <span className="text-xs font-black uppercase text-white block">
                        {labels[part].name}
                      </span>
                      <span className="text-[10px] text-slate-400 block -mt-0.5">
                        {labels[part].desc}
                      </span>
                      {/* 5-step level indicator */}
                      <div className="flex gap-1 mt-1.5">
                        {[1, 2, 3, 4, 5].map((step) => (
                          <div
                            key={step}
                            className={`w-3.5 h-1.5 rounded-sm ${
                              step <= lvl ? 'bg-cyan-400' : 'bg-slate-700'
                            }`}
                          />
                        ))}
                      </div>
                    </div>

                    {!isMax ? (
                      <button
                        onClick={() => handleUpgrade(part)}
                        disabled={!canAfford || !isUnlocked}
                        className={`px-3 py-1.5 rounded-lg text-xs font-black uppercase tracking-wider transition-all ${
                          canAfford && isUnlocked
                            ? 'bg-amber-400 text-slate-950 shadow-md shadow-amber-400/20 active:scale-95'
                            : 'bg-slate-800 text-slate-500 border border-slate-700 cursor-not-allowed'
                        }`}
                      >
                        NIV. {lvl + 1} ({nextCost.toLocaleString()} ⚡)
                      </button>
                    ) : (
                      <span className="text-[11px] font-black uppercase text-cyan-400 px-2 py-1 rounded bg-cyan-950/60 border border-cyan-800/40">
                        MAX
                      </span>
                    )}
                  </div>
                );
              })}
            </div>
          )}

          {/* TAB 3: Paint & Underglow Customizer */}
          {activeTab === 'paint' && (
            <div className="flex flex-col gap-4">
              {/* Body Paint Colors */}
              <div>
                <span className="text-xs font-black uppercase tracking-wider text-slate-400 block mb-2">
                  COULEUR DE CARROSSERIE
                </span>
                <div className="flex flex-wrap gap-2.5">
                  {currentCar.availableColors.map((hex) => {
                    const isSelectedColor = currentCustomization.color.toLowerCase() === hex.toLowerCase();
                    return (
                      <button
                        key={hex}
                        onClick={() => handleSelectColor(hex)}
                        aria-label={`Couleur ${hex}`}
                        className={`w-9 h-9 rounded-xl border-2 transition-transform active:scale-90 ${
                          isSelectedColor ? 'border-white scale-110 shadow-lg shadow-white/30' : 'border-black/50'
                        }`}
                        style={{ backgroundColor: hex }}
                      />
                    );
                  })}
                </div>
              </div>

              {/* Underglow Neon */}
              <div>
                <span className="text-xs font-black uppercase tracking-wider text-slate-400 block mb-2">
                  KIT NÉON SOUS CHÂSSIS
                </span>
                <div className="flex flex-wrap gap-2">
                  {[
                    { label: 'AUCUN', hex: null },
                    { label: 'CYAN', hex: '#00f2fe' },
                    { label: 'MAGENTA', hex: '#f43f5e' },
                    { label: 'LIME', hex: '#22c55e' },
                    { label: 'ORANGE', hex: '#f97316' },
                    { label: 'VIOLET', hex: '#a855f7' },
                  ].map((neon) => {
                    const isSel = currentCustomization.underglowColor === neon.hex;
                    return (
                      <button
                        key={neon.label}
                        onClick={() => handleSelectUnderglow(neon.hex)}
                        className={`px-3 py-1.5 rounded-xl text-xs font-black uppercase border transition-all ${
                          isSel
                            ? 'bg-cyan-500/20 border-cyan-400 text-cyan-300 shadow-md shadow-cyan-500/30'
                            : 'bg-slate-950 border-white/10 text-slate-400'
                        }`}
                      >
                        {neon.label}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
