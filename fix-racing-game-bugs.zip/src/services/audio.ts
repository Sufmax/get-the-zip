// Procedural Web Audio engine for zero-dependency, ultra-responsive racing sound effects

class AudioManager {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private engineGain: GainNode | null = null;
  private sfxGain: GainNode | null = null;
  private musicGain: GainNode | null = null;

  // Engine oscillators
  private engineOsc1: OscillatorNode | null = null;
  private engineOsc2: OscillatorNode | null = null;
  private engineSubOsc: OscillatorNode | null = null;
  private engineFilter: BiquadFilterNode | null = null;
  private engineRunning = false;

  // Tire screech
  private tireNoiseNode: AudioBufferSourceNode | null = null;
  private tireFilter: BiquadFilterNode | null = null;
  private tireGain: GainNode | null = null;
  private tireBuffer: AudioBuffer | null = null;

  // Nitro whoosh
  private nitroGain: GainNode | null = null;
  private nitroNoiseNode: AudioBufferSourceNode | null = null;

  // Synthwave music sequencer
  private isMusicPlaying = false;
  private musicInterval: number | null = null;
  private musicStep = 0;

  // Volumes
  private masterVol = 0.8;
  private engineVol = 0.7;
  private sfxVol = 0.8;
  private musicVol = 0.4;
  private isMuted = false;

  public init() {
    if (this.ctx) return;
    try {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx();

      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.value = this.masterVol;
      this.masterGain.connect(this.ctx.destination);

      this.engineGain = this.ctx.createGain();
      this.engineGain.gain.value = this.engineVol;
      this.engineGain.connect(this.masterGain);

      this.sfxGain = this.ctx.createGain();
      this.sfxGain.gain.value = this.sfxVol;
      this.sfxGain.connect(this.masterGain);

      this.musicGain = this.ctx.createGain();
      this.musicGain.gain.value = this.musicVol;
      this.musicGain.connect(this.masterGain);

      this.buildTireBuffer();
    } catch (e) {
      console.warn('AudioContext failed to initialize:', e);
    }
  }

  public resume() {
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  private buildTireBuffer() {
    if (!this.ctx) return;
    const sampleRate = this.ctx.sampleRate;
    const length = sampleRate * 2; // 2 seconds loop
    this.tireBuffer = this.ctx.createBuffer(1, length, sampleRate);
    const data = this.tireBuffer.getChannelData(0);
    for (let i = 0; i < length; i++) {
      data[i] = (Math.random() * 2 - 1) * 0.5;
    }
  }

  public startEngine(soundType: 'v8' | 'turbo' | 'hyper' | 'electric' | 'formula' = 'turbo') {
    this.init();
    this.resume();
    if (!this.ctx || this.engineRunning) return;

    try {
      this.engineFilter = this.ctx.createBiquadFilter();
      this.engineFilter.type = soundType === 'electric' ? 'bandpass' : 'lowpass';
      this.engineFilter.frequency.value = soundType === 'formula' ? 1800 : soundType === 'v8' ? 500 : 800;
      this.engineFilter.Q.value = soundType === 'formula' ? 4 : 2;

      this.engineOsc1 = this.ctx.createOscillator();
      this.engineOsc2 = this.ctx.createOscillator();
      this.engineSubOsc = this.ctx.createOscillator();

      if (soundType === 'electric') {
        this.engineOsc1.type = 'sine';
        this.engineOsc2.type = 'triangle';
        this.engineSubOsc.type = 'sine';
      } else if (soundType === 'formula') {
        this.engineOsc1.type = 'sawtooth';
        this.engineOsc2.type = 'sawtooth';
        this.engineSubOsc.type = 'triangle';
      } else if (soundType === 'v8') {
        this.engineOsc1.type = 'sawtooth';
        this.engineOsc2.type = 'square';
        this.engineSubOsc.type = 'sawtooth';
      } else {
        this.engineOsc1.type = 'sawtooth';
        this.engineOsc2.type = 'triangle';
        this.engineSubOsc.type = 'sine';
      }

      this.engineOsc1.frequency.value = 55;
      this.engineOsc2.frequency.value = 110;
      this.engineSubOsc.frequency.value = 27.5;

      const oscGain = this.ctx.createGain();
      oscGain.gain.value = 0.25;

      this.engineOsc1.connect(this.engineFilter);
      this.engineOsc2.connect(this.engineFilter);
      this.engineSubOsc.connect(this.engineFilter);
      this.engineFilter.connect(this.engineGain!);

      const now = this.ctx.currentTime;
      this.engineOsc1.start(now);
      this.engineOsc2.start(now);
      this.engineSubOsc.start(now);

      this.engineRunning = true;

      // Start continuous tire screech node with 0 initial gain
      this.tireGain = this.ctx.createGain();
      this.tireGain.gain.value = 0;
      this.tireFilter = this.ctx.createBiquadFilter();
      this.tireFilter.type = 'bandpass';
      this.tireFilter.frequency.value = 1100;
      this.tireFilter.Q.value = 5;

      if (this.tireBuffer) {
        this.tireNoiseNode = this.ctx.createBufferSource();
        this.tireNoiseNode.buffer = this.tireBuffer;
        this.tireNoiseNode.loop = true;
        this.tireNoiseNode.connect(this.tireFilter);
        this.tireFilter.connect(this.tireGain);
        this.tireGain.connect(this.sfxGain!);
        this.tireNoiseNode.start(now);
      }

      // Start nitro whoosh gain node
      this.nitroGain = this.ctx.createGain();
      this.nitroGain.gain.value = 0;
      const nitroFilter = this.ctx.createBiquadFilter();
      nitroFilter.type = 'lowpass';
      nitroFilter.frequency.value = 3500;
      if (this.tireBuffer) {
        this.nitroNoiseNode = this.ctx.createBufferSource();
        this.nitroNoiseNode.buffer = this.tireBuffer;
        this.nitroNoiseNode.loop = true;
        this.nitroNoiseNode.connect(nitroFilter);
        nitroFilter.connect(this.nitroGain);
        this.nitroGain.connect(this.sfxGain!);
        this.nitroNoiseNode.start(now);
      }
    } catch (e) {
      console.warn('Error starting engine audio:', e);
    }
  }

  public updateEnginePitch(rpmFactor: number, gear: number, speedRatio: number, soundType: 'v8' | 'turbo' | 'hyper' | 'electric' | 'formula' = 'turbo') {
    if (!this.ctx || !this.engineRunning || !this.engineOsc1 || !this.engineOsc2 || !this.engineSubOsc || !this.engineFilter) return;

    const gearAcousticMod = 1 + (gear - 1) * 0.04;
    const baseFreq = (soundType === 'formula' ? 120 : soundType === 'v8' ? 42 : soundType === 'electric' ? 160 : 58) * gearAcousticMod;
    const rpmMultiplier = 1 + rpmFactor * 2.8;
    const freq1 = baseFreq * rpmMultiplier;
    const freq2 = freq1 * (soundType === 'v8' ? 1.5 : soundType === 'formula' ? 2.0 : 1.33);
    const subFreq = freq1 * 0.5;

    const time = this.ctx.currentTime + 0.05;
    this.engineOsc1.frequency.setTargetAtTime(freq1, time, 0.06);
    this.engineOsc2.frequency.setTargetAtTime(freq2, time, 0.06);
    this.engineSubOsc.frequency.setTargetAtTime(subFreq, time, 0.06);

    const filterCutoff = soundType === 'electric' ? 800 + speedRatio * 3200 : 400 + rpmFactor * 2200;
    this.engineFilter.frequency.setTargetAtTime(filterCutoff, time, 0.08);
  }

  public setTireScreech(intensity: number) {
    if (!this.ctx || !this.tireGain) return;
    const clamped = Math.max(0, Math.min(1, intensity));
    this.tireGain.gain.setTargetAtTime(clamped * 0.55, this.ctx.currentTime, 0.04);
    if (this.tireFilter) {
      this.tireFilter.frequency.setTargetAtTime(1000 + clamped * 800, this.ctx.currentTime, 0.05);
    }
  }

  public setNitroWhoosh(active: boolean) {
    if (!this.ctx || !this.nitroGain) return;
    const target = active ? 0.75 : 0;
    this.nitroGain.gain.setTargetAtTime(target, this.ctx.currentTime, 0.05);
  }

  public stopEngine() {
    if (!this.engineRunning) return;
    try {
      this.engineOsc1?.stop();
      this.engineOsc2?.stop();
      this.engineSubOsc?.stop();
      this.tireNoiseNode?.stop();
      this.nitroNoiseNode?.stop();
    } catch {
      // Ignore
    }
    this.engineRunning = false;
  }

  // Turbo blow-off valve "psshh" sound on gear change / throttle release
  public playTurboBlowOff() {
    if (!this.ctx || !this.sfxGain) return;
    try {
      const now = this.ctx.currentTime;
      const noise = this.ctx.createBufferSource();
      if (!this.tireBuffer) return;
      noise.buffer = this.tireBuffer;

      const filter = this.ctx.createBiquadFilter();
      filter.type = 'highpass';
      filter.frequency.setValueAtTime(2400, now);
      filter.frequency.exponentialRampToValueAtTime(1200, now + 0.25);

      const gain = this.ctx.createGain();
      gain.gain.setValueAtTime(0.4, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.28);

      noise.connect(filter);
      filter.connect(gain);
      gain.connect(this.sfxGain);

      noise.start(now);
      noise.stop(now + 0.3);
    } catch {
      // Ignore
    }
  }

  // Crash impact sound
  public playCrash(intensity = 1) {
    if (!this.ctx || !this.sfxGain) return;
    try {
      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(160, now);
      osc.frequency.exponentialRampToValueAtTime(35, now + 0.3);

      const oscGain = this.ctx.createGain();
      oscGain.gain.setValueAtTime(0.7 * intensity, now);
      oscGain.gain.exponentialRampToValueAtTime(0.01, now + 0.3);

      osc.connect(oscGain);
      oscGain.connect(this.sfxGain);
      osc.start(now);
      osc.stop(now + 0.35);

      // Add noise crack
      if (this.tireBuffer) {
        const noise = this.ctx.createBufferSource();
        noise.buffer = this.tireBuffer;
        const filter = this.ctx.createBiquadFilter();
        filter.type = 'bandpass';
        filter.frequency.setValueAtTime(600, now);

        const nGain = this.ctx.createGain();
        nGain.gain.setValueAtTime(0.8 * intensity, now);
        nGain.gain.exponentialRampToValueAtTime(0.01, now + 0.25);

        noise.connect(filter);
        filter.connect(nGain);
        nGain.connect(this.sfxGain);
        noise.start(now);
        noise.stop(now + 0.26);
      }
    } catch {
      // Ignore
    }
  }

  // Countdown beep (pitch = 440 for 3, 2, 1; 880 for GO!)
  public playCountdownBeep(isGo = false) {
    if (!this.ctx || !this.sfxGain) return;
    try {
      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      osc.type = 'sine';
      osc.frequency.value = isGo ? 880 : 440;

      const gain = this.ctx.createGain();
      gain.gain.setValueAtTime(0.45, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + (isGo ? 0.6 : 0.2));

      osc.connect(gain);
      gain.connect(this.sfxGain);
      osc.start(now);
      osc.stop(now + (isGo ? 0.65 : 0.25));
    } catch {
      // Ignore
    }
  }

  // Checkpoint chime
  public playCheckpoint() {
    if (!this.ctx || !this.sfxGain) return;
    try {
      const now = this.ctx.currentTime;
      [659.25, 880].forEach((freq, idx) => {
        const osc = this.ctx!.createOscillator();
        osc.type = 'triangle';
        osc.frequency.value = freq;
        const gain = this.ctx!.createGain();
        gain.gain.setValueAtTime(0.35, now + idx * 0.08);
        gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.08 + 0.25);
        osc.connect(gain);
        gain.connect(this.sfxGain!);
        osc.start(now + idx * 0.08);
        osc.stop(now + idx * 0.08 + 0.3);
      });
    } catch {
      // Ignore
    }
  }

  // Victory fanfare
  public playVictory() {
    if (!this.ctx || !this.sfxGain) return;
    try {
      const now = this.ctx.currentTime;
      const notes = [523.25, 659.25, 783.99, 1046.5]; // C5, E5, G5, C6
      notes.forEach((freq, idx) => {
        const osc = this.ctx!.createOscillator();
        osc.type = 'sine';
        osc.frequency.value = freq;
        const gain = this.ctx!.createGain();
        gain.gain.setValueAtTime(0.35, now + idx * 0.12);
        gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.12 + 0.45);
        osc.connect(gain);
        gain.connect(this.sfxGain!);
        osc.start(now + idx * 0.12);
        osc.stop(now + idx * 0.12 + 0.5);
      });
    } catch {
      // Ignore
    }
  }

  // UI click sound
  public playClick() {
    if (!this.ctx || !this.sfxGain) return;
    try {
      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(800, now);
      osc.frequency.exponentialRampToValueAtTime(400, now + 0.04);
      const gain = this.ctx.createGain();
      gain.gain.setValueAtTime(0.18, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.04);
      osc.connect(gain);
      gain.connect(this.sfxGain);
      osc.start(now);
      osc.stop(now + 0.05);
    } catch {
      // Ignore
    }
  }

  // Procedural Synthwave BGM loop (Arcade Electro vibe)
  public startSynthwaveMusic() {
    this.init();
    this.resume();
    if (this.isMusicPlaying || !this.ctx) return;
    this.isMusicPlaying = true;
    this.musicStep = 0;

    const tempo = 128; // BPM
    const stepDuration = (60 / tempo) / 4; // 16th notes (approx 117ms)

    const bassNotes = [36, 36, 48, 36, 41, 41, 48, 41, 43, 43, 48, 43, 41, 41, 46, 41]; // MIDI notes in D-minor
    const chordFrequencies = [
      [293.66, 349.23, 440.0], // Dm
      [349.23, 440.0, 523.25], // F
      [392.0, 493.88, 587.33], // G
      [329.63, 392.0, 493.88], // Em
    ];

    this.musicInterval = window.setInterval(() => {
      if (!this.ctx || !this.isMusicPlaying || !this.musicGain) return;
      const now = this.ctx.currentTime;

      // Kick drum every 4 steps (quarter note)
      if (this.musicStep % 4 === 0) {
        const kickOsc = this.ctx.createOscillator();
        const kickGain = this.ctx.createGain();
        kickOsc.frequency.setValueAtTime(130, now);
        kickOsc.frequency.exponentialRampToValueAtTime(38, now + 0.12);
        kickGain.gain.setValueAtTime(0.38, now);
        kickGain.gain.exponentialRampToValueAtTime(0.001, now + 0.13);
        kickOsc.connect(kickGain);
        kickGain.connect(this.musicGain);
        kickOsc.start(now);
        kickOsc.stop(now + 0.14);
      }

      // Snare / clap on steps 4 and 12
      if (this.musicStep % 8 === 4 && this.tireBuffer) {
        const snareNoise = this.ctx.createBufferSource();
        snareNoise.buffer = this.tireBuffer;
        const snareFilter = this.ctx.createBiquadFilter();
        snareFilter.type = 'highpass';
        snareFilter.frequency.value = 1000;
        const snareGain = this.ctx.createGain();
        snareGain.gain.setValueAtTime(0.18, now);
        snareGain.gain.exponentialRampToValueAtTime(0.001, now + 0.12);
        snareNoise.connect(snareFilter);
        snareFilter.connect(snareGain);
        snareGain.connect(this.musicGain);
        snareNoise.start(now);
        snareNoise.stop(now + 0.13);
      }

      // Synth bassline 16th notes
      const midiNote = bassNotes[this.musicStep % bassNotes.length];
      const freq = 440 * Math.pow(2, (midiNote - 69) / 12);
      const bassOsc = this.ctx.createOscillator();
      bassOsc.type = 'sawtooth';
      bassOsc.frequency.value = freq;
      const bassFilter = this.ctx.createBiquadFilter();
      bassFilter.type = 'lowpass';
      bassFilter.frequency.setValueAtTime(450, now);
      bassFilter.frequency.exponentialRampToValueAtTime(150, now + stepDuration * 0.9);
      const bassGain = this.ctx.createGain();
      bassGain.gain.setValueAtTime(0.2, now);
      bassGain.gain.exponentialRampToValueAtTime(0.01, now + stepDuration * 0.9);

      bassOsc.connect(bassFilter);
      bassFilter.connect(bassGain);
      bassGain.connect(this.musicGain);
      bassOsc.start(now);
      bassOsc.stop(now + stepDuration);

      // Pad chord swells every 16 steps
      if (this.musicStep % 16 === 0) {
        const chordIdx = Math.floor(this.musicStep / 16) % chordFrequencies.length;
        const freqs = chordFrequencies[chordIdx];
        freqs.forEach((f) => {
          const padOsc = this.ctx!.createOscillator();
          padOsc.type = 'sawtooth';
          padOsc.frequency.value = f;
          const padFilter = this.ctx!.createBiquadFilter();
          padFilter.type = 'lowpass';
          padFilter.frequency.value = 900;
          const padGain = this.ctx!.createGain();
          padGain.gain.setValueAtTime(0.06, now);
          padGain.gain.exponentialRampToValueAtTime(0.001, now + stepDuration * 15);
          padOsc.connect(padFilter);
          padFilter.connect(padGain);
          padGain.connect(this.musicGain!);
          padOsc.start(now);
          padOsc.stop(now + stepDuration * 16);
        });
      }

      this.musicStep = (this.musicStep + 1) % 64;
    }, stepDuration * 1000);
  }

  public stopSynthwaveMusic() {
    if (this.musicInterval !== null) {
      clearInterval(this.musicInterval);
      this.musicInterval = null;
    }
    this.isMusicPlaying = false;
  }

  public setVolumes(master: number, engine: number, sfx: number, music: number) {
    this.masterVol = master;
    this.engineVol = engine;
    this.sfxVol = sfx;
    this.musicVol = music;

    if (this.masterGain) this.masterGain.gain.value = this.isMuted ? 0 : master;
    if (this.engineGain) this.engineGain.gain.value = engine;
    if (this.sfxGain) this.sfxGain.gain.value = sfx;
    if (this.musicGain) this.musicGain.gain.value = music;
  }

  public toggleMute(): boolean {
    this.isMuted = !this.isMuted;
    if (this.masterGain) {
      this.masterGain.gain.value = this.isMuted ? 0 : this.masterVol;
    }
    return this.isMuted;
  }
}

export const audio = new AudioManager();
