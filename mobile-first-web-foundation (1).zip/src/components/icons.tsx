import type { SVGProps } from 'react';

type IconProps = SVGProps<SVGSVGElement> & { size?: number };

const base = (size: number) => ({
  width: size,
  height: size,
  viewBox: '0 0 24 24',
  fill: 'none',
  stroke: 'currentColor',
  strokeWidth: 1.8,
  strokeLinecap: 'round' as const,
  strokeLinejoin: 'round' as const,
});

export const IconChevronRight = ({ size = 18, ...p }: IconProps) => (
  <svg {...base(size)} {...p}>
    <path d="M9 6l6 6-6 6" />
  </svg>
);
export const IconChevronLeft = ({ size = 18, ...p }: IconProps) => (
  <svg {...base(size)} {...p}>
    <path d="M15 6l-6 6 6 6" />
  </svg>
);
export const IconSearch = ({ size = 18, ...p }: IconProps) => (
  <svg {...base(size)} {...p}>
    <circle cx="11" cy="11" r="7" />
    <path d="M20 20l-3.5-3.5" />
  </svg>
);
export const IconStar = ({ size = 18, filled = false, ...p }: IconProps & { filled?: boolean }) => (
  <svg {...base(size)} fill={filled ? 'currentColor' : 'none'} {...p}>
    <path d="M12 3.2l2.4 4.9 5.4.8-3.9 3.8.9 5.4L12 15.6 7.2 18.1l.9-5.4L4.2 8.9l5.4-.8L12 3.2z" />
  </svg>
);
export const IconShare = ({ size = 18, ...p }: IconProps) => (
  <svg {...base(size)} {...p}>
    <path d="M12 4v10" />
    <path d="M8 8l4-4 4 4" />
    <path d="M5 14v5h14v-5" />
  </svg>
);
export const IconFilter = ({ size = 18, ...p }: IconProps) => (
  <svg {...base(size)} {...p}>
    <path d="M4 6h16M7 12h10M10 18h4" />
  </svg>
);
export const IconHome = ({ size = 18, ...p }: IconProps) => (
  <svg {...base(size)} {...p}>
    <path d="M4 11.5L12 4l8 7.5" />
    <path d="M6 10.5V20h12v-9.5" />
  </svg>
);
export const IconAnalyze = ({ size = 18, ...p }: IconProps) => (
  <svg {...base(size)} {...p}>
    <circle cx="6" cy="8" r="2.2" />
    <circle cx="18" cy="7" r="2.2" />
    <circle cx="12" cy="17" r="2.2" />
    <path d="M8 9.2l2.6 5.4M16.2 8.8l-2.4 5.6" />
  </svg>
);
export const IconClock = ({ size = 18, ...p }: IconProps) => (
  <svg {...base(size)} {...p}>
    <circle cx="12" cy="12" r="8" />
    <path d="M12 8v4.5l3 2" />
  </svg>
);
export const IconChart = ({ size = 18, ...p }: IconProps) => (
  <svg {...base(size)} {...p}>
    <path d="M4 18h16" />
    <path d="M5 14l4-4 3 2.5 7-7" />
  </svg>
);
export const IconBars = ({ size = 18, ...p }: IconProps) => (
  <svg {...base(size)} {...p}>
    <path d="M5 18V10M12 18V6M19 18v-7" />
  </svg>
);
export const IconBacktest = ({ size = 18, ...p }: IconProps) => (
  <svg {...base(size)} {...p}>
    <path d="M4 16c2-6 5-9 8-9s6 3 8 9" />
    <path d="M4 16h16" />
  </svg>
);
export const IconSettings = ({ size = 18, ...p }: IconProps) => (
  <svg {...base(size)} {...p}>
    <circle cx="12" cy="12" r="3" />
    <path d="M12 3.5v2.2M12 18.3v2.2M4.8 6.5l1.6 1.6M17.6 16.9l1.6 1.6M3.5 12h2.2M18.3 12h2.2M4.8 17.5l1.6-1.6M17.6 7.1l1.6-1.6" />
  </svg>
);
export const IconExport = ({ size = 18, ...p }: IconProps) => (
  <svg {...base(size)} {...p}>
    <path d="M12 14V4" />
    <path d="M8 8l4-4 4 4" />
    <path d="M5 18h14" />
  </svg>
);
export const IconMenu = ({ size = 18, ...p }: IconProps) => (
  <svg {...base(size)} {...p}>
    <path d="M4 7h16M4 12h16M4 17h16" />
  </svg>
);
export const IconCheck = ({ size = 18, ...p }: IconProps) => (
  <svg {...base(size)} {...p}>
    <path d="M5 12.5l4.2 4.2L19 7.5" />
  </svg>
);
export const IconX = ({ size = 18, ...p }: IconProps) => (
  <svg {...base(size)} {...p}>
    <path d="M6 6l12 12M18 6L6 18" />
  </svg>
);
export const IconPlus = ({ size = 18, ...p }: IconProps) => (
  <svg {...base(size)} {...p}>
    <path d="M12 5v14M5 12h14" />
  </svg>
);
export const IconMinus = ({ size = 18, ...p }: IconProps) => (
  <svg {...base(size)} {...p}>
    <path d="M5 12h14" />
  </svg>
);
export const IconCalendar = ({ size = 18, ...p }: IconProps) => (
  <svg {...base(size)} {...p}>
    <rect x="4" y="5" width="16" height="15" rx="2" />
    <path d="M8 3v4M16 3v4M4 10h16" />
  </svg>
);
export const IconAlert = ({ size = 18, ...p }: IconProps) => (
  <svg {...base(size)} {...p}>
    <path d="M12 4l9 16H3L12 4z" />
    <path d="M12 10v4M12 17h.01" />
  </svg>
);
export const IconInfo = ({ size = 18, ...p }: IconProps) => (
  <svg {...base(size)} {...p}>
    <circle cx="12" cy="12" r="8" />
    <path d="M12 11v5M12 8h.01" />
  </svg>
);
export const IconBook = ({ size = 18, ...p }: IconProps) => (
  <svg {...base(size)} {...p}>
    <path d="M5 5.5A2.5 2.5 0 017.5 3H20v16H7.5A2.5 2.5 0 005 16.5v-11z" />
    <path d="M5 16.5A2.5 2.5 0 017.5 19H20" />
  </svg>
);
export const IconChat = ({ size = 18, ...p }: IconProps) => (
  <svg {...base(size)} {...p}>
    <path d="M5 6h14v10H8l-3 3V6z" />
  </svg>
);
export const IconPhone = ({ size = 18, ...p }: IconProps) => (
  <svg {...base(size)} {...p}>
    <path d="M7 3.5h3.2l1 4-2.2 1.4a12 12 0 006.1 6.1l1.4-2.2 4 1V17a2 2 0 01-2.2 2A16 16 0 015 6.2 2 2 0 017 4.1V3.5z" />
  </svg>
);
export const IconRefresh = ({ size = 18, ...p }: IconProps) => (
  <svg {...base(size)} {...p}>
    <path d="M20 12a8 8 0 10-2.2 5.5" />
    <path d="M20 12V6m0 6h-6" />
  </svg>
);
export const IconGear = ({ size = 18, ...p }: IconProps) => (
  <svg {...base(size)} {...p}>
    <circle cx="12" cy="12" r="3.2" />
    <path d="M12 2.8l1.2 2.2 2.4-.4 1.2 2.2 2.2 1.2-.4 2.4 2.2 1.2-2.2 1.2.4 2.4-2.2 1.2-1.2 2.2-2.4-.4-1.2 2.2-1.2-2.2-2.4.4-1.2-2.2-2.2-1.2.4-2.4-2.2-1.2 2.2-1.2-.4-2.4 2.2-1.2 1.2-2.2 2.4.4L12 2.8z" />
  </svg>
);
export const IconLogout = ({ size = 18, ...p }: IconProps) => (
  <svg {...base(size)} {...p}>
    <path d="M10 7V5a2 2 0 012-2h7v18h-7a2 2 0 01-2-2v-2" />
    <path d="M4 12h10M10 8l4 4-4 4" />
  </svg>
);
export const IconHeart = ({ size = 18, ...p }: IconProps) => (
  <svg {...base(size)} {...p}>
    <path d="M12 20s-7-4.4-7-10a4 4 0 017-2 4 4 0 017 2c0 5.6-7 10-7 10z" />
  </svg>
);
export const IconLayers = ({ size = 18, ...p }: IconProps) => (
  <svg {...base(size)} {...p}>
    <path d="M12 4l8 4-8 4-8-4 8-4z" />
    <path d="M4 12l8 4 8-4" />
    <path d="M4 16l8 4 8-4" />
  </svg>
);
export const IconArrowUp = ({ size = 14, ...p }: IconProps) => (
  <svg {...base(size)} {...p}>
    <path d="M12 18V6M7 11l5-5 5 5" />
  </svg>
);
export const IconArrowDown = ({ size = 14, ...p }: IconProps) => (
  <svg {...base(size)} {...p}>
    <path d="M12 6v12M7 13l5 5 5-5" />
  </svg>
);
export const IconEqual = ({ size = 14, ...p }: IconProps) => (
  <svg {...base(size)} {...p}>
    <path d="M6 10h12M6 14h12" />
  </svg>
);
export const IconWifi = ({ size = 16, ...p }: IconProps) => (
  <svg {...base(size)} strokeWidth={2.2} {...p}>
    <path d="M5 12.5a9 9 0 0114 0" />
    <path d="M8.2 15.2a5.2 5.2 0 017.6 0" />
    <circle cx="12" cy="18" r="1" fill="currentColor" stroke="none" />
  </svg>
);
export const IconBattery = ({ size = 22, ...p }: IconProps) => (
  <svg width={size} height={size * 0.5} viewBox="0 0 28 14" fill="currentColor" {...p}>
    <rect x="0.6" y="1.2" width="24" height="11.6" rx="2.4" fill="none" stroke="currentColor" strokeWidth="1.6" />
    <rect x="2.4" y="3.2" width="18" height="7.6" rx="1.2" />
    <rect x="25.2" y="4.4" width="2.2" height="5.2" rx="0.8" />
  </svg>
);
export const IconSignal = ({ size = 16, ...p }: IconProps) => (
  <svg width={size} height={size} viewBox="0 0 18 14" fill="currentColor" {...p}>
    <rect x="0" y="9" width="3" height="5" rx="0.6" />
    <rect x="5" y="6.5" width="3" height="7.5" rx="0.6" />
    <rect x="10" y="3.5" width="3" height="10.5" rx="0.6" />
    <rect x="15" y="0.5" width="3" height="13.5" rx="0.6" opacity="0.35" />
  </svg>
);

export function CategoryGlyph({
  category,
  size = 36,
}: {
  category: 'crypto' | 'forex' | 'stock' | 'commodity';
  size?: number;
}) {
  const wrap: Record<string, string> = {
    crypto: 'from-orange-400 to-amber-500',
    forex: 'from-teal-400 to-cyan-500',
    stock: 'from-violet-500 to-fuchsia-500',
    commodity: 'from-yellow-400 to-amber-500',
  };
  return (
    <div
      className={`flex items-center justify-center rounded-full bg-gradient-to-br ${wrap[category]} text-white shadow-lg`}
      style={{ width: size, height: size }}
    >
      {category === 'crypto' && (
        <svg width={size * 0.5} height={size * 0.5} viewBox="0 0 24 24" fill="currentColor">
          <path d="M14.5 11.4c1.7-.4 2.7-1.4 2.7-2.9 0-2-1.6-3.2-4.2-3.4V3h-2.1v2h-1.3V3H7.5v2H4.8l.4 2.2h1.6v8.6H4.8L4.4 18h3.1v2h2.1v-2h1.3v2h2.1v-2.1c3 .2 5-1.1 5-3.5 0-1.8-1.1-2.8-3-3.2zM9.3 7.2h2.6c1.3 0 2.1.5 2.1 1.5s-.8 1.6-2.3 1.6H9.3V7.2zm3.2 8.6H9.3v-3.3h3.3c1.6 0 2.4.6 2.4 1.7s-.9 1.6-2.5 1.6z" />
        </svg>
      )}
      {category === 'forex' && <span className="text-[15px] font-bold leading-none">£</span>}
      {category === 'stock' && (
        <svg width={size * 0.48} height={size * 0.48} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2">
          <path d="M4 16l5-5 3 3 8-8" />
          <path d="M14 6h6v6" />
        </svg>
      )}
      {category === 'commodity' && (
        <svg width={size * 0.5} height={size * 0.5} viewBox="0 0 24 24" fill="currentColor">
          <ellipse cx="12" cy="7" rx="7" ry="3" />
          <path d="M5 7v4c0 1.7 3.1 3 7 3s7-1.3 7-3V7" opacity="0.85" />
          <path d="M5 11v4c0 1.7 3.1 3 7 3s7-1.3 7-3v-4" opacity="0.7" />
        </svg>
      )}
    </div>
  );
}

export function AssetGlyph({ symbol }: { symbol: string; category?: string }) {
  const map: Record<string, { bg: string; label: string }> = {
    BTC: { bg: 'from-orange-400 to-amber-600', label: '₿' },
    ETH: { bg: 'from-indigo-400 to-violet-600', label: '◆' },
    SOL: { bg: 'from-fuchsia-500 to-purple-700', label: 'S' },
    BNB: { bg: 'from-yellow-400 to-amber-600', label: 'B' },
    EURUSD: { bg: 'from-blue-500 to-indigo-600', label: '€' },
    GBPUSD: { bg: 'from-teal-400 to-cyan-600', label: '£' },
    USDJPY: { bg: 'from-rose-400 to-red-600', label: '¥' },
    AAPL: { bg: 'from-slate-200 to-slate-400', label: '' },
    MSFT: { bg: 'from-sky-500 to-blue-700', label: 'M' },
    XAUUSD: { bg: 'from-yellow-300 to-amber-500', label: 'Au' },
    WTI: { bg: 'from-stone-500 to-stone-800', label: '🛢' },
  };
  const g = map[symbol] ?? { bg: 'from-slate-500 to-slate-700', label: symbol[0] };
  return (
    <div
      className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-gradient-to-br ${g.bg} text-[15px] font-bold text-white shadow`}
    >
      {symbol === 'AAPL' ? (
        <svg width="18" height="18" viewBox="0 0 24 24" fill="black">
          <path d="M16.7 12.4c0-2.4 2-3.6 2.1-3.7-1.1-1.7-2.9-1.9-3.5-1.9-1.5-.2-2.9.9-3.6.9s-1.9-.9-3.2-.8c-1.6.1-3.1 1-3.9 2.5-1.7 2.9-.4 7.2 1.2 9.6.8 1.1 1.7 2.4 3 2.4 1.2 0 1.6-.7 3.1-.7s1.8.7 3.1.7 2.1-1.2 2.9-2.4c.9-1.3 1.3-2.6 1.3-2.7-.03-.01-2.5-1-2.5-3.9zM14.4 5.8c.6-.8 1.1-1.9.9-3-.9 0-2 .6-2.6 1.4-.6.7-1.1 1.8-.9 2.9 1 .1 2-.5 2.6-1.3z" />
        </svg>
      ) : symbol === 'ETH' ? (
        <svg width="14" height="18" viewBox="0 0 16 24" fill="white">
          <path d="M8 0l-.2 8.2L0 10.8 8 0zM8 0l8 10.8-7.8-2.6L8 0z" opacity="0.7" />
          <path d="M8 8.8L0 10.8 8 15.4V8.8zM8 8.8v6.6l8-4.6-8-2z" />
          <path d="M8 16.7L.1 12.2 8 24l7.9-11.8L8 16.7z" />
        </svg>
      ) : (
        g.label
      )}
    </div>
  );
}

export function BrandMark({ brand }: { brand: DataProviderBrand }) {
  if (brand === 'yahoo') {
    return (
      <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-br from-violet-500 to-purple-700 text-white">
        <IconChart size={20} />
      </div>
    );
  }
  if (brand === 'binance') {
    return (
      <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-[#1a1a2e]">
        <svg width="22" height="22" viewBox="0 0 24 24">
          <path fill="#F3BA2F" d="M12 3.2l2.7 2.7-2.7 2.7-2.7-2.7L12 3.2zm-6.1 6.1l2.7 2.7-2.7 2.7-2.7-2.7 2.7-2.7zm12.2 0l2.7 2.7-2.7 2.7-2.7-2.7 2.7-2.7zM12 9.3l2.7 2.7-2.7 2.7-2.7-2.7L12 9.3zm0 6.1l2.7 2.7-2.7 2.7-2.7-2.7 2.7-2.7z" />
        </svg>
      </div>
    );
  }
  if (brand === 'kraken') {
    return (
      <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-br from-indigo-500 to-purple-800 text-xl font-black text-white">
        ⬡
      </div>
    );
  }
  if (brand === 'iress') {
    return (
      <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-br from-sky-500 to-blue-700 text-white">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
          <circle cx="12" cy="12" r="8" />
          <path d="M4 12h16M12 4c2.5 3 2.5 13 0 16M12 4c-2.5 3-2.5 13 0 16" />
        </svg>
      </div>
    );
  }
  return (
    <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-br from-emerald-400 to-teal-700 text-white">
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <path d="M4 16l5-8 4 5 3-4 4 7" />
      </svg>
    </div>
  );
}

type DataProviderBrand = 'yahoo' | 'binance' | 'kraken' | 'iress' | 'forex';

export function LogoMark({ size = 56 }: { size?: number }) {
  return (
    <div className="relative drop-shadow-[0_0_18px_rgba(74,222,128,0.35)]" style={{ width: size, height: size }}>
      <svg viewBox="0 0 64 64" width={size} height={size}>
        <defs>
          <linearGradient id="lg" x1="0" y1="1" x2="1" y2="0">
            <stop offset="0%" stopColor="#14b8a6" />
            <stop offset="100%" stopColor="#4ade80" />
          </linearGradient>
        </defs>
        <path d="M6 48 L18 28 L28 38 L40 16 L58 16" fill="none" stroke="url(#lg)" strokeWidth="5" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M46 8h14v14" fill="none" stroke="#4ade80" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M6 52h52" stroke="#4ade80" strokeWidth="2" opacity="0.25" />
      </svg>
    </div>
  );
}
