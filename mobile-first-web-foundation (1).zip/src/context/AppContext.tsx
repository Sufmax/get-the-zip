import { createContext, useCallback, useContext, useMemo, useState, type ReactNode } from 'react';
import { defaultExport, defaultPeriod, defaultSettings } from '../services/api';
import type {
  AppSettings,
  Asset,
  AssetCategory,
  ExportConfig,
  PatternMatch,
  PatternZone,
  PeriodConfig,
  ScreenId,
  SelectionMode,
  Timeframe,
} from '../types';

interface AppState {
  screen: ScreenId;
  history: ScreenId[];
  selectedCategory: AssetCategory | 'all';
  selectedAsset: Asset | null;
  timeframe: Timeframe;
  selectionMode: SelectionMode;
  zone: PatternZone;
  selectedMatch: PatternMatch | null;
  matches: PatternMatch[];
  period: PeriodConfig;
  settings: AppSettings;
  exportConfig: ExportConfig;
  favorites: string[];
  helpArticleId: string | null;
  analyzing: boolean;
}

interface AppContextValue extends AppState {
  navigate: (s: ScreenId, opts?: { replace?: boolean }) => void;
  back: () => void;
  setCategory: (c: AssetCategory | 'all') => void;
  selectAsset: (a: Asset) => void;
  setTimeframe: (t: Timeframe) => void;
  setSelectionMode: (m: SelectionMode) => void;
  setZone: (z: PatternZone) => void;
  setMatches: (m: PatternMatch[]) => void;
  selectMatch: (m: PatternMatch) => void;
  setPeriod: (p: PeriodConfig) => void;
  setSettings: (s: AppSettings) => void;
  setExportConfig: (e: ExportConfig) => void;
  toggleFavorite: (id: string) => void;
  setHelpArticleId: (id: string | null) => void;
  setAnalyzing: (v: boolean) => void;
  resetSession: () => void;
}

const AppContext = createContext<AppContextValue | null>(null);

const initial: AppState = {
  screen: 'welcome',
  history: [],
  selectedCategory: 'all',
  selectedAsset: null,
  timeframe: '1h',
  selectionMode: 'auto',
  zone: { startIndex: 52, endIndex: 76 },
  selectedMatch: null,
  matches: [],
  period: defaultPeriod(),
  settings: defaultSettings(),
  exportConfig: defaultExport(),
  favorites: ['btc-usdt'],
  helpArticleId: null,
  analyzing: false,
};

export function AppProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<AppState>(initial);

  const navigate = useCallback((s: ScreenId, opts?: { replace?: boolean }) => {
    setState((prev) => {
      if (opts?.replace) return { ...prev, screen: s };
      if (prev.screen === s) return prev;
      return { ...prev, history: [...prev.history, prev.screen], screen: s };
    });
  }, []);

  const back = useCallback(() => {
    setState((prev) => {
      if (!prev.history.length) return { ...prev, screen: 'welcome' };
      const history = [...prev.history];
      const screen = history.pop()!;
      return { ...prev, history, screen };
    });
  }, []);

  const value = useMemo<AppContextValue>(
    () => ({
      ...state,
      navigate,
      back,
      setCategory: (c) => setState((p) => ({ ...p, selectedCategory: c })),
      selectAsset: (a) => setState((p) => ({ ...p, selectedAsset: a })),
      setTimeframe: (t) => setState((p) => ({ ...p, timeframe: t })),
      setSelectionMode: (m) => setState((p) => ({ ...p, selectionMode: m })),
      setZone: (z) => setState((p) => ({ ...p, zone: z })),
      setMatches: (m) => setState((p) => ({ ...p, matches: m })),
      selectMatch: (m) => setState((p) => ({ ...p, selectedMatch: m })),
      setPeriod: (period) => setState((p) => ({ ...p, period })),
      setSettings: (settings) => setState((p) => ({ ...p, settings })),
      setExportConfig: (exportConfig) => setState((p) => ({ ...p, exportConfig })),
      toggleFavorite: (id) =>
        setState((p) => ({
          ...p,
          favorites: p.favorites.includes(id) ? p.favorites.filter((x) => x !== id) : [...p.favorites, id],
        })),
      setHelpArticleId: (helpArticleId) => setState((p) => ({ ...p, helpArticleId })),
      setAnalyzing: (analyzing) => setState((p) => ({ ...p, analyzing })),
      resetSession: () => setState(initial),
    }),
    [navigate, back, state],
  );

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}
