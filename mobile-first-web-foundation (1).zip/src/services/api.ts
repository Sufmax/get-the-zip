/**
 * =============================================================================
 * Couche API MarketScope
 * =============================================================================
 * En mode présentation (USE_MOCK = true), chaque méthode renvoie des
 * données fictives avec un léger délai pour simuler le réseau.
 *
 * Pour brancher le backend :
 *  1. Passez USE_MOCK à false (ou définissez VITE_USE_MOCK=false)
 *  2. Renseignez VITE_API_URL
 *  3. Les signatures ci-dessous restent identiques — aucun écran à modifier
 * =============================================================================
 */

import {
  APP_UPDATED_AT,
  APP_VERSION,
  DEMO_ASSETS,
  DEMO_BACKTEST,
  DEMO_CHARTS,
  DEMO_CONDITIONS,
  DEMO_HELP,
  DEMO_MATCHES,
  DEMO_OUTCOME,
  DEMO_PROVIDERS,
  DEMO_SCENARIOS,
  DEMO_SYNC_STEPS,
  generateCandles,
} from '../data/mockData';
import type {
  AppSettings,
  Asset,
  AssetCategory,
  BacktestStats,
  Candle,
  ConditionItem,
  DataProvider,
  ExportConfig,
  HelpArticle,
  PatternMatch,
  PatternZone,
  PeriodConfig,
  Scenario,
  SyncStep,
  Timeframe,
} from '../types';

export const API_CONFIG = {
  /** true = données de présentation. false = appels HTTP réels. */
  USE_MOCK: (import.meta.env.VITE_USE_MOCK ?? 'true') !== 'false',
  BASE_URL: import.meta.env.VITE_API_URL || 'http://localhost:3000/api',
};

const wait = (ms = 180) => new Promise((r) => setTimeout(r, ms));

async function http<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${API_CONFIG.BASE_URL}${path}`, {
    headers: { 'Content-Type': 'application/json', ...(init?.headers || {}) },
    ...init,
  });
  if (!res.ok) {
    throw new Error(`API ${path} → ${res.status}`);
  }
  return res.json() as Promise<T>;
}

export const marketApi = {
  /** GET /assets?category=&q= */
  async listAssets(params?: { category?: AssetCategory | 'all'; query?: string }): Promise<Asset[]> {
    if (API_CONFIG.USE_MOCK) {
      await wait(120);
      let list = DEMO_ASSETS;
      if (params?.category && params.category !== 'all') {
        list = list.filter((a) => a.category === params.category);
      }
      if (params?.query) {
        const q = params.query.toLowerCase();
        list = list.filter(
          (a) =>
            a.symbol.toLowerCase().includes(q) ||
            a.name.toLowerCase().includes(q) ||
            a.pairLabel.toLowerCase().includes(q),
        );
      }
      return list;
    }
    const qs = new URLSearchParams();
    if (params?.category && params.category !== 'all') qs.set('category', params.category);
    if (params?.query) qs.set('q', params.query);
    return http(`/assets?${qs.toString()}`);
  },

  /** GET /assets/:id/candles?tf= */
  async getCandles(assetId: string, timeframe: Timeframe): Promise<Candle[]> {
    if (API_CONFIG.USE_MOCK) {
      await wait(160);
      const base = DEMO_CHARTS[assetId] ?? generateCandles({ count: 80, start: 100, seed: 1 });
      // La granularité n'est pas recalculée en démo ; le backend le fera.
      void timeframe;
      return base;
    }
    return http(`/assets/${assetId}/candles?tf=${timeframe}`);
  },

  /**
   * POST /analysis
   * Corps attendu : { assetId, timeframe, zone, mode, period }
   */
  async runAnalysis(_payload: {
    assetId: string;
    timeframe: Timeframe;
    zone: PatternZone;
    mode: 'auto' | 'manual';
    period: PeriodConfig;
  }): Promise<PatternMatch[]> {
    if (API_CONFIG.USE_MOCK) {
      await wait(420);
      return DEMO_MATCHES;
    }
    return http('/analysis', { method: 'POST', body: JSON.stringify(_payload) });
  },

  /** GET /analysis/matches/:id */
  async getMatch(id: string): Promise<PatternMatch | undefined> {
    if (API_CONFIG.USE_MOCK) {
      await wait(80);
      return DEMO_MATCHES.find((m) => m.id === id);
    }
    return http(`/analysis/matches/${id}`);
  },

  /** GET /analysis/matches/:id/scenarios */
  async getScenarios(_matchId: string): Promise<Scenario[]> {
    if (API_CONFIG.USE_MOCK) {
      await wait(100);
      return DEMO_SCENARIOS;
    }
    return http(`/analysis/matches/${_matchId}/scenarios`);
  },

  /** GET /analysis/matches/:id/conditions */
  async getConditions(_matchId: string): Promise<ConditionItem[]> {
    if (API_CONFIG.USE_MOCK) {
      await wait(80);
      return DEMO_CONDITIONS;
    }
    return http(`/analysis/matches/${_matchId}/conditions`);
  },

  /** GET /analysis/outcome?matchId= */
  async getOutcome(_matchId: string) {
    if (API_CONFIG.USE_MOCK) {
      await wait(80);
      return DEMO_OUTCOME;
    }
    return http<{ bullish: number; bearish: number; neutral: number }>(
      `/analysis/outcome?matchId=${_matchId}`,
    );
  },

  /** GET /backtest */
  async getBacktest(_settings: AppSettings): Promise<BacktestStats> {
    if (API_CONFIG.USE_MOCK) {
      await wait(260);
      return DEMO_BACKTEST;
    }
    return http('/backtest');
  },

  /** GET /providers */
  async listProviders(): Promise<DataProvider[]> {
    if (API_CONFIG.USE_MOCK) {
      await wait(80);
      return DEMO_PROVIDERS;
    }
    return http('/providers');
  },

  /** GET /help */
  async listHelp(): Promise<HelpArticle[]> {
    if (API_CONFIG.USE_MOCK) {
      return DEMO_HELP;
    }
    return http('/help');
  },

  async getHelpArticle(id: string): Promise<HelpArticle | undefined> {
    if (API_CONFIG.USE_MOCK) {
      return DEMO_HELP.find((h) => h.id === id);
    }
    return http(`/help/${id}`);
  },

  getSyncSteps(): SyncStep[] {
    return DEMO_SYNC_STEPS;
  },

  /**
   * POST /export
   * En démo : génère un fichier local à partir des options.
   */
  async exportResults(config: ExportConfig, payload: unknown): Promise<{ ok: true; filename: string }> {
    if (API_CONFIG.USE_MOCK) {
      await wait(500);
      const ext = config.format === 'image' ? 'png' : config.format;
      const filename = `marketscope-export.${ext}`;
      const blob = new Blob([JSON.stringify(payload, null, 2)], {
        type: config.format === 'csv' ? 'text/csv' : 'application/json',
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      a.click();
      URL.revokeObjectURL(url);
      return { ok: true, filename };
    }
    return http('/export', { method: 'POST', body: JSON.stringify(config) });
  },

  version() {
    return { version: APP_VERSION, updatedAt: APP_UPDATED_AT };
  },
};

export const defaultPeriod = (): PeriodConfig => ({
  mode: 'lastCandles',
  candleCount: 500,
  startDate: '2024-01-01',
  endDate: '2025-04-25',
  sinceDate: '2024-01-01',
});

export const defaultSettings = (): AppSettings => ({
  dataMode: 'auto',
  cloudflare: true,
  directProviders: true,
  localFolder: false,
  granularity: '1h',
  resultCount: 20,
  searchLimit: 500,
});

export const defaultExport = (): ExportConfig => ({
  format: 'pdf',
  includeCharts: true,
  includeMatches: true,
  includeScenarios: true,
  includeSettings: true,
});
