/**
 * MarketScope — socle frontend mobile-first (application de présentation).
 *
 * Navigation par état (pas de react-router) : facile à remplacer plus tard.
 * Données : src/data/mockData.ts (fictives) via src/services/api.ts.
 * Pour le backend : passer VITE_USE_MOCK=false et VITE_API_URL.
 */
import type { ComponentType } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { PhoneShell } from './components/layout/PhoneShell';
import { WelcomeScreen } from './screens/WelcomeScreen';
import { AssetSelectScreen } from './screens/AssetSelectScreen';
import { ChartScreen } from './screens/ChartScreen';
import { PatternSelectScreen } from './screens/PatternSelectScreen';
import { MatchesScreen } from './screens/MatchesScreen';
import { MatchDetailScreen } from './screens/MatchDetailScreen';
import { ScenariosScreen } from './screens/ScenariosScreen';
import { ConditionsScreen } from './screens/ConditionsScreen';
import { PeriodScreen } from './screens/PeriodScreen';
import { SettingsScreen } from './screens/SettingsScreen';
import { BacktestScreen } from './screens/BacktestScreen';
import { ExportScreen } from './screens/ExportScreen';
import { SyncScreen } from './screens/SyncScreen';
import { HelpScreen } from './screens/HelpScreen';
import { MenuScreen } from './screens/MenuScreen';
import { DataSourcesScreen } from './screens/DataSourcesScreen';
import { FavoritesScreen, HistoryScreen } from './screens/FavoritesScreen';
import type { ScreenId } from './types';

const SCREENS: Record<ScreenId, ComponentType> = {
  welcome: WelcomeScreen,
  assets: AssetSelectScreen,
  chart: ChartScreen,
  pattern: PatternSelectScreen,
  matches: MatchesScreen,
  matchDetail: MatchDetailScreen,
  scenarios: ScenariosScreen,
  conditions: ConditionsScreen,
  period: PeriodScreen,
  settings: SettingsScreen,
  backtest: BacktestScreen,
  export: ExportScreen,
  sync: SyncScreen,
  help: HelpScreen,
  helpArticle: HelpScreen,
  menu: MenuScreen,
  dataSources: DataSourcesScreen,
  favorites: FavoritesScreen,
  history: HistoryScreen,
};

function ScreenRouter() {
  const { screen } = useApp();
  const View = SCREENS[screen] ?? WelcomeScreen;
  return <View />;
}

export default function App() {
  return (
    <AppProvider>
      <PhoneShell>
        <ScreenRouter />
      </PhoneShell>
    </AppProvider>
  );
}
