import { useState } from 'react';
import { CandlestickChart } from '../components/chart/CandlestickChart';
import { IconCheck } from '../components/icons';
import { ScreenHeader } from '../components/ui/primitives';
import { useApp } from '../context/AppContext';
import { cn } from '../utils/cn';

export function MatchDetailScreen() {
  const { selectedMatch, matches, selectMatch, navigate, back } = useApp();
  const match = selectedMatch ?? matches[0];
  const [tab, setTab] = useState<'vue' | 'details' | 'evo'>('vue');

  if (!match) {
    return (
      <div className="flex flex-1 flex-col">
        <ScreenHeader title="Correspondance" onBack={back} />
        <p className="p-6 text-center text-slate-400">Aucune correspondance sélectionnée.</p>
      </div>
    );
  }

  const scoreLabel =
    match.score >= 9.5 ? 'Excellente correspondance' : match.score >= 8.5 ? 'Très bonne correspondance' : 'Correspondance correcte';

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <ScreenHeader title={`Correspondance #${match.rank}`} onBack={back} />

      <div className="flex flex-col items-center px-5">
        <div className="flex items-center gap-2">
          <span className="flex h-7 w-7 items-center justify-center rounded-full bg-emerald-500/20 text-emerald-400">
            <IconCheck size={16} />
          </span>
          <span className="text-[32px] font-bold tracking-tight text-emerald-400">
            {match.score.toFixed(1).replace('.', ',')}
            <span className="text-[16px] text-slate-400"> /10</span>
          </span>
        </div>
        <p className="text-[13px] text-emerald-400/90">{scoreLabel}</p>
      </div>

      <div className="mx-5 mt-3 flex rounded-full bg-[#0c1a2e] p-1">
        {[
          { id: 'vue' as const, label: 'Vue' },
          { id: 'details' as const, label: 'Détails' },
          { id: 'evo' as const, label: 'Évolution' },
        ].map((t) => (
          <button
            key={t.id}
            onClick={() => {
              if (t.id === 'evo') navigate('scenarios');
              else setTab(t.id);
            }}
            className={cn(
              'flex-1 rounded-full py-1.5 text-[13px] font-semibold',
              tab === t.id ? 'bg-[#1a3358] text-white' : 'text-slate-400',
            )}
          >
            {t.label}
          </button>
        ))}
      </div>

      <div className="mt-3 px-2">
        <div className="mb-1 flex items-center justify-center gap-4 text-[11px] text-slate-400">
          <span className="flex items-center gap-1">
            <span className="h-2 w-2 rounded-full bg-emerald-400" /> Pattern
          </span>
          <span className="flex items-center gap-1">
            <span className="h-2 w-2 rounded-full bg-sky-400" /> Correspondance
          </span>
        </div>
        <CandlestickChart
          candles={match.candles}
          compareCandles={match.followThrough}
          height={200}
          showVolume={false}
          variant="compare"
        />
        <div className="mt-1 flex justify-center gap-2">
          <span className="rounded-full bg-[#15263d] px-3 py-0.5 text-[11px] text-slate-300">Raffiné</span>
          <span className="rounded-full bg-cyan-500/15 px-3 py-0.5 text-[11px] text-cyan-300">Correspondance</span>
        </div>
      </div>

      {tab === 'details' ? (
        <div className="mt-4 px-5 text-[13px] leading-relaxed text-slate-400">
          <p>
            Correspondance historique du {match.date} sur {match.candleCount} bougies. Score de similarité{' '}
            {match.score.toFixed(1).replace('.', ',')}/10 (données de présentation).
          </p>
          <button
            className="mt-3 text-[13px] font-semibold text-cyan-300"
            onClick={() => {
              const idx = matches.findIndex((x) => x.id === match.id);
              const next = matches[idx + 1] ?? matches[0];
              if (next) selectMatch(next);
            }}
          >
            Voir la correspondance suivante
          </button>
        </div>
      ) : (
        <div className="mt-4 px-5">
          <h3 className="mb-2 text-[14px] font-semibold text-white">Points forts</h3>
          <ul className="space-y-2">
            {match.strengths.map((s) => (
              <li key={s} className="flex items-center gap-2 text-[13px] text-slate-200">
                <span className="flex h-5 w-5 items-center justify-center rounded-full bg-emerald-500/20 text-emerald-400">
                  <IconCheck size={12} />
                </span>
                {s}
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
