import * as THREE from 'three';

interface Particle {
  pos: THREE.Vector3;
  vel: THREE.Vector3;
  color: THREE.Color;
  size: number;
  alpha: number;
  life: number;
  maxLife: number;
}

export class ParticleSystem {
  private particles: Particle[] = [];
  private maxParticles = 400;
  private pGeo: THREE.BufferGeometry;
  private pMat: THREE.PointsMaterial;
  private pSystem: THREE.Points;

  private flameGeo: THREE.BufferGeometry;
  private flameMat: THREE.PointsMaterial;
  private flameSystem: THREE.Points;
  private flameParticles: Particle[] = [];

  constructor(scene: THREE.Scene) {
    // 1. General Particles (Smoke & Sparks)
    this.pGeo = new THREE.BufferGeometry();
    const positions = new Float32Array(this.maxParticles * 3);
    const colors = new Float32Array(this.maxParticles * 3);
    this.pGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    this.pGeo.setAttribute('color', new THREE.BufferAttribute(colors, 3));

    this.pMat = new THREE.PointsMaterial({
      size: 0.9,
      vertexColors: true,
      transparent: true,
      opacity: 0.75,
      blending: THREE.NormalBlending,
      depthWrite: false,
    });

    this.pSystem = new THREE.Points(this.pGeo, this.pMat);
    scene.add(this.pSystem);

    // 2. Nitro Flame Particles
    this.flameGeo = new THREE.BufferGeometry();
    const flamePositions = new Float32Array(120 * 3);
    const flameColors = new Float32Array(120 * 3);
    this.flameGeo.setAttribute('position', new THREE.BufferAttribute(flamePositions, 3));
    this.flameGeo.setAttribute('color', new THREE.BufferAttribute(flameColors, 3));

    this.flameMat = new THREE.PointsMaterial({
      size: 0.8,
      vertexColors: true,
      transparent: true,
      opacity: 0.9,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });

    this.flameSystem = new THREE.Points(this.flameGeo, this.flameMat);
    scene.add(this.flameSystem);
  }

  public emitSmoke(pos: THREE.Vector3, carVel: THREE.Vector3) {
    if (this.particles.length >= this.maxParticles) return;

    this.particles.push({
      pos: pos.clone().add(new THREE.Vector3((Math.random() - 0.5) * 0.4, 0.1, (Math.random() - 0.5) * 0.4)),
      vel: new THREE.Vector3(
        carVel.x * 0.2 + (Math.random() - 0.5) * 1.5,
        0.8 + Math.random() * 0.8,
        carVel.z * 0.2 + (Math.random() - 0.5) * 1.5
      ),
      color: new THREE.Color(0.85, 0.88, 0.92),
      size: 0.8 + Math.random() * 0.6,
      alpha: 0.6,
      life: 0,
      maxLife: 0.7 + Math.random() * 0.4,
    });
  }

  public emitSparks(pos: THREE.Vector3, normal: THREE.Vector3, count = 12) {
    for (let i = 0; i < count; i++) {
      if (this.particles.length >= this.maxParticles) break;

      const spread = new THREE.Vector3((Math.random() - 0.5) * 2, (Math.random() - 0.5) * 2, (Math.random() - 0.5) * 2);
      const vel = normal.clone().multiplyScalar(6 + Math.random() * 8).add(spread);

      this.particles.push({
        pos: pos.clone().add(new THREE.Vector3((Math.random() - 0.5) * 0.3, 0.2, (Math.random() - 0.5) * 0.3)),
        vel,
        color: new THREE.Color(1.0, 0.7 + Math.random() * 0.3, 0.1), // Bright amber spark
        size: 0.5,
        alpha: 1.0,
        life: 0,
        maxLife: 0.25 + Math.random() * 0.3,
      });
    }
  }

  public updateNitroFlames(exhaustWorldPos: THREE.Vector3[], carFwd: THREE.Vector3, isNitroActive: boolean) {
    if (isNitroActive) {
      for (const pt of exhaustWorldPos) {
        if (this.flameParticles.length >= 100) break;
        // Flame shoots out opposite to car forward
        const flameVel = carFwd.clone().multiplyScalar(-14 - Math.random() * 8);
        this.flameParticles.push({
          pos: pt.clone().add(new THREE.Vector3((Math.random() - 0.5) * 0.1, (Math.random() - 0.5) * 0.1, (Math.random() - 0.5) * 0.1)),
          vel: flameVel,
          color: Math.random() > 0.4 ? new THREE.Color(0.1, 0.75, 1.0) : new THREE.Color(0.9, 0.3, 1.0),
          size: 0.7,
          alpha: 1.0,
          life: 0,
          maxLife: 0.12 + Math.random() * 0.08,
        });
      }
    }
  }

  public update(dt: number) {
    // 1. General particles update
    const posAttr = this.pGeo.attributes.position as THREE.BufferAttribute;
    const colAttr = this.pGeo.attributes.color as THREE.BufferAttribute;
    const posArray = posAttr.array as Float32Array;
    const colArray = colAttr.array as Float32Array;

    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.life += dt;
      if (p.life >= p.maxLife) {
        this.particles.splice(i, 1);
        continue;
      }

      p.pos.addScaledVector(p.vel, dt);
      p.vel.y -= 3.5 * dt; // gravity

      const progress = p.life / p.maxLife;
      const alpha = (1 - progress);

      const idx = i * 3;
      posArray[idx] = p.pos.x;
      posArray[idx + 1] = p.pos.y;
      posArray[idx + 2] = p.pos.z;

      colArray[idx] = p.color.r * alpha;
      colArray[idx + 1] = p.color.g * alpha;
      colArray[idx + 2] = p.color.b * alpha;
    }

    // Zero out unused slots
    for (let i = this.particles.length; i < this.maxParticles; i++) {
      const idx = i * 3;
      posArray[idx] = 0;
      posArray[idx + 1] = -999;
      posArray[idx + 2] = 0;
    }

    posAttr.needsUpdate = true;
    colAttr.needsUpdate = true;

    // 2. Nitro Flames update
    const fPosAttr = this.flameGeo.attributes.position as THREE.BufferAttribute;
    const fColAttr = this.flameGeo.attributes.color as THREE.BufferAttribute;
    const fPosArray = fPosAttr.array as Float32Array;
    const fColArray = fColAttr.array as Float32Array;

    for (let i = this.flameParticles.length - 1; i >= 0; i--) {
      const p = this.flameParticles[i];
      p.life += dt;
      if (p.life >= p.maxLife) {
        this.flameParticles.splice(i, 1);
        continue;
      }

      p.pos.addScaledVector(p.vel, dt);

      const idx = i * 3;
      fPosArray[idx] = p.pos.x;
      fPosArray[idx + 1] = p.pos.y;
      fPosArray[idx + 2] = p.pos.z;

      fColArray[idx] = p.color.r;
      fColArray[idx + 1] = p.color.g;
      fColArray[idx + 2] = p.color.b;
    }

    for (let i = this.flameParticles.length; i < 120; i++) {
      const idx = i * 3;
      fPosArray[idx] = 0;
      fPosArray[idx + 1] = -999;
      fPosArray[idx + 2] = 0;
    }

    fPosAttr.needsUpdate = true;
    fColAttr.needsUpdate = true;
  }
}
