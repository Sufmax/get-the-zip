/**
 * =============================================================================
 * DONNÉES DE PRÉSENTATION — MarketScope (démo)
 * =============================================================================
 * Toutes les valeurs ci-dessous sont FICTIVES et destinées uniquement
 * à l'application de présentation. Elles devront être remplacées par
 * les réponses du backend (voir src/services/api.ts).
 *
 * Ne pas utiliser ces chiffres comme des cours réels.
 * =============================================================================
 */

import type {
  Asset,
  BacktestStats,
  Candle,
  ConditionItem,
  DataProvider,
  HelpArticle,
  PatternMatch,
  Scenario,
  SyncStep,
} from '../types';

/** Générateur pseudo-aléatoire déterministe pour des graphiques stables. */
function mulberry32(seed: number) {
  return () => {
    let t = (seed += 0x6d2b79f5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function generateCandles(options: {
  count: number;
  start: number;
  seed: number;
  volatility?: number;
  startTs?: number;
  stepMs?: number;
  bullishBias?: number;
}): Candle[] {
  const {
    count,
    start,
    seed,
    volatility = 0.012,
    startTs = Date.UTC(2024, 3, 10),
    stepMs = 60 * 60 * 1000,
    bullishBias = 0.0004,
  } = options;
  const rand = mulberry32(seed);
  const candles: Candle[] = [];
  let price = start;

  for (let i = 0; i < count; i++) {
    const drift = (rand() - 0.48 + bullishBias) * volatility * price;
    const open = price;
    const close = Math.max(price * 0.2, open + drift);
    const wick = volatility * price * (0.25 + rand() * 0.9);
    const high = Math.max(open, close) + wick * rand();
    const low = Math.min(open, close) - wick * rand();
    const volume = 800 + rand() * 4200 + (close > open ? 600 : 0);
    candles.push({
      timestamp: startTs + i * stepMs,
      open,
      high,
      low,
      close,
      volume,
    });
    price = close;
  }
  return candles;
}

/** Cours fictifs pour la démo — ne pas considérer comme des prix marché. */
export const DEMO_ASSETS: Asset[] = [
  {
    id: 'btc-usdt',
    symbol: 'BTC',
    name: 'Bitcoin',
    category: 'crypto',
    price: 68542.32,
    change24h: 2.14,
    quoteCurrency: 'USD',
    exchange: 'Binance',
    pairLabel: 'BTC/USDT',
    decimals: 2,
  },
  {
    id: 'eth-usdt',
    symbol: 'ETH',
    name: 'Ethereum',
    category: 'crypto',
    price: 3246.77,
    change24h: 1.85,
    quoteCurrency: 'USD',
    exchange: 'Binance',
    pairLabel: 'ETH/USDT',
    decimals: 2,
  },
  {
    id: 'sol-usdt',
    symbol: 'SOL',
    name: 'Solana',
    category: 'crypto',
    price: 158.42,
    change24h: 3.21,
    quoteCurrency: 'USD',
    exchange: 'Binance',
    pairLabel: 'SOL/USDT',
    decimals: 2,
  },
  {
    id: 'bnb-usdt',
    symbol: 'BNB',
    name: 'BNB',
    category: 'crypto',
    price: 574.18,
    change24h: 0.92,
    quoteCurrency: 'USD',
    exchange: 'Binance',
    pairLabel: 'BNB/USDT',
    decimals: 2,
  },
  {
    id: 'eurusd',
    symbol: 'EURUSD',
    name: 'EUR / USD',
    category: 'forex',
    price: 1.0823,
    change24h: -1.12,
    quoteCurrency: '',
    exchange: 'Forex',
    pairLabel: 'EUR/USD',
    decimals: 4,
  },
  {
    id: 'gbpusd',
    symbol: 'GBPUSD',
    name: 'GBP / USD',
    category: 'forex',
    price: 1.2698,
    change24h: -0.08,
    quoteCurrency: '',
    exchange: 'Forex',
    pairLabel: 'GBP/USD',
    decimals: 4,
  },
  {
    id: 'usdjpy',
    symbol: 'USDJPY',
    name: 'USD / JPY',
    category: 'forex',
    price: 154.82,
    change24h: 0.34,
    quoteCurrency: '',
    exchange: 'Forex',
    pairLabel: 'USD/JPY',
    decimals: 2,
  },
  {
    id: 'aapl',
    symbol: 'AAPL',
    name: 'Apple',
    category: 'stock',
    price: 189.32,
    change24h: 0.76,
    quoteCurrency: 'USD',
    exchange: 'NASDAQ',
    pairLabel: 'AAPL',
    decimals: 2,
  },
  {
    id: 'msft',
    symbol: 'MSFT',
    name: 'Microsoft',
    category: 'stock',
    price: 428.55,
    change24h: 1.12,
    quoteCurrency: 'USD',
    exchange: 'NASDAQ',
    pairLabel: 'MSFT',
    decimals: 2,
  },
  {
    id: 'xauusd',
    symbol: 'XAUUSD',
    name: 'Or',
    category: 'commodity',
    price: 2324.8,
    change24h: 0.48,
    quoteCurrency: 'USD',
    exchange: 'COMEX',
    pairLabel: 'XAU/USD',
    decimals: 2,
  },
  {
    id: 'wti',
    symbol: 'WTI',
    name: 'Pétrole WTI',
    category: 'commodity',
    price: 81.42,
    change24h: -0.63,
    quoteCurrency: 'USD',
    exchange: 'NYMEX',
    pairLabel: 'WTI',
    decimals: 2,
  },
];

const btcMain = generateCandles({
  count: 80,
  start: 61200,
  seed: 42,
  volatility: 0.011,
  startTs: Date.UTC(2024, 3, 10, 8),
  stepMs: 6 * 60 * 60 * 1000,
  bullishBias: 0.08,
});

/** Force la dernière bougie à coller au cours affiché (démo). */
btcMain[btcMain.length - 1] = {
  ...btcMain[btcMain.length - 1],
  close: 68542.32,
  high: Math.max(btcMain[btcMain.length - 1].high, 69280),
  open: 67890.1,
  low: Math.min(btcMain[btcMain.length - 1].low, 67120),
};

export const DEMO_CHARTS: Record<string, Candle[]> = {
  'btc-usdt': btcMain,
  'eth-usdt': generateCandles({ count: 80, start: 2980, seed: 7, volatility: 0.014 }),
  'sol-usdt': generateCandles({ count: 80, start: 142, seed: 11, volatility: 0.02 }),
  'bnb-usdt': generateCandles({ count: 80, start: 540, seed: 13, volatility: 0.012 }),
  eurusd: generateCandles({ count: 80, start: 1.095, seed: 17, volatility: 0.004, bullishBias: -0.1 }),
  gbpusd: generateCandles({ count: 80, start: 1.274, seed: 19, volatility: 0.0035 }),
  usdjpy: generateCandles({ count: 80, start: 151.2, seed: 23, volatility: 0.005 }),
  aapl: generateCandles({ count: 80, start: 178, seed: 29, volatility: 0.01 }),
  msft: generateCandles({ count: 80, start: 402, seed: 31, volatility: 0.009 }),
  xauusd: generateCandles({ count: 80, start: 2260, seed: 37, volatility: 0.007 }),
  wti: generateCandles({ count: 80, start: 84.5, seed: 41, volatility: 0.013, bullishBias: -0.05 }),
};

function miniPattern(seed: number, start: number, dir: 'up' | 'down' | 'flat'): Candle[] {
  const bias = dir === 'up' ? 0.25 : dir === 'down' ? -0.22 : 0;
  return generateCandles({
    count: 28,
    start,
    seed,
    volatility: 0.016,
    bullishBias: bias,
    startTs: Date.UTC(2023, 0, 1),
    stepMs: 24 * 60 * 60 * 1000,
  });
}

/** Correspondances historiques fictives (présentation). */
export const DEMO_MATCHES: PatternMatch[] = [
  {
    id: 'm1',
    rank: 1,
    score: 9.6,
    date: '14 février 2024',
    dateShort: '14 fév. 2024',
    candleCount: 38,
    direction: 'bullish',
    volumeTrend: 'up',
    candles: miniPattern(101, 42000, 'up'),
    followThrough: generateCandles({
      count: 40,
      start: 68542,
      seed: 201,
      volatility: 0.01,
      bullishBias: 0.18,
    }),
    strengths: [
      'Même structure de mouvement',
      'Amplitude similaire (+2,3%)',
      'Volatilité comparable',
      'Volume en hausse',
    ],
  },
  {
    id: 'm2',
    rank: 2,
    score: 9.2,
    date: '3 janvier 2024',
    dateShort: '3 jan. 2024',
    candleCount: 36,
    direction: 'bullish',
    volumeTrend: 'up',
    candles: miniPattern(102, 39800, 'up'),
    followThrough: generateCandles({ count: 40, start: 68542, seed: 202, bullishBias: 0.12 }),
    strengths: ['Canal ascendant identique', 'Rejet des plus bas similaire', 'Volume croissant'],
  },
  {
    id: 'm3',
    rank: 3,
    score: 8.9,
    date: '22 novembre 2023',
    dateShort: '22 nov. 2023',
    candleCount: 32,
    direction: 'neutral',
    volumeTrend: 'flat',
    candles: miniPattern(103, 36500, 'flat'),
    followThrough: generateCandles({ count: 40, start: 68542, seed: 203, bullishBias: 0.02 }),
    strengths: ['Compression de volatilité', 'Range comparable', 'Ombres inférieures répétées'],
  },
  {
    id: 'm4',
    rank: 4,
    score: 8.7,
    date: '5 octobre 2023',
    dateShort: '5 oct. 2023',
    candleCount: 40,
    direction: 'bullish',
    volumeTrend: 'up',
    candles: miniPattern(104, 27200, 'up'),
    followThrough: generateCandles({ count: 40, start: 68542, seed: 204, bullishBias: 0.1 }),
    strengths: ['Breakout de consolidation', 'Volume de confirmation', 'Plus hauts croissants'],
  },
  {
    id: 'm5',
    rank: 5,
    score: 8.4,
    date: '18 août 2023',
    dateShort: '18 août 2023',
    candleCount: 28,
    direction: 'bearish',
    volumeTrend: 'down',
    candles: miniPattern(105, 29400, 'down'),
    followThrough: generateCandles({ count: 40, start: 68542, seed: 205, bullishBias: -0.08 }),
    strengths: ['Épaule-tête inversée partielle', 'Perte de momentum', 'Volume en retrait'],
  },
  {
    id: 'm6',
    rank: 6,
    score: 8.1,
    date: '2 juin 2023',
    dateShort: '2 juin 2023',
    candleCount: 34,
    direction: 'bullish',
    volumeTrend: 'up',
    candles: miniPattern(106, 25800, 'up'),
    followThrough: generateCandles({ count: 40, start: 68542, seed: 206, bullishBias: 0.09 }),
    strengths: ['Reprise en V', 'Support respecté', 'Divergence RSI haussière (démo)'],
  },
  {
    id: 'm7',
    rank: 7,
    score: 7.8,
    date: '19 mars 2023',
    dateShort: '19 mar. 2023',
    candleCount: 30,
    direction: 'neutral',
    volumeTrend: 'flat',
    candles: miniPattern(107, 24100, 'flat'),
    followThrough: generateCandles({ count: 40, start: 68542, seed: 207, bullishBias: 0 }),
    strengths: ['Triangle symétrique', 'Volatilité décroissante'],
  },
  {
    id: 'm8',
    rank: 8,
    score: 7.4,
    date: '11 janvier 2023',
    dateShort: '11 jan. 2023',
    candleCount: 42,
    direction: 'bullish',
    volumeTrend: 'up',
    candles: miniPattern(108, 17800, 'up'),
    followThrough: generateCandles({ count: 40, start: 68542, seed: 208, bullishBias: 0.14 }),
    strengths: ['Double creux', 'Cassure de résistance', 'Volume d’absorption'],
  },
];

export const DEMO_SCENARIOS: Scenario[] = [
  {
    id: 's1',
    label: 'Très court terme',
    horizon: '1-6 bougies',
    direction: 'bullish',
    probability: 62,
    deviation: 1.8,
  },
  {
    id: 's2',
    label: 'Court terme',
    horizon: '7-20 bougies',
    direction: 'bullish',
    probability: 56,
    deviation: 3.4,
  },
  {
    id: 's3',
    label: 'Moyen terme',
    horizon: '21-60 bougies',
    direction: 'neutral',
    probability: 48,
    deviation: 6.7,
  },
  {
    id: 's4',
    label: 'Long terme',
    horizon: '61+ bougies',
    direction: 'bullish',
    probability: 52,
    deviation: 12.3,
  },
];

export const DEMO_CONDITIONS: ConditionItem[] = [
  {
    id: 'c1',
    kind: 'confirm',
    label: 'Franchissement de la résistance',
    detail: '69 500 $',
  },
  { id: 'c2', kind: 'confirm', label: 'Augmentation du volume' },
  { id: 'c3', kind: 'confirm', label: 'Accélération du mouvement' },
  { id: 'c4', kind: 'risk', label: 'Cassure du support', detail: '64 200 $' },
  { id: 'c5', kind: 'risk', label: 'Ralentissement de la dynamique' },
  { id: 'c6', kind: 'risk', label: 'Hausse de la volatilité' },
  { id: 'c7', kind: 'invalidate', label: 'Divergence importante' },
  { id: 'c8', kind: 'invalidate', label: 'Écart avec les correspondances' },
];

export const DEMO_BACKTEST: BacktestStats = {
  cases: 142,
  correctDirection: 58,
  averageError: 2.8,
  calibration: 0.63,
  bySimilarity: [
    { range: '9-10', accuracy: 72, error: 0.9 },
    { range: '8–8,9', accuracy: 61, error: 2.3 },
    { range: '7–7,9', accuracy: 54, error: 3.7 },
    { range: '6–6,9', accuracy: 48, error: 5.1 },
  ],
  equityCurve: Array.from({ length: 40 }, (_, i) => {
    const rand = mulberry32(90 + i)();
    const y = Math.sin(i / 6) * 8 + i * 0.18 + (rand - 0.5) * 6;
    return { x: i * 4, y };
  }),
};

export const DEMO_PROVIDERS: DataProvider[] = [
  {
    id: 'yahoo',
    name: 'Yahoo Finance',
    subtitle: 'Fournisseur principal',
    connected: true,
    primary: true,
    brand: 'yahoo',
  },
  {
    id: 'binance',
    name: 'Binance API',
    subtitle: 'Binance API',
    connected: true,
    primary: false,
    brand: 'binance',
  },
  {
    id: 'kraken',
    name: 'Kraken API',
    subtitle: 'Crypto API',
    connected: true,
    primary: false,
    brand: 'kraken',
  },
  {
    id: 'iress',
    name: 'IRESS API',
    subtitle: 'Generic Forex/Equities',
    connected: true,
    primary: false,
    brand: 'iress',
  },
  {
    id: 'forexfeed',
    name: 'Forex Data Feed',
    subtitle: 'Forex Data',
    connected: false,
    primary: false,
    brand: 'forex',
  },
];

export const DEMO_HELP: HelpArticle[] = [
  {
    id: 'guide',
    title: 'Guide de démarrage',
    icon: 'book',
    body: [
      'MarketScope compare le motif de prix actuel à l’historique pour estimer les scénarios les plus probables.',
      '1. Choisissez un actif. 2. Vérifiez le graphique. 3. Lancez l’analyse (Auto ou Manuel). 4. Explorez les correspondances.',
      'Les données affichées dans cette version sont des exemples de présentation.',
    ],
  },
  {
    id: 'results',
    title: 'Types de résultats',
    icon: 'layers',
    body: [
      'Chaque correspondance reçoit un score de similarité (0 à 10) basé sur la structure, l’amplitude, la volatilité et le volume.',
      'Haussière / baissière / neutre décrit la direction observée après le motif historique — pas un conseil d’investissement.',
    ],
  },
  {
    id: 'granularity',
    title: 'Types de granularité',
    icon: 'grid',
    body: [
      '1m, 15m, 1h, 1j, 1s (semaine) et 1M (mois) définissent la taille d’une bougie.',
      'Une granularité plus fine détecte des micro-motifs ; une granularité plus large capte les structures de fond.',
    ],
  },
  {
    id: 'scores',
    title: 'Interprétation des scores',
    icon: 'star',
    body: [
      '9–10 : correspondance excellente. 8–8,9 : très bonne. 7–7,9 : correcte. Sous 7 : à prendre avec prudence.',
      'Un score élevé ne garantit pas la direction future. Croisez toujours avec les conditions d’invalidation.',
    ],
  },
  {
    id: 'charts',
    title: 'Lecture des graphiques',
    icon: 'chart',
    body: [
      'Les bougies vertes ferment au-dessus de l’ouverture, les rouges en dessous.',
      'La zone cyan délimite le motif analysé. En mode manuel, ajustez cette zone avant de lancer la recherche.',
    ],
  },
  {
    id: 'support',
    title: 'Contacter le support',
    icon: 'chat',
    body: [
      'Pour la version de présentation, le support est simulé.',
      'Endpoint prévu : POST /api/support/tickets — à brancher côté backend.',
    ],
  },
  {
    id: 'call',
    title: 'Nous appeler',
    icon: 'phone',
    body: [
      'Ligne fictive de démonstration : +33 1 00 00 00 00',
      'Horaires indicatifs : lun–ven, 9h–18h (CET).',
    ],
  },
];

export const DEMO_SYNC_STEPS: SyncStep[] = [
  { id: 'running', label: 'En cours…' },
  { id: 'fetch', label: 'Récupération des données' },
  { id: 'normalize', label: 'Normalisation' },
  { id: 'dedupe', label: 'Dédoublonnage' },
  { id: 'cache', label: 'Mise en cache' },
];

export const APP_VERSION = '1.4.2';
export const APP_UPDATED_AT = '12 oct. 2024';

/** Outcome agrégé après la meilleure correspondance (démo). */
export const DEMO_OUTCOME = { bullish: 68, bearish: 10, neutral: 22 };
