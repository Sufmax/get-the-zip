import React from 'react';
import { PlayerProgress } from '../types/game';
import { ACHIEVEMENTS } from '../services/storage';
import { audio } from '../services/audio';
import { triggerHaptic } from '../services/storage';
import { X, Trophy, Check, Zap } from 'lucide-react';

interface AchievementsModalProps {
  progress: PlayerProgress;
  onUpdateProgress: (newProgress: PlayerProgress) => void;
  onClose: () => void;
}

export const AchievementsModal: React.FC<AchievementsModalProps> = ({
  progress,
  onUpdateProgress,
  onClose,
}) => {
  const isUnlocked = (id: string) => progress.achievementsUnlocked.includes(id);

  // Auto-check achievement eligibility
  const checkEligibility = (id: string): boolean => {
    switch (id) {
      case 'first_win':
        return progress.totalWins > 0;
      case 'speed_250':
        return true; // awarded during gameplay
      case 'drift_master':
        return progress.driftHighScore >= 4000;
      case 'car_collector':
        return progress.unlockedCars.length >= 4;
      case 'endless_ace':
        return progress.endlessHighScore >= 10000;
      case 'nitro_holic':
        return progress.totalRaces >= 5;
      default:
        return false;
    }
  };

  const handleClaim = (achId: string, reward: number) => {
    if (isUnlocked(achId)) return;
    audio.playVictory();
    triggerHaptic(50);

    onUpdateProgress({
      ...progress,
      money: progress.money + reward,
      achievementsUnlocked: [...progress.achievementsUnlocked, achId],
    });
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-slate-900 border border-white/20 rounded-3xl p-5 shadow-2xl flex flex-col max-h-[85vh] overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="flex justify-between items-center pb-3 border-b border-white/10 mb-4">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-400/20 text-amber-400 flex items-center justify-center border border-amber-400/30">
              <Trophy className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] font-black uppercase tracking-widest text-cyan-400 block -mb-0.5">
                PALMARÈS
              </span>
              <h2 className="text-xl font-black italic uppercase text-white">
                TROPHÉES & DÉFIS
              </h2>
            </div>
          </div>
          <button
            onClick={() => {
              audio.playClick();
              onClose();
            }}
            aria-label="Fermer"
            className="w-9 h-9 rounded-xl bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center active:scale-95"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* List of achievements */}
        <div className="flex-1 overflow-y-auto flex flex-col gap-2.5 pr-1">
          {ACHIEVEMENTS.map((ach) => {
            const unlocked = isUnlocked(ach.id);
            const canClaim = !unlocked && checkEligibility(ach.id);

            return (
              <div
                key={ach.id}
                className={`flex items-center justify-between p-3.5 rounded-2xl border transition-all ${
                  unlocked
                    ? 'bg-slate-950/60 border-emerald-500/30'
                    : canClaim
                    ? 'bg-gradient-to-r from-amber-950/50 to-slate-900 border-amber-400/50 shadow-lg shadow-amber-950/30'
                    : 'bg-slate-950 border-white/10 opacity-75'
                }`}
              >
                <div className="flex items-center gap-3">
                  <span className="text-2xl">{ach.icon}</span>
                  <div>
                    <h3 className="text-xs font-black uppercase text-white">
                      {ach.titleFr}
                    </h3>
                    <p className="text-[10px] text-slate-400 leading-tight">
                      {ach.descFr}
                    </p>
                  </div>
                </div>

                {unlocked ? (
                  <div className="flex items-center gap-1 text-[11px] font-black uppercase text-emerald-400 bg-emerald-500/10 px-2.5 py-1 rounded-lg border border-emerald-500/20">
                    <Check className="w-3.5 h-3.5" /> REÇU
                  </div>
                ) : canClaim ? (
                  <button
                    onClick={() => handleClaim(ach.id, ach.reward)}
                    className="flex items-center gap-1 text-[11px] font-black uppercase text-slate-950 bg-amber-400 hover:bg-amber-300 px-3 py-1.5 rounded-xl shadow-md shadow-amber-400/30 active:scale-95 animate-pulse"
                  >
                    <Zap className="w-3 h-3 fill-slate-950" />
                    +{ach.reward.toLocaleString()} ⚡
                  </button>
                ) : (
                  <div className="text-[11px] font-mono font-bold text-slate-400">
                    +{ach.reward.toLocaleString()} ⚡
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
