import React from 'react';
import { GameMode, TrackDefinition } from '../types/game';
import { TRACKS_CATALOG } from '../game/tracksData';
import { X, Play, Timer, Trophy } from 'lucide-react';
import { triggerHaptic } from '../services/storage';

interface TrackSelectModalProps {
  onSelectTrack: (mode: GameMode, trackId: string) => void;
  onClose: () => void;
}

export const TrackSelectModal: React.FC<TrackSelectModalProps> = ({
  onSelectTrack,
  onClose,
}) => {
  return (
    <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-xl flex flex-col p-4 md:p-8 overflow-y-auto select-none">
      {/* Header */}
      <div className="flex justify-between items-center w-full max-w-5xl mx-auto pb-4 border-b border-white/10">
        <div>
          <h2 className="text-xl md:text-3xl font-black italic tracking-tight text-white uppercase flex items-center gap-2">
            <span>SÉLECTION DU</span>
            <span className="text-cyan-400">CIRCUIT</span>
          </h2>
          <p className="text-xs text-slate-400">Choisissez votre destination et votre mode de jeu</p>
        </div>

        <button
          onClick={onClose}
          className="w-10 h-10 rounded-2xl bg-slate-800 hover:bg-slate-700 text-white flex items-center justify-center border border-white/10 active:scale-95 transition-all"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Grid of Track Cards */}
      <div className="w-full max-w-5xl mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6 py-6">
        {TRACKS_CATALOG.map((track: TrackDefinition) => {
          const isEndless = track.id === 'endless_highway';

          return (
            <div
              key={track.id}
              className="p-5 rounded-3xl bg-slate-900/80 border border-white/10 hover:border-cyan-400/50 flex flex-col justify-between shadow-xl transition-all"
            >
              <div>
                {/* Theme & Difficulty Badges */}
                <div className="flex justify-between items-center mb-2">
                  <span
                    className="text-[10px] font-black uppercase tracking-wider px-2.5 py-0.5 rounded-lg border"
                    style={{
                      borderColor: track.curbColor1,
                      color: track.curbColor1,
                    }}
                  >
                    {track.theme}
                  </span>

                  <span
                    className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded-lg ${
                      track.difficulty === 'Facile'
                        ? 'bg-emerald-500/20 text-emerald-300'
                        : track.difficulty === 'Moyen'
                        ? 'bg-amber-500/20 text-amber-300'
                        : track.difficulty === 'Difficile'
                        ? 'bg-rose-500/20 text-rose-300'
                        : 'bg-purple-500/20 text-purple-300'
                    }`}
                  >
                    {track.difficulty}
                  </span>
                </div>

                <h3 className="text-lg md:text-xl font-black italic text-white tracking-tight">
                  {track.nameFr}
                </h3>
                <p className="text-xs text-slate-400 mb-4">{track.subtitleFr}</p>

                {/* Track Stats */}
                <div className="grid grid-cols-2 gap-2 text-center mb-4">
                  <div className="bg-slate-950/60 p-2 rounded-xl border border-white/5">
                    <span className="text-[9px] uppercase font-bold text-slate-400 block">LONGUEUR</span>
                    <span className="text-xs font-black text-white italic">{track.lengthMeters.toLocaleString()} m</span>
                  </div>
                  <div className="bg-slate-950/60 p-2 rounded-xl border border-white/5">
                    <span className="text-[9px] uppercase font-bold text-slate-400 block">TOURS</span>
                    <span className="text-xs font-black text-cyan-400 italic">
                      {isEndless ? 'Infini' : `${track.defaultLaps} Tours`}
                    </span>
                  </div>
                </div>
              </div>

              {/* Mode Launch Buttons */}
              <div className="flex gap-2">
                {isEndless ? (
                  <button
                    onClick={() => {
                      triggerHaptic(30);
                      onSelectTrack('endless_traffic', track.id);
                    }}
                    className="w-full py-3 rounded-2xl bg-gradient-to-r from-amber-500 to-orange-500 hover:brightness-110 text-white font-black italic text-xs tracking-wider flex items-center justify-center gap-2 active:scale-95 transition-all"
                  >
                    <Play className="w-4 h-4 fill-white" />
                    <span>LANCER L’AUTOROUTE</span>
                  </button>
                ) : (
                  <>
                    <button
                      onClick={() => {
                        triggerHaptic(30);
                        onSelectTrack('circuit', track.id);
                      }}
                      className="flex-1 py-3 rounded-2xl bg-cyan-500 hover:bg-cyan-400 text-white font-black italic text-xs tracking-wider flex items-center justify-center gap-1.5 active:scale-95 transition-all shadow-lg shadow-cyan-500/20"
                    >
                      <Trophy className="w-4 h-4" />
                      <span>COURSE</span>
                    </button>

                    <button
                      onClick={() => {
                        triggerHaptic(30);
                        onSelectTrack('time_trial', track.id);
                      }}
                      className="py-3 px-3.5 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white font-black italic text-xs tracking-wider flex items-center justify-center gap-1.5 active:scale-95 transition-all border border-white/10"
                      title="Contre-la-montre (solo)"
                    >
                      <Timer className="w-4 h-4" />
                    </button>
                  </>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
