import * as THREE from 'three';
import { CarDefinition, PlayerCarCustomization } from '../types/game';
import { TrackData } from './proceduralTrack';

export interface VehicleInputs {
  throttle: number; // 0 to 1
  brake: number; // 0 to 1
  steer: number; // -1 (Left) to +1 (Right)
  handbrake: boolean;
  nitro: boolean;
}

export interface VehicleState {
  position: THREE.Vector3;
  velocity: THREE.Vector3;
  heading: number; // yaw in radians
  angularVelocity: number;
  speed: number; // m/s
  speedKmh: number;
  gear: number;
  rpm: number; // 0 to 1
  isDrifting: boolean;
  driftAngle: number;
  driftScore: number;
  driftMultiplier: number;
  nitroPercent: number; // 0 to 100
  isNitroActive: boolean;
  slipstreamActive: boolean;
  slipstreamTimer: number;
  progressT: number; // 0 to 1 along track
  currentSampleIndex: number;
  hasReachedHalfway: boolean;
  lap: number;
  collisionCooldown: number;
  stuckTimer: number;
  isReversingStuck: boolean;
  isAI: boolean;
  aiTargetSpeed: number;
  aiLaneOffset: number; // offset from track center
  aiSkill: number;
}

export class PhysicsEngine {
  private trackData: TrackData;

  constructor(trackData: TrackData) {
    this.trackData = trackData;
  }

  public setTrack(trackData: TrackData) {
    this.trackData = trackData;
  }

  public createInitialState(
    startPos: THREE.Vector3,
    startHeading: number,
    isAI = false,
    laneOffset = 0
  ): VehicleState {
    const pos = startPos.clone();

    // Find initial closest sample index
    let initialIndex = 0;
    let initialT = 0;
    if (this.trackData && this.trackData.samplePoints && this.trackData.samplePoints.length > 0) {
      const samples = this.trackData.samplePoints;
      let minDSq = Infinity;
      for (let i = 0; i < samples.length; i++) {
        const dSq = samples[i].pos.distanceToSquared(pos);
        if (dSq < minDSq) {
          minDSq = dSq;
          initialIndex = i;
        }
      }
      initialT = samples[initialIndex].t;
    }

    return {
      position: pos,
      velocity: new THREE.Vector3(0, 0, 0),
      heading: startHeading,
      angularVelocity: 0,
      speed: 0,
      speedKmh: 0,
      gear: 1,
      rpm: 0.1,
      isDrifting: false,
      driftAngle: 0,
      driftScore: 0,
      driftMultiplier: 1.0,
      nitroPercent: 100,
      isNitroActive: false,
      slipstreamActive: false,
      slipstreamTimer: 0,
      progressT: initialT,
      currentSampleIndex: initialIndex,
      hasReachedHalfway: false,
      lap: 1,
      collisionCooldown: 0,
      stuckTimer: 0,
      isReversingStuck: false,
      isAI,
      aiTargetSpeed: 58 + Math.random() * 16, // 208 - 266 km/h
      aiLaneOffset: laneOffset,
      aiSkill: 0.85 + Math.random() * 0.25,
    };
  }

  public updateVehicle(
    state: VehicleState,
    inputs: VehicleInputs,
    carDef: CarDefinition,
    customization: PlayerCarCustomization | undefined,
    dt: number,
    otherVehicles: VehicleState[] = []
  ): {
    collidedBarrier: boolean;
    collidedCar: boolean;
    nearMiss: boolean;
    gearShift: boolean;
    driftJustStarted: boolean;
  } {
    let collidedBarrier = false;
    let collidedCar = false;
    let nearMiss = false;
    let gearShift = false;
    const wasDrifting = state.isDrifting;

    if (state.collisionCooldown > 0) {
      state.collisionCooldown = Math.max(0, state.collisionCooldown - dt);
    }

    // Auto-throttle when Nitro or Drift is pressed!
    if (inputs.nitro || inputs.handbrake) {
      inputs.throttle = Math.max(inputs.throttle, 1.0);
    }

    // Performance upgrades
    const engineLvl = customization?.upgrades.engine ?? 0;
    const brakesLvl = customization?.upgrades.brakes ?? 0;
    const handlingLvl = customization?.upgrades.handling ?? 0;
    const nitroLvl = customization?.upgrades.nitro ?? 0;

    const turboMod = 1 + engineLvl * 0.08;
    const brakesMod = 1 + brakesLvl * 0.12;
    const handlingMod = 1 + handlingLvl * 0.07;
    const nitroMod = 1 + nitroLvl * 0.15;

    // Nitro handling
    if (inputs.nitro && state.nitroPercent > 3 && inputs.throttle > 0.1) {
      state.isNitroActive = true;
      state.nitroPercent = Math.max(0, state.nitroPercent - dt * 24);
    } else {
      state.isNitroActive = false;
      // Gradual natural nitro regeneration
      state.nitroPercent = Math.min(100, state.nitroPercent + dt * 2.8 * nitroMod);
    }

    // Slipstream detection
    let inSlipstream = false;
    if (!state.isAI) {
      const fwdVec = new THREE.Vector3(Math.sin(state.heading), 0, Math.cos(state.heading));
      for (const other of otherVehicles) {
        if (other === state) continue;
        const diff = other.position.clone().sub(state.position);
        const dist = diff.length();
        if (dist > 3 && dist < 24) {
          const dot = diff.normalize().dot(fwdVec);
          if (dot > 0.88 && other.speed > 25 && state.speed > 22) {
            inSlipstream = true;
            state.slipstreamTimer += dt;
            break;
          }
        }
      }
    }
    state.slipstreamActive = inSlipstream && state.slipstreamTimer > 0.4;
    if (!inSlipstream) state.slipstreamTimer = Math.max(0, state.slipstreamTimer - dt * 1.5);

    // Forward and Right direction vectors
    // Forward = (sin H, 0, cos H)
    // Driver's visual Right = (-cos H, 0, sin H)
    const forward = new THREE.Vector3(Math.sin(state.heading), 0, Math.cos(state.heading));
    const right = new THREE.Vector3(-Math.cos(state.heading), 0, Math.sin(state.heading));

    const currentForwardSpeed = state.velocity.dot(forward);
    const currentLateralSpeed = state.velocity.dot(right);
    const speedMag = state.velocity.length();

    // 1. Throttle / Acceleration
    const maxSpeedMs = (carDef.specs.topSpeed / 3.6) * turboMod * (state.isNitroActive ? 1.2 : state.slipstreamActive ? 1.12 : 1.0);
    const baseAccel = (carDef.specs.acceleration * 4.4 * turboMod) * (state.isNitroActive ? 1.85 : inSlipstream ? 1.25 : 1.0);
    let forwardForce = 0;

    if (inputs.throttle > 0) {
      const speedRatio = Math.max(0, currentForwardSpeed / maxSpeedMs);
      const torqueCurve = Math.max(0.14, 1 - Math.pow(Math.min(1, speedRatio), 1.8));
      forwardForce = inputs.throttle * baseAccel * torqueCurve;
    }

    // 2. Braking & Reverse (Fixed: No reversing during handbrake or countdown)
    if (inputs.handbrake) {
      // Handbrake slows down car but does NOT reverse!
      if (currentForwardSpeed > 0.5) {
        forwardForce -= 20 * brakesMod;
      }
    } else if (inputs.brake > 0) {
      if (currentForwardSpeed > 0.8) {
        // Active braking
        forwardForce -= inputs.brake * 32 * brakesMod;
      } else if (inputs.throttle === 0 && !inputs.handbrake) {
        // Only reverse if explicit brake held while stopped
        forwardForce -= inputs.brake * 10;
      }
    }

    // 3. Rolling resistance & aerodynamic drag
    const dragCoeff = 0.0015;
    const rollingResistance = 0.85;
    if (Math.abs(currentForwardSpeed) > 0.2) {
      forwardForce -= Math.sign(currentForwardSpeed) * (rollingResistance + dragCoeff * currentForwardSpeed * currentForwardSpeed);
    } else if (inputs.throttle === 0 && inputs.brake === 0 && !inputs.handbrake) {
      state.velocity.set(0, 0, 0);
    }

    // 4. Drift mechanics & lateral grip
    const driftEaseFactor = carDef.specs.driftEase / 10;
    const initiatesDrift =
      (inputs.handbrake || (Math.abs(inputs.steer) > 0.55 && inputs.brake > 0.15)) &&
      currentForwardSpeed > 8;

    if (initiatesDrift) {
      state.isDrifting = true;
    } else if (state.isDrifting) {
      if (Math.abs(inputs.steer) < 0.12 && Math.abs(currentLateralSpeed) < 1.6 && !inputs.handbrake) {
        state.isDrifting = false;
      } else if (currentForwardSpeed < 5) {
        state.isDrifting = false;
      }
    }

    // Lateral grip
    const baseGrip = state.isDrifting ? 0.35 + (1 - driftEaseFactor) * 0.15 : 0.98 * handlingMod;
    const lateralFriction = -currentLateralSpeed * baseGrip * 16;

    // Apply forces
    const accelVector = forward.clone().multiplyScalar(forwardForce).add(right.clone().multiplyScalar(lateralFriction));
    state.velocity.addScaledVector(accelVector, dt);

    // Grip alignment in normal driving
    if (!state.isDrifting && speedMag > 0.8) {
      const targetForwardVel = forward.clone().multiplyScalar(state.velocity.dot(forward));
      const gripRate = Math.min(1, dt * 14 * handlingMod);
      state.velocity.lerp(targetForwardVel, gripRate);
    }

    // Speed calculation
    state.speed = state.velocity.length();
    state.speedKmh = Math.round(state.speed * 3.6);

    // 5. Steering & Yaw Rotation (Fixed: steer > 0 turns RIGHT, steer < 0 turns LEFT!)
    const steerSpeedFactor = Math.min(1, Math.max(0.24, speedMag / 8));
    const maxSteerRate = (carDef.specs.handling / 10) * 2.9 * handlingMod;
    const steerDir = currentForwardSpeed < -0.5 ? -1 : 1;
    // Driver right is towards -X (decreasing heading), so multiply by -1
    let targetAngularVel = -steerDir * inputs.steer * maxSteerRate * steerSpeedFactor;

    if (state.isDrifting) {
      targetAngularVel *= 1.45;
      const driftDelta = Math.abs(currentLateralSpeed) * dt * 55 * state.driftMultiplier;
      state.driftScore += Math.round(driftDelta);
      state.driftMultiplier = Math.min(5.0, state.driftMultiplier + dt * 0.35);
      state.nitroPercent = Math.min(100, state.nitroPercent + dt * 10);
    } else {
      state.driftMultiplier = 1.0;
    }

    state.angularVelocity += (targetAngularVel - state.angularVelocity) * 12 * dt;
    state.heading += state.angularVelocity * dt;

    // Drift Angle
    if (speedMag > 2) {
      const moveAngle = Math.atan2(state.velocity.x, state.velocity.z);
      let angleDiff = state.heading - moveAngle;
      while (angleDiff > Math.PI) angleDiff -= Math.PI * 2;
      while (angleDiff < -Math.PI) angleDiff += Math.PI * 2;
      state.driftAngle = angleDiff;
    } else {
      state.driftAngle = 0;
    }

    // 6. Integrate Position
    state.position.addScaledVector(state.velocity, dt);

    // 7. Transmission simulation (RPM & Gears 1 to 6)
    const gearRatios = [0, 45, 85, 135, 185, 240, 340];
    let newGear = 1;
    for (let g = 1; g < gearRatios.length; g++) {
      if (state.speedKmh > gearRatios[g - 1] * 0.75) {
        newGear = g;
      }
    }
    if (newGear !== state.gear) {
      gearShift = true;
      state.gear = newGear;
    }

    const minGearKmh = gearRatios[state.gear - 1] || 0;
    const maxGearKmh = gearRatios[state.gear] || 320;
    const gearProgress = Math.max(0, Math.min(1, (state.speedKmh - minGearKmh) / (maxGearKmh - minGearKmh || 1)));
    state.rpm = 0.15 + 0.85 * gearProgress;

    // 8. Track Boundary Collision (Smooth bounce & slide, NO dead-stops)
    if (this.checkTrackBoundary(state, dt)) {
      collidedBarrier = true;
    }

    // 9. Inter-vehicle collisions & near-misses
    const carHitRadius = 2.4;
    for (const other of otherVehicles) {
      if (other === state) continue;
      const dist = state.position.distanceTo(other.position);

      if (dist < carHitRadius && state.collisionCooldown <= 0) {
        collidedCar = true;
        state.collisionCooldown = 0.35;

        // Elastic momentum rebound
        const pushDir = state.position.clone().sub(other.position).normalize();
        pushDir.y = 0;
        state.velocity.addScaledVector(pushDir, 9);
        other.velocity.addScaledVector(pushDir, -9);
      } else if (dist < 4.2 && dist >= carHitRadius && !state.isAI) {
        nearMiss = true;
      }
    }

    // 10. Track Progression & Lap Counting
    this.updateTrackProgress(state);

    return {
      collidedBarrier,
      collidedCar,
      nearMiss,
      gearShift,
      driftJustStarted: state.isDrifting && !wasDrifting,
    };
  }

  private updateTrackProgress(state: VehicleState) {
    if (!this.trackData || !this.trackData.samplePoints || this.trackData.samplePoints.length === 0) return;
    const samples = this.trackData.samplePoints;
    const n = samples.length;

    // Search localized window for closest sample
    let bestIdx = state.currentSampleIndex;
    let minDSq = Infinity;
    for (let k = -8; k <= 16; k++) {
      const idx = (state.currentSampleIndex + k + n * 4) % n;
      const dSq = samples[idx].pos.distanceToSquared(state.position);
      if (dSq < minDSq) {
        minDSq = dSq;
        bestIdx = idx;
      }
    }

    state.currentSampleIndex = bestIdx;
    state.progressT = samples[bestIdx].t;

    // Reliable Halfway check to prevent cheating lap count
    if (state.progressT > 0.45 && state.progressT < 0.65) {
      state.hasReachedHalfway = true;
    }

    // Lap finish line crossing
    if (state.hasReachedHalfway && state.currentSampleIndex <= 6) {
      state.lap++;
      state.hasReachedHalfway = false;
    }
  }

  private checkTrackBoundary(state: VehicleState, dt: number): boolean {
    if (!this.trackData || !this.trackData.samplePoints || this.trackData.samplePoints.length === 0) return false;
    const samples = this.trackData.samplePoints;
    const centerPt = samples[state.currentSampleIndex] || samples[0];
    if (!centerPt) return false;

    const toCar = state.position.clone().sub(centerPt.pos);
    const lateralDist = toCar.dot(centerPt.normal);
    const maxHalfW = this.trackData.roadWidth * 0.5 - 0.7;

    if (Math.abs(lateralDist) > maxHalfW) {
      const excess = Math.abs(lateralDist) - maxHalfW;
      const pushSign = Math.sign(lateralDist);

      // Smooth position rebound just inside barrier
      state.position.addScaledVector(centerPt.normal, -pushSign * (excess + 0.08));

      // Rebound lateral velocity elastically (no sticking)
      const normalVel = state.velocity.dot(centerPt.normal);
      if (Math.sign(normalVel) === pushSign) {
        state.velocity.addScaledVector(centerPt.normal, -normalVel * 1.3);
      }

      // Smooth wall friction (scrapes speed gently instead of 0.78 instant dead-stop)
      state.velocity.multiplyScalar(Math.max(0.88, 1 - 0.25 * dt));
      return true;
    }

    return false;
  }

  // AI Opponent navigation & behavior
  public updateAI(
    aiState: VehicleState,
    _aiDef: CarDefinition,
    dt: number,
    otherVehicles: VehicleState[]
  ): VehicleInputs {
    if (this.trackData.isEndlessHighway) {
      // Traffic on endless highway traveling steadily forward
      return {
        throttle: 0.68,
        brake: 0,
        steer: 0,
        handbrake: false,
        nitro: false,
      };
    }

    const samples = this.trackData.samplePoints;
    if (!samples || samples.length === 0) {
      return { throttle: 1, brake: 0, steer: 0, handbrake: false, nitro: false };
    }

    // Dynamic Look-Ahead scaling with vehicle speed
    const baseLook = 10;
    const speedBonus = Math.round((aiState.speedKmh / 260) * 16);
    const lookAheadSteps = baseLook + speedBonus;
    const targetIdx = (aiState.currentSampleIndex + lookAheadSteps) % samples.length;
    const targetPt = samples[targetIdx];

    // Compute target position with lane offset
    const targetPos = targetPt.pos.clone().addScaledVector(targetPt.normal, aiState.aiLaneOffset);
    const toTarget = targetPos.clone().sub(aiState.position);

    // Compute desired heading
    const desiredHeading = Math.atan2(toTarget.x, toTarget.z);
    let headingDiff = desiredHeading - aiState.heading;
    while (headingDiff > Math.PI) headingDiff -= Math.PI * 2;
    while (headingDiff < -Math.PI) headingDiff += Math.PI * 2;

    // AI steering: Driver's visual right is towards -X (headingDiff < 0)
    // So steer = -headingDiff * gain
    let steer = Math.max(-1, Math.min(1, -headingDiff * 2.8));

    // Curvature anticipation: evaluate upcoming track twist
    let upcomingTurnSeverity = 0;
    const checkSamples = 16;
    for (let s = 4; s < checkSamples; s += 4) {
      const idxA = (aiState.currentSampleIndex + s) % samples.length;
      const idxB = (aiState.currentSampleIndex + s + 4) % samples.length;
      const dot = samples[idxA].tangent.dot(samples[idxB].tangent);
      upcomingTurnSeverity += Math.max(0, 1 - dot);
    }

    const isSharpCorner = upcomingTurnSeverity > 0.35 || Math.abs(headingDiff) > 0.42;
    const isMediumCorner = upcomingTurnSeverity > 0.15 || Math.abs(headingDiff) > 0.22;

    const cornerMaxSpeed = isSharpCorner ? 115 : isMediumCorner ? 165 : 280;
    const targetSpeedKmh = Math.min(aiState.aiTargetSpeed * 3.6, cornerMaxSpeed * aiState.aiSkill);

    let throttle = 1.0;
    let brake = 0;

    if (aiState.speedKmh > targetSpeedKmh + 6) {
      throttle = 0;
      brake = Math.min(1, (aiState.speedKmh - targetSpeedKmh) / 22);
    } else if (aiState.speedKmh > targetSpeedKmh) {
      throttle = 0.4;
    }

    // AI Multi-Car Collision Avoidance & Overtaking
    const fwd = new THREE.Vector3(Math.sin(aiState.heading), 0, Math.cos(aiState.heading));
    for (const other of otherVehicles) {
      if (other === aiState) continue;
      const toOther = other.position.clone().sub(aiState.position);
      const dist = toOther.length();
      const dot = toOther.clone().normalize().dot(fwd);

      if (dist < 14 && dot > 0.6) {
        // Shift lane to overtake
        const shiftDir = aiState.aiLaneOffset >= 0 ? -1 : 1;
        aiState.aiLaneOffset += shiftDir * dt * 4;
        aiState.aiLaneOffset = Math.max(-5.5, Math.min(5.5, aiState.aiLaneOffset));

        if (dist < 5 && aiState.speed > other.speed) {
          brake = Math.max(brake, 0.4);
        }
      }
    }

    // AI Nitro on straights
    const useNitro =
      !isSharpCorner &&
      !isMediumCorner &&
      aiState.speedKmh > 130 &&
      aiState.nitroPercent > 35 &&
      Math.abs(headingDiff) < 0.15;

    // AI Stuck Detection & Recovery
    if (aiState.speedKmh < 8 && throttle > 0.5) {
      aiState.stuckTimer += dt;
      if (aiState.stuckTimer > 1.2) {
        aiState.isReversingStuck = true;
      }
    } else {
      aiState.stuckTimer = Math.max(0, aiState.stuckTimer - dt);
    }

    if (aiState.isReversingStuck) {
      throttle = 0;
      brake = 0.8; // reverse
      steer = -steer;
      if (aiState.stuckTimer > 2.2) {
        aiState.isReversingStuck = false;
        aiState.stuckTimer = 0;
      }
    }

    return {
      throttle,
      brake,
      steer,
      handbrake: false,
      nitro: useNitro,
    };
  }
}
