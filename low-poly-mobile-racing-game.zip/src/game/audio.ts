export class GameAudio {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private engine: OscillatorNode | null = null;
  private engine2: OscillatorNode | null = null;
  private engineGain: GainNode | null = null;
  private noise: AudioBufferSourceNode | null = null;
  private noiseFilter: BiquadFilterNode | null = null;
  private noiseGain: GainNode | null = null;
  private boostGain: GainNode | null = null;
  enabled = true;
  private started = false;

  async init() {
    if (!this.ctx) {
      this.ctx = new AudioContext();
      this.master = this.ctx.createGain();
      this.master.gain.value = 0.28;
      this.master.connect(this.ctx.destination);

      this.engineGain = this.ctx.createGain();
      this.engineGain.gain.value = 0;
      this.engineGain.connect(this.master);

      this.engine = this.ctx.createOscillator();
      this.engine.type = "sawtooth";
      this.engine.frequency.value = 50;
      const f1 = this.ctx.createBiquadFilter();
      f1.type = "lowpass";
      f1.frequency.value = 900;
      this.engine.connect(f1);
      f1.connect(this.engineGain);

      this.engine2 = this.ctx.createOscillator();
      this.engine2.type = "square";
      this.engine2.frequency.value = 90;
      const f2 = this.ctx.createBiquadFilter();
      f2.type = "lowpass";
      f2.frequency.value = 600;
      const g2 = this.ctx.createGain();
      g2.gain.value = 0.18;
      this.engine2.connect(f2);
      f2.connect(g2);
      g2.connect(this.engineGain);
      this.engine.start();
      this.engine2.start();

      const buf = this.ctx.createBuffer(1, this.ctx.sampleRate, this.ctx.sampleRate);
      const data = buf.getChannelData(0);
      for (let i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1;
      this.noise = this.ctx.createBufferSource();
      this.noise.buffer = buf;
      this.noise.loop = true;
      this.noiseFilter = this.ctx.createBiquadFilter();
      this.noiseFilter.type = "bandpass";
      this.noiseFilter.frequency.value = 400;
      this.noiseGain = this.ctx.createGain();
      this.noiseGain.gain.value = 0;
      this.noise.connect(this.noiseFilter);
      this.noiseFilter.connect(this.noiseGain);
      this.noiseGain.connect(this.master);
      this.noise.start();

      this.boostGain = this.ctx.createGain();
      this.boostGain.gain.value = 0;
      this.boostGain.connect(this.master);
    }
    if (this.ctx.state === "suspended") await this.ctx.resume();
    this.started = true;
  }

  setEnabled(v: boolean) {
    this.enabled = v;
    if (this.master) this.master.gain.value = v ? 0.28 : 0;
  }

  engineAt(speedT: number, boosting: boolean, racing: boolean) {
    if (!this.started || !this.ctx || !this.engine || !this.engine2 || !this.engineGain || !this.noiseGain || !this.noiseFilter)
      return;
    const t = this.ctx.currentTime;
    const st = racing ? speedT : 0.08;
    this.engine.frequency.setTargetAtTime(55 + st * 240 + (boosting ? 40 : 0), t, 0.06);
    this.engine2.frequency.setTargetAtTime(90 + st * 380, t, 0.06);
    this.engineGain.gain.setTargetAtTime(this.enabled && racing ? 0.12 + st * 0.22 : 0.04, t, 0.08);
    this.noiseFilter.frequency.setTargetAtTime(280 + st * 1400, t, 0.08);
    this.noiseGain.gain.setTargetAtTime(this.enabled && racing ? 0.015 + st * 0.05 + (boosting ? 0.04 : 0) : 0, t, 0.08);
  }

  beep(freq: number, dur = 0.12, vol = 0.2) {
    if (!this.ctx || !this.master || !this.enabled) return;
    const o = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    o.type = "square";
    o.frequency.value = freq;
    g.gain.value = vol;
    g.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + dur);
    o.connect(g);
    g.connect(this.master);
    o.start();
    o.stop(this.ctx.currentTime + dur);
  }

  countdown(n: number) {
    if (n <= 0) this.beep(880, 0.28, 0.24);
    else this.beep(420, 0.12, 0.18);
  }

  crash() {
    this.beep(90, 0.16, 0.28);
  }

  finish() {
    this.beep(523, 0.12, 0.18);
    setTimeout(() => this.beep(659, 0.12, 0.18), 120);
    setTimeout(() => this.beep(784, 0.28, 0.22), 240);
  }

  click() {
    this.beep(660, 0.05, 0.08);
  }
}

export const audio = new GameAudio();
