import React from 'react';
import { Play, RotateCcw, Home, Sliders } from 'lucide-react';
import { audio } from '../services/audio';
import { triggerHaptic } from '../services/storage';

interface PauseModalProps {
  onResume: () => void;
  onRestart: () => void;
  onOpenSettings: () => void;
  onQuit: () => void;
}

export const PauseModal: React.FC<PauseModalProps> = ({
  onResume,
  onRestart,
  onOpenSettings,
  onQuit,
}) => {
  return (
    <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4">
      <div className="w-full max-w-sm bg-slate-900 border border-white/20 rounded-3xl p-6 shadow-2xl flex flex-col items-center text-center animate-in fade-in zoom-in-95 duration-150">
        <span className="text-[10px] font-black uppercase tracking-widest text-cyan-400">
          COURSE EN PAUSE
        </span>
        <h2 className="text-2xl font-black italic uppercase text-white tracking-tight mb-6">
          PAUSE
        </h2>

        <div className="w-full flex flex-col gap-3">
          <button
            onClick={() => {
              audio.playClick();
              triggerHaptic(20);
              onResume();
            }}
            className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-cyan-500 to-sky-400 text-slate-950 font-black text-sm uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-cyan-500/30 active:scale-95 transition-all"
          >
            <Play className="w-4 h-4 fill-slate-950" /> REPRENDRE
          </button>

          <button
            onClick={() => {
              audio.playClick();
              triggerHaptic(20);
              onRestart();
            }}
            className="w-full py-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-white font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 border border-white/10 active:scale-95 transition-all"
          >
            <RotateCcw className="w-4 h-4" /> RESTART
          </button>

          <button
            onClick={() => {
              audio.playClick();
              triggerHaptic(20);
              onOpenSettings();
            }}
            className="w-full py-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-white font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 border border-white/10 active:scale-95 transition-all"
          >
            <Sliders className="w-4 h-4 text-cyan-400" /> PARAMÈTRES
          </button>

          <button
            onClick={() => {
              audio.playClick();
              triggerHaptic(20);
              onQuit();
            }}
            className="w-full py-3 rounded-2xl bg-rose-950/40 hover:bg-rose-900/50 text-rose-300 font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 border border-rose-500/30 active:scale-95 transition-all mt-2"
          >
            <Home className="w-4 h-4" /> QUITTER LA COURSE
          </button>
        </div>
      </div>
    </div>
  );
};
