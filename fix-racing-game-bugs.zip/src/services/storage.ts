import { PlayerProgress, ControlSettings, Achievement } from '../types/game';
import { CARS_CATALOG } from '../game/carsData';

const PROGRESS_KEY = 'apex_racing_progress_v1';
const SETTINGS_KEY = 'apex_racing_settings_v1';

export const ACHIEVEMENTS: Achievement[] = [
  {
    id: 'first_win',
    titleFr: 'Premier Trophée',
    titleEn: 'First Trophy',
    descFr: 'Remporter votre première course.',
    descEn: 'Win your first race.',
    reward: 2500,
    icon: '🏆',
  },
  {
    id: 'speed_250',
    titleFr: 'Mur du Son',
    titleEn: 'Speed Demon',
    descFr: 'Dépasser 250 km/h.',
    descEn: 'Exceed 250 km/h.',
    reward: 3000,
    icon: '⚡',
  },
  {
    id: 'drift_master',
    titleFr: 'Roi du Drift',
    titleEn: 'Drift King',
    descFr: 'Marquer 4 000 points en un seul drift.',
    descEn: 'Score 4,000 points in a single drift.',
    reward: 5000,
    icon: '🔥',
  },
  {
    id: 'car_collector',
    titleFr: 'Collectionneur',
    titleEn: 'Car Collector',
    descFr: 'Débloquer au moins 4 bolides.',
    descEn: 'Unlock at least 4 cars.',
    reward: 8000,
    icon: '🏎️',
  },
  {
    id: 'endless_ace',
    titleFr: 'As du Trafic',
    titleEn: 'Traffic Ace',
    descFr: 'Franchir 10 000m en mode Trafic Infini.',
    descEn: 'Travel 10,000m in Endless Highway.',
    reward: 6000,
    icon: '🛣️',
  },
  {
    id: 'nitro_holic',
    titleFr: 'Accro au Nitro',
    titleEn: 'Nitro Junkie',
    descFr: 'Vider 20 réservoirs de Nitro.',
    descEn: 'Deplete 20 Nitro tanks.',
    reward: 3500,
    icon: '💨',
  },
];

const DEFAULT_SETTINGS: ControlSettings = {
  scheme: 'buttons',
  autoAccelerate: false,
  steeringSensitivity: 1.0,
  vibrate: true,
  cameraFovBoost: true,
  speedLines: true,
  quality: 'high',
  audioVolume: 0.8,
  engineVolume: 0.7,
  musicVolume: 0.4,
  language: 'fr',
};

const getDefaultProgress = (): PlayerProgress => {
  const initialCustomizations: PlayerProgress['carCustomizations'] = {};
  CARS_CATALOG.forEach((car) => {
    initialCustomizations[car.id] = {
      color: car.baseColor,
      spoilerIndex: 0,
      underglowColor: null,
      upgrades: {
        engine: 1,
        turbo: 1,
        handling: 1,
        nitro: 1,
        brakes: 1,
      },
    };
  });

  return {
    money: 8000, // starting bonus to allow early tuning or saving
    unlockedCars: ['apex_gt'],
    selectedCarId: 'apex_gt',
    carCustomizations: initialCustomizations,
    bestLaps: {},
    careerCupIndex: 0,
    endlessHighScore: 0,
    driftHighScore: 0,
    totalRaces: 0,
    totalWins: 0,
    achievementsUnlocked: [],
  };
};

export const loadPlayerProgress = (): PlayerProgress => {
  try {
    const raw = localStorage.getItem(PROGRESS_KEY);
    if (!raw) return getDefaultProgress();
    const parsed = JSON.parse(raw);
    const defaults = getDefaultProgress();
    // Ensure all catalog cars exist in customizations
    CARS_CATALOG.forEach((car) => {
      if (!parsed.carCustomizations?.[car.id]) {
        parsed.carCustomizations = parsed.carCustomizations || {};
        parsed.carCustomizations[car.id] = defaults.carCustomizations[car.id];
      }
    });
    return { ...defaults, ...parsed };
  } catch {
    return getDefaultProgress();
  }
};

export const savePlayerProgress = (progress: PlayerProgress): void => {
  try {
    localStorage.setItem(PROGRESS_KEY, JSON.stringify(progress));
  } catch (e) {
    console.error('Failed to save progress to localStorage', e);
  }
};

export const loadControlSettings = (): ControlSettings => {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (!raw) return DEFAULT_SETTINGS;
    return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
  } catch {
    return DEFAULT_SETTINGS;
  }
};

export const saveControlSettings = (settings: ControlSettings): void => {
  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
  } catch (e) {
    console.error('Failed to save settings', e);
  }
};

export const triggerHaptic = (duration = 30) => {
  if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
    try {
      navigator.vibrate(duration);
    } catch {
      // Ignore vibration error
    }
  }
};
