import { useState, useEffect, useRef } from 'react';
import { GameMode, TrackId, RaceState, PlayerProgress, ControlSettings } from './types/game';
import { GameEngine } from './game/gameEngine';
import { HUD } from './components/HUD';
import { TouchControls } from './components/TouchControls';
import { MainMenu } from './components/MainMenu';
import { GarageModal } from './components/GarageModal';
import { TrackSelectModal } from './components/TrackSelectModal';
import { EndRaceModal } from './components/EndRaceModal';
import { PauseModal } from './components/PauseModal';
import { SettingsModal } from './components/SettingsModal';
import { AchievementsModal } from './components/AchievementsModal';
import {
  loadPlayerProgress,
  savePlayerProgress,
  loadControlSettings,
  saveControlSettings,
} from './services/storage';

export function App() {
  // Persistence states
  const [progress, setProgress] = useState<PlayerProgress>(loadPlayerProgress);
  const [settings, setSettings] = useState<ControlSettings>(loadControlSettings);

  // Screen state machine
  const [activeScreen, setActiveScreen] = useState<'menu' | 'garage' | 'track_select' | 'achievements' | 'racing'>('menu');
  const [showSettings, setShowSettings] = useState(false);
  const [isPaused, setIsPaused] = useState(false);

  // Active Race Configuration
  const [currentMode, setCurrentMode] = useState<GameMode>('quick_race');
  const [currentTrackId, setCurrentTrackId] = useState<TrackId>('cyber_highway');

  // Real-time race state from 3D physics engine
  const [raceState, setRaceState] = useState<RaceState | null>(null);
  const [raceResult, setRaceResult] = useState<any | null>(null);

  // 3D Engine ref & container
  const gameContainerRef = useRef<HTMLDivElement>(null);
  const engineRef = useRef<GameEngine | null>(null);

  // Save progress on change
  const handleUpdateProgress = (newProgress: PlayerProgress) => {
    setProgress(newProgress);
    savePlayerProgress(newProgress);
  };

  // Save settings on change
  const handleUpdateSettings = (newSettings: ControlSettings) => {
    setSettings(newSettings);
    saveControlSettings(newSettings);
  };

  // Start race
  const handleStartRace = (mode: GameMode, trackId: TrackId) => {
    setCurrentMode(mode);
    setCurrentTrackId(trackId);
    setRaceResult(null);
    setIsPaused(false);
    setActiveScreen('racing');
  };

  // Initialize 3D GameEngine when racing screen mounts
  useEffect(() => {
    if (activeScreen !== 'racing') {
      if (engineRef.current) {
        engineRef.current.stop();
        engineRef.current = null;
      }
      return;
    }

    const container = gameContainerRef.current;
    if (!container) return;

    const engine = new GameEngine(
      container,
      currentMode,
      currentTrackId,
      progress,
      settings,
      (state) => {
        setRaceState(state);
      },
      (result) => {
        // Race completed
        setRaceResult(result);

        // Update player stats and wallet
        const newTotalRaces = progress.totalRaces + 1;
        const newTotalWins = result.position === 1 ? progress.totalWins + 1 : progress.totalWins;
        const newBestLaps = { ...progress.bestLaps };
        if (result.bestLap > 0 && (!newBestLaps[currentTrackId] || result.bestLap < newBestLaps[currentTrackId])) {
          newBestLaps[currentTrackId] = result.bestLap;
        }

        const newEndlessHigh = Math.max(progress.endlessHighScore, result.distance);
        const newDriftHigh = Math.max(progress.driftHighScore, result.driftScore);

        const updated: PlayerProgress = {
          ...progress,
          money: progress.money + result.cashEarned,
          totalRaces: newTotalRaces,
          totalWins: newTotalWins,
          bestLaps: newBestLaps,
          endlessHighScore: newEndlessHigh,
          driftHighScore: newDriftHigh,
        };
        handleUpdateProgress(updated);
      }
    );

    engine.start();
    engineRef.current = engine;

    return () => {
      engine.stop();
      engineRef.current = null;
    };
  }, [activeScreen, currentMode, currentTrackId]);

  // Restart race
  const handleRestartRace = () => {
    if (engineRef.current) {
      engineRef.current.stop();
      engineRef.current = null;
    }
    setRaceResult(null);
    setIsPaused(false);
    // Trigger re-mount
    setActiveScreen('menu');
    setTimeout(() => {
      setActiveScreen('racing');
    }, 50);
  };

  // Return to main menu
  const handleQuitRace = () => {
    if (engineRef.current) {
      engineRef.current.stop();
      engineRef.current = null;
    }
    setIsPaused(false);
    setRaceResult(null);
    setActiveScreen('menu');
  };

  return (
    <main className="relative w-screen h-screen overflow-hidden bg-slate-950 font-sans select-none touch-none">
      {/* 1. Main Menu Screen */}
      {activeScreen === 'menu' && (
        <MainMenu
          progress={progress}
          onOpenTrackSelect={() => setActiveScreen('track_select')}
          onOpenGarage={() => setActiveScreen('garage')}
          onOpenAchievements={() => setActiveScreen('achievements')}
          onOpenSettings={() => setShowSettings(true)}
        />
      )}

      {/* 2. Garage Showroom Modal */}
      {activeScreen === 'garage' && (
        <GarageModal
          progress={progress}
          onUpdateProgress={handleUpdateProgress}
          onClose={() => setActiveScreen('menu')}
        />
      )}

      {/* 3. Track Select Modal */}
      {activeScreen === 'track_select' && (
        <TrackSelectModal
          progress={progress}
          onStartRace={handleStartRace}
          onClose={() => setActiveScreen('menu')}
        />
      )}

      {/* 4. Achievements Modal */}
      {activeScreen === 'achievements' && (
        <AchievementsModal
          progress={progress}
          onUpdateProgress={handleUpdateProgress}
          onClose={() => setActiveScreen('menu')}
        />
      )}

      {/* 5. In-Game 3D Racing View */}
      {activeScreen === 'racing' && (
        <div className="relative w-full h-full overflow-hidden">
          {/* Three.js 3D WebGL Canvas Viewport */}
          <div ref={gameContainerRef} className="absolute inset-0 w-full h-full z-0" />

          {/* HUD Overlay (Speed, Gear, Nitro, Standings, MiniMap) */}
          {raceState && (
            <HUD
              raceState={raceState}
              trackData={engineRef.current?.getTrackData() || null}
            />
          )}

          {/* Mobile Touch Controls & Keyboard Inputs */}
          {raceState && !raceResult && (
            <TouchControls
              settings={settings}
              onInputChange={(inputs) => engineRef.current?.setInputs(inputs)}
              onCameraSwitch={() => engineRef.current?.switchCamera()}
              onResetCar={() => engineRef.current?.resetCarOnTrack()}
              onPause={() => {
                const paused = engineRef.current?.togglePause();
                setIsPaused(!!paused);
              }}
              isNitroActive={raceState.isNitroActive}
              nitroPercent={raceState.nitroPercent}
            />
          )}

          {/* Pause Menu Modal */}
          {isPaused && (
            <PauseModal
              onResume={() => {
                engineRef.current?.togglePause();
                setIsPaused(false);
              }}
              onRestart={handleRestartRace}
              onOpenSettings={() => setShowSettings(true)}
              onQuit={handleQuitRace}
            />
          )}

          {/* End Race Results / Podium Modal */}
          {raceResult && (
            <EndRaceModal
              result={raceResult}
              isEndless={currentMode === 'endless_traffic'}
              onRestart={handleRestartRace}
              onGoGarage={() => {
                handleQuitRace();
                setActiveScreen('garage');
              }}
              onGoHome={handleQuitRace}
            />
          )}
        </div>
      )}

      {/* 6. Settings Modal */}
      {showSettings && (
        <SettingsModal
          settings={settings}
          onUpdateSettings={handleUpdateSettings}
          onClose={() => setShowSettings(false)}
        />
      )}
    </main>
  );
}

export default App;
