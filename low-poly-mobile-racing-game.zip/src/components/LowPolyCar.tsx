import { useRef } from "react";
import { useFrame } from "@react-three/fiber";
import type { Group } from "three";
import type { CarDef, CarShape } from "../game/types";

type Live = {
  wheelRot: number;
  steer: number;
  boosting: boolean;
  slip: number;
};

type Props = {
  def: CarDef;
  wheelRot?: number;
  steer?: number;
  boosting?: boolean;
  slip?: number;
  preview?: boolean;
  live?: () => Live;
};

function Wheel({
  x,
  z,
  y,
  rot,
  steer,
  scale = 1,
  wide = false,
}: {
  x: number;
  z: number;
  y: number;
  rot: number;
  steer: number;
  scale?: number;
  wide?: boolean;
}) {
  return (
    <group position={[x, y, z]} rotation={[0, steer, 0]}>
      <group rotation={[rot, 0, 0]}>
        <mesh rotation={[0, 0, Math.PI / 2]} castShadow>
          <cylinderGeometry args={[0.38 * scale, 0.38 * scale, wide ? 0.42 : 0.28, 8]} />
          <meshLambertMaterial color="#141414" flatShading />
        </mesh>
        <mesh rotation={[0, 0, Math.PI / 2]}>
          <cylinderGeometry args={[0.2 * scale, 0.2 * scale, wide ? 0.44 : 0.3, 6]} />
          <meshLambertMaterial color="#9aa3ad" flatShading />
        </mesh>
      </group>
    </group>
  );
}

function Body({ shape, def }: { shape: CarShape; def: CarDef }) {
  const c = def.color;
  const a = def.accent;
  const cabin = def.cabin;

  if (shape === "formula") {
    return (
      <group>
        <mesh position={[0, 0.28, 0.2]} castShadow>
          <boxGeometry args={[0.7, 0.28, 3.6]} />
          <meshLambertMaterial color={c} flatShading />
        </mesh>
        <mesh position={[0, 0.42, 0.55]} castShadow>
          <boxGeometry args={[0.55, 0.28, 1.1]} />
          <meshLambertMaterial color={c} flatShading />
        </mesh>
        <mesh position={[0, 0.62, 0.35]}>
          <boxGeometry args={[0.5, 0.22, 0.55]} />
          <meshLambertMaterial color={cabin} flatShading />
        </mesh>
        <mesh position={[0, 0.22, 1.7]}>
          <boxGeometry args={[0.28, 0.16, 0.9]} />
          <meshLambertMaterial color={c} flatShading />
        </mesh>
        <mesh position={[0, 0.55, -1.55]}>
          <boxGeometry args={[1.7, 0.08, 0.5]} />
          <meshLambertMaterial color={a} flatShading />
        </mesh>
        <mesh position={[0, 0.85, -1.62]}>
          <boxGeometry args={[1.7, 0.55, 0.08]} />
          <meshLambertMaterial color={a} flatShading />
        </mesh>
        <mesh position={[0, 0.22, -1.2]}>
          <boxGeometry args={[1.55, 0.12, 0.7]} />
          <meshLambertMaterial color="#222" flatShading />
        </mesh>
        <mesh position={[0.22, 0.18, -1.85]}>
          <boxGeometry args={[0.12, 0.1, 0.2]} />
          <meshBasicMaterial color="#ff8020" />
        </mesh>
      </group>
    );
  }

  if (shape === "truck") {
    return (
      <group>
        <mesh position={[0, 0.7, 1.05]} castShadow>
          <boxGeometry args={[1.7, 1.15, 1.5]} />
          <meshLambertMaterial color={c} flatShading />
        </mesh>
        <mesh position={[0, 1.15, 1.15]}>
          <boxGeometry args={[1.55, 0.45, 0.7]} />
          <meshLambertMaterial color={cabin} flatShading />
        </mesh>
        <mesh position={[0, 0.72, -0.85]} castShadow>
          <boxGeometry args={[1.75, 1.05, 2.2]} />
          <meshLambertMaterial color={a} flatShading />
        </mesh>
        <mesh position={[0.55, 0.55, 1.82]}>
          <boxGeometry args={[0.25, 0.18, 0.12]} />
          <meshBasicMaterial color="#ffe9a0" />
        </mesh>
        <mesh position={[-0.55, 0.55, 1.82]}>
          <boxGeometry args={[0.25, 0.18, 0.12]} />
          <meshBasicMaterial color="#ffe9a0" />
        </mesh>
      </group>
    );
  }

  if (shape === "suv") {
    return (
      <group>
        <mesh position={[0, 0.62, 0]} castShadow>
          <boxGeometry args={[1.7, 0.7, 3.3]} />
          <meshLambertMaterial color={c} flatShading />
        </mesh>
        <mesh position={[0, 1.12, -0.15]} castShadow>
          <boxGeometry args={[1.55, 0.55, 2.1]} />
          <meshLambertMaterial color={c} flatShading />
        </mesh>
        <mesh position={[0, 1.18, 0.15]}>
          <boxGeometry args={[1.4, 0.42, 1.5]} />
          <meshLambertMaterial color={cabin} flatShading />
        </mesh>
        <mesh position={[0, 1.45, -0.2]}>
          <boxGeometry args={[0.9, 0.08, 1.6]} />
          <meshLambertMaterial color={a} flatShading />
        </mesh>
        <mesh position={[0.5, 0.48, 1.68]}>
          <boxGeometry args={[0.28, 0.16, 0.1]} />
          <meshBasicMaterial color="#fff1c2" />
        </mesh>
        <mesh position={[-0.5, 0.48, 1.68]}>
          <boxGeometry args={[0.28, 0.16, 0.1]} />
          <meshBasicMaterial color="#fff1c2" />
        </mesh>
      </group>
    );
  }

  if (shape === "tuner") {
    return (
      <group>
        <mesh position={[0, 0.42, 0.1]} castShadow>
          <boxGeometry args={[1.85, 0.38, 3.15]} />
          <meshLambertMaterial color={c} flatShading />
        </mesh>
        <mesh position={[0, 0.72, -0.15]} castShadow>
          <boxGeometry args={[1.6, 0.38, 1.7]} />
          <meshLambertMaterial color={c} flatShading />
        </mesh>
        <mesh position={[0, 0.78, 0.05]}>
          <boxGeometry args={[1.4, 0.32, 1.15]} />
          <meshLambertMaterial color={cabin} flatShading />
        </mesh>
        <mesh position={[0, 0.95, -1.55]}>
          <boxGeometry args={[1.55, 0.5, 0.1]} />
          <meshLambertMaterial color={a} flatShading />
        </mesh>
        <mesh position={[0, 0.28, -1.55]}>
          <boxGeometry args={[1.9, 0.1, 0.55]} />
          <meshLambertMaterial color={a} flatShading />
        </mesh>
        <mesh position={[0, 0.28, 1.55]}>
          <boxGeometry args={[1.7, 0.12, 0.4]} />
          <meshLambertMaterial color="#222" flatShading />
        </mesh>
        <mesh position={[0.55, 0.4, 1.7]}>
          <boxGeometry args={[0.3, 0.12, 0.08]} />
          <meshBasicMaterial color="#fff3c0" />
        </mesh>
        <mesh position={[-0.55, 0.4, 1.7]}>
          <boxGeometry args={[0.3, 0.12, 0.08]} />
          <meshBasicMaterial color="#fff3c0" />
        </mesh>
      </group>
    );
  }

  if (shape === "prototype") {
    return (
      <group>
        <mesh position={[0, 0.38, 0.15]} castShadow>
          <boxGeometry args={[1.55, 0.32, 3.5]} />
          <meshLambertMaterial color={c} flatShading />
        </mesh>
        <mesh position={[0, 0.58, 0.35]} castShadow>
          <boxGeometry args={[1.35, 0.28, 2.2]} />
          <meshLambertMaterial color={c} flatShading />
        </mesh>
        <mesh position={[0, 0.72, 0.1]}>
          <boxGeometry args={[1.15, 0.28, 1.3]} />
          <meshLambertMaterial color={cabin} flatShading />
        </mesh>
        <mesh position={[0, 0.32, 1.7]}>
          <boxGeometry args={[0.5, 0.16, 0.8]} />
          <meshLambertMaterial color={a} flatShading />
        </mesh>
        <mesh position={[0, 0.62, -1.65]}>
          <boxGeometry args={[1.45, 0.28, 0.35]} />
          <meshLambertMaterial color={a} flatShading />
        </mesh>
        <mesh position={[0.35, 0.36, 1.92]}>
          <boxGeometry args={[0.22, 0.1, 0.08]} />
          <meshBasicMaterial color={a} />
        </mesh>
        <mesh position={[-0.35, 0.36, 1.92]}>
          <boxGeometry args={[0.22, 0.1, 0.08]} />
          <meshBasicMaterial color={a} />
        </mesh>
      </group>
    );
  }

  if (shape === "muscle") {
    return (
      <group>
        <mesh position={[0, 0.45, 0.15]} castShadow>
          <boxGeometry args={[1.72, 0.42, 3.55]} />
          <meshLambertMaterial color={c} flatShading />
        </mesh>
        <mesh position={[0, 0.78, -0.35]} castShadow>
          <boxGeometry args={[1.55, 0.42, 1.55]} />
          <meshLambertMaterial color={c} flatShading />
        </mesh>
        <mesh position={[0, 0.85, -0.2]}>
          <boxGeometry args={[1.38, 0.32, 1.15]} />
          <meshLambertMaterial color={cabin} flatShading />
        </mesh>
        <mesh position={[0, 0.52, 1.1]}>
          <boxGeometry args={[1.5, 0.16, 1.2]} />
          <meshLambertMaterial color={c} flatShading />
        </mesh>
        <mesh position={[0.5, 0.42, 1.9]}>
          <boxGeometry args={[0.32, 0.14, 0.1]} />
          <meshBasicMaterial color="#fff1b0" />
        </mesh>
        <mesh position={[-0.5, 0.42, 1.9]}>
          <boxGeometry args={[0.32, 0.14, 0.1]} />
          <meshBasicMaterial color="#fff1b0" />
        </mesh>
        <mesh position={[0, 0.55, -1.7]}>
          <boxGeometry args={[1.4, 0.16, 0.22]} />
          <meshLambertMaterial color={a} flatShading />
        </mesh>
      </group>
    );
  }

  if (shape === "buggy") {
    return (
      <group>
        <mesh position={[0, 0.55, 0]} castShadow>
          <boxGeometry args={[1.45, 0.35, 2.4]} />
          <meshLambertMaterial color={c} flatShading />
        </mesh>
        <mesh position={[0, 0.95, -0.15]} castShadow>
          <boxGeometry args={[1.2, 0.55, 1.1]} />
          <meshLambertMaterial color={a} flatShading />
        </mesh>
        <mesh position={[0, 1.05, 0]}>
          <boxGeometry args={[1.05, 0.35, 0.7]} />
          <meshLambertMaterial color={cabin} flatShading />
        </mesh>
        <mesh position={[0.55, 0.85, 0.9]}>
          <boxGeometry args={[0.08, 0.7, 0.08]} />
          <meshLambertMaterial color="#333" flatShading />
        </mesh>
        <mesh position={[-0.55, 0.85, 0.9]}>
          <boxGeometry args={[0.08, 0.7, 0.08]} />
          <meshLambertMaterial color="#333" flatShading />
        </mesh>
        <mesh position={[0.5, 0.48, 1.25]}>
          <boxGeometry args={[0.22, 0.14, 0.1]} />
          <meshBasicMaterial color="#fff3c0" />
        </mesh>
        <mesh position={[-0.5, 0.48, 1.25]}>
          <boxGeometry args={[0.22, 0.14, 0.1]} />
          <meshBasicMaterial color="#fff3c0" />
        </mesh>
      </group>
    );
  }

  if (shape === "van") {
    return (
      <group>
        <mesh position={[0, 0.85, -0.15]} castShadow>
          <boxGeometry args={[1.7, 1.35, 3.3]} />
          <meshLambertMaterial color={c} flatShading />
        </mesh>
        <mesh position={[0, 1.05, 1.05]}>
          <boxGeometry args={[1.55, 0.7, 0.9]} />
          <meshLambertMaterial color={cabin} flatShading />
        </mesh>
        <mesh position={[0.5, 0.55, 1.55]}>
          <boxGeometry args={[0.28, 0.16, 0.1]} />
          <meshBasicMaterial color="#fff1c2" />
        </mesh>
        <mesh position={[-0.5, 0.55, 1.55]}>
          <boxGeometry args={[0.28, 0.16, 0.1]} />
          <meshBasicMaterial color="#fff1c2" />
        </mesh>
        <mesh position={[0, 1.2, -1.3]}>
          <boxGeometry args={[1.2, 0.4, 0.08]} />
          <meshLambertMaterial color={a} flatShading />
        </mesh>
      </group>
    );
  }

  if (shape === "coupe") {
    return (
      <group>
        <mesh position={[0, 0.42, 0]} castShadow>
          <boxGeometry args={[1.62, 0.4, 3.2]} />
          <meshLambertMaterial color={c} flatShading />
        </mesh>
        <mesh position={[0, 0.78, -0.1]} castShadow>
          <boxGeometry args={[1.45, 0.42, 1.7]} />
          <meshLambertMaterial color={c} flatShading />
        </mesh>
        <mesh position={[0, 0.85, 0.05]}>
          <boxGeometry args={[1.28, 0.32, 1.2]} />
          <meshLambertMaterial color={cabin} flatShading />
        </mesh>
        <mesh position={[0.48, 0.4, 1.64]}>
          <boxGeometry args={[0.28, 0.12, 0.08]} />
          <meshBasicMaterial color="#fff3c0" />
        </mesh>
        <mesh position={[-0.48, 0.4, 1.64]}>
          <boxGeometry args={[0.28, 0.12, 0.08]} />
          <meshBasicMaterial color="#fff3c0" />
        </mesh>
        <mesh position={[0, 0.5, -1.58]}>
          <boxGeometry args={[1.3, 0.16, 0.18]} />
          <meshLambertMaterial color={a} flatShading />
        </mesh>
      </group>
    );
  }

  return (
    <group>
      <mesh position={[0, 0.4, 0.05]} castShadow>
        <boxGeometry args={[1.68, 0.38, 3.25]} />
        <meshLambertMaterial color={c} flatShading />
      </mesh>
      <mesh position={[0, 0.72, -0.2]} castShadow>
        <boxGeometry args={[1.52, 0.38, 1.75]} />
        <meshLambertMaterial color={c} flatShading />
      </mesh>
      <mesh position={[0, 0.8, -0.05]}>
        <boxGeometry args={[1.32, 0.3, 1.2]} />
        <meshLambertMaterial color={cabin} flatShading />
      </mesh>
      <mesh position={[0, 0.72, -1.55]}>
        <boxGeometry args={[1.4, 0.28, 0.22]} />
        <meshLambertMaterial color={a} flatShading />
      </mesh>
      <mesh position={[0.5, 0.4, 1.68]}>
        <boxGeometry args={[0.3, 0.12, 0.08]} />
        <meshBasicMaterial color="#fff3c0" />
      </mesh>
      <mesh position={[-0.5, 0.4, 1.68]}>
        <boxGeometry args={[0.3, 0.12, 0.08]} />
        <meshBasicMaterial color="#fff3c0" />
      </mesh>
      <mesh position={[0.35, 0.32, -1.68]}>
        <boxGeometry args={[0.18, 0.1, 0.08]} />
        <meshBasicMaterial color="#ff3030" />
      </mesh>
      <mesh position={[-0.35, 0.32, -1.68]}>
        <boxGeometry args={[0.18, 0.1, 0.08]} />
        <meshBasicMaterial color="#ff3030" />
      </mesh>
    </group>
  );
}

function Flames({ on, getOn }: { on: boolean; getOn?: () => boolean }) {
  const ref = useRef<Group>(null);
  useFrame(() => {
    if (!ref.current) return;
    const active = getOn ? getOn() : on;
    ref.current.visible = active;
    if (active) {
      const s = 0.8 + Math.random() * 0.7;
      ref.current.scale.set(1, s, 1);
      ref.current.position.z = -1.75 - Math.random() * 0.15;
    }
  });
  return (
    <group ref={ref} position={[0, 0.35, -1.75]} visible={on}>
      <mesh position={[0.28, 0, 0]} rotation={[Math.PI / 2, 0, 0]}>
        <coneGeometry args={[0.12, 1.1, 5]} />
        <meshBasicMaterial color="#7dffff" transparent opacity={0.9} />
      </mesh>
      <mesh position={[-0.28, 0, 0]} rotation={[Math.PI / 2, 0, 0]}>
        <coneGeometry args={[0.12, 1.1, 5]} />
        <meshBasicMaterial color="#ffb347" transparent opacity={0.85} />
      </mesh>
    </group>
  );
}

export function LowPolyCar({
  def,
  wheelRot = 0,
  steer = 0,
  boosting = false,
  slip = 0,
  preview = false,
  live,
}: Props) {
  const group = useRef<Group>(null);
  const bodyRoll = useRef<Group>(null);
  const w1 = useRef<Group>(null);
  const w2 = useRef<Group>(null);
  const w3 = useRef<Group>(null);
  const w4 = useRef<Group>(null);
  const yOff = def.shape === "formula" ? 0 : def.shape === "buggy" ? 0.12 : 0;
  const wScale = def.shape === "buggy" || def.shape === "truck" ? 1.15 : def.shape === "formula" ? 0.95 : 1;
  const wide = def.shape === "tuner" || def.shape === "formula";
  const wx = def.shape === "formula" ? 0.85 : def.shape === "tuner" ? 0.95 : 0.78;
  const zf = def.shape === "formula" ? 1.15 : def.shape === "van" ? 1.2 : def.shape === "buggy" ? 0.95 : 1.12;
  const zr = def.shape === "formula" ? -1.2 : def.shape === "van" ? -1.15 : def.shape === "buggy" ? -0.95 : -1.15;
  const wy = (def.shape === "truck" ? 0.48 : 0.38) + yOff;

  useFrame((state) => {
    if (preview && group.current) {
      group.current.rotation.y = state.clock.elapsedTime * 0.65;
      group.current.position.y = Math.sin(state.clock.elapsedTime * 1.4) * 0.06;
    }
    const L = live ? live() : { wheelRot, steer, boosting, slip };
    if (bodyRoll.current) bodyRoll.current.rotation.z = -L.steer * 0.12 - L.slip * 0.15;
    const sa = L.steer * 0.45;
    if (w1.current) {
      w1.current.rotation.y = sa;
      w1.current.children[0].rotation.x = L.wheelRot;
    }
    if (w2.current) {
      w2.current.rotation.y = sa;
      w2.current.children[0].rotation.x = L.wheelRot;
    }
    if (w3.current) w3.current.children[0].rotation.x = L.wheelRot;
    if (w4.current) w4.current.children[0].rotation.x = L.wheelRot;
  });

  return (
    <group ref={group}>
      <group ref={bodyRoll}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.02, 0]}>
          <circleGeometry args={[1.15, 10]} />
          <meshBasicMaterial color="#000" transparent opacity={0.28} />
        </mesh>
        <group position={[0, yOff, 0]}>
          <Body shape={def.shape} def={def} />
          <group ref={w1} position={[wx, wy, zf]}>
            <Wheel x={0} z={0} y={0} rot={0} steer={0} scale={wScale} wide={wide} />
          </group>
          <group ref={w2} position={[-wx, wy, zf]}>
            <Wheel x={0} z={0} y={0} rot={0} steer={0} scale={wScale} wide={wide} />
          </group>
          <group ref={w3} position={[wx, wy, zr]}>
            <Wheel x={0} z={0} y={0} rot={0} steer={0} scale={wScale} wide={wide} />
          </group>
          <group ref={w4} position={[-wx, wy, zr]}>
            <Wheel x={0} z={0} y={0} rot={0} steer={0} scale={wScale} wide={wide} />
          </group>
          <Flames on={boosting} getOn={live ? () => live().boosting : undefined} />
        </group>
      </group>
    </group>
  );
}
