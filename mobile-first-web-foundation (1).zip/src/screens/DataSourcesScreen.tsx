import { useEffect, useState } from 'react';
import { BrandMark, IconGear } from '../components/icons';
import { Button, ScreenHeader } from '../components/ui/primitives';
import { useApp } from '../context/AppContext';
import { marketApi } from '../services/api';
import type { DataProvider } from '../types';

export function DataSourcesScreen() {
  const { back } = useApp();
  const [providers, setProviders] = useState<DataProvider[]>([]);
  const [toast, setToast] = useState<string | null>(null);

  useEffect(() => {
    marketApi.listProviders().then(setProviders);
  }, []);

  const primary = providers.find((p) => p.primary);
  const backups = providers.filter((p) => !p.primary);

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <ScreenHeader title="Source de données (Backup)" onBack={back} />

      <div className="min-h-0 flex-1 overflow-y-auto px-4 pb-3">
        {primary && (
          <section className="mb-4">
            <h3 className="mb-2 px-1 text-[12px] font-semibold uppercase tracking-wide text-slate-400">
              Fournisseur principal
            </h3>
            <ProviderCard p={primary} />
          </section>
        )}

        <section>
          <h3 className="mb-2 px-1 text-[12px] font-semibold uppercase tracking-wide text-slate-400">
            Sources de secours
          </h3>
          <div className="space-y-2">
            {backups.map((p) => (
              <ProviderCard key={p.id} p={p} />
            ))}
          </div>
        </section>
        {toast && <p className="mt-4 text-center text-[12px] text-cyan-300">{toast}</p>}
      </div>

      <div className="px-5 pb-3">
        <Button
          className="h-auto py-3 leading-tight"
          onClick={() =>
            setToast('Ajout de source : à brancher sur POST /api/providers (démo).')
          }
        >
          Ajouter une nouvelle source de données
        </Button>
      </div>
    </div>
  );
}

function ProviderCard({ p }: { p: DataProvider }) {
  return (
    <div className="flex items-center gap-3 rounded-2xl border border-white/5 bg-[#101c31] px-3 py-3">
      <BrandMark brand={p.brand} />
      <div className="min-w-0 flex-1">
        <div className="text-[14px] font-semibold text-white">{p.name}</div>
        <div className="text-[12px] text-slate-400">{p.subtitle}</div>
        {p.connected ? (
          <div className="mt-0.5 flex items-center gap-1.5 text-[11px] text-emerald-400">
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" />
            Connecté
          </div>
        ) : (
          <div className="mt-0.5 text-[11px] text-slate-500">Non connecté</div>
        )}
      </div>
      <button className="p-2 text-slate-500" aria-label="Configurer">
        <IconGear size={18} />
      </button>
    </div>
  );
}
