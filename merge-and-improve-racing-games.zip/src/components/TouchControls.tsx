import React, { useState, useEffect, useRef, useCallback } from 'react';
import { ControlSettings, VehicleInputs } from '../types/game';
import { ArrowLeft, ArrowRight, Flame, Disc, Camera, RotateCcw, Pause } from 'lucide-react';
import { triggerHaptic } from '../services/storage';

interface TouchControlsProps {
  settings: ControlSettings;
  onInputChange: (inputs: Partial<VehicleInputs>) => void;
  onCameraSwitch: () => void;
  onResetCar: () => void;
  onPause: () => void;
  isNitroActive: boolean;
  nitroPercent: number;
}

export const TouchControls: React.FC<TouchControlsProps> = ({
  settings,
  onInputChange,
  onCameraSwitch,
  onResetCar,
  onPause,
  isNitroActive,
  nitroPercent,
}) => {
  const [leftPressed, setLeftPressed] = useState(false);
  const [rightPressed, setRightPressed] = useState(false);
  const [throttlePressed, setThrottlePressed] = useState(false);
  const [brakePressed, setBrakePressed] = useState(false);
  const [handbrakePressed, setHandbrakePressed] = useState(false);
  const [nitroPressed, setNitroPressed] = useState(false);

  // Joystick state
  const joystickBaseRef = useRef<HTMLDivElement>(null);
  const [knobPos, setKnobPos] = useState({ x: 0, y: 0 });
  const isDraggingJoystick = useRef(false);
  const joystickTouchId = useRef<number | null>(null);

  // Wheel state
  const wheelRef = useRef<HTMLDivElement>(null);
  const [wheelAngle, setWheelAngle] = useState(0);
  const isDraggingWheel = useRef(false);

  // Ref to always have latest inputs for keyboard handler
  const currentInputsRef = useRef<VehicleInputs>({
    steer: 0,
    throttle: 0,
    brake: 0,
    handbrake: false,
    nitro: false,
  });

  // Keyboard handler for desktop
  useEffect(() => {
    const activeKeys: Record<string, boolean> = {};

    const updateFromKeys = () => {
      let steer = 0;
      if (activeKeys['ArrowLeft'] || activeKeys['KeyA'] || activeKeys['a'] || activeKeys['q']) steer -= 1;
      if (activeKeys['ArrowRight'] || activeKeys['KeyD'] || activeKeys['d']) steer += 1;

      const nitroKey = !!activeKeys['ShiftLeft'] || !!activeKeys['ShiftRight'];
      const handbrakeKey = !!activeKeys['Space'];

      let throttle = 0;
      if (activeKeys['ArrowUp'] || activeKeys['KeyW'] || activeKeys['w'] || activeKeys['z']) throttle = 1;

      // Auto-throttle when Nitro or Drift key is pressed!
      if (nitroKey || handbrakeKey) {
        throttle = 1;
      }

      let brake = 0;
      if (activeKeys['ArrowDown'] || activeKeys['KeyS'] || activeKeys['s']) brake = 1;

      const newInputs = {
        steer: steer * settings.steeringSensitivity,
        throttle,
        brake,
        handbrake: handbrakeKey,
        nitro: nitroKey,
      };

      currentInputsRef.current = newInputs;
      onInputChange(newInputs);
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.repeat) return;
      activeKeys[e.code] = true;
      activeKeys[e.key] = true;

      if (e.code === 'KeyC') onCameraSwitch();
      if (e.code === 'KeyR') onResetCar();
      if (e.code === 'Escape' || e.code === 'KeyP') onPause();

      updateFromKeys();
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      activeKeys[e.code] = false;
      activeKeys[e.key] = false;
      updateFromKeys();
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [settings.steeringSensitivity, onInputChange, onCameraSwitch, onResetCar, onPause]);

  // Update touch buttons steer
  useEffect(() => {
    if (settings.scheme !== 'buttons') return;
    let steer = 0;
    // Left turns LEFT (-1), Right turns RIGHT (+1)
    if (leftPressed && !rightPressed) steer = -1 * settings.steeringSensitivity;
    if (rightPressed && !leftPressed) steer = 1 * settings.steeringSensitivity;
    onInputChange({ steer });
  }, [leftPressed, rightPressed, settings.steeringSensitivity, settings.scheme, onInputChange]);

  // Update pedals with AUTO-THROTTLE on nitro/drift!
  useEffect(() => {
    // When nitro or drift is pressed, automatically engage throttle!
    const effectiveThrottle = (nitroPressed || handbrakePressed || throttlePressed) ? 1 : 0;
    onInputChange({
      throttle: effectiveThrottle,
      brake: brakePressed ? 1 : 0,
      handbrake: handbrakePressed,
      nitro: nitroPressed,
    });
  }, [throttlePressed, brakePressed, handbrakePressed, nitroPressed, onInputChange]);

  // Progressive Non-linear Joystick calculations
  const handleJoystickMove = useCallback((clientX: number, clientY: number) => {
    if (!joystickBaseRef.current) return;
    const rect = joystickBaseRef.current.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;

    const maxRadius = 64; // larger travel range
    const deadzone = 6; // eliminates micro jitter

    let dx = clientX - centerX;
    let dy = clientY - centerY;
    const distance = Math.hypot(dx, dy);

    if (distance > maxRadius) {
      dx = (dx / distance) * maxRadius;
      dy = (dy / distance) * maxRadius;
    }

    setKnobPos({ x: dx, y: dy });

    // Compute progressive steering value
    let steer = 0;
    const absX = Math.abs(dx);
    if (absX > deadzone) {
      const normalized = (absX - deadzone) / (maxRadius - deadzone);
      // Non-linear power curve (x^1.55) gives fine, silky analog precision near center!
      const curved = Math.pow(Math.min(1, normalized), 1.55);
      // dx > 0 turns RIGHT (+1), dx < 0 turns LEFT (-1)
      steer = Math.sign(dx) * curved * settings.steeringSensitivity;
    }

    onInputChange({ steer });
  }, [settings.steeringSensitivity, onInputChange]);

  const handleJoystickTouchStart = (e: React.TouchEvent) => {
    e.preventDefault();
    isDraggingJoystick.current = true;
    const touch = e.changedTouches[0];
    joystickTouchId.current = touch.identifier;
    handleJoystickMove(touch.clientX, touch.clientY);
  };

  const handleJoystickTouchMove = (e: React.TouchEvent) => {
    if (!isDraggingJoystick.current) return;
    for (let i = 0; i < e.changedTouches.length; i++) {
      const touch = e.changedTouches[i];
      if (touch.identifier === joystickTouchId.current) {
        handleJoystickMove(touch.clientX, touch.clientY);
        break;
      }
    }
  };

  const handleJoystickTouchEnd = () => {
    isDraggingJoystick.current = false;
    joystickTouchId.current = null;
    setKnobPos({ x: 0, y: 0 });
    onInputChange({ steer: 0 });
  };

  // Virtual Steering Wheel handlers
  const handleWheelTouchMove = (clientX: number, clientY: number) => {
    if (!isDraggingWheel.current || !wheelRef.current) return;
    const rect = wheelRef.current.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;

    const rad = Math.atan2(clientY - centerY, clientX - centerX);
    let deg = (rad * 180) / Math.PI + 90;
    if (deg > 180) deg -= 360;

    const clampedDeg = Math.max(-85, Math.min(85, deg));
    setWheelAngle(clampedDeg);
    // clampedDeg > 0 is turning RIGHT, clampedDeg < 0 is turning LEFT
    onInputChange({ steer: (clampedDeg / 85) * settings.steeringSensitivity });
  };

  return (
    <div className="absolute inset-0 pointer-events-none select-none flex flex-col justify-between p-3 md:p-6 z-20 overflow-hidden">
      {/* Top Bar Quick Action Controls */}
      <div className="flex justify-end gap-2 pointer-events-auto">
        <button
          onClick={onCameraSwitch}
          className="w-10 h-10 md:w-11 md:h-11 rounded-2xl bg-slate-900/80 backdrop-blur-md border border-white/20 text-white flex items-center justify-center shadow-lg active:scale-95 transition-transform"
          title="Changer de vue caméra (C)"
        >
          <Camera className="w-5 h-5 text-cyan-400" />
        </button>

        <button
          onClick={onResetCar}
          className="w-10 h-10 md:w-11 md:h-11 rounded-2xl bg-slate-900/80 backdrop-blur-md border border-white/20 text-white flex items-center justify-center shadow-lg active:scale-95 transition-transform"
          title="Replacer la voiture sur la piste (R)"
        >
          <RotateCcw className="w-5 h-5 text-amber-400" />
        </button>

        <button
          onClick={onPause}
          className="w-10 h-10 md:w-11 md:h-11 rounded-2xl bg-slate-900/80 backdrop-blur-md border border-white/20 text-white flex items-center justify-center shadow-lg active:scale-95 transition-transform"
          title="Mettre en pause (P)"
        >
          <Pause className="w-5 h-5 text-rose-400" />
        </button>
      </div>

      {/* Bottom Driving Touch Controls */}
      <div className="flex justify-between items-end w-full pointer-events-auto pb-1 md:pb-2">
        {/* Left Thumb: Steering Scheme (Joystick, Buttons, or Wheel) */}
        <div>
          {settings.scheme === 'joystick' ? (
            /* Smooth Progressive Analog Joystick */
            <div
              ref={joystickBaseRef}
              onTouchStart={handleJoystickTouchStart}
              onTouchMove={handleJoystickTouchMove}
              onTouchEnd={handleJoystickTouchEnd}
              onTouchCancel={handleJoystickTouchEnd}
              onMouseDown={(e) => {
                isDraggingJoystick.current = true;
                handleJoystickMove(e.clientX, e.clientY);
                const onMouseMove = (moveE: MouseEvent) => {
                  if (isDraggingJoystick.current) handleJoystickMove(moveE.clientX, moveE.clientY);
                };
                const onMouseUp = () => {
                  isDraggingJoystick.current = false;
                  setKnobPos({ x: 0, y: 0 });
                  onInputChange({ steer: 0 });
                  window.removeEventListener('mousemove', onMouseMove);
                  window.removeEventListener('mouseup', onMouseUp);
                };
                window.addEventListener('mousemove', onMouseMove);
                window.addEventListener('mouseup', onMouseUp);
              }}
              className="relative w-32 h-32 md:w-36 md:h-36 rounded-full bg-slate-900/70 backdrop-blur-md border border-white/20 flex items-center justify-center shadow-2xl shadow-black/50 touch-none cursor-pointer"
            >
              {/* Outer guide ring */}
              <div className="absolute inset-2 rounded-full border border-dashed border-white/20 pointer-events-none" />
              {/* Center thumb stick */}
              <div
                className="w-14 h-14 md:w-16 md:h-16 rounded-full bg-gradient-to-tr from-cyan-600 to-sky-400 border-2 border-white/60 shadow-lg shadow-cyan-500/50 flex items-center justify-center pointer-events-none transition-transform duration-75"
                style={{
                  transform: `translate(${knobPos.x}px, ${knobPos.y}px)`,
                }}
              >
                <div className="w-5 h-5 rounded-full bg-slate-900/60" />
              </div>
            </div>
          ) : settings.scheme === 'wheel' ? (
            /* Virtual Steering Wheel */
            <div
              ref={wheelRef}
              onTouchStart={() => (isDraggingWheel.current = true)}
              onTouchMove={(e) => handleWheelTouchMove(e.touches[0].clientX, e.touches[0].clientY)}
              onTouchEnd={() => {
                isDraggingWheel.current = false;
                setWheelAngle(0);
                onInputChange({ steer: 0 });
              }}
              className="relative w-32 h-32 md:w-36 md:h-36 rounded-full border-4 border-slate-700 bg-slate-900/80 backdrop-blur-md flex items-center justify-center shadow-2xl touch-none cursor-pointer"
              style={{ transform: `rotate(${wheelAngle}deg)` }}
            >
              <div className="w-12 h-12 rounded-full border-2 border-white/40 bg-slate-800 flex items-center justify-center">
                <div className="w-3 h-3 rounded-full bg-cyan-400" />
              </div>
              <div className="absolute top-2 w-2 h-4 bg-red-500 rounded-full" />
            </div>
          ) : (
            /* Arrow Buttons (Touch) */
            <div className="flex gap-2.5">
              <button
                onTouchStart={(e) => {
                  e.preventDefault();
                  setLeftPressed(true);
                  triggerHaptic(20);
                }}
                onTouchEnd={(e) => {
                  e.preventDefault();
                  setLeftPressed(false);
                }}
                onMouseDown={() => setLeftPressed(true)}
                onMouseUp={() => setLeftPressed(false)}
                className={`w-20 h-20 md:w-24 md:h-24 rounded-3xl backdrop-blur-md border flex items-center justify-center transition-all ${
                  leftPressed
                    ? 'bg-cyan-500/40 border-cyan-300 scale-95 shadow-lg shadow-cyan-500/40'
                    : 'bg-slate-900/70 border-white/20 text-white shadow-xl shadow-black/40'
                }`}
                title="Tourner à gauche"
              >
                <ArrowLeft className="w-9 h-9 text-cyan-300" />
              </button>

              <button
                onTouchStart={(e) => {
                  e.preventDefault();
                  setRightPressed(true);
                  triggerHaptic(20);
                }}
                onTouchEnd={(e) => {
                  e.preventDefault();
                  setRightPressed(false);
                }}
                onMouseDown={() => setRightPressed(true)}
                onMouseUp={() => setRightPressed(false)}
                className={`w-20 h-20 md:w-24 md:h-24 rounded-3xl backdrop-blur-md border flex items-center justify-center transition-all ${
                  rightPressed
                    ? 'bg-cyan-500/40 border-cyan-300 scale-95 shadow-lg shadow-cyan-500/40'
                    : 'bg-slate-900/70 border-white/20 text-white shadow-xl shadow-black/40'
                }`}
                title="Tourner à droite"
              >
                <ArrowRight className="w-9 h-9 text-cyan-300" />
              </button>
            </div>
          )}
        </div>

        {/* Right Thumb: Nitro, Drift/Handbrake, Brake, Gas */}
        <div className="flex items-end gap-2.5">
          {/* Action Column: Nitro Boost & Drift */}
          <div className="flex flex-col gap-2.5">
            {/* Nitro Boost Button (Automatically engages full throttle!) */}
            <button
              onTouchStart={(e) => {
                e.preventDefault();
                setNitroPressed(true);
                triggerHaptic(40);
              }}
              onTouchEnd={(e) => {
                e.preventDefault();
                setNitroPressed(false);
              }}
              onMouseDown={() => setNitroPressed(true)}
              onMouseUp={() => setNitroPressed(false)}
              disabled={nitroPercent <= 5}
              className={`w-16 h-16 md:w-20 md:h-20 rounded-2xl backdrop-blur-md border flex flex-col items-center justify-center transition-all ${
                isNitroActive || nitroPressed
                  ? 'bg-gradient-to-tr from-cyan-600 to-sky-400 border-cyan-200 scale-95 shadow-xl shadow-cyan-400/60 text-white'
                  : nitroPercent > 20
                  ? 'bg-slate-900/80 border-cyan-500/40 text-cyan-400 shadow-lg shadow-cyan-900/30'
                  : 'bg-slate-900/40 border-slate-700/50 text-slate-500'
              }`}
              title="Nitro Boost (Shift) - Accélération auto !"
            >
              <Flame className={`w-7 h-7 ${isNitroActive ? 'animate-bounce text-yellow-200' : ''}`} />
              <span className="text-[10px] font-black uppercase tracking-tighter">NITRO</span>
            </button>

            {/* Handbrake Drift Button (Automatically engages full throttle!) */}
            <button
              onTouchStart={(e) => {
                e.preventDefault();
                setHandbrakePressed(true);
                triggerHaptic(25);
              }}
              onTouchEnd={(e) => {
                e.preventDefault();
                setHandbrakePressed(false);
              }}
              onMouseDown={() => setHandbrakePressed(true)}
              onMouseUp={() => setHandbrakePressed(false)}
              className={`w-16 h-16 md:w-20 md:h-20 rounded-2xl backdrop-blur-md border flex flex-col items-center justify-center transition-all ${
                handbrakePressed
                  ? 'bg-fuchsia-600/50 border-fuchsia-300 scale-95 shadow-lg shadow-fuchsia-500/40 text-white'
                  : 'bg-slate-900/80 border-fuchsia-500/30 text-fuchsia-400 shadow-xl shadow-black/40'
              }`}
              title="Drift / Frein à main (Espace) - Accélération auto !"
            >
              <Disc className="w-6 h-6 animate-spin" />
              <span className="text-[9px] font-black uppercase tracking-tighter">DRIFT</span>
            </button>
          </div>

          {/* Brake Pedal */}
          <button
            onTouchStart={(e) => {
              e.preventDefault();
              setBrakePressed(true);
              triggerHaptic(20);
            }}
            onTouchEnd={(e) => {
              e.preventDefault();
              setBrakePressed(false);
            }}
            onMouseDown={() => setBrakePressed(true)}
            onMouseUp={() => setBrakePressed(false)}
            className={`w-16 h-24 md:w-20 md:h-30 rounded-2xl backdrop-blur-md border flex flex-col items-center justify-center transition-all ${
              brakePressed
                ? 'bg-rose-600/40 border-rose-300 scale-95 shadow-xl shadow-rose-500/40'
                : 'bg-slate-900/80 border-white/20 text-slate-300 shadow-xl shadow-black/40'
            }`}
            title="Frein (Bas / S)"
          >
            <div className="w-8 h-2 rounded bg-rose-500/60 mb-2" />
            <span className="text-xs font-black uppercase tracking-wider text-rose-300">FREIN</span>
          </button>

          {/* Gas / Throttle Pedal */}
          <button
            onTouchStart={(e) => {
              e.preventDefault();
              setThrottlePressed(true);
              triggerHaptic(25);
            }}
            onTouchEnd={(e) => {
              e.preventDefault();
              setThrottlePressed(false);
            }}
            onMouseDown={() => setThrottlePressed(true)}
            onMouseUp={() => setThrottlePressed(false)}
            className={`w-18 h-28 md:w-22 md:h-34 rounded-2xl backdrop-blur-md border flex flex-col items-center justify-center transition-all ${
              throttlePressed || isNitroActive || handbrakePressed
                ? 'bg-emerald-500/40 border-emerald-300 scale-95 shadow-2xl shadow-emerald-500/50'
                : 'bg-slate-900/80 border-white/20 text-slate-300 shadow-xl shadow-black/40'
            }`}
            title="Accélérateur (Haut / W)"
          >
            <div className="w-10 h-2 rounded bg-emerald-400/80 mb-3" />
            <span className="text-sm font-black uppercase tracking-wider text-emerald-300">GAZ</span>
          </button>
        </div>
      </div>
    </div>
  );
};
