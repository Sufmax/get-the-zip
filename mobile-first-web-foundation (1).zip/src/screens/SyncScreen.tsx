import { useEffect, useState } from 'react';
import { IconCheck } from '../components/icons';
import { Button, ScreenHeader } from '../components/ui/primitives';
import { useApp } from '../context/AppContext';
import { marketApi } from '../services/api';
import { cn } from '../utils/cn';

export function SyncScreen() {
  const { back, navigate, setMatches, setAnalyzing, selectedAsset, timeframe, zone, selectionMode, period } =
    useApp();
  const steps = marketApi.getSyncSteps();
  const [progress, setProgress] = useState(8);
  const [doneStep, setDoneStep] = useState(0);
  const [cancelled, setCancelled] = useState(false);

  useEffect(() => {
    if (!selectedAsset) {
      marketApi.runAnalysis({
        assetId: 'btc-usdt',
        timeframe,
        zone,
        mode: selectionMode,
        period,
      }).then(setMatches);
      return;
    }
    marketApi
      .runAnalysis({
        assetId: selectedAsset.id,
        timeframe,
        zone,
        mode: selectionMode,
        period,
      })
      .then(setMatches);
  }, [period, selectedAsset, selectionMode, setMatches, timeframe, zone]);

  useEffect(() => {
    if (cancelled) return;
    const t = setInterval(() => {
      setProgress((p) => {
        const n = Math.min(100, p + 6);
        setDoneStep(Math.min(steps.length, Math.floor((n / 100) * steps.length) + (n > 12 ? 1 : 0)));
        if (n >= 100) {
          clearInterval(t);
          setAnalyzing(false);
        }
        return n;
      });
    }, 180);
    return () => clearInterval(t);
  }, [cancelled, setAnalyzing, steps.length]);

  const finished = progress >= 100;

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <ScreenHeader
        title={finished ? 'Synchronisation des données (Terminée)' : 'Synchronisation des données'}
        onBack={back}
      />

      <div className="px-5 pt-2">
        <div className="flex items-center gap-3">
          <span
            className={cn(
              'flex h-9 w-9 items-center justify-center rounded-full',
              finished ? 'bg-emerald-500 text-white' : 'bg-emerald-500/20 text-emerald-400',
            )}
          >
            <IconCheck size={18} />
          </span>
          <div className="flex-1">
            <div className="mb-1 flex items-center justify-between text-[13px] text-slate-300">
              <span>Progression…</span>
              <span className="font-semibold text-white">{progress}%</span>
            </div>
            <div className="h-2 overflow-hidden rounded-full bg-[#1a2d48]">
              <div
                className="h-full rounded-full bg-gradient-to-r from-emerald-400 to-cyan-300 transition-all"
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>
        </div>

        <ul className="mt-8 space-y-4">
          {steps.map((s, i) => {
            const on = i < doneStep || finished;
            return (
              <li key={s.id} className="flex items-center gap-3">
                <span
                  className={cn(
                    'flex h-6 w-6 items-center justify-center rounded-full',
                    on ? 'bg-emerald-500 text-white' : 'border border-slate-600 text-transparent',
                  )}
                >
                  <IconCheck size={12} />
                </span>
                <span className={cn('text-[14px]', on ? 'text-white' : 'text-slate-500')}>{s.label}</span>
              </li>
            );
          })}
        </ul>

        <p className="mt-10 text-[13px] leading-relaxed text-slate-400">
          {finished ? (
            <>
              Données mises en cache avec succès pour un accès rapide.
              <br />
              1 200 nouveaux points de données indexés.
            </>
          ) : (
            <>Indexation des séries (données de présentation)…</>
          )}
        </p>
      </div>

      <div className="mt-auto px-5 pb-3">
        <Button
          variant={finished ? 'cyan' : 'outline'}
          onClick={() => {
            setCancelled(true);
            if (finished) navigate('matches');
            else back();
          }}
        >
          {finished ? 'Continuer' : 'Annuler'}
        </Button>
      </div>
    </div>
  );
}
