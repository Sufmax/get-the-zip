import { db } from "@/db";
import { leaderboardEntries } from "@/db/schema";
import { desc, asc, eq, and } from "drizzle-orm";
import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const trackId = searchParams.get("trackId") || "azure";
    const gameMode = searchParams.get("gameMode") || "circuit";

    let entries;
    if (gameMode === "endless_traffic") {
      entries = await db
        .select()
        .from(leaderboardEntries)
        .where(
          and(
            eq(leaderboardEntries.trackId, trackId),
            eq(leaderboardEntries.gameMode, gameMode)
          )
        )
        .orderBy(desc(leaderboardEntries.distance), desc(leaderboardEntries.driftScore))
        .limit(10);
    } else {
      entries = await db
        .select()
        .from(leaderboardEntries)
        .where(
          and(
            eq(leaderboardEntries.trackId, trackId),
            eq(leaderboardEntries.gameMode, gameMode)
          )
        )
        .orderBy(asc(leaderboardEntries.timeSeconds))
        .limit(10);
    }

    return NextResponse.json({ success: true, entries });
  } catch (err) {
    console.error("Leaderboard GET error:", err);
    return NextResponse.json({ success: false, error: "Failed to fetch leaderboard" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { playerName, trackId, carId, gameMode, timeSeconds, driftScore, distance } = body;

    if (!playerName || !trackId || !carId || !gameMode) {
      return NextResponse.json({ success: false, error: "Missing required fields" }, { status: 400 });
    }

    const inserted = await db
      .insert(leaderboardEntries)
      .values({
        playerName: String(playerName).slice(0, 30),
        trackId: String(trackId),
        carId: String(carId),
        gameMode: String(gameMode),
        timeSeconds: timeSeconds ? parseFloat(timeSeconds) : null,
        driftScore: driftScore ? parseInt(driftScore, 10) : 0,
        distance: distance ? parseInt(distance, 10) : 0,
      })
      .returning();

    return NextResponse.json({ success: true, entry: inserted[0] });
  } catch (err) {
    console.error("Leaderboard POST error:", err);
    return NextResponse.json({ success: false, error: "Failed to record score" }, { status: 500 });
  }
}
