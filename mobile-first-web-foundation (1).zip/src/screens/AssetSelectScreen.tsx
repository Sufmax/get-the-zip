import { useEffect, useState } from 'react';
import { AssetGlyph, IconMenu, IconSearch } from '../components/icons';
import { Chip, ScreenHeader } from '../components/ui/primitives';
import { useApp } from '../context/AppContext';
import { marketApi } from '../services/api';
import type { Asset, AssetCategory } from '../types';
import { formatPct, formatPrice } from '../utils/format';
import { cn } from '../utils/cn';

const FILTERS: { id: AssetCategory | 'all'; label: string }[] = [
  { id: 'all', label: 'Tous' },
  { id: 'crypto', label: 'Crypto' },
  { id: 'forex', label: 'Forex' },
  { id: 'stock', label: 'Actions' },
  { id: 'commodity', label: 'Matières' },
];

const CAT_LABEL: Record<AssetCategory, string> = {
  crypto: 'Crypto',
  forex: 'Forex',
  stock: 'Actions',
  commodity: 'Matières',
};

export function AssetSelectScreen() {
  const { selectedCategory, setCategory, selectAsset, navigate, favorites } = useApp();
  const [query, setQuery] = useState('');
  const [assets, setAssets] = useState<Asset[]>([]);

  useEffect(() => {
    let live = true;
    marketApi.listAssets({ category: selectedCategory, query }).then((list) => {
      if (live) setAssets(list);
    });
    return () => {
      live = false;
    };
  }, [selectedCategory, query]);

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <ScreenHeader
        title="Sélectionner un actif"
        onBack={() => navigate('welcome')}
        right={
          <button onClick={() => navigate('menu')} className="p-1 text-white/70" aria-label="Menu">
            <IconMenu size={18} />
          </button>
        }
      />

      <div className="px-4">
        <label className="flex items-center gap-2 rounded-full bg-[#122036] px-4 py-2.5">
          <IconSearch className="text-slate-500" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Rechercher un symbole…"
            className="w-full bg-transparent text-[14px] text-white outline-none placeholder:text-slate-500"
          />
        </label>
        <div className="mt-3 flex gap-2 overflow-x-auto pb-1 [-ms-overflow-style:none] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
          {FILTERS.map((f) => (
            <Chip key={f.id} active={selectedCategory === f.id} onClick={() => setCategory(f.id)}>
              {f.label}
            </Chip>
          ))}
        </div>
      </div>

      <div className="mt-2 min-h-0 flex-1 overflow-y-auto px-3 pb-4">
        {assets.map((a) => {
          const up = a.change24h >= 0;
          return (
            <button
              key={a.id}
              onClick={() => {
                selectAsset(a);
                navigate('chart');
              }}
              className="flex w-full items-center gap-3 rounded-2xl px-2 py-2.5 text-left transition hover:bg-white/4 active:bg-white/6"
            >
              <AssetGlyph symbol={a.symbol} category={a.category} />
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-1.5">
                  <span className="text-[15px] font-semibold text-white">{a.symbol}</span>
                  <span className="truncate text-[13px] text-slate-400">{a.name}</span>
                  {favorites.includes(a.id) && <span className="text-[10px] text-amber-400">★</span>}
                </div>
                <div className="text-[12px] text-slate-500">{CAT_LABEL[a.category]}</div>
              </div>
              <div className="text-right">
                <div className="text-[14px] font-semibold text-white">
                  {formatPrice(a.price, a.decimals, a.quoteCurrency)}
                </div>
                <div className={cn('text-[12px] font-medium', up ? 'text-emerald-400' : 'text-rose-400')}>
                  {formatPct(a.change24h)}
                </div>
              </div>
            </button>
          );
        })}
        {!assets.length && (
          <p className="px-4 py-10 text-center text-sm text-slate-500">Aucun actif ne correspond.</p>
        )}
      </div>
    </div>
  );
}
