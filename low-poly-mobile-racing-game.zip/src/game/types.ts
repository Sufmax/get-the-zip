export type Vec2 = { x: number; z: number };

export type CarShape =
  | "sport"
  | "muscle"
  | "formula"
  | "suv"
  | "truck"
  | "tuner"
  | "prototype"
  | "coupe"
  | "buggy"
  | "van";

export type CarClass = "D" | "C" | "B" | "A" | "S";

export type CarDef = {
  id: string;
  name: string;
  tagline: string;
  class: CarClass;
  color: string;
  accent: string;
  cabin: string;
  shape: CarShape;
  maxSpeed: number;
  accel: number;
  handling: number;
  grip: number;
  brake: number;
  nitroPower: number;
  drift: number;
};

export type ThemeId = "coast" | "desert" | "city" | "forest";

export type TrackDef = {
  id: string;
  name: string;
  desc: string;
  difficulty: 1 | 2 | 3 | 4;
  laps: number;
  width: number;
  grip: number;
  theme: ThemeId;
  skyTop: string;
  skyBot: string;
  fog: string;
  ground: string;
  ground2: string;
  ambient: number;
  sun: number;
  sunColor: string;
  fn: (t: number) => Vec2;
};

export type Decoration = {
  kind: "tree" | "palm" | "rock" | "building" | "lamp" | "pine" | "cactus" | "sign";
  x: number;
  z: number;
  rot: number;
  scale: number;
  h: number;
  color: string;
};

export type BuiltTrack = {
  id: string;
  name: string;
  desc: string;
  difficulty: number;
  laps: number;
  width: number;
  grip: number;
  theme: ThemeId;
  skyTop: string;
  skyBot: string;
  fog: string;
  ground: string;
  ground2: string;
  ambient: number;
  sun: number;
  sunColor: string;
  length: number;
  points: Vec2[];
  tangents: Vec2[];
  normals: Vec2[];
  cumlen: number[];
  decorations: Decoration[];
  mountains: { x: number; z: number; s: number; h: number; color: string }[];
};

export type InputState = {
  steer: number;
  throttle: number;
  brake: number;
  nitro: boolean;
};

export type AiState = {
  skill: number;
  offset: number;
  aggression: number;
  look: number;
};

export type CarState = {
  id: string;
  name: string;
  isPlayer: boolean;
  def: CarDef;
  x: number;
  z: number;
  heading: number;
  speed: number;
  slip: number;
  steerVis: number;
  nitro: number;
  boosting: boolean;
  trackIndex: number;
  sector: number;
  lapsCompleted: number;
  lapStart: number;
  lapTimes: number[];
  finished: boolean;
  finishTime: number;
  wheelRot: number;
  shake: number;
  topSpeed: number;
  ai: AiState | null;
};

export type RacePhase = "countdown" | "racing" | "finished";

export type RaceState = {
  cars: CarState[];
  time: number;
  phase: RacePhase;
  countdown: number;
  totalLaps: number;
  finishTimer: number;
  ranks: number[];
  playerIndex: number;
};

export type HudSnapshot = {
  speed: number;
  maxSpeed: number;
  nitro: number;
  boosting: boolean;
  rpm: number;
  gear: number;
  position: number;
  totalCars: number;
  lap: number;
  totalLaps: number;
  lapTime: number;
  bestLap: number;
  raceTime: number;
  drift: number;
  phase: RacePhase;
  countdown: number;
  finished: boolean;
  minimap: { x: number; z: number; heading: number; color: string; player: boolean }[];
};

export type RaceResults = {
  position: number;
  total: number;
  time: number;
  bestLap: number;
  topSpeed: number;
  board: { name: string; color: string; player: boolean; time: number; finished: boolean; pos: number }[];
};

export type Settings = {
  audio: boolean;
  autoAccel: boolean;
  vibration: boolean;
  quality: "high" | "low";
};

export type Screen = "splash" | "menu" | "garage" | "tracks" | "race";
