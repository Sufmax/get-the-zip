import { pgTable, serial, text, integer, real, timestamp, jsonb } from "drizzle-orm/pg-core";

export const leaderboardEntries = pgTable("leaderboard_entries", {
  id: serial("id").primaryKey(),
  playerName: text("player_name").notNull(),
  trackId: text("track_id").notNull(),
  carId: text("car_id").notNull(),
  gameMode: text("game_mode").notNull(), // 'circuit' | 'time_trial' | 'endless_traffic'
  timeSeconds: real("time_seconds"),
  driftScore: integer("drift_score").default(0).notNull(),
  distance: integer("distance").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const playerProfiles = pgTable("player_profiles", {
  id: text("id").primaryKey(), // local UUID or guest ID
  playerName: text("player_name").notNull(),
  cash: integer("cash").default(5000).notNull(),
  unlockedCars: jsonb("unlocked_cars").$type<string[]>().default(["apex_gt"]).notNull(),
  carCustomizations: jsonb("car_customizations").default({}).notNull(),
  achievements: jsonb("achievements").$type<string[]>().default([]).notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export type LeaderboardEntry = typeof leaderboardEntries.$inferSelect;
export type NewLeaderboardEntry = typeof leaderboardEntries.$inferInsert;
export type PlayerProfile = typeof playerProfiles.$inferSelect;
export type NewPlayerProfile = typeof playerProfiles.$inferInsert;
