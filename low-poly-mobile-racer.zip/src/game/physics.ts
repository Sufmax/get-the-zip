import * as THREE from 'three';
import { CarDefinition, PlayerCarCustomization } from '../types/game';
import { TrackData } from './proceduralTrack';

export interface VehicleInputs {
  throttle: number; // 0 to 1
  brake: number; // 0 to 1
  steer: number; // -1 to 1
  handbrake: boolean;
  nitro: boolean;
}

export interface VehicleState {
  position: THREE.Vector3;
  velocity: THREE.Vector3;
  heading: number; // yaw in radians
  angularVelocity: number;
  speed: number; // m/s
  speedKmh: number;
  gear: number;
  rpm: number; // 0 to 1
  isDrifting: boolean;
  driftAngle: number;
  driftScore: number;
  driftMultiplier: number;
  nitroPercent: number; // 0 to 100
  isNitroActive: boolean;
  slipstreamActive: boolean;
  slipstreamTimer: number;
  progressT: number; // 0 to 1 along track
  lap: number;
  collisionCooldown: number;
  isAI: boolean;
  aiTargetSpeed: number;
  aiLaneOffset: number; // offset from track center
}

export class PhysicsEngine {
  private trackData: TrackData;

  constructor(trackData: TrackData) {
    this.trackData = trackData;
  }

  public setTrack(trackData: TrackData) {
    this.trackData = trackData;
  }

  public createInitialState(
    startPos: THREE.Vector3,
    startHeading: number,
    isAI = false,
    laneOffset = 0
  ): VehicleState {
    const pos = startPos.clone();
    if (laneOffset !== 0) {
      // Offset perpendicular to heading
      pos.x += Math.cos(startHeading) * laneOffset;
      pos.z -= Math.sin(startHeading) * laneOffset;
    }

    return {
      position: pos,
      velocity: new THREE.Vector3(0, 0, 0),
      heading: startHeading,
      angularVelocity: 0,
      speed: 0,
      speedKmh: 0,
      gear: 1,
      rpm: 0.1,
      isDrifting: false,
      driftAngle: 0,
      driftScore: 0,
      driftMultiplier: 1.0,
      nitroPercent: 100,
      isNitroActive: false,
      slipstreamActive: false,
      slipstreamTimer: 0,
      progressT: 0,
      lap: 1,
      collisionCooldown: 0,
      isAI,
      aiTargetSpeed: 55 + Math.random() * 20, // m/s
      aiLaneOffset: laneOffset,
    };
  }

  public updateVehicle(
    state: VehicleState,
    inputs: VehicleInputs,
    carDef: CarDefinition,
    customization: PlayerCarCustomization | undefined,
    dt: number,
    otherVehicles: VehicleState[] = []
  ): {
    collidedBarrier: boolean;
    collidedCar: boolean;
    nearMiss: boolean;
    gearShift: boolean;
    driftJustStarted: boolean;
  } {
    let collidedBarrier = false;
    let collidedCar = false;
    let nearMiss = false;
    let gearShift = false;
    const wasDrifting = state.isDrifting;

    if (state.collisionCooldown > 0) {
      state.collisionCooldown -= dt;
    }

    // Upgrades modifiers
    const upgrades = customization?.upgrades || { engine: 1, turbo: 1, handling: 1, nitro: 1, brakes: 1 };
    const engineMod = 1 + (upgrades.engine - 1) * 0.07;
    const turboMod = 1 + (upgrades.turbo - 1) * 0.08;
    const handlingMod = 1 + (upgrades.handling - 1) * 0.07;
    const nitroMod = 1 + (upgrades.nitro - 1) * 0.1;
    const brakesMod = 1 + (upgrades.brakes - 1) * 0.1;

    const baseTopSpeedKmh = carDef.specs.topSpeed * engineMod;
    let maxSpeedMs = (baseTopSpeedKmh * 1000) / 3600;

    // Nitro handling
    if (inputs.nitro && state.nitroPercent > 0 && inputs.throttle > 0.1) {
      state.isNitroActive = true;
      state.nitroPercent = Math.max(0, state.nitroPercent - dt * (18 / nitroMod));
      maxSpeedMs *= 1.25; // 25% top speed surge on nitro!
    } else {
      state.isNitroActive = false;
      // Passive slow nitro regen
      state.nitroPercent = Math.min(100, state.nitroPercent + dt * 3.5);
    }

    // Slipstream (Aspiration) mechanics
    let inSlipstream = false;
    for (const other of otherVehicles) {
      if (other === state) continue;
      const toOther = other.position.clone().sub(state.position);
      const dist = toOther.length();

      // Check near-miss (passing very close at high speed)
      if (dist < 3.2 && dist > 1.8 && state.speedKmh > 120 && !state.isAI) {
        nearMiss = true;
      }

      // Check if directly behind other car within 28m
      if (dist < 28 && dist > 4) {
        const carFwd = new THREE.Vector3(Math.sin(state.heading), 0, Math.cos(state.heading));
        const dot = toOther.normalize().dot(carFwd);
        if (dot > 0.92) {
          inSlipstream = true;
          break;
        }
      }
    }

    state.slipstreamActive = inSlipstream;
    if (inSlipstream) {
      state.slipstreamTimer += dt;
      maxSpeedMs *= 1.12; // 12% slipstream speed boost
      state.nitroPercent = Math.min(100, state.nitroPercent + dt * 6); // faster nitro refill in slipstream!
    } else {
      state.slipstreamTimer = Math.max(0, state.slipstreamTimer - dt * 2);
    }

    // Forward direction vector
    const forward = new THREE.Vector3(Math.sin(state.heading), 0, Math.cos(state.heading));
    const right = new THREE.Vector3(Math.cos(state.heading), 0, -Math.sin(state.heading));

    // Current forward & lateral speeds
    const currentForwardSpeed = state.velocity.dot(forward);
    const currentLateralSpeed = state.velocity.dot(right);

    // 1. Throttle / Acceleration
    const baseAccel = (carDef.specs.acceleration * 4.2 * turboMod) * (state.isNitroActive ? 1.9 : inSlipstream ? 1.3 : 1.0);
    let forwardForce = 0;

    if (inputs.throttle > 0) {
      // Curve falls off near max speed
      const speedRatio = Math.max(0, currentForwardSpeed / maxSpeedMs);
      const torqueCurve = Math.max(0.12, 1 - Math.pow(speedRatio, 1.8));
      forwardForce = inputs.throttle * baseAccel * torqueCurve;
    }

    // 2. Braking & Reverse
    if (inputs.brake > 0) {
      if (currentForwardSpeed > 1) {
        // Normal braking
        forwardForce -= inputs.brake * 28 * brakesMod;
      } else {
        // Reverse
        forwardForce -= inputs.brake * 10;
      }
    }

    // 3. Rolling resistance & aerodynamic drag
    const dragCoeff = 0.0016;
    const rollingResistance = 0.8;
    forwardForce -= Math.sign(currentForwardSpeed) * (rollingResistance + dragCoeff * currentForwardSpeed * currentForwardSpeed);

    // 4. Drift mechanics & lateral friction
    const driftEaseFactor = carDef.specs.driftEase / 10;
    const initiatesDrift =
      (inputs.handbrake || (Math.abs(inputs.steer) > 0.65 && inputs.brake > 0.2)) &&
      currentForwardSpeed > 14;

    if (initiatesDrift) {
      state.isDrifting = true;
    } else if (Math.abs(currentLateralSpeed) < 2.5 && !inputs.handbrake) {
      state.isDrifting = false;
    }

    // Lateral grip
    const baseGrip = state.isDrifting ? 0.35 + (1 - driftEaseFactor) * 0.15 : 0.94 * handlingMod;
    const lateralFriction = -currentLateralSpeed * baseGrip * 14;

    // Apply forces
    const accelVector = forward.clone().multiplyScalar(forwardForce).add(right.clone().multiplyScalar(lateralFriction));
    state.velocity.addScaledVector(accelVector, dt);

    // Speed clamping
    state.speed = state.velocity.length();
    state.speedKmh = Math.round(state.speed * 3.6);

    // 5. Steering & Yaw Rotation
    const steerSpeedFactor = Math.min(1, Math.max(0.15, currentForwardSpeed / 12));
    const maxSteerRate = (carDef.specs.handling / 10) * 2.8 * handlingMod;
    let targetAngularVel = -inputs.steer * maxSteerRate * steerSpeedFactor;

    if (state.isDrifting) {
      // Oversteer in drift
      targetAngularVel *= 1.35;
      // Drift score accumulation
      const driftDelta = Math.abs(currentLateralSpeed) * dt * 45 * state.driftMultiplier;
      state.driftScore += Math.round(driftDelta);
      state.driftMultiplier = Math.min(5.0, state.driftMultiplier + dt * 0.3);
      // Nitro bonus for drifting!
      state.nitroPercent = Math.min(100, state.nitroPercent + dt * 8);
    } else {
      state.driftMultiplier = 1.0;
    }

    state.angularVelocity += (targetAngularVel - state.angularVelocity) * 12 * dt;
    state.heading += state.angularVelocity * dt;

    // Drift Angle (difference between heading and velocity vector)
    if (state.speed > 5) {
      const velAngle = Math.atan2(state.velocity.x, state.velocity.z);
      let angleDiff = state.heading - velAngle;
      while (angleDiff > Math.PI) angleDiff -= Math.PI * 2;
      while (angleDiff < -Math.PI) angleDiff += Math.PI * 2;
      state.driftAngle = angleDiff;
    } else {
      state.driftAngle = 0;
    }

    // 6. 6-Speed Transmission & RPM
    const gearMaxSpeeds = [
      maxSpeedMs * 0.22,
      maxSpeedMs * 0.38,
      maxSpeedMs * 0.55,
      maxSpeedMs * 0.72,
      maxSpeedMs * 0.88,
      maxSpeedMs * 1.15,
    ];

    const prevGear = state.gear;
    let currentGear = 1;
    for (let g = 0; g < gearMaxSpeeds.length; g++) {
      if (currentForwardSpeed > gearMaxSpeeds[g] && g < 5) {
        currentGear = g + 2;
      }
    }
    state.gear = currentGear;
    if (state.gear !== prevGear) {
      gearShift = true;
    }

    // RPM computation (0 to 1)
    const prevGearSpeed = currentGear === 1 ? 0 : gearMaxSpeeds[currentGear - 2];
    const nextGearSpeed = gearMaxSpeeds[currentGear - 1];
    state.rpm = Math.min(1, Math.max(0.12, (currentForwardSpeed - prevGearSpeed) / (nextGearSpeed - prevGearSpeed)));

    // 7. Update Position
    state.position.addScaledVector(state.velocity, dt);

    // 8. Track Spline Progress & Elevation
    this.updateTrackProgress(state);

    // 9. Barrier Collisions
    if (this.checkBarrierCollisions(state)) {
      collidedBarrier = true;
      state.collisionCooldown = 0.25;
    }

    // 10. Car-to-Car Collisions
    for (const other of otherVehicles) {
      if (other === state) continue;
      const diff = state.position.clone().sub(other.position);
      const dist = diff.length();
      const minDistance = 2.4; // car collision sphere radius sum

      if (dist < minDistance && dist > 0.001) {
        collidedCar = true;
        const pushDir = diff.normalize();
        const overlap = minDistance - dist;

        // Separate cars
        state.position.addScaledVector(pushDir, overlap * 0.55);
        other.position.addScaledVector(pushDir, -overlap * 0.55);

        // Exchange momentum
        const impulse = pushDir.multiplyScalar(state.velocity.dot(pushDir) - other.velocity.dot(pushDir));
        state.velocity.addScaledVector(impulse, -0.7);
        other.velocity.addScaledVector(impulse, 0.7);
      }
    }

    return {
      collidedBarrier,
      collidedCar,
      nearMiss,
      gearShift,
      driftJustStarted: state.isDrifting && !wasDrifting,
    };
  }

  private updateTrackProgress(state: VehicleState) {
    if (this.trackData.isEndlessHighway) {
      // In endless mode, progress is measured simply by distance along -Z
      state.progressT = Math.max(0, -state.position.z / this.trackData.trackLength);
      return;
    }

    // Circuit track: find closest point on spline
    const samples = this.trackData.samplePoints;
    let closestDistSq = Infinity;
    let closestIndex = 0;

    for (let i = 0; i < samples.length; i++) {
      const distSq = samples[i].pos.distanceToSquared(state.position);
      if (distSq < closestDistSq) {
        closestDistSq = distSq;
        closestIndex = i;
      }
    }

    const currentSample = samples[closestIndex];
    const prevT = state.progressT;
    const newT = currentSample.t;

    // Detect lap completion (crossing from ~0.95 -> ~0.05)
    if (prevT > 0.85 && newT < 0.15) {
      state.lap += 1;
    } else if (prevT < 0.15 && newT > 0.85) {
      state.lap = Math.max(1, state.lap - 1);
    }

    state.progressT = newT;

    // Soft snap to road elevation (y)
    state.position.y += (currentSample.pos.y - state.position.y) * 0.15;
  }

  private checkBarrierCollisions(state: VehicleState): boolean {
    if (this.trackData.isEndlessHighway) {
      // Highway left/right bounds
      const halfW = this.trackData.roadWidth * 0.5 - 1.2;
      if (Math.abs(state.position.x) > halfW) {
        state.position.x = Math.sign(state.position.x) * halfW;
        state.velocity.x *= -0.4; // bounce off barrier
        state.velocity.z *= 0.85; // friction loss
        return true;
      }
      return false;
    }

    // Circuit track: test distance from track centerline
    const samples = this.trackData.samplePoints;
    const closestIdx = Math.round(state.progressT * (samples.length - 1));
    const centerPt = samples[closestIdx];
    if (!centerPt) return false;

    const toCar = state.position.clone().sub(centerPt.pos);
    const lateralDist = toCar.dot(centerPt.normal);
    const maxHalfW = this.trackData.roadWidth * 0.5 - 0.8;

    if (Math.abs(lateralDist) > maxHalfW) {
      const pushSign = Math.sign(lateralDist);
      // Reposition on track edge
      const targetPos = centerPt.pos.clone().addScaledVector(centerPt.normal, pushSign * maxHalfW);
      state.position.x = targetPos.x;
      state.position.z = targetPos.z;

      // Rebound velocity
      const normalVel = state.velocity.dot(centerPt.normal);
      if (Math.sign(normalVel) === pushSign) {
        state.velocity.addScaledVector(centerPt.normal, -normalVel * 1.4);
        state.velocity.multiplyScalar(0.75); // speed loss on barrier hit
      }
      return true;
    }

    return false;
  }

  // AI Opponent steering and throttle AI
  public updateAI(
    aiState: VehicleState,
    _aiDef: CarDefinition,
    dt: number,
    otherVehicles: VehicleState[]
  ): VehicleInputs {
    if (this.trackData.isEndlessHighway) {
      // Traffic car traveling steadily forward
      return {
        throttle: 0.7,
        brake: 0,
        steer: 0,
        handbrake: false,
        nitro: false,
      };
    }

    // Circuit AI: look ahead on spline
    const samples = this.trackData.samplePoints;
    const lookAheadSteps = 12;
    const currentIdx = Math.round(aiState.progressT * (samples.length - 1));
    const targetIdx = (currentIdx + lookAheadSteps) % samples.length;
    const targetPt = samples[targetIdx];

    // Compute target position with lane offset
    const targetPos = targetPt.pos.clone().addScaledVector(targetPt.normal, aiState.aiLaneOffset);
    const toTarget = targetPos.clone().sub(aiState.position);

    // Compute desired heading
    const desiredHeading = Math.atan2(toTarget.x, toTarget.z);
    let headingDiff = desiredHeading - aiState.heading;
    while (headingDiff > Math.PI) headingDiff -= Math.PI * 2;
    while (headingDiff < -Math.PI) headingDiff += Math.PI * 2;

    const steer = Math.max(-1, Math.min(1, headingDiff * 2.2));

    // Dynamic throttle based on upcoming curvature
    const isSharpTurn = Math.abs(headingDiff) > 0.45;
    let throttle = 1.0;
    let brake = 0;

    if (isSharpTurn && aiState.speedKmh > 160) {
      throttle = 0.2;
      brake = 0.5;
    }

    // AI nitro usage on straights
    const useNitro = !isSharpTurn && aiState.nitroPercent > 50 && Math.random() < 0.05;

    // Obstacle avoidance against other cars
    for (const other of otherVehicles) {
      if (other === aiState) continue;
      const toOther = other.position.clone().sub(aiState.position);
      if (toOther.length() < 9 && toOther.dot(new THREE.Vector3(Math.sin(aiState.heading), 0, Math.cos(aiState.heading))) > 0) {
        // Car ahead, adjust lane offset slightly
        aiState.aiLaneOffset += (aiState.aiLaneOffset > 0 ? 1 : -1) * dt * 2.5;
        aiState.aiLaneOffset = Math.max(-5, Math.min(5, aiState.aiLaneOffset));
      }
    }

    return {
      throttle,
      brake,
      steer,
      handbrake: isSharpTurn && aiState.speedKmh > 175,
      nitro: useNitro,
    };
  }
}
