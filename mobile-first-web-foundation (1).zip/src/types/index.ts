/**
 * Types métier MarketScope.
 * Ces interfaces correspondent au contrat API prévu pour le backend.
 * Les données actuelles sont des mocks de présentation (voir src/data/mockData.ts).
 */

export type AssetCategory = 'crypto' | 'forex' | 'stock' | 'commodity';

export type Timeframe = '1m' | '15m' | '1h' | '1j' | '1s' | '1M';

export type Direction = 'bullish' | 'bearish' | 'neutral';

export type VolumeTrend = 'up' | 'down' | 'flat';

export type SelectionMode = 'auto' | 'manual';

export type ScreenId =
  | 'welcome'
  | 'assets'
  | 'chart'
  | 'pattern'
  | 'matches'
  | 'matchDetail'
  | 'scenarios'
  | 'conditions'
  | 'period'
  | 'settings'
  | 'backtest'
  | 'export'
  | 'sync'
  | 'help'
  | 'helpArticle'
  | 'menu'
  | 'dataSources'
  | 'favorites'
  | 'history';

export interface Asset {
  id: string;
  symbol: string;
  name: string;
  category: AssetCategory;
  price: number;
  change24h: number;
  quoteCurrency: string;
  exchange: string;
  pairLabel: string;
  decimals: number;
}

export interface Candle {
  timestamp: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export interface PatternZone {
  startIndex: number;
  endIndex: number;
}

export interface PatternMatch {
  id: string;
  rank: number;
  score: number;
  date: string;
  dateShort: string;
  candleCount: number;
  direction: Direction;
  volumeTrend: VolumeTrend;
  candles: Candle[];
  followThrough: Candle[];
  strengths: string[];
}

export interface Scenario {
  id: string;
  label: string;
  horizon: string;
  direction: Direction;
  probability: number;
  deviation: number;
}

export interface ConditionItem {
  id: string;
  label: string;
  detail?: string;
  kind: 'confirm' | 'risk' | 'invalidate';
}

export interface PeriodConfig {
  mode: 'lastCandles' | 'customRange' | 'sinceDate' | 'allHistory' | 'onChart';
  candleCount: number;
  startDate: string;
  endDate: string;
  sinceDate: string;
}

export interface AppSettings {
  dataMode: 'auto' | 'manual';
  cloudflare: boolean;
  directProviders: boolean;
  localFolder: boolean;
  granularity: Timeframe;
  resultCount: number;
  searchLimit: number;
}

export interface BacktestStats {
  cases: number;
  correctDirection: number;
  averageError: number;
  calibration: number;
  bySimilarity: { range: string; accuracy: number; error: number }[];
  equityCurve: { x: number; y: number }[];
}

export interface DataProvider {
  id: string;
  name: string;
  subtitle: string;
  connected: boolean;
  primary: boolean;
  brand: 'yahoo' | 'binance' | 'kraken' | 'iress' | 'forex';
}

export interface HelpArticle {
  id: string;
  title: string;
  icon: 'book' | 'layers' | 'grid' | 'star' | 'chart' | 'chat' | 'phone';
  body: string[];
}

export interface ExportConfig {
  format: 'pdf' | 'csv' | 'json' | 'image';
  includeCharts: boolean;
  includeMatches: boolean;
  includeScenarios: boolean;
  includeSettings: boolean;
}

export interface SyncStep {
  id: string;
  label: string;
}

export interface AnalysisOutcome {
  bullish: number;
  bearish: number;
  neutral: number;
}
