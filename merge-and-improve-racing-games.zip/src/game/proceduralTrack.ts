import * as THREE from 'three';
import { TrackDefinition, GameMode } from '../types/game';

export interface TrackData {
  group: THREE.Group;
  spline: THREE.CatmullRomCurve3;
  trackLength: number;
  roadWidth: number;
  startPosition: THREE.Vector3;
  startRotationY: number;
  samplePoints: { pos: THREE.Vector3; tangent: THREE.Vector3; normal: THREE.Vector3; t: number }[];
  isEndlessHighway: boolean;
  barrierColliders: { left: THREE.Vector3[]; right: THREE.Vector3[] };
}

export function buildProceduralTrack(
  trackDef: TrackDefinition,
  mode: GameMode
): TrackData {
  const group = new THREE.Group();
  const roadWidth = 19; // Generous 3-lane width for comfortable drifting and overtaking
  const isEndless = mode === 'endless_traffic';

  // 1. Spline Control Points
  let points: THREE.Vector3[] = [];

  if (isEndless) {
    points = [
      new THREE.Vector3(0, 0, 500),
      new THREE.Vector3(0, 0, 0),
      new THREE.Vector3(0, 0, -2000),
      new THREE.Vector3(0, 0, -4500),
      new THREE.Vector3(0, 0, -7000),
      new THREE.Vector3(0, 0, -9500),
      new THREE.Vector3(0, 0, -12000),
    ];
  } else {
    switch (trackDef.id) {
      case 'desert_canyon':
        points = [
          new THREE.Vector3(0, 0, 0),
          new THREE.Vector3(0, 0, -220),
          new THREE.Vector3(130, 8, -400),
          new THREE.Vector3(320, 16, -460),
          new THREE.Vector3(480, 22, -320),
          new THREE.Vector3(520, 14, -120),
          new THREE.Vector3(400, 6, 120),
          new THREE.Vector3(460, -2, 340),
          new THREE.Vector3(320, -8, 500),
          new THREE.Vector3(110, -4, 520),
          new THREE.Vector3(-120, 0, 420),
          new THREE.Vector3(-300, 8, 280),
          new THREE.Vector3(-360, 14, 90),
          new THREE.Vector3(-240, 6, -70),
          new THREE.Vector3(-90, 0, 80),
          new THREE.Vector3(0, 0, 160),
        ];
        break;

      case 'cyber_highway':
        points = [
          new THREE.Vector3(0, 0, 0),
          new THREE.Vector3(0, 0, -260),
          new THREE.Vector3(90, 6, -440),
          new THREE.Vector3(240, 14, -500),
          new THREE.Vector3(410, 10, -400),
          new THREE.Vector3(470, 4, -190),
          new THREE.Vector3(380, 0, 0),
          new THREE.Vector3(440, 4, 190),
          new THREE.Vector3(340, 10, 380),
          new THREE.Vector3(150, 8, 460),
          new THREE.Vector3(-90, 4, 400),
          new THREE.Vector3(-220, 0, 250),
          new THREE.Vector3(-240, 0, 90),
          new THREE.Vector3(-130, 0, -20),
          new THREE.Vector3(0, 0, 160),
        ];
        break;

      case 'alpine_summit':
        points = [
          new THREE.Vector3(0, 0, 0),
          new THREE.Vector3(0, 0, -200),
          new THREE.Vector3(-110, 14, -350),
          new THREE.Vector3(-150, 32, -500),
          new THREE.Vector3(40, 42, -540),
          new THREE.Vector3(220, 36, -450),
          new THREE.Vector3(340, 24, -300),
          new THREE.Vector3(280, 15, -130),
          new THREE.Vector3(380, 9, 90),
          new THREE.Vector3(320, 3, 300),
          new THREE.Vector3(150, -4, 400),
          new THREE.Vector3(-70, -2, 340),
          new THREE.Vector3(-180, 0, 190),
          new THREE.Vector3(0, 0, 160),
        ];
        break;

      case 'foret_tunnel':
        points = [
          new THREE.Vector3(0, 0, 0),
          new THREE.Vector3(0, 0, -240),
          new THREE.Vector3(120, 4, -420),
          new THREE.Vector3(280, 8, -520),
          new THREE.Vector3(440, 12, -440),
          new THREE.Vector3(480, 10, -260),
          new THREE.Vector3(360, 6, -100),
          new THREE.Vector3(420, 4, 120),
          new THREE.Vector3(500, 2, 300),
          new THREE.Vector3(380, -2, 460),
          new THREE.Vector3(180, -4, 520),
          new THREE.Vector3(-60, 0, 440),
          new THREE.Vector3(-220, 4, 300),
          new THREE.Vector3(-300, 8, 120),
          new THREE.Vector3(-220, 4, -80),
          new THREE.Vector3(0, 0, 160),
        ];
        break;

      default:
        // Azure Coast
        points = [
          new THREE.Vector3(0, 0, 0),
          new THREE.Vector3(0, 0, -220),
          new THREE.Vector3(150, 2, -380),
          new THREE.Vector3(340, 8, -440),
          new THREE.Vector3(520, 12, -340),
          new THREE.Vector3(560, 8, -150),
          new THREE.Vector3(460, 4, 60),
          new THREE.Vector3(520, -2, 250),
          new THREE.Vector3(400, -6, 440),
          new THREE.Vector3(190, -6, 530),
          new THREE.Vector3(-50, -3, 460),
          new THREE.Vector3(-190, 2, 320),
          new THREE.Vector3(-290, 8, 150),
          new THREE.Vector3(-250, 4, -40),
          new THREE.Vector3(0, 0, 160),
        ];
        break;
    }
  }

  const spline = new THREE.CatmullRomCurve3(points, !isEndless);
  spline.curveType = 'catmullrom';
  spline.tension = 0.45;

  const sampleCount = isEndless ? 300 : 360;
  const samplePoints: TrackData['samplePoints'] = [];
  const trackLength = spline.getLength();

  // Materials
  const roadMat = new THREE.MeshStandardMaterial({
    color: new THREE.Color(trackDef.roadColor),
    roughness: 0.8,
    metalness: 0.15,
    flatShading: true,
    side: THREE.DoubleSide,
  });

  const curbMat1 = new THREE.MeshStandardMaterial({
    color: new THREE.Color(trackDef.curbColor1),
    roughness: 0.6,
    metalness: 0.2,
    flatShading: true,
    side: THREE.DoubleSide,
  });

  const curbMat2 = new THREE.MeshStandardMaterial({
    color: new THREE.Color(trackDef.curbColor2),
    roughness: 0.6,
    metalness: 0.2,
    flatShading: true,
    side: THREE.DoubleSide,
  });

  const barrierMat = new THREE.MeshStandardMaterial({
    color: 0x94a3b8,
    roughness: 0.45,
    metalness: 0.65,
    flatShading: true,
  });

  const stripeMat = new THREE.MeshBasicMaterial({ color: 0xffffff });

  // 2. Generate Road Ribbon Geometry
  const roadPositions: number[] = [];
  const roadIndices: number[] = [];
  const curb1Positions: number[] = [];
  const curb2Positions: number[] = [];
  const barrierLPositions: number[] = [];
  const barrierRPositions: number[] = [];

  const barrierLeftPoints: THREE.Vector3[] = [];
  const barrierRightPoints: THREE.Vector3[] = [];

  const halfW = roadWidth * 0.5;
  const curbW = 1.2;
  const curbH = 0.22;
  const barrierH = 1.4;

  for (let i = 0; i < sampleCount; i++) {
    const t = i / (isEndless ? sampleCount - 1 : sampleCount);
    const pos = spline.getPoint(t);
    const tangent = spline.getTangent(t).normalize();
    const up = new THREE.Vector3(0, 1, 0);
    const normal = new THREE.Vector3().crossVectors(tangent, up).normalize();

    samplePoints.push({ pos, tangent, normal, t });

    // Left and Right road edge vertices
    const leftEdge = pos.clone().addScaledVector(normal, -halfW);
    const rightEdge = pos.clone().addScaledVector(normal, halfW);

    roadPositions.push(leftEdge.x, leftEdge.y + 0.02, leftEdge.z);
    roadPositions.push(rightEdge.x, rightEdge.y + 0.02, rightEdge.z);

    // Curbs
    const curbLOuter = leftEdge.clone().addScaledVector(normal, -curbW);
    curbLOuter.y += curbH;
    const curbROuter = rightEdge.clone().addScaledVector(normal, curbW);
    curbROuter.y += curbH;

    const isCurb1 = Math.floor(i / 2) % 2 === 0;
    const targetCurbPositions = isCurb1 ? curb1Positions : curb2Positions;
    targetCurbPositions.push(leftEdge.x, leftEdge.y + 0.02, leftEdge.z);
    targetCurbPositions.push(curbLOuter.x, curbLOuter.y, curbLOuter.z);
    targetCurbPositions.push(rightEdge.x, rightEdge.y + 0.02, rightEdge.z);
    targetCurbPositions.push(curbROuter.x, curbROuter.y, curbROuter.z);

    // Barriers
    const barLTop = curbLOuter.clone();
    barLTop.y += barrierH;
    const barRTop = curbROuter.clone();
    barRTop.y += barrierH;

    barrierLeftPoints.push(curbLOuter.clone());
    barrierRightPoints.push(curbROuter.clone());

    barrierLPositions.push(curbLOuter.x, curbLOuter.y, curbLOuter.z);
    barrierLPositions.push(barLTop.x, barLTop.y, barLTop.z);
    barrierRPositions.push(curbROuter.x, curbROuter.y, curbROuter.z);
    barrierRPositions.push(barRTop.x, barRTop.y, barRTop.z);
  }

  // Build Indices
  const numSteps = isEndless ? sampleCount - 1 : sampleCount;
  for (let i = 0; i < numSteps; i++) {
    const next = (i + 1) % sampleCount;
    const rCurrent = i * 2;
    const rNext = next * 2;

    roadIndices.push(rCurrent, rNext, rCurrent + 1);
    roadIndices.push(rNext, rNext + 1, rCurrent + 1);
  }

  const roadGeom = new THREE.BufferGeometry();
  roadGeom.setAttribute('position', new THREE.Float32BufferAttribute(roadPositions, 3));
  roadGeom.setIndex(roadIndices);
  roadGeom.computeVertexNormals();
  const roadMesh = new THREE.Mesh(roadGeom, roadMat);
  roadMesh.receiveShadow = true;
  group.add(roadMesh);

  // Curbs mesh
  const curb1Geom = new THREE.BufferGeometry();
  curb1Geom.setAttribute('position', new THREE.Float32BufferAttribute(curb1Positions, 3));
  curb1Geom.computeVertexNormals();
  group.add(new THREE.Mesh(curb1Geom, curbMat1));

  const curb2Geom = new THREE.BufferGeometry();
  curb2Geom.setAttribute('position', new THREE.Float32BufferAttribute(curb2Positions, 3));
  curb2Geom.computeVertexNormals();
  group.add(new THREE.Mesh(curb2Geom, curbMat2));

  // Barriers mesh
  const barrierGeom = new THREE.BufferGeometry();
  barrierGeom.setAttribute('position', new THREE.Float32BufferAttribute([...barrierLPositions, ...barrierRPositions], 3));
  barrierGeom.computeVertexNormals();
  const barrierMesh = new THREE.Mesh(barrierGeom, barrierMat);
  barrierMesh.castShadow = true;
  group.add(barrierMesh);

  // Center dashed white road stripes
  const stripeGeom = new THREE.BoxGeometry(0.35, 0.05, 3.8);
  for (let i = 0; i < samplePoints.length; i += 3) {
    const pt = samplePoints[i];
    const stripe = new THREE.Mesh(stripeGeom, stripeMat);
    stripe.position.copy(pt.pos);
    stripe.position.y += 0.05;
    stripe.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), pt.tangent);
    group.add(stripe);
  }

  // Start / Finish Line Gantry
  const startPt = samplePoints[0];
  const startRotY = Math.atan2(startPt.tangent.x, startPt.tangent.z);

  if (!isEndless) {
    const gantryGroup = new THREE.Group();
    gantryGroup.position.copy(startPt.pos);
    gantryGroup.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), startPt.tangent);

    const postGeo = new THREE.BoxGeometry(0.9, 7.5, 0.9);
    const postMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.5, metalness: 0.8 });
    const postL = new THREE.Mesh(postGeo, postMat);
    postL.position.set(-halfW - 1.8, 3.75, 0);
    const postR = new THREE.Mesh(postGeo, postMat);
    postR.position.set(halfW + 1.8, 3.75, 0);

    const crossbeamGeo = new THREE.BoxGeometry(roadWidth + 4.5, 1.5, 1.2);
    const crossbeam = new THREE.Mesh(crossbeamGeo, postMat);
    crossbeam.position.set(0, 7.0, 0);

    const bannerGeo = new THREE.BoxGeometry(roadWidth * 0.85, 1.3, 0.15);
    const bannerMat = new THREE.MeshBasicMaterial({ color: 0x06b6d4 });
    const banner = new THREE.Mesh(bannerGeo, bannerMat);
    banner.position.set(0, 7.0, 0.65);

    const checkLineGeo = new THREE.BoxGeometry(roadWidth, 0.08, 2.2);
    const checkMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
    const checkLine = new THREE.Mesh(checkLineGeo, checkMat);
    checkLine.position.set(0, 0.06, 0);

    gantryGroup.add(postL, postR, crossbeam, banner, checkLine);
    group.add(gantryGroup);
  }

  // Build Environment Scenery
  buildThematicScenery(group, trackDef, samplePoints, roadWidth);

  return {
    group,
    spline,
    trackLength,
    roadWidth,
    startPosition: startPt.pos.clone(),
    startRotationY: startRotY,
    samplePoints,
    isEndlessHighway: isEndless,
    barrierColliders: { left: barrierLeftPoints, right: barrierRightPoints },
  };
}

function buildThematicScenery(
  parent: THREE.Group,
  trackDef: TrackDefinition,
  samples: TrackData['samplePoints'],
  roadWidth: number
) {
  const sceneryGroup = new THREE.Group();
  parent.add(sceneryGroup);

  const theme = trackDef.theme;

  // Ground plane
  const groundGeo = new THREE.PlaneGeometry(2800, 2800, 24, 24);
  groundGeo.rotateX(-Math.PI / 2);
  const groundMat = new THREE.MeshStandardMaterial({
    color: new THREE.Color(trackDef.groundColor),
    roughness: 0.95,
    metalness: 0.05,
    flatShading: true,
  });
  const groundMesh = new THREE.Mesh(groundGeo, groundMat);
  groundMesh.position.y = -0.5;
  groundMesh.receiveShadow = true;
  sceneryGroup.add(groundMesh);

  // Sea water plane for coastal track
  if (theme === 'coast') {
    const seaGeo = new THREE.PlaneGeometry(2800, 2800);
    seaGeo.rotateX(-Math.PI / 2);
    const seaMat = new THREE.MeshStandardMaterial({
      color: 0x0284c7,
      roughness: 0.2,
      metalness: 0.7,
      transparent: true,
      opacity: 0.85,
    });
    const seaMesh = new THREE.Mesh(seaGeo, seaMat);
    seaMesh.position.set(200, -1.2, 0);
    sceneryGroup.add(seaMesh);
  }

  // Instanced materials
  const neonBlue = new THREE.MeshBasicMaterial({ color: 0x06b6d4 });
  const neonPink = new THREE.MeshBasicMaterial({ color: 0xf43f5e });
  const pineTrunkMat = new THREE.MeshStandardMaterial({ color: 0x451a03, roughness: 0.9, flatShading: true });
  const pineNeedleMat = new THREE.MeshStandardMaterial({
    color: theme === 'snow' ? 0xe2e8f0 : 0x166534,
    roughness: 0.85,
    flatShading: true,
  });
  const rockMat = new THREE.MeshStandardMaterial({
    color: theme === 'desert' ? 0x9a3412 : theme === 'snow' ? 0x64748b : 0x78716c,
    roughness: 0.9,
    flatShading: true,
  });
  const palmTrunkMat = new THREE.MeshStandardMaterial({ color: 0x78350f, roughness: 0.9, flatShading: true });
  const palmLeafMat = new THREE.MeshStandardMaterial({ color: 0x15803d, roughness: 0.8, flatShading: true });
  const buildingMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.5, metalness: 0.8, flatShading: true });

  const step = 6;
  for (let i = 0; i < samples.length; i += step) {
    const pt = samples[i];
    const distLeft = roadWidth * 0.5 + 10 + (Math.sin(i * 1.5) + 1) * 16;
    const distRight = roadWidth * 0.5 + 10 + (Math.cos(i * 1.2) + 1) * 16;

    const leftPos = pt.pos.clone().addScaledVector(pt.normal, -distLeft);
    const rightPos = pt.pos.clone().addScaledVector(pt.normal, distRight);

    if (theme === 'cyber') {
      // Skyscrapers and glowing neon signs
      if (i % 12 === 0) {
        const height = 45 + Math.random() * 85;
        const bWidth = 20 + Math.random() * 16;
        const bGeo = new THREE.BoxGeometry(bWidth, height, bWidth);
        const building = new THREE.Mesh(bGeo, buildingMat);
        building.position.copy(leftPos);
        building.position.y = height * 0.5;
        building.castShadow = true;
        sceneryGroup.add(building);

        // Neon strip on facade
        const stripGeo = new THREE.BoxGeometry(bWidth + 0.5, 1.2, 0.4);
        const strip = new THREE.Mesh(stripGeo, i % 2 === 0 ? neonBlue : neonPink);
        strip.position.copy(building.position);
        strip.position.y += height * 0.25;
        sceneryGroup.add(strip);
      }
      if (i % 18 === 0) {
        // Overhead neon laser arch spanning track
        const arch = new THREE.Mesh(new THREE.TorusGeometry(roadWidth * 0.65, 0.4, 6, 12, Math.PI), neonBlue);
        arch.position.copy(pt.pos);
        arch.position.y += 0.5;
        arch.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), pt.tangent);
        arch.rotateZ(Math.PI);
        sceneryGroup.add(arch);
      }
    } else if (theme === 'desert') {
      // Canyon red sandstone rocks & arches
      if (i % 8 === 0) {
        const rSize = 8 + Math.random() * 14;
        const rock = new THREE.Mesh(new THREE.DodecahedronGeometry(rSize, 0), rockMat);
        rock.position.copy(leftPos);
        rock.position.y = rSize * 0.5;
        sceneryGroup.add(rock);
      }
      if (i % 10 === 0) {
        const rSize = 10 + Math.random() * 16;
        const rock = new THREE.Mesh(new THREE.DodecahedronGeometry(rSize, 0), rockMat);
        rock.position.copy(rightPos);
        rock.position.y = rSize * 0.5;
        sceneryGroup.add(rock);
      }
    } else if (theme === 'coast') {
      // Palm trees
      if (i % 10 === 0) {
        const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.35, 0.5, 7, 6), palmTrunkMat);
        trunk.position.copy(leftPos);
        trunk.position.y = 3.5;
        const leaves = new THREE.Mesh(new THREE.ConeGeometry(3.5, 2.2, 7), palmLeafMat);
        leaves.position.copy(trunk.position);
        leaves.position.y = 7.0;
        sceneryGroup.add(trunk, leaves);
      }
    } else if (theme === 'snow' || theme === 'forest') {
      // Pine trees
      if (i % 8 === 0) {
        const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.45, 3.5, 6), pineTrunkMat);
        trunk.position.copy(leftPos);
        trunk.position.y = 1.75;
        const needles = new THREE.Mesh(new THREE.ConeGeometry(3.2, 7.5, 6), pineNeedleMat);
        needles.position.copy(trunk.position);
        needles.position.y = 5.2;
        sceneryGroup.add(trunk, needles);
      }
      if (i % 12 === 0) {
        const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.45, 3.5, 6), pineTrunkMat);
        trunk.position.copy(rightPos);
        trunk.position.y = 1.75;
        const needles = new THREE.Mesh(new THREE.ConeGeometry(3.2, 7.5, 6), pineNeedleMat);
        needles.position.copy(trunk.position);
        needles.position.y = 5.2;
        sceneryGroup.add(trunk, needles);
      }
    } else if (theme === 'highway') {
      // Highway lampposts
      if (i % 8 === 0) {
        const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.25, 9, 6), buildingMat);
        pole.position.copy(leftPos);
        pole.position.y = 4.5;
        const lamp = new THREE.Mesh(new THREE.BoxGeometry(2.5, 0.3, 0.6), neonBlue);
        lamp.position.copy(pole.position);
        lamp.position.y = 8.8;
        sceneryGroup.add(pole, lamp);
      }
    }
  }
}
