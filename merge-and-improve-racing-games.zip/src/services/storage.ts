import { PlayerProgress, ControlSettings } from '../types/game';

const PROGRESS_KEY = 'polyrace_player_progress_v2';
const SETTINGS_KEY = 'polyrace_control_settings_v2';
const PLAYER_ID_KEY = 'polyrace_player_id_v2';

export function getOrCreatePlayerId(): string {
  if (typeof window === 'undefined') return 'server_player';
  let id = localStorage.getItem(PLAYER_ID_KEY);
  if (!id) {
    id = 'racer_' + Math.random().toString(36).substring(2, 10);
    localStorage.setItem(PLAYER_ID_KEY, id);
  }
  return id;
}

export const DEFAULT_PROGRESS: PlayerProgress = {
  cash: 8500,
  unlockedCars: ['apex_gt'],
  selectedCarId: 'apex_gt',
  carCustomizations: {
    apex_gt: {
      selectedColor: '#ffd21f',
      neonColor: 'none',
      upgrades: { engine: 0, brakes: 0, handling: 0, nitro: 0 },
    },
  },
  bestLapTimes: {},
  completedTracks: {},
  highScores: {
    endlessDistance: 0,
    maxDriftScore: 0,
  },
  achievementsUnlocked: [],
};

export const DEFAULT_SETTINGS: ControlSettings = {
  scheme: 'joystick', // Defaulting to the new ultra-smooth non-linear joystick!
  steeringSensitivity: 1.0,
  autoAccelerate: false,
  cameraView: 'chase',
  cameraFovBoost: true,
  audioMaster: 0.8,
  soundEnabled: true,
  musicEnabled: true,
  quality: 'high',
};

export function loadProgress(): PlayerProgress {
  if (typeof window === 'undefined') return DEFAULT_PROGRESS;
  try {
    const raw = localStorage.getItem(PROGRESS_KEY);
    if (!raw) return DEFAULT_PROGRESS;
    const parsed = JSON.parse(raw);
    return { ...DEFAULT_PROGRESS, ...parsed };
  } catch {
    return DEFAULT_PROGRESS;
  }
}

export function saveProgress(progress: PlayerProgress) {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(PROGRESS_KEY, JSON.stringify(progress));
    // Asynchronously sync with PostgreSQL backend
    const playerId = getOrCreatePlayerId();
    fetch('/api/profile', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        id: playerId,
        playerName: 'Pilote ' + playerId.slice(-4).toUpperCase(),
        cash: progress.cash,
        unlockedCars: progress.unlockedCars,
        carCustomizations: progress.carCustomizations,
        achievements: progress.achievementsUnlocked,
      }),
    }).catch(() => {
      // Offline fallback silent
    });
  } catch (e) {
    console.warn('Could not save progress:', e);
  }
}

export function loadSettings(): ControlSettings {
  if (typeof window === 'undefined') return DEFAULT_SETTINGS;
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (!raw) return DEFAULT_SETTINGS;
    return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
  } catch {
    return DEFAULT_SETTINGS;
  }
}

export function saveSettings(settings: ControlSettings) {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
  } catch (e) {
    console.warn('Could not save settings:', e);
  }
}

export function triggerHaptic(durationMs = 25) {
  if (typeof window !== 'undefined' && 'vibrate' in navigator) {
    try {
      navigator.vibrate(durationMs);
    } catch {
      // Ignored
    }
  }
}
