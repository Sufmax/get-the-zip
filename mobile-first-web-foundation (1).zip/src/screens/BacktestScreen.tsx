import { EquityCurve } from '../components/chart/CandlestickChart';
import { Button, ScreenHeader } from '../components/ui/primitives';
import { useApp } from '../context/AppContext';
import { DEMO_BACKTEST } from '../data/mockData';
import { formatNumber } from '../utils/format';

export function BacktestScreen() {
  const { back, navigate } = useApp();
  const b = DEMO_BACKTEST;

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <ScreenHeader title="Résultats du backtest" onBack={back} />

      <div className="min-h-0 flex-1 overflow-y-auto px-4 pb-3">
        <div className="grid grid-cols-2 gap-3">
          <Stat label="Nombre de cas" value={String(b.cases)} />
          <Stat label="Direction correcte" value={`${b.correctDirection}%`} />
          <Stat label="Erreur moyenne" value={`${formatNumber(b.averageError, 1)}%`} />
          <Stat label="Calibration prob." value={formatNumber(b.calibration, 2)} />
        </div>

        <h3 className="mb-2 mt-5 text-[13px] font-semibold text-slate-300">Par similarité</h3>
        <div className="rounded-2xl border border-white/5 bg-[#101c31] px-4 py-2">
          {b.bySimilarity.map((row) => (
            <div key={row.range} className="flex items-center justify-between py-2 text-[13px]">
              <span className="w-14 text-slate-400">{row.range}</span>
              <span className="font-semibold text-white">{row.accuracy}%</span>
              <span className="text-slate-500">{formatNumber(row.error, 1)}%</span>
            </div>
          ))}
        </div>

        <h3 className="mb-1 mt-5 text-[13px] font-semibold text-slate-300">Courbe de performance</h3>
        <div className="rounded-2xl border border-white/5 bg-[#101c31] p-2">
          <EquityCurve points={b.equityCurve} />
        </div>
      </div>

      <div className="px-5 pb-3">
        <Button onClick={() => navigate('export')}>Exporter</Button>
      </div>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl border border-white/5 bg-[#101c31] px-4 py-3">
      <div className="text-[12px] text-slate-400">{label}</div>
      <div className="mt-1 text-[26px] font-bold tracking-tight text-white">{value}</div>
    </div>
  );
}
