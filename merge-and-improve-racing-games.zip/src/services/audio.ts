class AudioManager {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private engineGain: GainNode | null = null;
  private sfxGain: GainNode | null = null;
  private musicGain: GainNode | null = null;

  // Engine oscillators
  private engineOsc1: OscillatorNode | null = null;
  private engineOsc2: OscillatorNode | null = null;
  private engineSubOsc: OscillatorNode | null = null;
  private engineFilter: BiquadFilterNode | null = null;
  private engineRunning = false;

  // Tire screech
  private tireNoiseNode: AudioBufferSourceNode | null = null;
  private tireFilter: BiquadFilterNode | null = null;
  private tireGain: GainNode | null = null;
  private tireBuffer: AudioBuffer | null = null;

  // Nitro whoosh
  private nitroGain: GainNode | null = null;
  private nitroNoiseNode: AudioBufferSourceNode | null = null;

  // Music sequencer
  private isMusicPlaying = false;
  private musicInterval: ReturnType<typeof setInterval> | null = null;
  private musicStep = 0;

  // Settings
  private masterVol = 0.75;
  private engineVol = 0.65;
  private sfxVol = 0.75;
  private musicVol = 0.35;
  private isMuted = false;

  public init() {
    if (this.ctx) return;
    try {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx();

      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.value = this.masterVol;
      this.masterGain.connect(this.ctx.destination);

      this.engineGain = this.ctx.createGain();
      this.engineGain.gain.value = this.engineVol;
      this.engineGain.connect(this.masterGain);

      this.sfxGain = this.ctx.createGain();
      this.sfxGain.gain.value = this.sfxVol;
      this.sfxGain.connect(this.masterGain);

      this.musicGain = this.ctx.createGain();
      this.musicGain.gain.value = this.musicVol;
      this.musicGain.connect(this.masterGain);

      this.buildTireBuffer();
    } catch (e) {
      console.warn('AudioContext failed to initialize:', e);
    }
  }

  public resume() {
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  private buildTireBuffer() {
    if (!this.ctx) return;
    const sampleRate = this.ctx.sampleRate;
    const length = sampleRate * 2;
    this.tireBuffer = this.ctx.createBuffer(1, length, sampleRate);
    const data = this.tireBuffer.getChannelData(0);
    for (let i = 0; i < length; i++) {
      data[i] = (Math.random() * 2 - 1) * 0.5;
    }
  }

  public setMuted(muted: boolean) {
    this.isMuted = muted;
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setValueAtTime(muted ? 0 : this.masterVol, this.ctx.currentTime);
    }
  }

  public setMasterVolume(vol: number) {
    this.masterVol = THREE_clamp(vol, 0, 1);
    if (this.masterGain && this.ctx && !this.isMuted) {
      this.masterGain.gain.setValueAtTime(this.masterVol, this.ctx.currentTime);
    }
  }

  public startEngine(soundType = 'turbo') {
    if (!this.ctx || this.engineRunning) return;
    this.resume();

    try {
      this.engineFilter = this.ctx.createBiquadFilter();
      this.engineFilter.type = 'lowpass';
      this.engineFilter.frequency.value = soundType === 'v8' ? 950 : 1600;
      this.engineFilter.connect(this.engineGain!);

      // Primary tone
      this.engineOsc1 = this.ctx.createOscillator();
      this.engineOsc1.type = soundType === 'v8' ? 'sawtooth' : 'triangle';
      this.engineOsc1.frequency.value = 55;
      this.engineOsc1.connect(this.engineFilter);

      // Secondary tone
      this.engineOsc2 = this.ctx.createOscillator();
      this.engineOsc2.type = 'sawtooth';
      this.engineOsc2.frequency.value = 110;
      const osc2Gain = this.ctx.createGain();
      osc2Gain.gain.value = soundType === 'v8' ? 0.35 : 0.2;
      this.engineOsc2.connect(osc2Gain);
      osc2Gain.connect(this.engineFilter);

      // Sub harmonic rumble
      this.engineSubOsc = this.ctx.createOscillator();
      this.engineSubOsc.type = 'sine';
      this.engineSubOsc.frequency.value = 35;
      const subGain = this.ctx.createGain();
      subGain.gain.value = 0.45;
      this.engineSubOsc.connect(subGain);
      subGain.connect(this.engineFilter);

      this.engineOsc1.start();
      this.engineOsc2.start();
      this.engineSubOsc.start();
      this.engineRunning = true;

      // Tire screech setup
      if (this.tireBuffer) {
        this.tireNoiseNode = this.ctx.createBufferSource();
        this.tireNoiseNode.buffer = this.tireBuffer;
        this.tireNoiseNode.loop = true;

        this.tireFilter = this.ctx.createBiquadFilter();
        this.tireFilter.type = 'bandpass';
        this.tireFilter.frequency.value = 1400;
        this.tireFilter.Q.value = 3.5;

        this.tireGain = this.ctx.createGain();
        this.tireGain.gain.value = 0;

        this.tireNoiseNode.connect(this.tireFilter);
        this.tireFilter.connect(this.tireGain);
        this.tireGain.connect(this.sfxGain!);
        this.tireNoiseNode.start();
      }

      // Nitro hiss setup
      if (this.tireBuffer) {
        this.nitroNoiseNode = this.ctx.createBufferSource();
        this.nitroNoiseNode.buffer = this.tireBuffer;
        this.nitroNoiseNode.loop = true;

        const nitroFilter = this.ctx.createBiquadFilter();
        nitroFilter.type = 'highpass';
        nitroFilter.frequency.value = 2200;

        this.nitroGain = this.ctx.createGain();
        this.nitroGain.gain.value = 0;

        this.nitroNoiseNode.connect(nitroFilter);
        nitroFilter.connect(this.nitroGain);
        this.nitroGain.connect(this.sfxGain!);
        this.nitroNoiseNode.start();
      }
    } catch (e) {
      console.warn('Failed to start engine audio:', e);
    }
  }

  public updateEnginePitch(rpm: number, gear: number, speedRatio: number, soundType = 'turbo') {
    if (!this.ctx || !this.engineRunning || !this.engineOsc1 || !this.engineOsc2 || !this.engineSubOsc) return;

    const baseFreq = soundType === 'v8' ? 45 : soundType === 'supercar' ? 85 : 60;
    const targetFreq1 = baseFreq + rpm * 110 + gear * 6;
    const targetFreq2 = targetFreq1 * (soundType === 'v8' ? 1.5 : 2.0);
    const targetSub = targetFreq1 * 0.5;

    const time = this.ctx.currentTime;
    this.engineOsc1.frequency.setTargetAtTime(targetFreq1, time, 0.05);
    this.engineOsc2.frequency.setTargetAtTime(targetFreq2, time, 0.05);
    this.engineSubOsc.frequency.setTargetAtTime(targetSub, time, 0.05);

    if (this.engineFilter) {
      const targetFilter = (soundType === 'v8' ? 750 : 1200) + speedRatio * 1800;
      this.engineFilter.frequency.setTargetAtTime(targetFilter, time, 0.08);
    }
  }

  public setTireScreech(intensity: number) {
    if (!this.ctx || !this.tireGain) return;
    const targetVol = THREE_clamp(intensity, 0, 1) * 0.35;
    this.tireGain.gain.setTargetAtTime(targetVol, this.ctx.currentTime, 0.04);
  }

  public setNitroWhoosh(active: boolean) {
    if (!this.ctx || !this.nitroGain) return;
    this.nitroGain.gain.setTargetAtTime(active ? 0.32 : 0, this.ctx.currentTime, 0.08);
  }

  public playTurboBlowOff() {
    if (!this.ctx || !this.sfxGain) return;
    try {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(1400, this.ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(300, this.ctx.currentTime + 0.15);

      gain.gain.setValueAtTime(0.18, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.15);

      osc.connect(gain);
      gain.connect(this.sfxGain);
      osc.start();
      osc.stop(this.ctx.currentTime + 0.16);
    } catch {
      // Audio node cleanup
    }
  }

  public playCrash(severity = 1) {
    if (!this.ctx || !this.sfxGain) return;
    try {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(120, this.ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(30, this.ctx.currentTime + 0.22);

      const vol = THREE_clamp(severity, 0.2, 1) * 0.45;
      gain.gain.setValueAtTime(vol, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.22);

      osc.connect(gain);
      gain.connect(this.sfxGain);
      osc.start();
      osc.stop(this.ctx.currentTime + 0.24);
    } catch {
      // Audio cleanup
    }
  }

  public playCountdownBeep(isGo: boolean) {
    if (!this.ctx || !this.sfxGain) return;
    try {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(isGo ? 880 : 440, this.ctx.currentTime);

      gain.gain.setValueAtTime(0.35, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + (isGo ? 0.35 : 0.15));

      osc.connect(gain);
      gain.connect(this.sfxGain);
      osc.start();
      osc.stop(this.ctx.currentTime + (isGo ? 0.38 : 0.18));
    } catch {
      // Audio cleanup
    }
  }

  public playCheckpoint() {
    if (!this.ctx || !this.sfxGain) return;
    try {
      const osc1 = this.ctx.createOscillator();
      const osc2 = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc1.frequency.setValueAtTime(523.25, this.ctx.currentTime); // C5
      osc2.frequency.setValueAtTime(659.25, this.ctx.currentTime); // E5

      gain.gain.setValueAtTime(0.2, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.25);

      osc1.connect(gain);
      osc2.connect(gain);
      gain.connect(this.sfxGain);

      osc1.start();
      osc2.start();
      osc1.stop(this.ctx.currentTime + 0.26);
      osc2.stop(this.ctx.currentTime + 0.26);
    } catch {
      // Audio cleanup
    }
  }

  public startMusic() {
    if (!this.ctx || this.isMusicPlaying) return;
    this.isMusicPlaying = true;
    this.musicStep = 0;

    const bassNotes = [55, 55, 65.41, 65.41, 73.42, 73.42, 49, 49]; // A1, C2, D2, G1

    this.musicInterval = setInterval(() => {
      if (!this.ctx || !this.musicGain || !this.isMusicPlaying) return;
      try {
        const note = bassNotes[this.musicStep % bassNotes.length];
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();

        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(note, this.ctx.currentTime);

        const filter = this.ctx.createBiquadFilter();
        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(450, this.ctx.currentTime);

        gain.gain.setValueAtTime(0.18, this.ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.14);

        osc.connect(filter);
        filter.connect(gain);
        gain.connect(this.musicGain);

        osc.start();
        osc.stop(this.ctx.currentTime + 0.15);

        this.musicStep++;
      } catch {
        // Ignored
      }
    }, 140);
  }

  public stopMusic() {
    this.isMusicPlaying = false;
    if (this.musicInterval) {
      clearInterval(this.musicInterval);
      this.musicInterval = null;
    }
  }

  public stopAll() {
    this.stopMusic();
    try {
      if (this.engineOsc1) { this.engineOsc1.stop(); this.engineOsc1.disconnect(); this.engineOsc1 = null; }
      if (this.engineOsc2) { this.engineOsc2.stop(); this.engineOsc2.disconnect(); this.engineOsc2 = null; }
      if (this.engineSubOsc) { this.engineSubOsc.stop(); this.engineSubOsc.disconnect(); this.engineSubOsc = null; }
      if (this.tireNoiseNode) { this.tireNoiseNode.stop(); this.tireNoiseNode.disconnect(); this.tireNoiseNode = null; }
      if (this.nitroNoiseNode) { this.nitroNoiseNode.stop(); this.nitroNoiseNode.disconnect(); this.nitroNoiseNode = null; }
      this.engineRunning = false;
    } catch {
      // Ignored
    }
  }
}

function THREE_clamp(val: number, min: number, max: number) {
  return Math.max(min, Math.min(max, val));
}

export const audio = new AudioManager();
